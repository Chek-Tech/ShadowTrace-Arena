#!/usr/bin/env python3
"""
Sentinel Ops Module Matrix — 25 fine-grained analysis modules (original).

Each module is a playbook: focus areas, local tools, external fallbacks,
checklist, defense notes. Content is rewritten for Code Sentinel — not a
port of any external KB chapter text.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional


@dataclass
class ModulePlaybook:
    id: str
    title: str
    family: str  # binary | mobile | web | net | crypto | cloud | special | triage
    signals: list[str]
    focus: list[str]
    local_tools: list[str]
    external_tools: list[str]
    checklist: list[str]
    defense: list[str]
    next_modules: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# ---------------------------------------------------------------------------
# 25 modules (Sentinel IDs M01–M25)
# ---------------------------------------------------------------------------
MODULES: dict[str, ModulePlaybook] = {}


def _m(**kwargs) -> ModulePlaybook:
    pb = ModulePlaybook(**kwargs)
    MODULES[pb.id] = pb
    return pb


_m(
    id="M01", title="Linux/ELF 静态", family="binary", signals=["S2", "S7"],
    focus=["ELF header/segments", "动态符号与 GOT/PLT", "strip 后字符串/常量", "ptrace/anti-debug",
           "公网 URL/域名提取"],
    local_tools=["reverse_engineering", "re_surface", "malware_analysis", "ctf_toolkit"],
    external_tools=["readelf", "objdump", "gdb", "r2", "ghidra"],
    checklist=["确认 class/endian/machine", "查 PT_NOTE/INTERP", "高熵段与 UPX 特征",
               "危险 API 与 capability_map", "re_surface 网络面"],
    defense=["全 RELRO+PIE+NX+Canary", "禁 ptrace 调试接口暴露", "符号与构建信息最小化"],
    next_modules=["M14", "M18", "M13"],
)
_m(
    id="M02", title="Windows/PE 静态", family="binary", signals=["S2", "S3", "S7"],
    focus=["PE 可选头/节表", "IAT/imphash/导出", "TLS 回调与 overlay", "反调试/注入 API",
           "公网 URL/域名/PDB", "版本资源与 Rich 头"],
    local_tools=["reverse_engineering", "re_surface", "malware_analysis"],
    external_tools=["die", "pebear", "x64dbg", "ghidra", "ida"],
    checklist=["imphash 与导入稀疏度", "RWX 节", "overlay 大小/熵", "VirtualAllocEx 链",
               "re_surface 提取公网端点", "CompanyName/ProductVersion 同源聚类"],
    defense=["Authenticode", "CFG/CET", "禁止随意加载未签名模块", "剥离 PDB 与内网路径"],
    next_modules=["M19", "M03", "M13", "M20"],
)
_m(
    id="M03", title="Apple/Mach-O", family="binary", signals=["S2"],
    focus=["Fat/Universal", "LC_LOAD_DYLIB", "ObjC/Swift 痕迹", "代码签名槽"],
    local_tools=["reverse_engineering"],
    external_tools=["otool", "nm", "lldb", "hopper", "class-dump"],
    checklist=["魔数与 CPU 类型", "加密段痕迹", "dylib 劫持面"],
    defense=["Hardened Runtime", "Library Validation", "公证/Notarization"],
    next_modules=["M05"],
)
_m(
    id="M04", title="Android/DEX·APK", family="mobile", signals=["S2", "S8"],
    focus=["APK 结构", "DEX magic/方法数", "加固/壳特征", "SSL Pinning 字符串"],
    local_tools=["reverse_engineering", "malware_analysis"],
    external_tools=["jadx", "apktool", "frida", "objection", "dex2jar"],
    checklist=["classes.dex 熵", "lib/* ABI", "权限与导出组件", "壳 so 名"],
    defense=["R8/混淆", "完整性校验", "证书固定+备份通道管控"],
    next_modules=["M19", "M14"],
)
_m(
    id="M05", title="iOS/IPA", family="mobile", signals=["S2", "S8"],
    focus=["IPA 砸壳痕迹", "ObjC selector", "Keychain/TCC 字符串", "越狱检测"],
    local_tools=["reverse_engineering"],
    external_tools=["frida", "class-dump", "theos", "hopper"],
    checklist=["是否加密 Mach-O", "越狱文件路径字符串", "URL scheme"],
    defense=["App Attest", "越狱检测多层", "敏感逻辑服务端化"],
    next_modules=["M03"],
)
_m(
    id="M06", title="WebAssembly", family="binary", signals=["S2", "S4"],
    focus=["WASM magic 00 61 73 6d", "导出函数名", "与 JS glue 交互", "内存线性区"],
    local_tools=["reverse_engineering", "ctf_toolkit"],
    external_tools=["wasm2wat", "wasm-decompile", "wabt"],
    checklist=["版本与 section", "可疑导入 env", "常量池加密特征"],
    defense=["CSP 限制 wasm", "完整性校验加载", "敏感逻辑勿纯前端"],
    next_modules=["M12", "M15"],
)
_m(
    id="M07", title="固件/嵌入式", family="special", signals=["S2", "S8"],
    focus=["固件镜像切分", "文件系统识别", "嵌入式 Web/默认口令", "启动链"],
    local_tools=["reverse_engineering", "ctf_toolkit"],
    external_tools=["binwalk", "unsquashfs", "strings", "qemu-user"],
    checklist=["魔数/头", "squashfs/jffs2", "busybox/httpd", "硬编码凭据"],
    defense=["安全启动", "签名升级包", "禁用调试接口"],
    next_modules=["M08", "M01"],
)
_m(
    id="M08", title="网络设备固件", family="special", signals=["S5", "S8"],
    focus=["私有协议", "管理面默认口令", "VPN/WAF 组件", "固件差分"],
    local_tools=["pentest_recon", "reverse_engineering"],
    external_tools=["binwalk", "nmap", "wireshark"],
    checklist=["开放管理端口", "已知 CVE banner", "未加密更新通道"],
    defense=["管理面隔离", "强制 MFA", "供应链签名"],
    next_modules=["M07", "M10"],
)
_m(
    id="M09", title="磁盘/内存取证", family="special", signals=["S3", "S8"],
    focus=["镜像哈希", "进程/网络工件", "时间线", "删除恢复线索"],
    local_tools=["malware_analysis", "reverse_engineering"],
    external_tools=["volatility3", "foremost", "bulk_extractor"],
    checklist=["镜像完整性", "异常进程链", "持久化位置", "外联 IP"],
    defense=["EDR 遥测", "只读取证流程", "证据链记录"],
    next_modules=["M10", "M03"],
)
_m(
    id="M10", title="终端工件取证", family="special", signals=["S3", "S8"],
    focus=["浏览器/邮件/聊天痕迹", "LNK/JumpList", "Office 元数据"],
    local_tools=["malware_analysis"],
    external_tools=["exiftool", "oletools", "strings"],
    checklist=["最近文件", "下载区", "宏痕迹", "USB 历史"],
    defense=["DLP", "宏默认禁用", "浏览器企业策略"],
    next_modules=["M09"],
)
_m(
    id="M11", title="图像隐写", family="special", signals=["S4", "S8"],
    focus=["LSB/块结构", "PNG chunk", "异常尺寸/熵"],
    local_tools=["ctf_toolkit", "reverse_engineering"],
    external_tools=["zsteg", "steghide", "exiftool"],
    checklist=["文件尾附加数据", "通道异常", "调色板异常"],
    defense=["上传重编码", "剥元数据", "类型白名单"],
    next_modules=["M12"],
)
_m(
    id="M12", title="音频/容器隐写", family="special", signals=["S4", "S8"],
    focus=["频谱异常", "文件尾", "容器附加流"],
    local_tools=["ctf_toolkit"],
    external_tools=["binwalk", "strings", "ffmpeg"],
    checklist=["双扩展名", "超大尾数据", "已知隐写工具指纹"],
    defense=["转码入库", "限制附件类型"],
    next_modules=["M11"],
)
_m(
    id="M13", title="流量/PCAP", family="net", signals=["S5", "S3"],
    focus=["会话还原", "TLS 元数据", "C2 周期", "隧道特征"],
    local_tools=["pentest_recon", "malware_analysis"],
    external_tools=["tshark", "wireshark", "zeek"],
    checklist=["DNS 异常", "长连接心跳", "明文凭据", "JA3 类指纹"],
    defense=["TLS 拦截策略", "DNS 日志", "出口代理"],
    next_modules=["M20", "M03"],
)
_m(
    id="M14", title="云原生/K8s", family="cloud", signals=["S1", "S7", "S8"],
    focus=["镜像与 RBAC", "特权容器", "元数据 SSRF", "供应链"],
    local_tools=["sentinel_scan", "web_pentest"],
    external_tools=["trivy", "kubectl", "checkov"],
    checklist=["privileged", "hostPath", "默认 SA", "未固定 digest"],
    defense=["PSS/PSA", "网络策略", "镜像签名"],
    next_modules=["M01", "M16"],
)
_m(
    id="M15", title="Web/JS 代码", family="web", signals=["S1", "S6"],
    focus=["框架识别", "敏感 API", "混淆包", "密钥泄漏"],
    local_tools=["sentinel_scan", "web_pentest", "redact"],
    external_tools=["semgrep", "nodejs", "prettier"],
    checklist=["source map", "hardcoded token", "危险 sink", "CORS"],
    defense=["构建剥离 map", "密钥托管", "CSP"],
    next_modules=["M16", "M06"],
)
_m(
    id="M16", title="Web 应用面", family="web", signals=["S6", "S7"],
    focus=["头/Cookie/CORS", "注入/LFI/重定向", "路径与弱口令"],
    local_tools=["web_pentest", "pentest_recon", "attack_spider"],
    external_tools=["nuclei", "ffuf", "sqlmap", "nikto"],
    checklist=["安全头", "敏感路径", "SQLi/XSS 信号", "默认凭据"],
    defense=["WAF+修复根因", "参数化查询", "登录锁定/MFA"],
    next_modules=["M15", "M17"],
)
_m(
    id="M17", title="内网与身份", family="net", signals=["S5", "S7", "S8"],
    focus=["主机发现", "SMB/WinRM/LDAP 面", "横向路径概念", "凭据暴露"],
    local_tools=["pentest_recon", "attack_network"],
    external_tools=["nmap", "impacket-smbclient", "nxc", "bloodhound-python"],
    checklist=["高危端口", "匿名枚举", "老旧服务 banner", "广播协议风险"],
    defense=["分段", "LAPS", "禁 LLMNR/NBT-NS", "特权分层"],
    next_modules=["M16", "M18"],
)
_m(
    id="M18", title="权限与持久化面", family="special", signals=["S7", "S3"],
    focus=["本地提权面", "服务/计划任务", "注册表/启动项", "容器逃逸概念"],
    local_tools=["malware_analysis", "reverse_engineering", "sentinel_scan"],
    external_tools=["winpeas", "linpeas", "pspy"],
    checklist=["可写服务路径", "弱权限计划任务", "SUID/capabilities", "内核版本过旧"],
    defense=["补丁基线", "最小权限", "应用白名单"],
    next_modules=["M14", "M19"],
)
_m(
    id="M19", title="进程注入/内存操作", family="binary", signals=["S3", "S7", "S8"],
    focus=["远程线程/APC", "hollowing 痕迹", "读写跨进程 API", "shellcode 缓冲"],
    local_tools=["malware_analysis", "reverse_engineering", "attack_game"],
    external_tools=["frida", "x64dbg", "processhacker"],
    checklist=["CreateRemoteThread 链", "RWX 分配", "无模块 shellcode", "父子异常"],
    defense=["ASR/攻击面减少", "ETW 行为规则", "禁止未签名内存执行"],
    next_modules=["M02", "M03"],
)
_m(
    id="M20", title="C2/远控画像", family="special", signals=["S3", "S5"],
    focus=["心跳/beacon", "协议混淆", "持久化+外联组合"],
    local_tools=["malware_analysis", "pentest_recon", "reverse_engineering"],
    external_tools=["yara", "wireshark", "floss"],
    checklist=["周期性外联", "硬编码 C2", "互斥体/管道", "伪装正常 UA"],
    defense=["出站白名单", "DNS 监控", "YARA 内存扫描"],
    next_modules=["M13", "M03"],
)
_m(
    id="M21", title="密码学/校验还原", family="crypto", signals=["S4", "S2"],
    focus=["算法常量", "自定义编码", "序列号/授权校验点", "padding/模式误用"],
    local_tools=["ctf_toolkit", "reverse_engineering", "attack_keygen"],
    external_tools=["openssl", "hashcat", "z3"],
    checklist=["S-box/TEA delta", "硬编码密钥", "ECB/弱随机", "strcmp 校验"],
    defense=["现代 AEAD", "密钥托管/HSM", "服务端授权"],
    next_modules=["M22", "M02"],
)
_m(
    id="M22", title="CTF/Pwn 利用构造", family="special", signals=["S7", "S4"],
    focus=["漏洞类型识别", "保护位", "泄漏→ROP 骨架", "flag 搜索"],
    local_tools=["ctf_toolkit", "reverse_engineering"],
    external_tools=["pwntools", "ropgadget", "gdb", "one_gadget"],
    checklist=["canary/nx/pie", "格式化/溢出点", "可写段", "libc 泄漏线索"],
    defense=["全保护编译", "FORTIFY", "沙箱化服务"],
    next_modules=["M01", "M21"],
)
_m(
    id="M23", title="供应链/依赖", family="cloud", signals=["S1", "S8"],
    focus=["未锁定版本", "typosquat", "安装脚本", "CI 密钥"],
    local_tools=["sentinel_scan", "sentinel_pack"],
    external_tools=["trivy", "npm", "osv-scanner"],
    checklist=["lockfile", "postinstall 脚本", "curl|sh", "公开 registry 混淆"],
    defense=["私服+签名", "CI OIDC", "依赖审核门禁"],
    next_modules=["M14", "M15"],
)
_m(
    id="M24", title="游戏客户端/协议", family="special", signals=["S8", "S2"],
    focus=["引擎特征", "内存数值", "协议字段", "反作弊字符串"],
    local_tools=["attack_game", "reverse_engineering", "attack_network"],
    external_tools=["frida", "il2cppdumper", "wireshark"],
    checklist=["Unity/Unreal 痕迹", "明文协议", "客户端权威逻辑"],
    defense=["服务端权威", "完整性校验", "反作弊分层"],
    next_modules=["M19", "M13"],
)
_m(
    id="M25", title="快速分诊入口", family="triage", signals=["S1", "S2", "S3", "S5", "S6"],
    focus=["类型识别", "哈希", "熵/壳", "路由到细模块"],
    local_tools=["ops_triage", "ops_router", "reverse_engineering"],
    external_tools=["file", "strings", "die"],
    checklist=["magic", "sha256", "packed?", "主信号"],
    defense=["先隔离样本", "只读分析", "记录证据哈希"],
    next_modules=["M01", "M02", "M04", "M16"],
)


# extension / magic → modules
EXT_TO_MODULES: dict[str, list[str]] = {
    ".exe": ["M02", "M03", "M19"], ".dll": ["M02", "M19"], ".sys": ["M02", "M18"],
    ".so": ["M01", "M19"], ".elf": ["M01"], ".bin": ["M07", "M01", "M02"],
    ".apk": ["M04"], ".dex": ["M04"], ".ipa": ["M05"], ".dylib": ["M03"],
    ".wasm": ["M06"], ".pcap": ["M13"], ".pcapng": ["M13"],
    ".png": ["M11"], ".jpg": ["M11"], ".jpeg": ["M11"], ".gif": ["M11"],
    ".wav": ["M12"], ".mp3": ["M12"],
    ".py": ["M15", "M23"], ".js": ["M15", "M16"], ".ts": ["M15"],
    ".tf": ["M14", "M23"], ".yaml": ["M14", "M01"], ".yml": ["M14"],
}

KEYWORD_TO_MODULES: list[tuple[str, list[str], float]] = [
    (r"k8s|kubernetes|docker|容器|镜像", ["M14", "M23"], 2.0),
    (r"域控|kerberos|ldap|bloodhound|横向", ["M17", "M18"], 2.0),
    (r"c2|beacon|远控|cobalt", ["M20", "M13"], 2.0),
    (r"pwn|rop|溢出|uaf|格式化字符串", ["M22", "M01"], 2.0),
    (r"keygen|注册机|license|序列号|aes|rsa|tea", ["M21", "M22"], 2.0),
    (r"游戏|unity|il2cpp|外挂|aimbot", ["M24", "M19"], 2.0),
    (r"固件|iot|binwalk|路由器", ["M07", "M08"], 2.0),
    (r"取证|volatility|内存镜像|磁盘", ["M09", "M10"], 2.0),
    (r"隐写|stego|lsb", ["M11", "M12"], 2.0),
    (r"web|xss|sqli|cors|http", ["M16", "M15"], 1.8),
    (r"android|apk|jadx", ["M04"], 2.0),
    (r"ios|ipa|越狱", ["M05"], 2.0),
    (r"pe\b|windows|\.exe", ["M02"], 1.5),
    (r"elf|linux", ["M01"], 1.5),
    (r"供应链|npm|pip|依赖", ["M23", "M15"], 1.8),
]


def select_modules(
    query: str = "",
    target: str = "",
    signals: Optional[list[str]] = None,
    limit: int = 5,
) -> list[dict[str, Any]]:
    """Score and return top modules for a task."""
    scores: dict[str, float] = {mid: 0.0 for mid in MODULES}
    blob = f"{query} {target}".lower()
    signals = signals or []

    for mid, pb in MODULES.items():
        for s in signals:
            if s in pb.signals:
                scores[mid] += 1.2

    ext = Path(target).suffix.lower() if target else ""
    for mid in EXT_TO_MODULES.get(ext, []):
        scores[mid] = scores.get(mid, 0) + 2.0

    for pat, mids, w in KEYWORD_TO_MODULES:
        if re.search(pat, blob, re.I):
            for mid in mids:
                scores[mid] = scores.get(mid, 0) + w

    # magic-ish hints in path
    if re.search(r"\b\d{1,3}(?:\.\d{1,3}){3}\b|https?://", blob):
        scores["M16"] += 1.5
        scores["M17"] += 1.0
        scores["M13"] += 0.8

    if not any(scores.values()):
        scores["M25"] = 1.0

    ranked = sorted(scores.items(), key=lambda x: (-x[1], x[0]))
    out = []
    for mid, sc in ranked:
        if sc <= 0:
            continue
        pb = MODULES[mid]
        item = pb.to_dict()
        item["score"] = round(sc, 2)
        out.append(item)
        if len(out) >= limit:
            break
    return out


def get_module(mid: str) -> Optional[dict[str, Any]]:
    pb = MODULES.get(mid.upper())
    return pb.to_dict() if pb else None


def list_modules() -> list[dict[str, Any]]:
    return [MODULES[k].to_dict() for k in sorted(MODULES)]


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Sentinel module matrix")
    parser.add_argument("query", nargs="*", help="task text")
    parser.add_argument("--target", default="")
    parser.add_argument("--list", action="store_true")
    parser.add_argument("--module", default="")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--limit", type=int, default=5)
    args = parser.parse_args(argv)

    if args.list:
        data = list_modules()
        print(json.dumps(data if args.json else [f"{m['id']} {m['title']}" for m in data],
                         ensure_ascii=False, indent=2 if args.json else None))
        return 0
    if args.module:
        m = get_module(args.module)
        if not m:
            print("module not found", file=sys.stderr)
            return 1
        print(json.dumps(m, ensure_ascii=False, indent=2))
        return 0

    query = " ".join(args.query)
    data = select_modules(query=query, target=args.target, limit=args.limit)
    if args.json:
        print(json.dumps(data, ensure_ascii=False, indent=2))
    else:
        for m in data:
            print(f"{m['id']}  {m['title']:<16} score={m['score']}  tools={','.join(m['local_tools'][:3])}")
            print(f"     focus: {'; '.join(m['focus'][:3])}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
