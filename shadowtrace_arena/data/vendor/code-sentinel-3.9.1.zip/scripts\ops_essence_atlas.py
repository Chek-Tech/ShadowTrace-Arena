#!/usr/bin/env python3
"""
Sentinel Domain Atlas — full-coverage map of security capability domains
to Code Sentinel original modules (surfaces / packs / scripts).

All titles and IDs are Sentinel-native. No third-party product brand IDs.
coverage_report() must remain complete for the built-in inventory.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Optional

_SCRIPTS = Path(__file__).resolve().parent
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))

ATLAS: dict[str, dict[str, Any]] = {}


def _a(sid: str, title: str, kind: str, maps_to: list[str], status: str = "fused", notes: str = "") -> None:
    ATLAS[sid] = {
        "id": sid,
        "title": title,
        "kind": kind,
        "maps_to": maps_to,
        "status": status,
        "notes": notes,
    }


# --- platform / product domains ---
_a("domain.game-client", "客户端完整性 / 游戏安全研究", "skill",
   ["attack_game", "pack:game7", "surface:game-client", "ops_framing"])
_a("domain.codex-inject", "Codex 注入与实验室指令机制", "inject",
   ["ops_instruct", "codex_inject", "ops_obedience"])
_a("domain.ctf-lab-contract", "CTF/实验室会话契约", "prompt",
   ["ops_ctf_runner", "ops_sandbox", "ops_instruct"])
_a("domain.anti-refusal", "任务专业包装与防空拒", "prompt",
   ["ops_framing", "ops_sandbox", "ops_obedience", "ops_instruct"],
   notes="原创 framing/L1–L5；禁止第三方越狱语料")

# --- skill domains ---
_a("skill.api-security", "API 安全", "skill", ["pack:api10", "surface:web-runtime", "surface:graphql-rpc", "surface:jwt-claim", "web_pentest"])
_a("skill.apk-reverse", "APK 逆向", "skill", ["pack:mobile5", "surface:android-hook", "reverse_engineering", "re_surface"])
_a("skill.attack-chain", "攻击链编排", "skill", ["ops_chain", "pack:ad8", "surface:attack-chain"])
_a("skill.binary-diff", "二进制差分 / 符号迁移", "skill", ["pack:patch5", "surface:patch-diff", "reverse_engineering"])
_a("skill.browser-automation", "浏览器自动化", "skill", ["pack:browse5", "surface:browser-auto", "web_pentest"])
_a("skill.diagram-generator", "攻击图 / 架构图", "skill", ["pack:diagram3", "ops_report_contract"])
_a("skill.docs-generator", "安全报告文档", "skill", ["pack:docs3", "ops_report_contract", "ops_anon"])
_a("skill.edr-surface", "EDR/检测面评估", "skill", ["pack:edr6", "malware_analysis", "ops_payloads"])
_a("skill.field-journal", "战地日志", "skill", ["ops_journal", "ops_anon", "ops_obedience"])
_a("skill.firmware-pentest", "固件渗透链", "skill", ["pack:fw9", "surface:firmware", "reverse_engineering"])
_a("skill.static-decompile", "深度静态反编译", "skill", ["pack:ida4", "surface:static-ida", "reverse_engineering"])
_a("skill.js-reverse", "前端 JS 签名逆向", "skill", ["pack:js5", "surface:js-sign", "surface:bundle-sourcemap"])
_a("skill.llm-security", "LLM/Agent 安全", "skill", ["pack:llm7", "surface:prompt-injection", "ops_framing", "ops_obedience"])
_a("skill.malware-analysis", "恶意样本分析", "skill", ["pack:mal6", "surface:malware-config", "malware_analysis"])
_a("skill.mobile-reverse", "移动逆向", "skill", ["pack:mobile5", "surface:android-hook", "surface:ios-runtime"])
_a("skill.patch-diff-exploit", "补丁差分到利用面", "skill", ["pack:patch5", "surface:patch-diff", "pack:pwn6"])
_a("skill.pentest-tools", "渗透工具链编排", "skill", ["pack:loop6", "pentest_recon", "web_pentest", "ops_tool_index"])
_a("skill.src-bounty", "SRC/众测纪律", "skill", ["pack:src5", "pack:gap4", "pack:evidence3", "surface:src-bounty"])
_a("skill.pwn-chain", "漏洞利用链", "skill", ["pack:pwn6", "surface:reverse-pwn", "ctf_toolkit"])
_a("skill.cli-reverse", "CLI 二进制侦察", "skill", ["pack:r24", "surface:cli-r2", "reverse_engineering"])
_a("skill.reverse-engineering", "通用逆向", "skill", ["pack:re6", "ops_pattern_db", "reverse_engineering"])
_a("skill.supply-chain", "供应链安全", "skill", ["pack:supply6", "surface:supply-chain", "sentinel_scan"])
_a("skill.routing", "任务路由矩阵", "skill", ["ops_router", "ops_surface_matrix", "ops_method_packs"])
_a("skill.bootstrap", "工具索引与注入", "skill", ["ops_tool_index", "codex_inject"])
_a(
    "skill.gpt56-reverse-pentest",
    "Desktop 全栈逆向+渗透融合包",
    "skill",
    [
        "pack:re6",
        "pack:pwn6",
        "pack:js5",
        "pack:mobile5",
        "pack:fw9",
        "pack:mal6",
        "pack:edr6",
        "pack:llm7",
        "pack:supply6",
        "pack:patch5",
        "reverse_engineering",
        "malware_analysis",
        "ctf_toolkit",
        "web_pentest",
        "ops_ctf_runner",
        "ops_pipeline",
    ],
)
_a(
    "domain.ptes-lab",
    "PTES 生命周期实验室编排（原创）",
    "skill",
    [
        "ops_ptes_lab",
        "ops_phase_kb",
        "ops_chain",
        "ops_report_contract",
        "pentest_recon",
        "web_pentest",
        "ops_surface_matrix",
    ],
    notes="manifest 交接 + 目标目录契约 + 转段门禁；无第三方语料",
)
_a(
    "method.phase-kb-drive",
    "上阶段输出驱动知识路由",
    "reference",
    ["ops_phase_kb", "ops_ptes_lab", "ops_method_packs"],
)
_a(
    "domain.engagement-suite",
    "全量交战精髓栈（原创）",
    "skill",
    [
        "ops_engagement",
        "ops_ptes_lab",
        "ops_phase_kb",
        "ops_chain",
        "ops_report_contract",
        "pentest_recon",
        "web_pentest",
        "ops_tool_index",
    ],
    notes="目录契约/枚举剧本/Web预检/solutions合并/报告门禁/范围访谈",
)
_a(
    "method.service-enum-matrix",
    "端口服务枚举剧本矩阵",
    "reference",
    ["ops_engagement", "pentest_recon", "web_pentest"],
)
_a(
    "method.web-pretest-blueprint",
    "Web 预检蓝图（无第三方浏览器脚本）",
    "reference",
    ["ops_engagement", "web_pentest", "ops_ptes_lab"],
)
_a(
    "method.solutions-ledger",
    "交战经验全局台账",
    "reference",
    ["ops_engagement", "ops_ptes_lab", "ops_journal"],
)
_a(
    "method.phase-runner",
    "阶段真执行落盘与全自动交战",
    "reference",
    ["ops_phase_runner", "ops_ptes_lab", "ops_engagement", "pentest_recon", "web_pentest"],
)

# reverse chapters
for chap, maps in [
    ("anti-analysis", ["ops_method_packs", "malware_analysis", "ops_knowledge"]),
    ("go-reverse", ["ops_pattern_db", "pack:re6"]),
    ("kernel-driver", ["pack:kernel_drv4", "surface:kernel-driver"]),
    ("languages", ["ops_pattern_db", "pack:re6"]),
    ("languages-compiled", ["ops_pattern_db", "pack:re6"]),
    ("patterns-ctf", ["pack:pwn6", "pack:js5", "ctf_toolkit", "ops_ctf_runner"]),
    ("platforms", ["pack:re6", "surface:firmware"]),
    ("platforms-hardware", ["pack:fw9", "surface:firmware"]),
    ("elf-analysis", ["reverse_engineering", "pack:re6"]),
    ("tools-dynamic", ["malware_analysis", "pack:ida4"]),
    ("crypto-decode", ["ops_algo", "ctf_toolkit", "surface:crypto-chain"]),
]:
    _a(f"re.chapter.{chap}", f"逆向专题/{chap}", "reference", maps)

# methodology
_a("method.attack-priority", "攻击优先级", "reference", ["ops_ctf_runner", "pack:src5", "ops_surface_matrix"])
_a("method.bypass-toolkit", "变形/绕过工具箱纪律", "reference", ["web_pentest", "pack:src5"])
_a("method.evidence", "黑盒证据纪律", "reference", ["pack:evidence3", "ops_report_contract"])
_a("method.control-gap", "控制缺口狩猎", "reference", ["pack:gap4"])
_a("method.timebox", "时间盒优先级", "reference", ["pack:src5", "ops_journal"])

# competition-style surfaces (domain names = technical topics, Sentinel-owned maps)
_COMP = {
    "ad-certificate": ["surface:adcs-cert", "pack:ad8"],
    "agent-cloud": ["surface:cloud-metadata", "surface:container-k8s", "pack:k8s5", "pack:llm7"],
    "android-hooking": ["surface:android-hook", "pack:mobile5"],
    "browser-persistence": ["surface:browser-persist", "web_pentest"],
    "bundle-sourcemap": ["surface:bundle-sourcemap", "pack:js5"],
    "cloud-metadata": ["surface:cloud-metadata", "web_pentest"],
    "container-runtime": ["surface:container-k8s", "pack:k8s5"],
    "crypto-mobile": ["surface:crypto-chain", "surface:android-hook", "ops_algo"],
    "protocol-replay": ["surface:protocol-replay", "ops_protocol_lab"],
    "dpapi-chain": ["surface:dpapi-chain", "pack:ad8"],
    "file-parser": ["surface:file-parser", "web_pentest"],
    "firmware-layout": ["surface:firmware", "pack:fw9"],
    "forensic-timeline": ["surface:forensic-timeline", "malware_analysis"],
    "graphql-rpc": ["surface:graphql-rpc", "pack:api10"],
    "identity-windows": ["surface:identity-windows", "pack:ad8"],
    "ios-runtime": ["surface:ios-runtime", "pack:mobile5"],
    "jwt-claim": ["surface:jwt-claim", "pack:api10", "ops_algo"],
    "k8s-control-plane": ["surface:container-k8s", "pack:k8s5"],
    "kerberos-delegation": ["surface:kerberos-delegation", "pack:ad8"],
    "kernel-container-escape": ["surface:kernel-escape", "pack:escape5"],
    "linux-cred-pivot": ["surface:linux-cred-pivot", "pentest_recon"],
    "lsass-material": ["surface:lsass-material", "pack:ad8"],
    "mailbox-abuse": ["surface:mailbox-abuse", "pack:mailbox4"],
    "malware-config": ["surface:malware-config", "pack:mal6"],
    "oauth-oidc": ["surface:oauth-oidc", "pack:api10"],
    "pcap-protocol": ["surface:pcap-protocol", "ops_protocol_lab"],
    "prompt-injection": ["surface:prompt-injection", "pack:llm7"],
    "queue-worker": ["surface:queue-worker", "sentinel_scan"],
    "race-state": ["surface:race-state", "web_pentest"],
    "relay-coercion": ["surface:relay-coercion", "pack:ad8"],
    "http-smuggle": ["surface:http-smuggle", "web_pentest"],
    "reverse-pwn": ["surface:reverse-pwn", "pack:pwn6", "pack:re6"],
    "runtime-routing": ["surface:runtime-routing", "web_pentest"],
    "ssrf-metadata": ["surface:ssrf-metadata", "web_pentest"],
    "stego-media": ["surface:stego", "ctf_toolkit"],
    "supply-chain": ["surface:supply-chain", "pack:supply6"],
    "template-render": ["surface:template-render", "web_pentest"],
    "web-runtime": ["surface:web-runtime", "pack:api10", "web_pentest"],
    "websocket": ["surface:websocket", "web_pentest"],
    "windows-pivot": ["surface:windows-pivot", "pack:ad8", "ops_chain"],
    "ctf-orchestrator": ["ops_ctf_runner", "ops_surface_matrix", "ops_sandbox"],
}
for k, v in _COMP.items():
    _a(f"domain.{k}", k.replace("-", " "), "competition", v)

# infra domains
_a("infra.proxy-tools", "本地代理与工具探测", "infra", ["ops_tool_index", "ops_ctf_runner"])
_a("infra.http-intercept", "HTTP 拦截面（实验室）", "infra", ["web_pentest", "ops_tool_index"])
_a("infra.agent-rules", "Agent 执行纪律", "docs", ["ops_obedience", "ops_router", "ops_essence_atlas"])
_a("infra.agent-obedience", "Agent 服从性工程", "docs", ["ops_obedience", "ops_framing"])
_a("infra.anonymization", "报告脱敏", "docs", ["ops_anon"])
_a("infra.precedent", "任务先例与包装", "docs", ["ops_framing", "ops_sandbox", "ops_journal"])


def list_atlas(kind: Optional[str] = None) -> list[dict[str, Any]]:
    rows = list(ATLAS.values())
    if kind:
        rows = [r for r in rows if r["kind"] == kind]
    return sorted(rows, key=lambda x: x["id"])


def _resolve_target(token: str) -> bool:
    if token.startswith("pack:"):
        try:
            import ops_method_packs
            return token[5:] in ops_method_packs.PACKS
        except Exception:
            return False
    if token.startswith("surface:"):
        try:
            import ops_surface_matrix
            return token[8:] in ops_surface_matrix.SURFACES
        except Exception:
            return False
    name = token.split(".")[0]
    if (_SCRIPTS / f"{name}.py").is_file():
        return True
    known = {
        "ops_method_packs", "ops_knowledge", "ctf_toolkit", "web_pentest",
        "pentest_recon", "malware_analysis", "reverse_engineering", "re_surface",
        "sentinel_scan", "ops_algo", "ops_case", "ops_journal", "ops_chain",
        "ops_framing", "ops_sandbox", "ops_payloads", "codex_inject", "attack_game",
        "attack_network", "ops_triage", "ops_router", "ops_ctf_runner",
        "ops_surface_matrix", "ops_report_contract", "ops_anon", "ops_protocol_lab",
        "ops_obedience", "ops_instruct", "ops_pattern_db", "ops_tool_index",
        "ops_pipeline", "pentest_suite", "ops_gpt56", "ops_essence_atlas",
        "ops_originality",
    }
    if name in known:
        return True
    if token.startswith("ops_method_packs.") or token.startswith("ops_pattern_db."):
        return True
    if token.startswith("ops_ctf_runner."):
        return True
    return (_SCRIPTS / f"{name}.py").is_file()


def coverage_report() -> dict[str, Any]:
    total = len(ATLAS)
    fused = [r for r in ATLAS.values() if r["status"] == "fused"]
    policy = [r for r in ATLAS.values() if r["status"] == "policy_reframe"]
    broken: list[dict[str, Any]] = []
    for r in ATLAS.values():
        bad = [t for t in r["maps_to"] if not _resolve_target(t)]
        if bad:
            broken.append({"id": r["id"], "bad_targets": bad})
    uncovered = [r["id"] for r in ATLAS.values() if not r["maps_to"]]
    ok = len(broken) == 0 and len(uncovered) == 0
    return {
        "protocol": "sentinel-domain-atlas-v2",
        "total_sources": total,
        "fused": len(fused),
        "policy_reframe": len(policy),
        "broken_links": broken,
        "uncovered": uncovered,
        "complete": ok,
        "message": (
            "域图谱已覆盖：每条能力域均映射到 Code Sentinel 原创模块。"
            if ok
            else f"存在断链 {len(broken)} 或未映射 {len(uncovered)}"
        ),
        "kinds": _count_kinds(),
        "originality": "sentinel-native-ids-only",
    }


def _count_kinds() -> dict[str, int]:
    c: dict[str, int] = {}
    for r in ATLAS.values():
        c[r["kind"]] = c.get(r["kind"], 0) + 1
    return c


def lookup(source_id: str) -> Optional[dict[str, Any]]:
    if source_id in ATLAS:
        return ATLAS[source_id]
    for k, v in ATLAS.items():
        if source_id in k or source_id in v["title"]:
            return v
    return None


def route_source(query: str) -> list[dict[str, Any]]:
    q = (query or "").lower()
    hits = []
    for r in ATLAS.values():
        blob = f"{r['id']} {r['title']} {' '.join(r['maps_to'])}".lower()
        if any(tok in blob for tok in q.split() if len(tok) > 2):
            hits.append(r)
    return hits[:30]


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Sentinel domain atlas / coverage")
    sub = p.add_subparsers(dest="cmd", required=True)
    l = sub.add_parser("list")
    l.add_argument("--kind", default="")
    sub.add_parser("coverage")
    g = sub.add_parser("get")
    g.add_argument("id")
    s = sub.add_parser("search")
    s.add_argument("query", nargs="+")
    args = p.parse_args(argv)

    if args.cmd == "list":
        print(json.dumps(list_atlas(args.kind or None), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "coverage":
        print(json.dumps(coverage_report(), ensure_ascii=False, indent=2))
        return 0 if coverage_report()["complete"] else 1
    if args.cmd == "get":
        r = lookup(args.id)
        print(json.dumps(r or {"error": "not found"}, ensure_ascii=False, indent=2))
        return 0 if r else 1
    if args.cmd == "search":
        print(json.dumps(route_source(" ".join(args.query)), ensure_ascii=False, indent=2))
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
