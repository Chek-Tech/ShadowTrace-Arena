#!/usr/bin/env python3
"""
External security tool bridge — optional integration layer for deep scanning.

Runs industry-standard tools when available, parses their output into the
unified SentinelFinding schema, and merges with scanner results.

Design principle: every tool is OPTIONAL. If not installed, skip gracefully.
No tool dependency is ever required.
"""

from __future__ import annotations

import json
import os
import shlex
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class ToolResult:
    """Output from one external tool run."""
    tool: str
    success: bool
    available: bool
    findings: list[dict] = field(default_factory=list)
    raw_output: str = ""
    error: str = ""


# ── Tool registry ────────────────────────────────────────────────────

TOOL_REGISTRY: dict[str, dict] = {
    "semgrep": {
        "binary": "semgrep",
        "install_hint": "pip install semgrep  or  brew install semgrep",
        "description": "Multi-language static analysis with 2000+ community rules",
        "category": "sast",
    },
    "gitleaks": {
        "binary": "gitleaks",
        "install_hint": "brew install gitleaks  or  go install github.com/gitleaks/gitleaks/v8@latest",
        "description": "Detect hardcoded secrets and credentials in git repos",
        "category": "secrets",
    },
    "hadolint": {
        "binary": "hadolint",
        "install_hint": "brew install hadolint  or  docker pull hadolint/hadolint",
        "description": "Dockerfile best-practice linter",
        "category": "docker",
    },
    "shellcheck": {
        "binary": "shellcheck",
        "install_hint": "apt install shellcheck  or  brew install shellcheck",
        "description": "Shell script static analysis",
        "category": "shell",
    },
    "checkov": {
        "binary": "checkov",
        "install_hint": "pip install checkov",
        "description": "Infrastructure-as-Code security scanning (Terraform, K8s, CloudFormation)",
        "category": "iac",
    },
    "bandit": {
        "binary": "bandit",
        "install_hint": "pip install bandit",
        "description": "Python security-focused static analysis",
        "category": "sast",
    },
    "npm_audit": {
        "binary": "npm",
        "install_hint": "Install Node.js: https://nodejs.org",
        "description": "Node.js dependency vulnerability scanner",
        "category": "supply-chain",
    },
    "trivy": {
        "binary": "trivy",
        "install_hint": "brew install trivy  or  see https://aquasecurity.github.io/trivy/latest/getting-started/installation/",  # sentinel: ignore docker-curl-pipe-shell
        "description": "Container, filesystem, and git repository vulnerability scanner",
        "category": "supply-chain",
    },
}


def _find_binary(name: str) -> str | None:
    """Locate a binary in PATH. Returns path or None."""
    return shutil.which(name)


def _run_command(cmd: list[str], *, timeout: int = 120, cwd: Path | None = None) -> subprocess.CompletedProcess:
    """Run a command safely with timeout."""
    try:
        return subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=str(cwd) if cwd else None,
        )
    except subprocess.TimeoutExpired:
        return subprocess.CompletedProcess(cmd, -1, stdout="", stderr="Timed out")
    except FileNotFoundError:
        return subprocess.CompletedProcess(cmd, -2, stdout="", stderr="Binary not found")
    except Exception as exc:
        return subprocess.CompletedProcess(cmd, -3, stdout="", stderr=str(exc))


def check_availability() -> dict[str, bool]:
    """Check which tools are available in the current environment."""
    return {
        name: _find_binary(info["binary"]) is not None
        for name, info in TOOL_REGISTRY.items()
    }


def run_semgrep(target: Path, **kwargs) -> ToolResult:
    """Run Semgrep and parse findings."""
    binary = _find_binary("semgrep")
    if not binary:
        return ToolResult("semgrep", False, False, error="semgrep not installed")

    cmd = [
        binary, "scan",
        "--config", "auto",
        "--json",
        "--quiet",
        "--no-git-ignore",
        str(target),
    ]
    # Skip if there's a .semgrepignore or user prefs
    result = _run_command(cmd, timeout=kwargs.get("timeout", 180), cwd=target if target.is_dir() else target.parent)
    if result.returncode not in (0, 1):  # 0=clean, 1=findings
        return ToolResult("semgrep", False, True, error=result.stderr[:500])

    findings = []
    try:
        data = json.loads(result.stdout)
        for res in data.get("results", []):
            findings.append({
                "rule_id": f"semgrep-{res.get('check_id', 'unknown')}",
                "title": res.get("extra", {}).get("message", "Semgrep finding"),
                "severity": _map_semgrep_severity(res.get("extra", {}).get("severity", "WARNING")),
                "path": res.get("path", ""),
                "line": res.get("start", {}).get("line", 1),
                "column": res.get("start", {}).get("col", 1),
                "snippet": res.get("extra", {}).get("lines", ""),
                "remediation": res.get("extra", {}).get("fix", ""),
                "source": "semgrep",
            })
    except json.JSONDecodeError:
        return ToolResult("semgrep", False, True, error="Failed to parse Semgrep JSON output")

    return ToolResult("semgrep", True, True, findings=findings)


def run_gitleaks(target: Path, **kwargs) -> ToolResult:
    """Run Gitleaks and parse findings."""
    binary = _find_binary("gitleaks")
    if not binary:
        return ToolResult("gitleaks", False, False, error="gitleaks not installed")

    cmd = [
        binary, "detect",
        "--source", str(target),
        "--format", "json",
        "--no-git",
        "--verbose",
    ]
    result = _run_command(cmd, timeout=kwargs.get("timeout", 120))
    if result.returncode not in (0, 1):
        return ToolResult("gitleaks", False, True, error=result.stderr[:500])

    findings = []
    try:
        data = json.loads(result.stdout) if result.stdout else []
        for leak in data if isinstance(data, list) else []:
            findings.append({
                "rule_id": f"gitleaks-{leak.get('ruleID', 'unknown')}",
                "title": f"Hardcoded secret: {leak.get('Description', 'Unknown secret')}",
                "severity": "HIGH",
                "path": leak.get("File", ""),
                "line": leak.get("StartLine", 1),
                "column": leak.get("StartColumn", 1),
                "snippet": f"[REDACTED - {leak.get('ruleID', 'secret')}]",
                "remediation": "Remove from source, rotate the credential, use a secret manager.",
                "source": "gitleaks",
            })
    except (json.JSONDecodeError, AttributeError):
        pass

    return ToolResult("gitleaks", True, True, findings=findings)


def run_hadolint(target: Path, **kwargs) -> ToolResult:
    """Run Hadolint on all Dockerfiles in the target."""
    binary = _find_binary("hadolint")
    if not binary:
        return ToolResult("hadolint", False, False, error="hadolint not installed")

    findings = []
    dockerfiles = list(target.rglob("Dockerfile*")) if target.is_dir() else (
        [target] if "dockerfile" in target.name.lower() else []
    )

    for dockerfile in dockerfiles:
        if "node_modules" in dockerfile.parts:
            continue
        cmd = [binary, "--format", "json", str(dockerfile)]
        result = _run_command(cmd, timeout=kwargs.get("timeout", 30))
        if result.returncode not in (0, 1):
            continue
        try:
            data = json.loads(result.stdout) if result.stdout else []
            for issue in data if isinstance(data, list) else []:
                findings.append({
                    "rule_id": f"hadolint-{issue.get('code', 'unknown')}",
                    "title": issue.get("message", "Dockerfile issue"),
                    "severity": _map_hadolint_severity(issue.get("level", "warning")),
                    "path": str(dockerfile.relative_to(target) if target.is_dir() else dockerfile.name),
                    "line": issue.get("line", 1),
                    "column": issue.get("column", 1),
                    "snippet": issue.get("message", ""),
                    "remediation": "Fix the Dockerfile issue as recommended.",
                    "source": "hadolint",
                })
        except (json.JSONDecodeError, AttributeError):
            continue

    return ToolResult("hadolint", True, True, findings=findings)


def run_bandit(target: Path, **kwargs) -> ToolResult:
    """Run Bandit on Python files."""
    binary = _find_binary("bandit")
    if not binary:
        return ToolResult("bandit", False, False, error="bandit not installed")

    cmd = [binary, "-r", str(target), "-f", "json", "-q"]
    result = _run_command(cmd, timeout=kwargs.get("timeout", 120))
    if result.returncode not in (0, 1):
        return ToolResult("bandit", False, True, error=result.stderr[:500])

    findings = []
    try:
        data = json.loads(result.stdout)
        for res in data.get("results", []):
            findings.append({
                "rule_id": f"bandit-{res.get('test_id', 'unknown')}",
                "title": res.get("issue_text", "Bandit finding"),
                "severity": _map_bandit_severity(res.get("issue_severity", "low")),
                "path": res.get("filename", ""),
                "line": res.get("line_number", 1),
                "column": res.get("col_offset", 1) if res.get("col_offset") else 1,
                "snippet": res.get("code", "").strip() if res.get("code") else "",
                "remediation": res.get("more_info", ""),
                "source": "bandit",
            })
    except json.JSONDecodeError:
        pass

    return ToolResult("bandit", True, True, findings=findings)


def run_all(target: Path, *, tools: list[str] | None = None, timeout: int = 600) -> dict[str, ToolResult]:
    """
    Run all available external tools against a target.
    Returns a dict of tool_name → ToolResult.

    Tools are run sequentially to avoid resource contention.
    Each tool gets a sub-timeout; the total is capped by `timeout`.
    """
    available = check_availability()
    per_tool_timeout = max(30, timeout // max(len(available), 1))

    runners = {
        "semgrep": run_semgrep,
        "gitleaks": run_gitleaks,
        "hadolint": run_hadolint,
        "bandit": run_bandit,
    }

    results = {}
    for name, runner in runners.items():
        if tools and name not in tools:
            continue
        if not available.get(name):
            results[name] = ToolResult(name, False, False, error=f"{name} not installed — {TOOL_REGISTRY[name]['install_hint']}")
            continue
        results[name] = runner(target, timeout=per_tool_timeout)

    return results


def merge_external_findings(
    scanner_report: Any,     # SentinelReport from sentinel_scan
    external_results: dict[str, ToolResult],
) -> dict:
    """Merge scanner findings with external tool findings into a unified result."""
    all_findings = [f.to_dict() for f in scanner_report.findings]

    for tool_name, result in external_results.items():
        if result.success and result.findings:
            all_findings.extend(result.findings)

    # Simple dedup by (rule_id, path, line)
    seen = set()
    deduped = []
    for f in all_findings:
        key = (f.get("rule_id", ""), f.get("path", ""), f.get("line", 0))
        if key not in seen:
            seen.add(key)
            deduped.append(f)

    return {
        "scanner": scanner_report.summary.to_dict(),
        "external_tools": {
            name: {
                "available": r.available,
                "success": r.success,
                "finding_count": len(r.findings),
                "error": r.error if not r.success else None,
            }
            for name, r in external_results.items()
        },
        "findings": deduped,
        "total_findings": len(deduped),
    }


# ── Severity mappers ─────────────────────────────────────────────────

def _map_semgrep_severity(sev: str) -> str:
    mapping = {"ERROR": "HIGH", "WARNING": "MEDIUM", "INFO": "LOW", "INVENTORY": "INFO"}
    return mapping.get(sev.upper(), "MEDIUM")


def _map_hadolint_severity(level: str) -> str:
    mapping = {"error": "HIGH", "warning": "MEDIUM", "info": "LOW", "style": "INFO"}
    return mapping.get(level.lower(), "MEDIUM")


def _map_bandit_severity(sev: str) -> str:
    mapping = {"HIGH": "HIGH", "MEDIUM": "MEDIUM", "LOW": "LOW"}
    return mapping.get(sev.upper(), "LOW")

# ═══════════════════════════════════════════════════════════════════════
# Reverse engineering & dynamic analysis tool bridge
# ═══════════════════════════════════════════════════════════════════════

REVERSE_TOOL_REGISTRY: dict[str, dict] = {
    # ── Disassemblers / Decompilers ──
    "ghidra": {
        "binary": "ghidraHeadless",
        "install_hint": "Download from https://ghidra-sre.org",
        "description": "NSA reverse engineering suite — headless analysis",
        "category": "disassembler",
    },
    "ida": {
        "binary": "idat64",
        "install_hint": "Commercial: https://hex-rays.com/ida-pro",
        "description": "IDA Pro — industry-standard disassembler",
        "category": "disassembler",
    },
    "radare2": {
        "binary": "r2",
        "install_hint": "brew install radare2  or  apt install radare2",
        "description": "Portable reversing framework",
        "category": "disassembler",
    },
    "rizin": {
        "binary": "rizin",
        "install_hint": "brew install rizin  or  apt install rizin",
        "description": "Rizin — radare2 fork, modern Cutter backend",
        "category": "disassembler",
    },
    "jadx": {
        "binary": "jadx",
        "install_hint": "brew install jadx  or  download from https://github.com/skylot/jadx",
        "description": "DEX to Java/Smali decompiler — APK reverse engineering",
        "category": "decompiler",
    },
    "apktool": {
        "binary": "apktool",
        "install_hint": "brew install apktool  or  apt install apktool",
        "description": "APK reverse engineering — decode resources, rebuild",
        "category": "decompiler",
    },
    "dex2jar": {
        "binary": "d2j-dex2jar",
        "install_hint": "Download from https://github.com/pxb1988/dex2jar",
        "description": "DEX to JAR converter — use with JD-GUI",
        "category": "decompiler",
    },
    "retdec": {
        "binary": "retdec-decompiler",
        "install_hint": "brew install retdec  or  apt install retdec",
        "description": "RetDec — machine-code decompiler (x86/ARM/MIPS/PowerPC)",
        "category": "decompiler",
    },
    # ── Unpackers / Unpacking ──
    "upx": {
        "binary": "upx",
        "install_hint": "brew install upx  or  apt install upx-ucl",
        "description": "UPX executable packer/unpacker",
        "category": "unpacker",
    },
    "unipacker": {
        "binary": "unipacker",
        "install_hint": "pip install unipacker",
        "description": "Automatic PE unpacker with emulation",
        "category": "unpacker",
    },
    # ── Dynamic analysis / Instrumentation ──
    "frida": {
        "binary": "frida",
        "install_hint": "pip install frida-tools",
        "description": "Dynamic instrumentation toolkit — hook anything",
        "category": "dynamic",
    },
    "xposed": {
        "binary": None,
        "install_hint": "Install Xposed Framework / LSPosed on rooted Android",
        "description": "Android hooking framework — Java method interception",
        "category": "dynamic",
    },
    "strace": {
        "binary": "strace",
        "install_hint": "apt install strace",
        "description": "System call tracer — see what binary does at syscall level",
        "category": "dynamic",
    },
    "ltrace": {
        "binary": "ltrace",
        "install_hint": "apt install ltrace",
        "description": "Library call tracer — hook shared lib function calls",
        "category": "dynamic",
    },
    # ── Debuggers ──
    "gdb": {
        "binary": "gdb",
        "install_hint": "apt install gdb  or  brew install gdb",
        "description": "GNU Debugger — with pwndbg/gef/peda plugins for exploit dev",
        "category": "debugger",
    },
    "x64dbg": {
        "binary": "x64dbg",
        "install_hint": "Download from https://x64dbg.com (Windows)",
        "description": "Windows x64/x86 debugger — ScyllaHide anti-anti-debug plugin",
        "category": "debugger",
    },
    "ollydbg": {
        "binary": "ollydbg",
        "install_hint": "Download from http://ollydbg.de (Windows)",
        "description": "Classic Windows 32-bit ring-3 debugger",
        "category": "debugger",
    },
    # ── Binary analysis / PE/ELF tools ──
    "die": {
        "binary": "diec",
        "install_hint": "Download Detect-It-Easy from https://github.com/horsicq/DIE-engine",
        "description": "Detect-It-Easy — packer/crypto/compiler detector",
        "category": "analysis",
    },
    "pebear": {
        "binary": None,
        "install_hint": "Download from https://github.com/hasherezade/pe-bear",
        "description": "PE-bear — PE32/PE64 file viewer with structure analysis",
        "category": "analysis",
    },
    "readelf": {
        "binary": "readelf",
        "install_hint": "Included with binutils: apt install binutils",
        "description": "ELF file header/section/symbol viewer",
        "category": "analysis",
    },
    "objdump": {
        "binary": "objdump",
        "install_hint": "Included with binutils: apt install binutils",
        "description": "Object file disassembler and section dumper",
        "category": "analysis",
    },
    "strings": {
        "binary": "strings",
        "install_hint": "Included with binutils or macOS system",
        "description": "Extract printable strings from binary (with Unicode support)",
        "category": "analysis",
    },
    "binwalk": {
        "binary": "binwalk",
        "install_hint": "apt install binwalk  or  pip install binwalk",
        "description": "Firmware analysis — extract embedded files and filesystems",
        "category": "analysis",
    },
    # ── Exploit development ──
    "pwntools": {
        "binary": None,
        "install_hint": "pip install pwntools",
        "description": "CTF & exploit development library — tube, ROP, shellcraft",
        "category": "exploit",
    },
    "ropgadget": {
        "binary": "ROPgadget",
        "install_hint": "pip install ROPgadget",
        "description": "Gadget finder for ROP chains in ELF/PE/Mach-O",
        "category": "exploit",
    },
    "ropper": {
        "binary": "ropper",
        "install_hint": "pip install ropper",
        "description": "ROP gadget finder with semantic search",
        "category": "exploit",
    },
    "one_gadget": {
        "binary": "one_gadget",
        "install_hint": "gem install one_gadget",
        "description": "Find one-shot RCE gadgets in libc (Linux)",
        "category": "exploit",
    },
    "pwndbg": {
        "binary": None,
        "install_hint": "git clone https://github.com/pwndbg/pwndbg",
        "description": "GDB plugin for exploit development and reverse engineering",
        "category": "exploit",
    },
    # ── Malware analysis sandbox ──
    "yara": {
        "binary": "yara",
        "install_hint": "brew install yara  or  apt install yara  or  pip install yara-python",
        "description": "Pattern matching swiss-army knife for malware research",
        "category": "malware",
    },
    "volatility3": {
        "binary": "vol",
        "install_hint": "pip install volatility3",
        "description": "Memory forensics framework — analyze RAM dumps",
        "category": "forensics",
    },
    "floss": {
        "binary": "floss",
        "install_hint": "pip install flare-floss  or  download from FireEye",
        "description": "FLARE Obfuscated String Solver — extract obfuscated strings",
        "category": "malware",
    },
}


def check_reverse_tool_availability() -> dict[str, bool]:
    """Check which reverse engineering tools are installed."""
    result = {}
    for name, info in REVERSE_TOOL_REGISTRY.items():
        binary = info.get("binary")
        if binary is None:
            result[name] = False
        else:
            result[name] = shutil.which(binary) is not None
    return result


def list_available_reverse_tools() -> dict[str, list[str]]:
    """List reverse tools grouped by category."""
    avail = check_reverse_tool_availability()
    by_cat: dict[str, list[str]] = {}
    for name, info in REVERSE_TOOL_REGISTRY.items():
        cat = info["category"]
        by_cat.setdefault(cat, [])
        status = "✓" if avail.get(name) else "✗"
        by_cat[cat].append(f"{status} {name}")
    return by_cat


def run_yara_scan(target: str, rule_file: str | None = None,
                  timeout: int = 120) -> ToolResult:
    """Run YARA scan on target with optional custom rule file."""
    if not shutil.which("yara"):
        return ToolResult("yara", False, False,
                         error="yara not installed — pip install yara-python")
    cmd = ["yara", "-r"]
    if rule_file:
        cmd.extend([rule_file, target])
    else:
        cmd.extend(["-w", str(target)])
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True,
                            timeout=timeout, cwd=str(Path(target).parent))
        findings = []
        for line in proc.stdout.strip().splitlines():
            if line:
                parts = line.split(maxsplit=1)
                findings.append({"rule_id": parts[0] if parts else "yara_match",
                               "title": parts[1] if len(parts) > 1 else line,
                               "severity": "MEDIUM", "source": "yara",
                               "path": target, "line": 0})
        return ToolResult("yara", True, True, findings=findings,
                         raw_output=proc.stdout[:5000])
    except subprocess.TimeoutExpired:
        return ToolResult("yara", False, True, error="YARA scan timed out")
    except Exception as e:
        return ToolResult("yara", False, True, error=str(e))


def run_strings_extraction(target: str, min_len: int = 4,
                           timeout: int = 60) -> ToolResult:
    """Extract ASCII/Unicode strings from binary using system strings command."""
    if not shutil.which("strings"):
        return ToolResult("strings", False, False,
                         error="strings not installed — apt install binutils")
    cmd = ["strings", "-n", str(min_len), "-e", "l", target]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True,
                            timeout=timeout)
        lines = [l.strip() for l in proc.stdout.splitlines() if l.strip()]
        interesting = []
        for line in lines:
            for pat in [r"http", r"\.exe", r"\.dll", r"password", r"secret",
                       r"key", r"flag", r"CTF{", r"admin", r"cmd", r"/bin/",
                       r"REG", r"HKEY", r"Mozilla", r"curl", r"wget"]:
                if re.search(pat, line, re.IGNORECASE):
                    interesting.append(line)
                    break
        return ToolResult("strings", True, True,
                         findings=[{"rule_id": "strings_interesting",
                                   "title": "Interesting string found",
                                   "severity": "INFO", "path": target,
                                   "line": 0, "snippet": i}
                                   for i in interesting[:50]],
                         raw_output=f"{len(lines)} strings, {len(interesting)} interesting")
    except subprocess.TimeoutExpired:
        return ToolResult("strings", False, True, error="Strings extraction timed out")
    except Exception as e:
        return ToolResult("strings", False, True, error=str(e))


def run_frida_hook(target_package: str, hook_script: str = "",
                   timeout: int = 60) -> ToolResult:
    """Run Frida on Android package. Requires adb + frida-server on device."""
    if not shutil.which("frida"):
        return ToolResult("frida", False, False,
                         error="frida not installed — pip install frida-tools")
    cmd = ["frida", "-U", "-f", target_package, "--no-pause"]
    if hook_script:
        cmd.extend(["-l", hook_script])
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True,
                            timeout=timeout)
        return ToolResult("frida", True, True,
                         raw_output=proc.stdout[:5000] + "\n" + proc.stderr[:2000])
    except subprocess.TimeoutExpired:
        return ToolResult("frida", False, True, error="Frida session timed out")
    except Exception as e:
        return ToolResult("frida", False, True, error=str(e))


def run_apk_decompile(apk_path: str, output_dir: str | None = None,
                      timeout: int = 300) -> dict[str, ToolResult]:
    """Decompile APK using jadx + apktool. Returns dict of tool results."""
    results = {}
    out = output_dir or f"{apk_path}_decompiled"

    # apktool
    if shutil.which("apktool"):
        try:
            proc = subprocess.run(
                ["apktool", "d", "-f", apk_path, "-o", f"{out}_apktool"],
                capture_output=True, text=True, timeout=timeout)
            results["apktool"] = ToolResult("apktool", proc.returncode == 0, True,
                                          raw_output=proc.stdout[:2000])
        except Exception as e:
            results["apktool"] = ToolResult("apktool", False, True, error=str(e))
    else:
        results["apktool"] = ToolResult("apktool", False, False,
                                        error="apktool not installed")

    # jadx
    if shutil.which("jadx"):
        try:
            proc = subprocess.run(
                ["jadx", "-d", f"{out}_jadx", apk_path],
                capture_output=True, text=True, timeout=timeout)
            results["jadx"] = ToolResult("jadx", proc.returncode == 0, True,
                                        raw_output=proc.stdout[:2000])
        except Exception as e:
            results["jadx"] = ToolResult("jadx", False, True, error=str(e))
    else:
        results["jadx"] = ToolResult("jadx", False, False,
                                     error="jadx not installed")

    return results


def run_binary_patch(filepath: str, offset: int, original: bytes,
                     replacement: bytes) -> ToolResult:
    """Patch binary at given offset. Backup created as .bak."""
    try:
        with open(filepath, "rb") as f:
            data = bytearray(f.read())
        backup = filepath + ".bak"
        with open(backup, "wb") as f:
            f.write(data)
        if data[offset:offset + len(original)] != original:
            return ToolResult("patch", False, True,
                            error=f"Bytes at offset {offset} don't match expected {original.hex()}")
        data[offset:offset + len(replacement)] = replacement
        with open(filepath, "wb") as f:
            f.write(data)
        return ToolResult("patch", True, True,
                         raw_output=f"Patched {len(replacement)} bytes at offset {offset}. Backup: {backup}")
    except Exception as e:
        return ToolResult("patch", False, True, error=str(e))

# ═══════════════════════════════════════════════════════════════════════
# Offensive Attack Tool Bridge
# ═══════════════════════════════════════════════════════════════════════

OFFENSIVE_TOOLS: dict[str, dict] = {
    "sqlmap": {"binary": "sqlmap","desc": "Automatic SQL injection tool","cat": "injection",
        "install": "pip install sqlmap"},
    "hydra": {"binary": "hydra","desc": "Network login brute-forcer (50+ protocols)","cat": "brute",
        "install": "apt install hydra"},
    "nmap": {"binary": "nmap","desc": "Network scanner & port discovery","cat": "scan",
        "install": "apt install nmap"},
    "masscan": {"binary": "masscan","desc": "Fast Internet-scale port scanner","cat": "scan",
        "install": "apt install masscan"},
    "hashcat": {"binary": "hashcat","desc": "GPU-accelerated password cracker","cat": "brute",
        "install": "apt install hashcat"},
    "john": {"binary": "john","desc": "John the Ripper password cracker","cat": "brute",
        "install": "apt install john"},
    "bettercap": {"binary": "bettercap","desc": "MITM framework — ARP/DNS/HTTP spoofing","cat": "network",
        "install": "apt install bettercap"},
    "aircrack-ng": {"binary": "aircrack-ng","desc": "WiFi WEP/WPA cracking suite","cat": "network",
        "install": "apt install aircrack-ng"},
    "gobuster": {"binary": "gobuster","desc": "Directory/DNS brute-forcing","cat": "web",
        "install": "apt install gobuster"},
    "ffuf": {"binary": "ffuf","desc": "Fast web fuzzer","cat": "web",
        "install": "go install github.com/ffuf/ffuf/v2@latest"},
    "wfuzz": {"binary": "wfuzz","desc": "Web fuzzer — parameter/URL brute force","cat": "web",
        "install": "pip install wfuzz"},
    "nikto": {"binary": "nikto","desc": "Web server scanner","cat": "web",
        "install": "apt install nikto"},
    "whatweb": {"binary": "whatweb","desc": "Web technology fingerprinting","cat": "web",
        "install": "apt install whatweb"},
    "nuclei": {"binary": "nuclei","desc": "Template-based vulnerability scanner","cat": "vuln",
        "install": "go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"},
    "httpx": {"binary": "httpx","desc": "HTTP probe / tech detect","cat": "recon",
        "install": "go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest"},
    "subfinder": {"binary": "subfinder","desc": "Subdomain discovery","cat": "recon",
        "install": "go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"},
    "amass": {"binary": "amass","desc": "In-depth attack surface mapping","cat": "recon",
        "install": "go install -v github.com/owasp-amass/amass/v4/...@master"},
    "searchsploit": {"binary": "searchsploit","desc": "Exploit-DB offline search","cat": "exploit",
        "install": "apt install exploitdb"},
    "metasploit": {"binary": "msfconsole","desc": "Exploitation framework","cat": "exploit",
        "install": "see https://docs.metasploit.com/"},
    "responder": {"binary": "responder","desc": "LLMNR/NBT-NS/MDNS poisoner","cat": "network",
        "install": "apt install responder"},
    "impacket-smbclient": {"binary": "impacket-smbclient","desc": "Impacket SMB client","cat": "lateral",
        "install": "pip install impacket"},
    "bloodhound-python": {"binary": "bloodhound-python","desc": "AD enumeration collector","cat": "ad",
        "install": "pip install bloodhound"},
    "enum4linux": {"binary": "enum4linux","desc": "SMB/RPC enumeration","cat": "enum",
        "install": "apt install enum4linux"},
    "crackmapexec": {"binary": "crackmapexec","desc": "Swiss army knife for pentesting networks","cat": "lateral",
        "install": "pip install crackmapexec"},
    "netexec": {"binary": "nxc","desc": "NetExec network execution suite","cat": "lateral",
        "install": "pip install netexec"},
}

def check_offensive_tools() -> dict[str, bool]:
    import shutil
    return {name: shutil.which(info["binary"]) is not None
            for name, info in OFFENSIVE_TOOLS.items()}
