﻿# ops-lab

运行 `ops_pipeline` / 案例归档时写入此处。交付包保持空目录结构（仅 .gitkeep）。

- reports/  — SEN-*.md / .json 案例
- samples/  — 可选样本
- tmp/      — 临时 decrypt sketch 等
- logs/ shared/
