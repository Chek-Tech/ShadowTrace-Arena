@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Code Sentinel Windows 一键卸载
echo ================================================
echo   Code Sentinel - Windows 一键卸载
echo ================================================
echo.
python "%~dp0Windows卸载.py" %*
if errorlevel 1 (
  echo.
  echo 若提示找不到 python，请先安装 Python 3.10+ 并加入 PATH。
  pause
  exit /b 1
)
