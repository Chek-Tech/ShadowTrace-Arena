#!/usr/bin/env python3
"""
Offensive web crawler engine — multi-threaded, proxy pool, anti-anti-spider,
JS rendering bypass, rate-limit evasion, cookie/session management.
Pure stdlib where possible, with optional aiohttp/selenium integration.
"""

from __future__ import annotations

import hashlib, http.cookiejar, json, queue, random, re, socket, ssl, struct
import threading, time, urllib.parse, urllib.request, urllib.robotparser
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

# ═══════════════════════════════════════════════════════════════════════
# User-Agent rotation pool — 50+ real browser fingerprints
# ═══════════════════════════════════════════════════════════════════════
USER_AGENTS = [
    # Chrome Windows
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/124.0.0.0 Safari/537.36",
    # Chrome Mac
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4_1) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/125.0.0.0 Safari/537.36",
    # Firefox
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0",
    "Mozilla/5.0 (X11; Linux x86_64; rv:127.0) Gecko/20100101 Firefox/127.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14.5; rv:128.0) Gecko/20100101 Firefox/128.0",
    # Edge
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0",
    # Safari
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5) AppleWebKit/605.1.15 (KHTML,like Gecko) Version/17.5 Safari/605.1.15",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML,like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
    # Opera
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/126.0.0.0 Safari/537.36 OPR/111.0.0.0",
    # Mobile
    "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/126.0.6478.122 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/126.0.6478.122 Mobile Safari/537.36",
]

# ═══════════════════════════════════════════════════════════════════════
# Referrer rotation
# ═══════════════════════════════════════════════════════════════════════
REFERRERS = [
    "https://www.google.com/search?q=",
    "https://www.bing.com/search?q=",
    "https://www.baidu.com/s?wd=",
    "https://duckduckgo.com/?q=",
    "https://www.google.com/",
    "https://www.bing.com/",
    "https://t.co/",
    "https://github.com/",
]

# ═══════════════════════════════════════════════════════════════════════
# Common proxy sources (free proxy API endpoints)
# ═══════════════════════════════════════════════════════════════════════
PROXY_SOURCES = [
    "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=5000&country=all&ssl=all&anonymity=all",
    "https://www.proxy-list.download/api/v1/get?type=http",
    "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
    "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt",
    "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
]

# ═══════════════════════════════════════════════════════════════════════
# Anti-bot detection evasion patterns
# ═══════════════════════════════════════════════════════════════════════
CLOUDFLARE_INDICATORS = [
    "cf-browser-verification", "cf_chl_opt", "jschl_vc", "jschl_answer",
    "__cfuid", "cf_clearance", "challenge-platform",
]

CAPTCHA_INDICATORS = [
    "g-recaptcha", "h-captcha", "hcaptcha", "funcaptcha",
    "arkose-enforcement", "geetest", "data-sitekey",
]

RATE_LIMIT_INDICATORS = [
    "rate limit", "too many requests", "429", "throttl",
    "try again later", "blocked", "access denied",
]

# ═══════════════════════════════════════════════════════════════════════
# Data classes
# ═══════════════════════════════════════════════════════════════════════

@dataclass
class Proxy:
    host: str
    port: int
    protocol: str = "http"
    username: str = ""
    password: str = ""
    alive: bool = True
    last_checked: float = 0.0
    fail_count: int = 0
    latency: float = 999.0

    def url(self) -> str:
        auth = f"{self.username}:{self.password}@" if self.username else ""
        return f"{self.protocol}://{auth}{self.host}:{self.port}"

@dataclass
class CrawlRequest:
    url: str
    method: str = "GET"
    headers: dict = field(default_factory=dict)
    data: bytes | None = None
    timeout: int = 30
    retries: int = 3
    use_proxy: bool = True
    follow_redirects: bool = True
    verify_ssl: bool = False
    cookies: dict = field(default_factory=dict)
    referrer: str = ""

@dataclass
class CrawlResponse:
    url: str
    status: int
    headers: dict
    content: bytes
    text: str = ""
    elapsed: float = 0.0
    redirected_url: str = ""
    cookies: dict = field(default_factory=dict)
    extracted_urls: list[str] = field(default_factory=list)
    has_captcha: bool = False
    has_cloudflare: bool = False
    is_rate_limited: bool = False
    proxy_used: str = ""
    error: str = ""

# ═══════════════════════════════════════════════════════════════════════
# Proxy Manager
# ═══════════════════════════════════════════════════════════════════════

class ProxyManager:
    """Rotating proxy pool with auto-validation."""

    def __init__(self):
        self._proxies: list[Proxy] = []
        self._lock = threading.Lock()
        self._index = 0

    def add(self, host: str, port: int, protocol: str = "http"):
        with self._lock:
            self._proxies.append(Proxy(host=host, port=port, protocol=protocol))

    def add_batch(self, proxy_list: list[str]):
        for p in proxy_list:
            p = p.strip()
            if not p or p.startswith("#"):
                continue
            try:
                parts = p.split(":")
                if len(parts) >= 2:
                    self.add(parts[0], int(parts[1]))
            except ValueError:
                continue

    def fetch_from_source(self, url: str, timeout: int = 15) -> int:
        """Download proxy list from a source URL."""
        try:
            req = urllib.request.Request(url, headers={"User-Agent": random.choice(USER_AGENTS)})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                text = resp.read().decode("utf-8", errors="replace")
                proxies = [line.strip() for line in text.splitlines() if line.strip()]
                self.add_batch(proxies)
                return len(proxies)
        except Exception:
            return 0

    def fetch_all_sources(self) -> int:
        total = 0
        for src in PROXY_SOURCES:
            total += self.fetch_from_source(src)
        return total

    def get_random(self) -> Proxy | None:
        with self._lock:
            alive = [p for p in self._proxies if p.alive and p.fail_count < 5]
            if not alive:
                return None
            return random.choice(alive)

    def get_round_robin(self) -> Proxy | None:
        with self._lock:
            alive = [p for p in self._proxies if p.alive and p.fail_count < 5]
            if not alive:
                return None
            self._index = (self._index + 1) % len(alive)
            return alive[self._index]

    def mark_dead(self, proxy: Proxy):
        with self._lock:
            proxy.fail_count += 1
            if proxy.fail_count >= 5:
                proxy.alive = False

    def count(self) -> int:
        with self._lock:
            return len([p for p in self._proxies if p.alive])

    def count_total(self) -> int:
        return len(self._proxies)

# ═══════════════════════════════════════════════════════════════════════
# Cookie Jar Manager
# ═══════════════════════════════════════════════════════════════════════

class CookieManager:
    """Per-domain cookie management + session persistence."""

    def __init__(self):
        self._jars: dict[str, http.cookiejar.CookieJar] = defaultdict(http.cookiejar.CookieJar)
        self._session_cookies: dict[str, dict] = {}

    def get_jar(self, domain: str) -> http.cookiejar.CookieJar:
        return self._jars[domain]

    def set_session(self, domain: str, cookies: dict):
        self._session_cookies[domain] = cookies

    def get_session(self, domain: str) -> dict:
        return self._session_cookies.get(domain, {})

    def extract_cookies(self, domain: str, response_headers: dict) -> dict:
        jar = self._jars[domain]
        result = {}
        for header_name, header_value in response_headers.items():
            if header_name.lower() == "set-cookie":
                for cookie_str in header_value.split(","):
                    parts = cookie_str.strip().split(";")[0].split("=", 1)
                    if len(parts) == 2:
                        result[parts[0].strip()] = parts[1].strip()
        self._session_cookies[domain].update(result)
        return result

# ═══════════════════════════════════════════════════════════════════════
# URL Extractor
# ═══════════════════════════════════════════════════════════════════════

URL_RE = re.compile(r'(?:href|src|action|content)=["\']([^"\']+)["\']|'
                    r'https?://[^\s<>"\']+|'
                    r'["\']\s*:\s*["\'](https?://[^\s"\'<>]+)["\']')
REL_URL_RE = re.compile(r'(?:href|src|action)=["\']([^:"\'][^"\']+)["\']')
JS_URL_RE = re.compile(r'(?:fetch|axios|XMLHttpRequest)\s*\([\s\n]*["\']([^"\']+)["\']|'
                       r'window\.location\s*=\s*["\']([^"\']+)["\']|'
                       r'\.open\s*\(\s*["\'](GET|POST|PUT|DELETE)["\']\s*,\s*["\']([^"\']+)')

def extract_urls(html: str, base_url: str) -> list[str]:
    """Extract all links from HTML including JS-generated URLs."""
    urls = set()
    base = urllib.parse.urlparse(base_url)
    base_domain = f"{base.scheme}://{base.netloc}"

    for match in URL_RE.finditer(html):
        for g in match.groups():
            if g and g.startswith("http"):
                urls.add(g)
            elif g and not g.startswith(("#", "javascript:", "mailto:", "tel:")):
                urls.add(urllib.parse.urljoin(base_domain, g))

    # Extract relative URLs
    for match in REL_URL_RE.finditer(html):
        g = match.group(1)
        if g and g.startswith("/"):
            urls.add(urllib.parse.urljoin(base_domain, g))

    # Extract JS API endpoints
    for match in JS_URL_RE.finditer(html):
        for g in match.groups():
            if g and g.startswith("/"):
                urls.add(urllib.parse.urljoin(base_domain, g))

    return list(urls)

# ═══════════════════════════════════════════════════════════════════════
# Form / Input Extraction
# ═══════════════════════════════════════════════════════════════════════

FORM_RE = re.compile(
    r'<form[^>]*?(?:action|id|name)\s*=\s*["\']([^"\']+)["\'].*?>'
    r'(.*?)</form>', re.DOTALL | re.IGNORECASE
)
INPUT_RE = re.compile(
    r'<input[^>]*?(?:name|id|type)\s*=\s*["\']([^"\']+)["\'][^>]*?>', re.IGNORECASE
)

def extract_forms(html: str) -> list[dict]:
    """Extract all forms and input fields from HTML."""
    forms = []
    for match in FORM_RE.finditer(html):
        action = match.group(1)
        inner = match.group(2)
        inputs = []
        for inp in INPUT_RE.finditer(inner):
            inputs.append({"name": inp.group(1)})
        forms.append({"action": action, "inputs": inputs})
    return forms

# ═══════════════════════════════════════════════════════════════════════
# Core Spider Engine
# ═══════════════════════════════════════════════════════════════════════

class SpiderEngine:
    """Multi-threaded offensive web crawler with anti-detection."""

    def __init__(
        self,
        threads: int = 10,
        delay: tuple[float, float] = (0.5, 2.0),
        max_depth: int = 3,
        max_urls: int = 10000,
        use_proxy: bool = False,
        respect_robots: bool = False,
    ):
        self.threads = threads
        self.delay = delay
        self.max_depth = max_depth
        self.max_urls = max_urls
        self.use_proxy = use_proxy
        self.respect_robots = respect_robots
        self.proxy_manager = ProxyManager()
        self.cookie_manager = CookieManager()
        self._url_queue: queue.Queue = queue.Queue()
        self._seen_urls: set[str] = set()
        self._seen_lock = threading.Lock()
        self._results: list[CrawlResponse] = []
        self._results_lock = threading.Lock()
        self._robot_parsers: dict[str, urllib.robotparser.RobotFileParser] = {}
        self._session = self._build_opener()
        self._running = False
        self._form_data: list[dict] = []

    def _build_opener(self):
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        handler = urllib.request.HTTPSHandler(context=ctx)
        return urllib.request.build_opener(handler)

    def _random_headers(self, url: str = "", referrer: str = "") -> dict:
        headers = {
            "User-Agent": random.choice(USER_AGENTS),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": random.choice([
                "en-US,en;q=0.9", "zh-CN,zh;q=0.9,en;q=0.8",
                "ja-JP,ja;q=0.9,en;q=0.8", "ko-KR,ko;q=0.9,en;q=0.8",
            ]),
            "Accept-Encoding": "gzip, deflate, br",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
            "Sec-Ch-Ua": '"Chromium";v="126","Google Chrome";v="126","Not?A_Brand";v="99"',
            "Sec-Ch-Ua-Mobile": "?0",
            "Sec-Ch-Ua-Platform": '"Windows"',
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1",
            "Upgrade-Insecure-Requests": "1",
            "DNT": "1",
        }
        if referrer:
            headers["Referer"] = referrer
        return headers

    def _should_crawl(self, url: str, robots_url: str) -> bool:
        if not self.respect_robots:
            return True
        domain = urllib.parse.urlparse(url).netloc
        if domain not in self._robot_parsers:
            rp = urllib.robotparser.RobotFileParser()
            rp.set_url(robots_url)
            try:
                rp.read()
            except Exception:
                return True
            self._robot_parsers[domain] = rp
        return self._robot_parsers[domain].can_fetch(USER_AGENTS[0], url)

    def crawl(self, url: str, depth: int = 0) -> CrawlResponse:
        """Execute single crawl request with full evasion."""
        result = CrawlResponse(url=url)
        start = time.time()

        try:
            parsed = urllib.parse.urlparse(url)
            domain = parsed.netloc
            referrer = random.choice(REFERRERS) + urllib.parse.quote(url)
            headers = self._random_headers(url, referrer)

            # Add domain cookies
            session_cookies = self.cookie_manager.get_session(domain)
            if session_cookies:
                cookie_str = "; ".join(f"{k}={v}" for k, v in session_cookies.items())
                headers["Cookie"] = cookie_str

            req = urllib.request.Request(url, headers=headers)

            # Proxy
            if self.use_proxy:
                proxy = self.proxy_manager.get_random()
                if proxy:
                    result.proxy_used = proxy.url()
                    req.set_proxy(proxy.host + ":" + str(proxy.port), proxy.protocol)

            # Random delay
            time.sleep(random.uniform(*self.delay))

            resp = self._session.open(req, timeout=30)
            result.status = resp.status
            result.headers = dict(resp.headers)
            result.content = resp.read()
            result.redirected_url = resp.url
            result.elapsed = time.time() - start

            # Decode content
            content_type = resp.headers.get("Content-Type", "")
            charset = "utf-8"
            if "charset=" in content_type:
                charset = content_type.split("charset=")[-1].split(";")[0].strip()
            try:
                result.text = result.content.decode(charset, errors="replace")
            except Exception:
                result.text = result.content.decode("latin-1", errors="replace")

            # Extract cookies
            self.cookie_manager.extract_cookies(domain, dict(resp.headers))

            # Detect anti-bot measures
            text_lower = result.text[:10000].lower()
            result.has_cloudflare = any(ind in text_lower for ind in CLOUDFLARE_INDICATORS)
            result.has_captcha = any(ind in text_lower for ind in CAPTCHA_INDICATORS)
            result.is_rate_limited = (result.status == 429 or
                any(ind in text_lower for ind in RATE_LIMIT_INDICATORS))

        except urllib.error.HTTPError as e:
            result.status = e.code
            result.error = str(e)
        except urllib.error.URLError as e:
            result.error = str(e.reason)
        except Exception as e:
            result.error = str(e)

        # Extract URLs from response
        if result.text:
            try:
                result.extracted_urls = extract_urls(result.text, url)
            except Exception:
                pass

        return result

    def _worker(self):
        """Thread worker: process URL queue."""
        while self._running:
            try:
                url, depth = self._url_queue.get(timeout=2)
            except queue.Empty:
                continue

            with self._seen_lock:
                if url in self._seen_urls:
                    self._url_queue.task_done()
                    continue
                if len(self._seen_urls) >= self.max_urls:
                    self._url_queue.task_done()
                    continue
                self._seen_urls.add(url)

            resp = self.crawl(url, depth)

            with self._results_lock:
                self._results.append(resp)

            # Queue discovered URLs
            if depth < self.max_depth and resp.text:
                for extracted in resp.extracted_urls[:50]:
                    normalized = urllib.parse.urljoin(url, extracted.split("#")[0])
                    if not normalized.startswith("http"):
                        continue
                    with self._seen_lock:
                        if normalized not in self._seen_urls:
                            self._url_queue.put((normalized, depth + 1))

            self._url_queue.task_done()

    def run(self, seed_urls: list[str], timeout: int = 300) -> list[CrawlResponse]:
        """Start multi-threaded crawl from seed URLs."""
        self._running = True
        for url in seed_urls:
            self._url_queue.put((url, 0))

        threads_list = []
        for _ in range(min(self.threads, 20)):
            t = threading.Thread(target=self._worker, daemon=True)
            t.start()
            threads_list.append(t)

        try:
            self._url_queue.join()
        except KeyboardInterrupt:
            pass
        finally:
            self._running = False

        for t in threads_list:
            t.join(timeout=5)

        return self._results

    def quick_crawl(self, url: str) -> CrawlResponse:
        """Single-page quick crawl."""
        return self.crawl(url, depth=0)

    def dump_results(self, output_dir: str = "spider_output"):
        """Save all crawled pages to disk."""
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)
        for i, resp in enumerate(self._results):
            if resp.text:
                domain = urllib.parse.urlparse(resp.url).netloc
                safe_url = hashlib.md5(resp.url.encode()).hexdigest()[:12]
                fname = out / f"{domain}_{safe_url}_{i}.html"
                fname.write_text(resp.text, encoding="utf-8", errors="replace")

    @property
    def results(self) -> list[CrawlResponse]:
        return self._results

    @property
    def url_count(self) -> int:
        return len(self._seen_urls)


# ═══════════════════════════════════════════════════════════════════════
# Quick-start helpers
# ═══════════════════════════════════════════════════════════════════════

def quick_spider(url: str, threads: int = 5, depth: int = 2,
                 proxy: bool = False) -> list[CrawlResponse]:
    """One-liner: crawl a site with default settings."""
    spider = SpiderEngine(threads=threads, max_depth=depth, use_proxy=proxy)
    return spider.run([url])


def extract_api_endpoints(html: str, base_url: str = "") -> list[str]:
    """Extract API endpoints from HTML/JS source."""
    patterns = [
        r'(?:fetch|axios\.(?:get|post|put|delete|patch)|XMLHttpRequest)\s*\(\s*["\']([^"\']+)["\']',
        r'(?:url|api|endpoint|baseURL|base_url)\s*[:=]\s*["\']([^"\']+)["\']',
        r'\.open\s*\(\s*["\'](GET|POST|PUT|DELETE)["\']\s*,\s*["\']([^"\']+)',
        r'(?:action|href)\s*=\s*["\'](/api/[^"\']+)["\']',
    ]
    endpoints = set()
    for pat in patterns:
        for match in re.finditer(pat, html, re.IGNORECASE):
            groups = match.groups()
            for g in groups:
                if g and ("api/" in g or g.startswith("/")):
                    endpoints.add(urllib.parse.urljoin(base_url, g) if base_url else g)
    return sorted(endpoints)


def extract_secrets_from_page(html: str) -> dict[str, list[str]]:
    """Find API keys, tokens, endpoints in page source."""
    findings: dict[str, list[str]] = {
        "api_keys": [], "tokens": [], "endpoints": [],
        "internal_ips": [], "admin_urls": [], "debug_info": [],
    }
    patterns = {
        "api_keys": [
            r'(?:api[_-]?key|apikey|API_KEY)\s*[:=]\s*["\']([^"\']{8,})["\']',
            r'(?:sk-[A-Za-z0-9]{20,})',
            r'(?:ghp_[A-Za-z0-9]{36})',
        ],
        "tokens": [
            r'(?:token|access_token|auth_token|jwt)\s*[:=]\s*["\']([^"\']{8,})["\']',
            r'eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+',
        ],
        "endpoints": [
            r'["\']\s*(/api/v\d+/[^"\'\s]+)\s*["\']',
            r'(?:url|host|server)\s*[:=]\s*["\'](https?://[^"\']+)["\']',
        ],
        "internal_ips": [
            r'\b(?:10\.\d{1,3}\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3})\b',
        ],
        "admin_urls": [
            r'(?:/admin|/wp-admin|/dashboard|/panel|/manage|/backend)',
        ],
        "debug_info": [
            r'(?:debug|DEBUG)\s*=\s*(?:true|True|1)',
            r'(?:console\.log|debugger|debugInfo|__DEV__)',
            r'<!--.*?(?:TODO|FIXME|DEBUG|TEMP).*?-->',
        ],
    }
    for category, pats in patterns.items():
        for pat in pats:
            for match in re.finditer(pat, html, re.IGNORECASE):
                value = match.group(1) if match.groups() else match.group(0)
                if value and len(value) < 500:
                    findings[category].append(value)
    return {k: list(set(v))[:30] for k, v in findings.items()}


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        spider = SpiderEngine(threads=5, max_depth=2)
        results = spider.run([sys.argv[1]])
        for r in results:
            print(f"[{r.status}] {r.url} ({len(r.text)} bytes)")
        print(f"\nTotal URLs crawled: {spider.url_count}")
    else:
        print("Usage: python attack_spider.py <url>")
