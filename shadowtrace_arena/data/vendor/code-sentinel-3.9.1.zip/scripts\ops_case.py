#!/usr/bin/env python3
"""
Sentinel Ops Case — full multi-section case writer (original).

Report sections align with ops_knowledge.REPORT_SECTIONS (8 blocks).
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional


LAB_DIRS = ("samples", "reports", "logs", "shared", "tmp")


def ensure_workspace(root: Optional[Path] = None) -> Path:
    if root is None:
        root = Path(__file__).resolve().parents[1] / "ops-lab"
    root = Path(root)
    for name in LAB_DIRS:
        d = root / name
        d.mkdir(parents=True, exist_ok=True)
        gk = d / ".gitkeep"
        if not gk.exists():
            gk.write_text("", encoding="utf-8")
    return root


def case_id(target: str, query: str = "") -> str:
    day = datetime.now(timezone.utc).strftime("%Y%m%d")
    digest = hashlib.sha1(f"{target}|{query}|{day}".encode()).hexdigest()[:6].upper()
    return f"SEN-{day}-{digest}"


def _j(obj: Any, limit: int = 4000) -> str:
    s = json.dumps(obj, ensure_ascii=False, indent=2, default=str)
    return s if len(s) <= limit else s[:limit] + "\n…(truncated)"


def write_case(pipeline_result: Any, out_dir: Optional[str] = None) -> Path:
    lab = ensure_workspace(Path(out_dir) if out_dir else None)
    data = pipeline_result.to_dict() if hasattr(pipeline_result, "to_dict") else dict(pipeline_result)
    cid = case_id(data.get("target", "unknown"), data.get("query", ""))
    md_path = lab / "reports" / f"{cid}.md"
    json_path = lab / "reports" / f"{cid}.json"

    route = data.get("route") or {}
    syn = data.get("synthesis") or {}
    stages = {st.get("name"): st for st in (data.get("stages") or [])}
    triage = (stages.get("TRIAGE") or {}).get("data") or {}
    static = (stages.get("STATIC") or {}).get("data") or {}
    dynamic = (stages.get("DYNAMIC") or {}).get("data") or {}
    algo = (stages.get("ALGORITHM") or {}).get("data") or {}
    fp = triage.get("fingerprint") or {}

    lines = [
        f"# Sentinel Case {cid}",
        "",
        f"> 自动生成 · 攻防一体 · 可复现",
        "",
        "## 1. 样本信息",
        "",
        f"| 字段 | 值 |",
        f"|------|----|",
        f"| Case | `{cid}` |",
        f"| Target | `{data.get('target')}` |",
        f"| Query | {data.get('query')} |",
        f"| Started (UTC) | {data.get('started_at')} |",
        f"| Kind | {fp.get('kind')} / {fp.get('format')} |",
        f"| Size | {fp.get('size')} |",
        f"| SHA256 | `{fp.get('sha256') or 'n/a'}` |",
        f"| MD5 | `{fp.get('md5') or 'n/a'}` |",
        f"| Entropy | {fp.get('entropy')} | packed={fp.get('packed_hint')} |",
        f"| Arch | {fp.get('arch_guess')} |",
        "",
        "## 2. 分诊结论",
        "",
        f"- **Primary signal**: `{route.get('primary')}`",
        f"- **Signals**: `{' > '.join(route.get('signals') or [])}`",
        f"- **Scores**: `{json.dumps(route.get('scores') or {}, ensure_ascii=False)}`",
        f"- **Modules**: {', '.join(m.get('id','')+':'+m.get('title','') for m in (route.get('modules') or [])[:6])}",
        f"- **Patterns**: {', '.join(p.get('id','')+':'+p.get('name','') for p in (route.get('patterns') or [])[:4])}",
        f"- **Notes**: {'; '.join(fp.get('notes') or []) or '-'}",
        "",
        "### Fingerprint",
        "```json",
        _j(fp, 2500),
        "```",
        "",
        "## 3. 静态分析",
        "",
        "```json",
        _j({k: static.get(k) for k in ("sentinel_scan", "reverse", "malware", "ctf", "modules") if k in static}),
        "```",
        "",
    ]
    if static.get("fallbacks"):
        lines += ["### Fallbacks triggered", "```json", _j(static.get("fallbacks"), 2000), "```", ""]

    lines += [
        "## 4. 动态分析",
        "",
        "```json",
        _j(dynamic, 3500),
        "```",
        "",
        "## 5. 算法还原",
        "",
        "```json",
        _j(algo, 3000),
        "```",
        "",
    ]
    sketch = (algo.get("algo") or {}).get("decrypt_sketch") or ""
    if sketch:
        lines += ["### Decrypt sketch", "```python", sketch[:2000], "```", ""]
    if algo.get("sketch_path"):
        lines.append(f"- Sketch file: `{algo.get('sketch_path')}`")
        lines.append("")

    lines += [
        "## 6. 结论与利用/验证路径",
        "",
        f"- **Severity**: **{syn.get('severity', 'INFO')}**",
        f"- **One-liner**: {syn.get('one_liner', '')}",
        f"- **Risks**:",
    ]
    for r in syn.get("risks") or []:
        lines.append(f"  - `{r}`")
    if not syn.get("risks"):
        lines.append("  - (none)")
    lines += ["- **Evidence**:"]
    for e in syn.get("evidence") or []:
        lines.append(f"  - {e}")
    lines += [
        f"- **Capabilities**: {', '.join(syn.get('capabilities') or []) or '-'}",
        f"- **Plan commands**:",
    ]
    for step in (route.get("plan") or [])[:8]:
        lines.append(f"  1. `{step.get('cmd')}`")

    lines += [
        "",
        "## 7. 防御视角（攻防一体）",
        "",
    ]
    for d in syn.get("defense") or []:
        lines.append(f"- {d}")
    # per-module defense
    for m in (route.get("modules") or [])[:4]:
        lines.append(f"- **{m.get('id')} {m.get('title')}**")
        for d in (m.get("defense") or [])[:3]:
            lines.append(f"  - {d}")

    lines += [
        "",
        "## 8. 附件与复现",
        "",
        "```bash",
        f"python scripts/ops_pipeline.py {data.get('target')} --query \"{data.get('query', '')}\"",
        f"python scripts/ops_router.py \"{data.get('query', '')}\" --target {data.get('target')} --json",
        f"python scripts/ops_triage.py {data.get('target')} --json",
        "```",
        "",
        f"- JSON twin: `{cid}.json`",
        f"- Stages: {', '.join(st.get('name','')+('✓' if st.get('ok') else '✗') for st in (data.get('stages') or []))}",
        "",
    ]

    md_path.write_text("\n".join(lines), encoding="utf-8")
    json_path.write_text(json.dumps(data, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return md_path


def main(argv: Optional[list] = None) -> int:
    import argparse
    parser = argparse.ArgumentParser(description="Ensure ops-lab workspace")
    parser.add_argument("--init", action="store_true")
    parser.add_argument("--path", default="")
    args = parser.parse_args(argv)
    root = ensure_workspace(Path(args.path) if args.path else None)
    print(f"ops-lab ready: {root}")
    for d in LAB_DIRS:
        print(f"  - {d}/")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
