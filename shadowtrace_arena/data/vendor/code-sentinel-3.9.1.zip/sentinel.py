#!/usr/bin/env python3
"""
Code Sentinel — project root entrypoint.

Delegates to scripts/pentest_suite.py so users can run:
  python sentinel.py doctor
  python sentinel.py gpt56 boot
  python sentinel.py pipeline sample.exe --query "..."
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))


def main(argv: list[str] | None = None) -> int:
    import pentest_suite
    return int(pentest_suite.main(argv if argv is not None else sys.argv[1:]) or 0)


if __name__ == "__main__":
    raise SystemExit(main())
