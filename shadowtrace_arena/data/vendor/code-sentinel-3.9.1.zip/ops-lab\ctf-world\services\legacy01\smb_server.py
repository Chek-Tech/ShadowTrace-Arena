#!/usr/bin/env python3
"""Simulated SMB service with null session vulnerability."""
import os, socket, threading, hashlib

FLAG = os.environ.get("FLAG_LEGACY", "CS{test}")
SHARE_PATH = "/smbshare"

# Write a flag file in the share
with open(f"{SHARE_PATH}/flag.txt", "w") as f:
    f.write(FLAG + "\n")
with open(f"{SHARE_PATH}/passwords.txt", "w") as f:
    f.write("admin:Password123\nservice:SvcPass456\nbackup:b@ckup789\n")
with open(f"{SHARE_PATH}/confidential.txt", "w") as f:
    f.write("Internal memos: VPN gateway at 10.0.2.50, creds vpnuser/vpnpass123\n")

def handle_smb(conn, addr):
    """Simulated SMB — accepts any connection, lists shares."""
    conn.settimeout(10)
    try:
        conn.send(b"SMB Null Session Server v1.0\r\n")
        conn.send(b"Username: ")
        user = conn.recv(1024).strip()
        conn.send(b"Password: ")
        pwd = conn.recv(1024).strip()
        # VULN: accepts null session (empty username)
        conn.send(b"\r\nAccess granted (null session)\r\n")
        import glob
        files = glob.glob(f"{SHARE_PATH}/*")
        listing = "\n".join(f.replace(SHARE_PATH, "") for f in files)
        conn.send(f"Shares available:\n{listing}\n".encode())
        while True:
            conn.send(b"\n> ")
            cmd = conn.recv(1024).strip().decode()
            if cmd in ("exit", "quit"): break
            parts = cmd.split()
            if parts[0] == "read" and len(parts) > 1:
                fn = parts[1].replace("..", "").replace("/", "")
                try:
                    with open(f"{SHARE_PATH}/{fn}") as f:
                        conn.send(f.read().encode())
                except:
                    conn.send(b"File not found\n")
            elif parts[0] == "list":
                for f in files:
                    conn.send(f"{f.replace(SHARE_PATH, '')}\n".encode())
            else:
                conn.send(b"Commands: read <file>, list, exit\n")
    except:
        pass
    finally:
        conn.close()

s = socket.socket()
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("0.0.0.0", 445))
s.listen(5)
print("[*] SMB Null Session on :445")
while True:
    c, a = s.accept()
    threading.Thread(target=handle_smb, args=(c, a), daemon=True).start()
