#!/usr/bin/env python3
"""
Sentinel PTES Lab — original engagement orchestrator.

Technical essences distilled (re-implemented, NOT ported):
  * Standard multi-phase engagement lifecycle (scope → recon → model →
    analyze → exploit → post → report)
  * Split recon into host/service recon + optional web pretest when HTTP is in play
  * Phase-to-phase handoff via machine-readable manifests (not tribal chat memory)
  * Per-target workspace contract: ports / services / vulns / solutions / report
  * Hard transition gate before advancing (evidence written, temp cleaned, next KB primed)
  * Prior-phase outputs drive next knowledge/tool selection (not generic keyword search)
  * URL targets may short-circuit pure-scope when scope already explicit
  * Parallel-capable work units within a phase (declared as work packages)

All IDs, paths, checklists, and prose are Code Sentinel originals.
No third-party skill text, templates, or knowledge corpus is copied here.
"""

from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

_SCRIPTS = Path(__file__).resolve().parent
_ROOT = _SCRIPTS.parent
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))

PROTOCOL = "sentinel-ptes-lab-v1"

# ---------------------------------------------------------------------------
# Phase catalog (Sentinel-native IDs)
# ---------------------------------------------------------------------------
PHASES: list[dict[str, Any]] = [
    {
        "id": "L0",
        "name": "scope",
        "title": "范围与授权对齐",
        "goals": ["目标清单", "深度/禁区", "时间窗", "明确授权确认"],
        "success": "范围可复述且用户已确认可执行",
        "artifacts": ["scope.json", "authorization.md"],
        "tools": ["ops_sandbox", "ops_framing", "ops_tool_index"],
        "kb_hints": ["references/ops-method.md", "references/ops-sandbox-protocol.md"],
        "work_packages": [
            {"id": "W0a", "title": "参数补齐", "parallel": False},
            {"id": "W0b", "title": "合规核对", "parallel": False},
        ],
    },
    {
        "id": "L1",
        "name": "recon",
        "title": "情报收集 / 主机与服务测绘",
        "goals": ["端口/服务", "指纹", "OSINT 线索", "入口候选"],
        "success": "ports + services 有可验证清单",
        "artifacts": ["ports/", "services/", "scans/"],
        "tools": ["pentest_recon", "re_surface", "ops_surface_matrix", "ops_tool_index"],
        "kb_hints": ["references/gpt56-reverse-pentest/kali-toolchain.md"],
        "work_packages": [
            {"id": "W1a", "title": "TCP/服务探测", "parallel": True},
            {"id": "W1b", "title": "DNS/OSINT", "parallel": True},
            {"id": "W1c", "title": "非 Web 服务枚举", "parallel": True},
        ],
    },
    {
        "id": "L1W",
        "name": "web_pretest",
        "title": "Web 预检 / 应用面快扫",
        "goals": ["入口 URL 地图", "表单/API 线索", "安全头/基础误配", "截图/HTML 证据位"],
        "success": "web_map 与至少一条可验证 web 观察",
        "artifacts": ["web/", "screenshots/"],
        "tools": ["web_pentest", "pentest_recon", "ops_ctf_runner"],
        "kb_hints": [
            "references/gpt56-reverse-pentest/web-payloads.md",
            "references/gpt56-reverse-pentest/web-reverse.md",
            "references/gpt56-reverse-pentest/api-security.md",
        ],
        "work_packages": [
            {"id": "W1w1", "title": "页面/链接地图", "parallel": True},
            {"id": "W1w2", "title": "基础漏洞探针", "parallel": True},
        ],
        "optional": True,
        "when": "http_surface",
    },
    {
        "id": "L2",
        "name": "threat_model",
        "title": "威胁建模 / 攻击面排序",
        "goals": ["资产分级", "信任边界", "优先攻击路径", "STRIDE 式面清单"],
        "success": "threat_model.md 含优先级排序",
        "artifacts": ["threat_model.md"],
        "tools": ["ops_surface_matrix", "ops_chain", "ops_method_packs"],
        "kb_hints": ["references/deep-analysis.md", "references/ops-method.md"],
        "work_packages": [
            {"id": "W2a", "title": "资产与边界", "parallel": False},
            {"id": "W2b", "title": "路径排序", "parallel": False},
        ],
    },
    {
        "id": "L3",
        "name": "vuln_analysis",
        "title": "漏洞分析 / 验证与评级",
        "goals": ["候选漏洞", "可复现步骤", "严重性", "误报剔除"],
        "success": "vulns/ 至少一条含证据指针的发现（或明确无发现）",
        "artifacts": ["vulns/"],
        "tools": ["web_pentest", "ctf_toolkit", "ops_pipeline", "sentinel_scan"],
        "kb_hints": [
            "references/gpt56-reverse-pentest/api-security.md",
            "references/ai-output-schema.md",
        ],
        "work_packages": [
            {"id": "W3a", "title": "自动化面扫", "parallel": True},
            {"id": "W3b", "title": "手工验证", "parallel": True},
        ],
    },
    {
        "id": "L4",
        "name": "exploitation",
        "title": "利用验证 / 最小据点",
        "goals": ["受控 PoC", "权威态确认", "影响说明"],
        "success": "在授权范围内证明可达或不可达",
        "artifacts": ["exploits/", "loot/"],
        "tools": ["ctf_toolkit", "ops_pipeline", "ops_payloads", "web_pentest"],
        "kb_hints": ["references/gpt56-reverse-pentest/reverse-cheatsheet.md"],
        "work_packages": [
            {"id": "W4a", "title": "PoC 构造", "parallel": False},
            {"id": "W4b", "title": "证据固化", "parallel": False},
        ],
    },
    {
        "id": "L5",
        "name": "post_exploitation",
        "title": "后利用 / 权限与横向（授权范围内）",
        "goals": ["权限边界", "横向候选", "凭证/会话面", "业务影响"],
        "success": "post.md 记录实际跨越或明确停止线",
        "artifacts": ["post/", "loot/"],
        "tools": ["pentest_recon", "ops_chain", "ops_surface_matrix"],
        "kb_hints": [
            "references/gpt56-reverse-pentest/linux-privesc.md",
            "references/gpt56-reverse-pentest/edr-bypass.md",
        ],
        "work_packages": [
            {"id": "W5a", "title": "本机面", "parallel": True},
            {"id": "W5b", "title": "网络横向面", "parallel": True},
        ],
    },
    {
        "id": "L6",
        "name": "reporting",
        "title": "报告与证据打包",
        "goals": ["结构化报告", "证据索引", "修复建议", "复测点"],
        "success": "report.md 通过交付检查清单",
        "artifacts": ["report.md", "evidence_index.json"],
        "tools": ["ops_report_contract", "ops_case", "ops_anon", "ops_journal"],
        "kb_hints": ["references/review-policy.md", "references/ai-output-schema.md"],
        "work_packages": [
            {"id": "W6a", "title": "报告草稿", "parallel": False},
            {"id": "W6b", "title": "脱敏与校验", "parallel": False},
        ],
    },
]

PHASE_ORDER = [p["id"] for p in PHASES]
PHASE_BY_ID = {p["id"]: p for p in PHASES}

# Transition gate — original wording (essence: force evidence continuity)
TRANSITION_CHECKS: list[dict[str, str]] = [
    {"id": "T1", "title": "读取上阶段产物", "do": "打开 manifests 与 ports/services/vulns 等权威目录"},
    {"id": "T2", "title": "本阶段产物落盘", "do": "本阶段 findings 已写入 target 目录，非仅聊天记录"},
    {"id": "T3", "title": "经验回灌", "do": "可复用方法记入 solutions.md 或 knowledge 卡片"},
    {"id": "T4", "title": "临时物清理", "do": "扫描缓存/一次性 payload 移入 tmp 或删除"},
    {"id": "T5", "title": "下阶段知识预热", "do": "按本阶段输出关键词加载 kb_hints / 本地 references"},
    {"id": "T6", "title": "工具可用性", "do": "ops_tool_index 确认下阶段 tools 可用或有 fallback"},
    {"id": "T7", "title": "缺口外查策略", "do": "本地无方法时用「端口/服务/版本/CVE」关键词外查，禁止空转"},
    {"id": "T8", "title": "进度告知", "do": "向用户报告当前阶段、已完成、下一步"},
]

TARGET_DIRS = (
    "ports",
    "services",
    "vulns",
    "web",
    "scans",
    "screenshots",
    "exploits",
    "post",
    "loot",
    "manifests",
    "tmp",
)


def _utc() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def lab_root(base: Optional[Path] = None) -> Path:
    root = Path(base) if base else (_ROOT / "ops-lab")
    root.mkdir(parents=True, exist_ok=True)
    return root


def slugify_target(target: str) -> str:
    t = target.strip()
    t = re.sub(r"^https?://", "", t, flags=re.I)
    t = t.split("/")[0]
    t = re.sub(r"[^\w.\-]+", "_", t)
    return t[:80] or "target"


def is_url_target(target: str) -> bool:
    return bool(re.match(r"^https?://", target.strip(), re.I))


def targets_root(base: Optional[Path] = None) -> Path:
    p = lab_root(base) / "targets"
    p.mkdir(parents=True, exist_ok=True)
    return p


def target_dir(target: str, base: Optional[Path] = None) -> Path:
    return targets_root(base) / slugify_target(target)


def init_target(
    target: str,
    *,
    base: Optional[Path] = None,
    depth: str = "standard",
    notes: str = "",
    force: bool = False,
) -> dict[str, Any]:
    """Create per-target workspace contract (original schema)."""
    td = target_dir(target, base)
    if td.exists() and not force:
        state = load_state(target, base)
        return {
            "ok": True,
            "created": False,
            "path": str(td),
            "slug": slugify_target(target),
            "state": state,
            "message": "target exists — use --force to reinit skeleton files",
        }

    for name in TARGET_DIRS:
        (td / name).mkdir(parents=True, exist_ok=True)

    url = is_url_target(target)
    start_phase = "L1" if url else "L0"
    state = {
        "protocol": PROTOCOL,
        "target": target,
        "slug": slugify_target(target),
        "created_at": _utc(),
        "updated_at": _utc(),
        "depth": depth,
        "url_shortcut": url,
        "current_phase": start_phase,
        "completed_phases": [],
        "skipped_phases": ["L0"] if url else [],
        "notes": notes,
        "http_surface": url,
    }
    _write_json(td / "state.json", state)
    _write_text(
        td / "authorization.md",
        "# Authorization\n\n"
        "- Scope target: `{t}`\n"
        "- Confirm authorized engagement before active tests.\n"
        "- Depth: `{d}`\n"
        "- Created: {ts}\n".format(t=target, d=depth, ts=_utc()),
    )
    _write_json(
        td / "scope.json",
        {
            "target": target,
            "depth": depth,
            "url": url,
            "in_scope": [target],
            "out_of_scope": [],
            "constraints": [],
        },
    )
    _write_text(td / "solutions.md", "# Solutions ledger\n\n| Time | Phase | Note | Artifact |\n|------|-------|------|----------|\n")
    _write_text(td / "threat_model.md", "# Threat model\n\n(pending L2)\n")
    _write_text(td / "report.md", "# Engagement report\n\n(pending L6)\n")
    _write_json(td / "evidence_index.json", {"items": []})

    # seed empty indexes
    _write_text(td / "ports" / "README.md", "# Ports\n\nDrop recon outputs here.\n")
    _write_text(td / "services" / "README.md", "# Services\n")
    _write_text(td / "vulns" / "README.md", "# Vulnerabilities\n")

    return {
        "ok": True,
        "created": True,
        "path": str(td),
        "slug": state["slug"],
        "state": state,
        "next": plan_phase(start_phase, target=target),
        "message": f"initialized; start at {start_phase}"
        + (" (URL shortcut: L0 skipped)" if url else ""),
    }


def load_state(target: str, base: Optional[Path] = None) -> dict[str, Any]:
    td = target_dir(target, base)
    sp = td / "state.json"
    if not sp.is_file():
        raise FileNotFoundError(f"no state.json — run init first: {td}")
    return json.loads(sp.read_text(encoding="utf-8"))


def save_state(target: str, state: dict[str, Any], base: Optional[Path] = None) -> None:
    state["updated_at"] = _utc()
    _write_json(target_dir(target, base) / "state.json", state)


def validate_schema(target: str, base: Optional[Path] = None) -> dict[str, Any]:
    td = target_dir(target, base)
    missing = [d for d in TARGET_DIRS if not (td / d).is_dir()]
    files_ok = {
        "state.json": (td / "state.json").is_file(),
        "scope.json": (td / "scope.json").is_file(),
        "solutions.md": (td / "solutions.md").is_file(),
        "report.md": (td / "report.md").is_file(),
    }
    return {
        "path": str(td),
        "ok": not missing and all(files_ok.values()),
        "missing_dirs": missing,
        "files": files_ok,
    }


def plan_phase(phase_id: str, *, target: str = "{target}") -> dict[str, Any]:
    phase = PHASE_BY_ID.get(phase_id)
    if not phase:
        raise KeyError(f"unknown phase: {phase_id}")
    cmds = []
    for tool in phase.get("tools") or []:
        cmds.append(_tool_cmd(tool, target))
    return {
        "phase": {k: phase[k] for k in ("id", "name", "title", "goals", "success") if k in phase},
        "artifacts": phase.get("artifacts"),
        "tools": phase.get("tools"),
        "kb_hints": phase.get("kb_hints"),
        "work_packages": phase.get("work_packages"),
        "commands": cmds,
        "optional": phase.get("optional", False),
        "when": phase.get("when"),
    }


def _tool_cmd(tool: str, target: str) -> str:
    mapping = {
        "pentest_recon": f"python scripts/pentest_recon.py {target} --json",
        "web_pentest": f"python scripts/web_pentest.py {target} --json",
        "re_surface": f"python scripts/re_surface.py {target} --json",
        "ops_surface_matrix": f'python scripts/ops_surface_matrix.py route "{target}" --json',
        "ops_chain": f'python scripts/ops_chain.py plan --query "{target}"',
        "ops_tool_index": "python scripts/ops_tool_index.py refresh",
        "ops_pipeline": f'python scripts/ops_pipeline.py {target} --query "ptes"',
        "ops_ctf_runner": "python scripts/ops_ctf_runner.py resume .",
        "ops_report_contract": "python scripts/ops_report_contract.py checklist",
        "ops_case": "python scripts/ops_case.py",
        "ops_sandbox": "python scripts/ops_sandbox.py status",
        "ops_framing": f'python scripts/ops_framing.py auto --text "{target}"',
        "ops_method_packs": f'python scripts/ops_method_packs.py route "{target}"',
        "ops_payloads": "python scripts/ops_payloads.py list",
        "ops_anon": "python scripts/ops_anon.py run --text sample",
        "ops_journal": f'python scripts/ops_journal.py suggest "{target}"',
        "ctf_toolkit": f"python scripts/ctf_toolkit.py {target}",
        "sentinel_scan": f"python scripts/sentinel_scan.py {target} --fail-on HIGH",
    }
    return mapping.get(tool, f"python scripts/{tool}.py")


def write_manifest(
    target: str,
    phase_id: str,
    *,
    summary: str = "",
    outputs: Optional[list[str]] = None,
    findings: Optional[list[dict[str, Any]]] = None,
    signals: Optional[dict[str, Any]] = None,
    base: Optional[Path] = None,
) -> Path:
    """Write phase handoff manifest — next phase must read this first."""
    td = target_dir(target, base)
    phase = PHASE_BY_ID[phase_id]
    manifest = {
        "protocol": PROTOCOL,
        "phase_id": phase_id,
        "phase_name": phase["name"],
        "target": target,
        "written_at": _utc(),
        "summary": summary,
        "outputs": outputs or [],
        "findings": findings or [],
        "signals": signals or {},
        "kb_drive": _kb_drive_from_signals(signals or {}, findings or []),
        "next_phase": _next_phase_id(phase_id, http_surface=bool((signals or {}).get("http_surface"))),
    }
    path = td / "manifests" / f"manifest-{phase_id}.json"
    _write_json(path, manifest)
    # append solutions ledger line if summary
    if summary:
        append_solution(target, phase_id, summary, str(path), base=base)
    return path


def read_manifest(target: str, phase_id: str, base: Optional[Path] = None) -> dict[str, Any]:
    path = target_dir(target, base) / "manifests" / f"manifest-{phase_id}.json"
    if not path.is_file():
        raise FileNotFoundError(str(path))
    return json.loads(path.read_text(encoding="utf-8"))


def list_manifests(target: str, base: Optional[Path] = None) -> list[str]:
    md = target_dir(target, base) / "manifests"
    if not md.is_dir():
        return []
    return sorted(p.stem.replace("manifest-", "") for p in md.glob("manifest-*.json"))


def _kb_drive_from_signals(signals: dict[str, Any], findings: list[dict[str, Any]]) -> dict[str, Any]:
    """Prior outputs drive next knowledge — essence reimplemented."""
    ports = signals.get("ports") or []
    services = signals.get("services") or []
    cves = signals.get("cves") or []
    for f in findings:
        if f.get("cve"):
            cves.append(f["cve"])
        if f.get("service"):
            services.append(f["service"])
    keywords = []
    for p in ports[:20]:
        keywords.append(str(p))
    for s in services[:20]:
        keywords.append(str(s))
    for c in cves[:20]:
        keywords.append(str(c))
    return {
        "keywords": keywords,
        "query_hint": " ".join(keywords[:12]),
        "prefer_local_refs": True,
        "fallback": "web_search with port/service/version/CVE tokens only",
    }


def _next_phase_id(phase_id: str, *, http_surface: bool = False) -> Optional[str]:
    order = list(PHASE_ORDER)
    # dynamic insert L1W after L1 when HTTP
    if phase_id == "L1" and http_surface:
        return "L1W"
    if phase_id == "L1" and not http_surface:
        return "L2"
    if phase_id == "L1W":
        return "L2"
    try:
        i = order.index(phase_id)
    except ValueError:
        return None
    if i + 1 < len(order):
        nxt = order[i + 1]
        if nxt == "L1W":
            return order[i + 2] if i + 2 < len(order) else None
        return nxt
    return None


def transition_checklist(
    target: str,
    phase_id: str,
    *,
    base: Optional[Path] = None,
    checked: Optional[list[str]] = None,
) -> dict[str, Any]:
    """Evaluate transition gate (manual check ids may be supplied)."""
    checked_set = set(checked or [])
    td = target_dir(target, base)
    auto: dict[str, bool] = {}
    auto["T1"] = bool(list_manifests(target, base)) or (td / "ports").exists()
    auto["T2"] = (td / "manifests" / f"manifest-{phase_id}.json").is_file()
    auto["T3"] = (td / "solutions.md").is_file() and (td / "solutions.md").stat().st_size > 40
    auto["T4"] = True  # advisory
    auto["T5"] = True
    auto["T6"] = True
    auto["T7"] = True
    auto["T8"] = True

    rows = []
    for item in TRANSITION_CHECKS:
        cid = item["id"]
        ok = cid in checked_set or auto.get(cid, False)
        rows.append({**item, "ok": ok, "auto": auto.get(cid, False)})

    passed = all(r["ok"] for r in rows)
    return {
        "phase_id": phase_id,
        "passed": passed,
        "checks": rows,
        "next_phase": _next_phase_id(
            phase_id,
            http_surface=bool(load_state(target, base).get("http_surface")),
        )
        if passed
        else None,
        "message": "transition OK" if passed else "transition blocked — complete failed checks",
    }


def advance(
    target: str,
    *,
    base: Optional[Path] = None,
    force: bool = False,
    summary: str = "",
    mark_http: Optional[bool] = None,
) -> dict[str, Any]:
    """Complete current phase (write minimal manifest if missing) and move forward."""
    state = load_state(target, base)
    cur = state["current_phase"]
    if mark_http is not None:
        state["http_surface"] = bool(mark_http)

    man_path = target_dir(target, base) / "manifests" / f"manifest-{cur}.json"
    if not man_path.is_file():
        write_manifest(
            target,
            cur,
            summary=summary or f"phase {cur} closed",
            signals={"http_surface": state.get("http_surface", False)},
            base=base,
        )

    gate = transition_checklist(target, cur, base=base)
    if not gate["passed"] and not force:
        return {"ok": False, "gate": gate, "state": state, "message": "gate failed"}

    if cur not in state["completed_phases"]:
        state["completed_phases"].append(cur)
    nxt = _next_phase_id(cur, http_surface=bool(state.get("http_surface")))
    if nxt:
        state["current_phase"] = nxt
    save_state(target, state, base)
    return {
        "ok": True,
        "completed": cur,
        "current_phase": state["current_phase"],
        "next_plan": plan_phase(state["current_phase"], target=target) if nxt else None,
        "gate": gate,
        "state": state,
    }


def append_solution(
    target: str,
    phase_id: str,
    note: str,
    artifact: str = "",
    base: Optional[Path] = None,
) -> None:
    path = target_dir(target, base) / "solutions.md"
    line = f"| {_utc()} | {phase_id} | {note.replace('|', '/')} | {artifact} |\n"
    if path.is_file():
        text = path.read_text(encoding="utf-8")
        if not text.endswith("\n"):
            text += "\n"
        path.write_text(text + line, encoding="utf-8")
    else:
        path.write_text(
            "# Solutions ledger\n\n| Time | Phase | Note | Artifact |\n|------|-------|------|----------|\n" + line,
            encoding="utf-8",
        )


def engagement_status(target: str, base: Optional[Path] = None) -> dict[str, Any]:
    state = load_state(target, base)
    schema = validate_schema(target, base)
    cur = state["current_phase"]
    return {
        "protocol": PROTOCOL,
        "state": state,
        "schema": schema,
        "manifests": list_manifests(target, base),
        "current_plan": plan_phase(cur, target=target),
        "phases": [{"id": p["id"], "title": p["title"]} for p in PHASES],
    }


def report_brief(target: str, base: Optional[Path] = None) -> dict[str, Any]:
    """Generate a minimal report skeleton from manifests (no third-party template)."""
    state = load_state(target, base)
    td = target_dir(target, base)
    manifests = []
    for pid in list_manifests(target, base):
        try:
            manifests.append(read_manifest(target, pid, base))
        except Exception:
            pass
    lines = [
        f"# Sentinel Engagement Report — {state.get('target')}",
        "",
        f"- Protocol: `{PROTOCOL}`",
        f"- Slug: `{state.get('slug')}`",
        f"- Generated: {_utc()}",
        f"- Depth: {state.get('depth')}",
        f"- Completed: {', '.join(state.get('completed_phases') or []) or '(none)'}",
        "",
        "## Executive summary",
        "",
        state.get("notes") or "(fill after L6)",
        "",
        "## Phase timeline",
        "",
    ]
    for m in manifests:
        lines.append(f"### {m.get('phase_id')} — {m.get('phase_name')}")
        lines.append("")
        lines.append(m.get("summary") or "")
        lines.append("")
        if m.get("findings"):
            lines.append("Findings:")
            for f in m["findings"]:
                lines.append(f"- {json.dumps(f, ensure_ascii=False)}")
            lines.append("")
    lines.extend(
        [
            "## Remediation priorities",
            "",
            "1. (critical)",
            "2. (high)",
            "3. (hardening)",
            "",
            "## Evidence index",
            "",
            f"See `{td / 'evidence_index.json'}` and per-phase manifests under `manifests/`.",
            "",
        ]
    )
    report_path = td / "report.md"
    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"ok": True, "report": str(report_path), "manifest_count": len(manifests)}


def list_targets(base: Optional[Path] = None) -> list[dict[str, Any]]:
    root = targets_root(base)
    rows = []
    for d in sorted(root.iterdir()):
        if not d.is_dir():
            continue
        sp = d / "state.json"
        if not sp.is_file():
            continue
        try:
            st = json.loads(sp.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            continue
        rows.append(
            {
                "slug": d.name,
                "target": st.get("target"),
                "current_phase": st.get("current_phase"),
                "completed": st.get("completed_phases"),
            }
        )
    return rows


def phase_table() -> list[dict[str, Any]]:
    return [
        {
            "id": p["id"],
            "name": p["name"],
            "title": p["title"],
            "tools": p.get("tools"),
            "optional": p.get("optional", False),
        }
        for p in PHASES
    ]


def _write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Sentinel PTES Lab (original)")
    p.add_argument("--base", default=None, help="ops-lab root override")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("phases", help="list phase catalog")
    sub.add_parser("targets", help="list engagement targets")

    i = sub.add_parser("init", help="init target workspace")
    i.add_argument("target")
    i.add_argument("--depth", default="standard")
    i.add_argument("--notes", default="")
    i.add_argument("--force", action="store_true")

    s = sub.add_parser("status", help="engagement status")
    s.add_argument("target")

    pl = sub.add_parser("plan", help="plan a phase")
    pl.add_argument("phase")
    pl.add_argument("--target", default="{target}")

    m = sub.add_parser("manifest", help="write phase manifest")
    m.add_argument("target")
    m.add_argument("phase")
    m.add_argument("--summary", default="")
    m.add_argument("--http", action="store_true", help="mark http_surface in signals")

    a = sub.add_parser("advance", help="close current phase and advance")
    a.add_argument("target")
    a.add_argument("--summary", default="")
    a.add_argument("--force", action="store_true")
    a.add_argument("--http", action="store_true", help="set http_surface true")
    a.add_argument("--no-http", action="store_true", help="set http_surface false")

    g = sub.add_parser("gate", help="run transition checklist")
    g.add_argument("target")
    g.add_argument("--phase", default=None)

    v = sub.add_parser("validate", help="validate target schema")
    v.add_argument("target")

    r = sub.add_parser("report", help="build report brief from manifests")
    r.add_argument("target")

    sol = sub.add_parser("solution", help="append solutions ledger line")
    sol.add_argument("target")
    sol.add_argument("note")
    sol.add_argument("--phase", default="")
    sol.add_argument("--artifact", default="")

    args = p.parse_args(argv)
    base = Path(args.base) if args.base else None

    def dump(obj: Any) -> int:
        print(json.dumps(obj, ensure_ascii=False, indent=2, default=str))
        return 0

    try:
        if args.cmd == "phases":
            return dump({"protocol": PROTOCOL, "phases": phase_table(), "transition": TRANSITION_CHECKS})
        if args.cmd == "targets":
            return dump({"targets": list_targets(base)})
        if args.cmd == "init":
            return dump(init_target(args.target, base=base, depth=args.depth, notes=args.notes, force=args.force))
        if args.cmd == "status":
            return dump(engagement_status(args.target, base))
        if args.cmd == "plan":
            return dump(plan_phase(args.phase, target=args.target))
        if args.cmd == "manifest":
            path = write_manifest(
                args.target,
                args.phase,
                summary=args.summary,
                signals={"http_surface": bool(args.http)},
                base=base,
            )
            if args.http:
                st = load_state(args.target, base)
                st["http_surface"] = True
                save_state(args.target, st, base)
            return dump({"ok": True, "manifest": str(path)})
        if args.cmd == "advance":
            mh = True if args.http else (False if args.no_http else None)
            return dump(advance(args.target, base=base, force=args.force, summary=args.summary, mark_http=mh))
        if args.cmd == "gate":
            st = load_state(args.target, base)
            phase = args.phase or st["current_phase"]
            return dump(transition_checklist(args.target, phase, base=base))
        if args.cmd == "validate":
            return dump(validate_schema(args.target, base))
        if args.cmd == "report":
            return dump(report_brief(args.target, base))
        if args.cmd == "solution":
            st = load_state(args.target, base)
            phase = args.phase or st.get("current_phase") or "L?"
            append_solution(args.target, phase, args.note, args.artifact, base=base)
            return dump({"ok": True})
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
