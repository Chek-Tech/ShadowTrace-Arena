#!/usr/bin/env python3
"""
Sentinel Surface Matrix — multi-axis evidence-surface router (original).

Technical essences learned (re-implemented, not copied):
  1) Route BEFORE deep work: target-type × user-intent × dominant evidence surface.
  2) Stay generic until one surface dominates; then narrow to a surface playbook.
  3) Re-route when the blocker no longer matches the active surface.
  4) Large surface catalog as compact structured data (not third-party SKILL prose).
  5) MUST emit routing rationale (why this surface / tools).

Maps surfaces → Code Sentinel local modules + short original focus checklists.
Complements S1–S8 (ops_router) and M01–M25 (ops_modules); does not replace them.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import asdict, dataclass, field
from typing import Any, Optional


# ---------------------------------------------------------------------------
# Surface catalog (id → playbook). Original condensed focus, lab framing.
# ---------------------------------------------------------------------------
@dataclass
class Surface:
    id: str
    title: str
    family: str  # web | reverse | identity | cloud | mobile | crypto | special
    cues: list[str]
    focus: list[str]
    tools: list[str]
    signals: list[str] = field(default_factory=list)
    re_route_when: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


SURFACES: dict[str, Surface] = {}


def _s(**kwargs) -> Surface:
    s = Surface(**kwargs)
    SURFACES[s.id] = s
    return s


# --- Web / runtime ---
_s(
    id="web-runtime",
    title="Web 运行时 / API 面",
    family="web",
    cues=[r"web|api|http|https|session|cookie|cors|csrf|upload|路由|鉴权"],
    focus=["入口 HTML/路由注册", "鉴权会话流", "隐藏端点/worker", "上传与缓存"],
    tools=["web_pentest", "ops_ctf_runner", "pentest_recon"],
    signals=["S6"],
    re_route_when="主导阻塞变为 WS/GraphQL/JWT/SSRF 等更窄面",
)
_s(
    id="browser-persist",
    title="浏览器持久化面",
    family="web",
    cues=[r"localStorage|sessionStorage|indexeddb|service.?worker|cache.?storage|浏览器存储"],
    focus=["存储键与信任边界", "SW 拦截范围", "缓存投毒面", "与服务端会话一致性"],
    tools=["web_pentest", "ops_ctf_runner"],
    signals=["S6"],
)
_s(
    id="websocket",
    title="WebSocket / 实时通道",
    family="web",
    cues=[r"websocket|ws://|wss://|sse\b|订阅|reconnect|实时帧"],
    focus=["握手鉴权", "订阅主题", "重连状态机", "帧级注入/重放"],
    tools=["web_pentest", "attack_network"],
    signals=["S6", "S5"],
)
_s(
    id="runtime-routing",
    title="主机头 / 反代路由",
    family="web",
    cues=[r"host.?header|vhost|反向代理|nginx|traefik|路由解析|x-forwarded"],
    focus=["Host 信任", "内外路由差", "头伪造影响", "后端选路"],
    tools=["web_pentest", "ops_ctf_runner"],
    signals=["S6"],
)
_s(
    id="template-render",
    title="模板 / SSR 渲染路径",
    family="web",
    cues=[r"ssti|jinja|freemarker|twig|ssr|hydration|模板注入"],
    focus=["模板引擎边界", "用户可控插值", "渲染层鉴权漂移"],
    tools=["web_pentest", "sentinel_scan"],
    signals=["S6", "S1"],
)
_s(
    id="bundle-sourcemap",
    title="前端 Bundle / SourceMap 恢复",
    family="web",
    cues=[r"sourcemap|\.map\b|webpack|chunk|bundle|前端还原"],
    focus=["map 泄露", "chunk 加载链", "签名/加密函数定位"],
    tools=["web_pentest", "ctf_toolkit", "ops_algo"],
    signals=["S6", "S4"],
)
_s(
    id="graphql-rpc",
    title="GraphQL / RPC 契约漂移",
    family="web",
    cues=[r"graphql|persisted.?query|rpc|grpc|schema|introspection"],
    focus=["内省与字段授权", "批量/嵌套 DoS", "客户端契约 vs 服务端"],
    tools=["web_pentest", "pentest_recon"],
    signals=["S6"],
)
_s(
    id="oauth-oidc",
    title="OAuth / OIDC 链",
    family="identity",
    cues=[r"oauth|oidc|pkce|redirect_uri|callback|授权码|id_token"],
    focus=["redirect 绑定", "state/nonce", "claim 接受策略", "token 互换"],
    tools=["web_pentest", "ops_algo"],
    signals=["S6", "S4"],
)
_s(
    id="jwt-claim",
    title="JWT Claim 混淆",
    family="identity",
    cues=[r"jwt|kid\b|alg\b|none\b|issuer|audience|claim|jwk"],
    focus=["alg/kid 混淆", "iss/aud 校验", "角色 claim 篡改", "密钥来源"],
    tools=["ops_algo", "web_pentest", "ctf_toolkit"],
    signals=["S4", "S6"],
)
_s(
    id="file-parser",
    title="上传 / 解析器链",
    family="web",
    cues=[r"upload|zip.?slip|反序列化|解析器|preview|archive|xxe"],
    focus=["魔数与扩展名差", "解压路径", "预览转换链", "反序列化入口"],
    tools=["web_pentest", "malware_analysis"],
    signals=["S6", "S3"],
)
_s(
    id="queue-worker",
    title="队列 / Worker 漂移",
    family="web",
    cues=[r"queue|worker|cron|retry|celery|sidekiq|后台任务|webhook"],
    focus=["任务鉴权", "重试副作用", "仅 worker 可达路径", "下游影响"],
    tools=["sentinel_scan", "web_pentest"],
    signals=["S1", "S6"],
)
_s(
    id="ssrf-metadata",
    title="SSRF / 元数据枢轴",
    family="cloud",
    cues=[r"ssrf|169\.254|metadata|imds|link.?local|云元数据"],
    focus=["出站可控 URL", "重定向跟随", "元数据 token", "内网 pivot"],
    tools=["web_pentest", "pentest_recon"],
    signals=["S6", "S5"],
)
_s(
    id="race-state",
    title="竞态 / 状态漂移",
    family="web",
    cues=[r"race|竞态|toctou|idempoten|并发|限购|扣减"],
    focus=["读写窗口", "幂等键", "最终权威态", "时序差分"],
    tools=["web_pentest", "ops_ctf_runner"],
    signals=["S6"],
)
_s(
    id="http-smuggle",
    title="请求归一化 / 走私",
    family="web",
    cues=[r"smuggl|cl\.te|te\.cl|http.?request.?smuggl|归一化|路径穿越代理"],
    focus=["代理/后端解析差", "路径规范化", "分帧歧义"],
    tools=["web_pentest", "attack_network"],
    signals=["S6"],
)
_s(
    id="payment-callback",
    title="支付 / 回调 / 订单",
    family="web",
    cues=[r"支付|回调|notify|订单|签名|商户|支付回调"],
    focus=["签名归一化", "重复参数", "notify 可达性", "最终订单态"],
    tools=["web_pentest", "ops_algo"],
    signals=["S6", "S4"],
)

# --- Reverse / DFIR ---
_s(
    id="reverse-pwn",
    title="二进制逆向 / Pwn 原语",
    family="reverse",
    cues=[r"pwn|rop|溢出|uaf|crash|elf|pe\b|mitigation|shellcode|ret2"],
    focus=["格式与缓解", "可控字节/泄漏", "崩溃偏移", "协议帧"],
    tools=["reverse_engineering", "ctf_toolkit", "re_surface"],
    signals=["S2", "S7"],
)
_s(
    id="malware-config",
    title="样本配置 / C2 解码",
    family="reverse",
    cues=[r"c2|beacon|配置解密|ioc|样本配置|staged"],
    focus=["配置层定位", "解码链", "IOC 提取", "分阶段加载"],
    tools=["malware_analysis", "reverse_engineering", "ops_algo"],
    signals=["S3", "S2"],
)
_s(
    id="firmware",
    title="固件布局 / 提取",
    family="reverse",
    cues=[r"firmware|固件|binwalk|squashfs|ubi|boot.?chain|iot"],
    focus=["分区表", "文件系统提取", "默认凭据", "更新包完整性"],
    tools=["reverse_engineering", "ctf_toolkit"],
    signals=["S2", "S8"],
)
_s(
    id="pcap-protocol",
    title="PCAP / 协议重建",
    family="reverse",
    cues=[r"pcap|wireshark|协议逆向|tcp.?stream|自定义协议"],
    focus=["流重组", "状态机", "校验和", "可重放会话"],
    tools=["pentest_recon", "ctf_toolkit", "attack_network"],
    signals=["S5", "S4"],
)
_s(
    id="protocol-replay",
    title="自定义协议重放",
    family="reverse",
    cues=[r"重放|replay|checksum|会话复现|自定义包"],
    focus=["字段语义", "校验算法", "接受条件", "状态推进"],
    tools=["ctf_toolkit", "ops_algo", "attack_network"],
    signals=["S4", "S5"],
)
_s(
    id="forensic-timeline",
    title="取证时间线",
    family="special",
    cues=[r"取证|forensic|timeline|注册表|日志关联|mailbox"],
    focus=["多源时间对齐", "删除恢复线索", "关联 PCAP/磁盘"],
    tools=["malware_analysis", "ctf_toolkit"],
    signals=["S3", "S8"],
)
_s(
    id="patch-diff",
    title="补丁差分 / N-day 定位",
    family="reverse",
    cues=[r"补丁|patch.?diff|n-?day|1day|bindiff|ghidriff|cve.?还原"],
    focus=["补丁前后函数差", "根因点", "可达条件", "最小 PoC 面"],
    tools=["reverse_engineering", "ctf_toolkit"],
    signals=["S2", "S7"],
)
_s(
    id="js-sign",
    title="JS 签名 / 前端加密",
    family="web",
    cues=[r"js.?逆|签名参数|webpack.?sign|补环境|ast.?反混淆|前端加密"],
    focus=["观察→捕获→本地重建", "加密边界", "Node 补环境"],
    tools=["web_pentest", "ops_algo", "ctf_toolkit"],
    signals=["S6", "S4"],
)

# --- Crypto / mobile ---
_s(
    id="crypto-chain",
    title="变换链 / 密码学边界",
    family="crypto",
    cues=[r"crypto|aes|rsa|xor|编码链|oracle|padding|变换链"],
    focus=["完整变换顺序", "精确参数", "oracle 边界"],
    tools=["ops_algo", "ctf_toolkit"],
    signals=["S4"],
)
_s(
    id="stego",
    title="隐写 / 媒体信道",
    family="crypto",
    cues=[r"隐写|stego|lsb|trailer|媒体隐藏"],
    focus=["元数据", "信道", "trailer", "容量与密钥"],
    tools=["ctf_toolkit", "malware_analysis"],
    signals=["S4", "S8"],
)
_s(
    id="android-hook",
    title="Android 动态插桩面",
    family="mobile",
    cues=[r"apk|frida|ssl.?pin|okhttp|jadx|smali|android"],
    focus=["manifest/入口", "pinning", "native bridge", "签名逻辑"],
    tools=["reverse_engineering", "malware_analysis", "re_surface"],
    signals=["S2", "S3"],
)
_s(
    id="ios-runtime",
    title="iOS 运行时面",
    family="mobile",
    cues=[r"ios|ipa|keychain|objc|swift|越狱|jailbreak"],
    focus=["运行时方法", "Keychain", "deeplink", "pinning"],
    tools=["reverse_engineering", "malware_analysis"],
    signals=["S2"],
)

# --- Cloud / agent ---
_s(
    id="prompt-injection",
    title="Prompt 注入 / Agent 工具滥用",
    family="special",
    cues=[r"prompt.?inject|越狱|工具滥用|agent.?hijack|llm.?安全|系统提示词"],
    focus=["不可信检索内容", "工具调用边界", "记忆投毒", "规划漂移"],
    tools=["ops_framing", "ops_sandbox", "sentinel_scan"],
    signals=["S1", "S8"],
)
_s(
    id="container-k8s",
    title="容器 / K8s 控制面",
    family="cloud",
    cues=[r"k8s|kubernetes|rbac|service.?account|容器逃逸|cgroup|namespace"],
    focus=["SA 权限", "挂载与 sidecars", "API server 面", "逃逸前置条件"],
    tools=["pentest_recon", "sentinel_scan"],
    signals=["S5", "S1"],
)
_s(
    id="cloud-metadata",
    title="云元数据 / 工作负载身份",
    family="cloud",
    cues=[r"imds|instance.?profile|workload.?identity|云凭据|sts"],
    focus=["元数据路径", "token 生命周期", "横向到云 API"],
    tools=["web_pentest", "pentest_recon"],
    signals=["S5", "S6"],
)
_s(
    id="supply-chain",
    title="供应链 / CI 构建完整性",
    family="cloud",
    cues=[r"供应链|sbom|sca|ci/?cd|依赖投毒|构建完整性|lockfile"],
    focus=["依赖漂移", "构建篡改", "发布签名", "可达性"],
    tools=["sentinel_scan", "sentinel_pack"],
    signals=["S1", "S8"],
)

# --- Identity / Windows ---
_s(
    id="identity-windows",
    title="Windows 身份 / 票据链",
    family="identity",
    cues=[r"kerberos|ntlm|票证|lsass|dpapi|adcs|域渗透|pth|ptt"],
    focus=["token/ticket 可用性", "委托关系", "证书模板", "重放边界"],
    tools=["pentest_recon", "attack_network", "ops_ctf_runner"],
    signals=["S5", "S8"],
)
_s(
    id="windows-pivot",
    title="Windows 横向 / 跳板",
    family="identity",
    cues=[r"横向|winrm|smb|rdp|wmi|跳板|pivot"],
    focus=["已接受会话", "管理协议面", "凭据复用"],
    tools=["pentest_recon", "attack_network"],
    signals=["S5"],
)
_s(
    id="linux-cred-pivot",
    title="Linux 凭据 / 主机间移动",
    family="identity",
    cues=[r"ssh.?key|linux.?凭据|/etc/shadow|sudo|容器到主机"],
    focus=["密钥与 socket 信任", "sudo 规则", "主机间 SSH"],
    tools=["pentest_recon", "ctf_toolkit"],
    signals=["S5", "S7"],
)

# --- Game / client integrity (lab) ---
_s(
    id="game-client",
    title="客户端完整性 / 反作弊研究面",
    family="special",
    cues=[r"游戏|外挂|自瞄|esp|内存修改|反作弊|trainer|aimbot|il2cpp|unity"],
    focus=[
        "服务端权威 vs 本地可信字段",
        "可行性分级（单机→内核 AC）",
        "渲染/输入层分析边界",
        "检测特征与加固",
    ],
    tools=["attack_game", "reverse_engineering", "re_surface", "ops_framing"],
    signals=["S8", "S2"],
)
_s(
    id="attack-chain",
    title="多阶段攻击链编排",
    family="special",
    cues=[r"攻击链|红队|打点|后渗透|从外网到域控|hw演练|全流程渗透"],
    focus=["阶段目标", "据点→下一跳", "证据与回滚", "痕迹最小化（演练）"],
    tools=["ops_chain", "pentest_suite", "ops_pipeline"],
    signals=["S5", "S7", "S8"],
)
_s(
    id="adcs-cert",
    title="ADCS / 证书滥用面",
    family="identity",
    cues=[r"adcs|证书模板|esc1|pkinit|certificate.?auth"],
    focus=["模板权限", "注册权", "证书认证路径", "持久化"],
    tools=["ops_pattern_db", "pentest_recon", "ops_method_packs"],
    signals=["S8", "S5"],
)
_s(
    id="kerberos-delegation",
    title="Kerberos 委托面",
    family="identity",
    cues=[r"委派|rbcd|s4u|unconstrained|constrained.?deleg"],
    focus=["委托类型", "S4U", "RBCD 配置差", "票证接受"],
    tools=["ops_pattern_db", "pentest_recon"],
    signals=["S8"],
)
_s(
    id="lsass-material",
    title="LSASS / 会话材料面",
    family="identity",
    cues=[r"lsass|票证缓存|sekurlsa|凭证转储"],
    focus=["会话材料类型", "可用性", "重放边界", "防护（Credential Guard）"],
    tools=["malware_analysis", "ops_pattern_db"],
    signals=["S3", "S8"],
)
_s(
    id="dpapi-chain",
    title="DPAPI / 浏览器密钥链",
    family="identity",
    cues=[r"dpapi|masterkey|vault|浏览器密码|凭据保管"],
    focus=["masterkey 作用域", "unwrap 链", "浏览器存储", "用户上下文"],
    tools=["malware_analysis", "ops_pattern_db"],
    signals=["S3", "S8"],
)
_s(
    id="relay-coercion",
    title="强制认证 / 中继面",
    family="identity",
    cues=[r"ntlm.?relay|coercer|petitpotam|强制认证|中继"],
    focus=["强制原语", "中继目标", "签名/EPA 接受条件"],
    tools=["attack_network", "pentest_recon", "ops_pattern_db"],
    signals=["S5", "S8"],
)
_s(
    id="mailbox-abuse",
    title="邮箱规则 / 委托滥用",
    family="identity",
    cues=[r"邮箱规则|邮件转发|mailbox|oauth.?consent|inbox.?rule"],
    focus=["转发规则", "委托", "OAuth 同意", "外传路径"],
    tools=["pentest_recon", "web_pentest"],
    signals=["S6", "S8"],
)
_s(
    id="kernel-escape",
    title="容器/内核逃逸前置",
    family="cloud",
    cues=[r"容器逃逸|kernel.?escape|docker\.sock|privileged|cap_sys"],
    focus=["能力/挂载/sock", "内核版本", "利用前置是否满足"],
    tools=["pentest_recon", "ctf_toolkit", "ops_method_packs"],
    signals=["S7", "S5"],
)
_s(
    id="browser-auto",
    title="浏览器自动化面",
    family="web",
    cues=[r"playwright|浏览器自动化|headless|填表|截图自动化"],
    focus=["选择器稳定", "网络+UI 同步", "证据捕获"],
    tools=["web_pentest", "ops_ctf_runner"],
    signals=["S6"],
)
_s(
    id="static-ida",
    title="深度静态反编译面",
    family="reverse",
    cues=[r"\bida\b|ghidra|伪代码|交叉引用深度"],
    focus=["入口", "xref", "类型恢复", "动静态对照"],
    tools=["reverse_engineering", "ops_triage", "ops_method_packs"],
    signals=["S2"],
)
_s(
    id="cli-r2",
    title="radare2 CLI 面",
    family="reverse",
    cues=[r"radare2|\br2\b|rabin2"],
    focus=["info", "strings", "analyze", "可复现命令"],
    tools=["reverse_engineering", "ctf_toolkit"],
    signals=["S2"],
)
_s(
    id="kernel-driver",
    title="内核驱动 / IOCTL 面",
    family="reverse",
    cues=[r"ioctl|驱动逆向|rootkit|deviceiocontrol|\.sys\b"],
    focus=["分发例程", "IOCTL 码", "输入验证", "任意读写原语"],
    tools=["reverse_engineering", "ctf_toolkit"],
    signals=["S2", "S7"],
)
_s(
    id="src-bounty",
    title="SRC / 众测作业面",
    family="web",
    cues=[r"src|众测|bug.?bounty|挖洞优先级"],
    focus=["scope", "优先级", "证据", "时间盒"],
    tools=["web_pentest", "ops_report_contract", "ops_method_packs"],
    signals=["S6"],
)


# Target-type shortcuts (file/extension → surfaces)
TARGET_TYPE_MAP: list[tuple[str, list[str]]] = [
    (r"\.apk$|\.dex$|\.xapk$", ["android-hook", "reverse-pwn"]),
    (r"\.ipa$|\.app$", ["ios-runtime"]),
    (r"\.exe$|\.dll$|\.sys$", ["reverse-pwn", "malware-config", "game-client"]),
    (r"\.so$|\.elf$|\.bin$", ["reverse-pwn", "firmware"]),
    (r"\.pcap$|\.pcapng$|\.har$", ["pcap-protocol", "protocol-replay"]),
    (r"\.js$|\.mjs$|\.ts$", ["js-sign", "bundle-sourcemap", "web-runtime"]),
    (r"\.map$", ["bundle-sourcemap"]),
    (r"https?://", ["web-runtime", "ssrf-metadata", "oauth-oidc"]),
]


@dataclass
class MatrixHit:
    surface_id: str
    title: str
    score: float
    family: str
    focus: list[str]
    tools: list[str]
    signals: list[str]
    rationale: list[str]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def score_surface(query: str, target: str = "") -> list[MatrixHit]:
    """Score all surfaces against free-text query + target path/url."""
    blob = f"{query} {target}".strip()
    blob_l = blob.lower()
    scores: dict[str, float] = {sid: 0.0 for sid in SURFACES}
    reasons: dict[str, list[str]] = {sid: [] for sid in SURFACES}

    for sid, surf in SURFACES.items():
        for cue in surf.cues:
            if re.search(cue, blob, re.I):
                scores[sid] += 2.0
                reasons[sid].append(f"cue:{cue[:40]}")

    for pat, sids in TARGET_TYPE_MAP:
        if re.search(pat, target or blob, re.I):
            for sid in sids:
                if sid in scores:
                    scores[sid] += 1.8
                    reasons[sid].append(f"target:{pat[:30]}")

    hits: list[MatrixHit] = []
    for sid, sc in scores.items():
        if sc <= 0:
            continue
        s = SURFACES[sid]
        hits.append(
            MatrixHit(
                surface_id=sid,
                title=s.title,
                score=round(sc, 2),
                family=s.family,
                focus=list(s.focus),
                tools=list(s.tools),
                signals=list(s.signals),
                rationale=reasons[sid][:6],
            )
        )
    hits.sort(key=lambda h: (-h.score, h.surface_id))
    return hits


def route_matrix(
    query: str,
    target: str = "",
    top_k: int = 5,
) -> dict[str, Any]:
    """
    Multi-axis route result for agents.
    Stay generic (ctf runner) if scores are flat / low.
    """
    hits = score_surface(query, target)
    top = hits[: max(1, top_k)]
    dominant = top[0] if top else None
    stay_generic = (
        dominant is None
        or dominant.score < 2.0
        or (len(top) >= 2 and top[0].score - top[1].score < 0.8)
    )
    plan_cmds = []
    if stay_generic:
        plan_cmds.append("python scripts/ops_ctf_runner.py resume .")
        plan_cmds.append("python scripts/ops_router.py \"{q}\" --target {t} --json".format(
            q=query or "task", t=target or "."
        ))
    if dominant:
        for tool in dominant.tools[:4]:
            if tool == "ops_ctf_runner":
                plan_cmds.append("python scripts/ops_ctf_runner.py brief . --domain web")
            elif tool == "ops_chain":
                plan_cmds.append(f'python scripts/ops_chain.py plan --query "{query or "attack chain"}"')
            elif tool == "ops_framing":
                plan_cmds.append(f'python scripts/ops_framing.py auto --text "{query}"')
            else:
                plan_cmds.append(f"python scripts/{tool}.py {target or '<target>'} --json")

    return {
        "protocol": "sentinel-surface-matrix-v1",
        "query": query,
        "target": target,
        "stay_generic": stay_generic,
        "dominant": dominant.to_dict() if dominant else None,
        "top": [h.to_dict() for h in top],
        "routing_rule": (
            "分数接近时保持通用 CTF/ops 流水线；仅当单一表面显著领先时收窄。"
            "阻塞不再匹配时回到 matrix 重新 route。"
        ),
        "commands": plan_cmds,
        "catalog_size": len(SURFACES),
    }


def list_surfaces(family: Optional[str] = None) -> list[dict[str, Any]]:
    out = []
    for s in SURFACES.values():
        if family and s.family != family:
            continue
        out.append({
            "id": s.id,
            "title": s.title,
            "family": s.family,
            "tools": s.tools,
            "signals": s.signals,
        })
    return sorted(out, key=lambda x: (x["family"], x["id"]))


def get_surface(sid: str) -> Optional[dict[str, Any]]:
    s = SURFACES.get(sid)
    return s.to_dict() if s else None


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Sentinel multi-axis surface matrix")
    sub = p.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("route", help="Route query to surfaces")
    r.add_argument("query", nargs="+")
    r.add_argument("--target", default="")
    r.add_argument("--top", type=int, default=5)
    r.add_argument("--json", action="store_true")

    l = sub.add_parser("list", help="List surfaces")
    l.add_argument("--family", default="")
    l.add_argument("--json", action="store_true")

    g = sub.add_parser("get", help="Get one surface playbook")
    g.add_argument("id")
    g.add_argument("--json", action="store_true")

    args = p.parse_args(argv)

    if args.cmd == "route":
        data = route_matrix(" ".join(args.query), target=args.target, top_k=args.top)
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "list":
        data = list_surfaces(args.family or None)
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "get":
        data = get_surface(args.id)
        if not data:
            print(json.dumps({"error": "unknown surface", "id": args.id}, ensure_ascii=False))
            return 1
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
