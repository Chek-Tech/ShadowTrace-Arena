#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Windows 一键注入 Code Sentinel 到 Codex（原创启动器）。"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))


def main() -> int:
    print("=" * 50)
    print("  Code Sentinel · Windows 一键启动（注入 Codex）")
    print("  触发词：豆包大人")
    print("=" * 50)
    print()
    import codex_inject

    try:
        result = codex_inject.install()
    except Exception as exc:
        print(f"[失败] {exc}")
        _pause()
        return 1

    print(f"[完成] {result.get('message', 'ok')}")
    print(f"  Codex 目录 : {result.get('codex_home')}")
    print(f"  项目目录   : {result.get('project_home')}")
    print(f"  Skills     : {', '.join(result.get('skills') or [])}")
    print(f"  备份       : {result.get('backup')}")
    print()
    print("请完全退出并重新打开 Codex，然后在对话中发送：豆包大人")
    print()
    _pause()
    return 0


def _pause() -> None:
    if sys.stdin.isatty():
        try:
            input("按 Enter 关闭…")
        except EOFError:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
