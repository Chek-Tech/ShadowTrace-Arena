#!/usr/bin/env python3
"""
Code Sentinel doctor — aggregate health / gap check for the whole ops stack.
"""

from __future__ import annotations

import argparse
import importlib
import json
import sys
from pathlib import Path
from typing import Any, Optional

_SCRIPTS = Path(__file__).resolve().parent
_ROOT = _SCRIPTS.parent
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))


CORE_MODULES = [
    "sentinel_scan", "sentinel_pack", "sentinel_report", "redact",
    "rules_builtin", "rules_reverse", "rules_offensive",
    "reverse_engineering", "malware_analysis", "ctf_toolkit",
    "pentest_recon", "web_pentest", "pentest_suite",
    "ops_router", "ops_pipeline", "ops_case", "ops_modules", "ops_patterns",
    "ops_fallback", "ops_triage", "ops_algo", "ops_knowledge",
    "ops_framing", "ops_gpt56", "ops_sandbox", "ops_payloads",
    "ops_ctf_runner", "ops_surface_matrix", "ops_tool_index", "ops_journal",
    "ops_chain", "ops_method_packs", "ops_anon", "ops_report_contract",
    "ops_protocol_lab", "ops_obedience", "ops_instruct", "ops_pattern_db",
    "ops_essence_atlas", "ops_originality", "ops_trigger", "codex_inject",
    "ops_ptes_lab", "ops_phase_kb", "ops_engagement", "ops_phase_runner",
    "ops_gap_audit",
    "auditors.regex_sandbox", "auditors.variable_tracker", "auditors.tool_bridge",
]


def _version() -> str:
    vf = _ROOT / "VERSION"
    if vf.is_file():
        return vf.read_text(encoding="utf-8").strip()
    return "unknown"


def run_doctor() -> dict[str, Any]:
    checks: list[dict[str, Any]] = []

    def add(cid: str, label: str, ok: bool, detail: str = "") -> None:
        checks.append({"id": cid, "label": label, "ok": bool(ok), "detail": detail})

    add("version", f"VERSION={_version()}", (_ROOT / "VERSION").is_file())
    add("gpt56_core", "prompts/gpt56-core.md", (_ROOT / "prompts" / "gpt56-core.md").is_file())
    add("gpt56_config", "prompts/config.gpt56.json", (_ROOT / "prompts" / "config.gpt56.json").is_file())
    add("agent_gpt56", "agents/gpt56.yaml", (_ROOT / "agents" / "gpt56.yaml").is_file())
    add("entry_sentinel", "sentinel.py root entry", (_ROOT / "sentinel.py").is_file())
    add("codex_bundle", "codex-bundle fragment+skills", (_ROOT / "codex-bundle" / "AGENTS.fragment.md").is_file())
    _cs_skills = (
        "code-sentinel",
        "code-sentinel-gpt56",
        "code-sentinel-ops",
        "code-sentinel-payload",
        "code-sentinel-ctf",
        "code-sentinel-matrix",
        "gpt56-reverse-pentest",
        "code-sentinel-ptes",
        "code-sentinel-engagement",
    )
    add(
        "codex_skills",
        f"{len(_cs_skills)} codex skills",
        all((_ROOT / "codex-bundle" / "skills" / n / "SKILL.md").is_file() for n in _cs_skills),
    )
    add(
        "gpt56_rev_refs",
        "gpt56-reverse-pentest references",
        (_ROOT / "references" / "gpt56-reverse-pentest" / "ctf-speedrun.md").is_file()
        and (_ROOT / "scripts" / "gpt56_reverse_pentest" / "reverse_tools.py").is_file(),
    )
    # fusion helpers import + CLI surface
    try:
        import importlib.util

        def _load(name: str, path: Path):
            spec = importlib.util.spec_from_file_location(name, path)
            mod = importlib.util.module_from_spec(spec)
            assert spec and spec.loader
            spec.loader.exec_module(mod)
            return mod

        rt = _load(
            "gpt56_reverse_tools",
            _ROOT / "scripts" / "gpt56_reverse_pentest" / "reverse_tools.py",
        )
        ch = _load(
            "gpt56_crypto_helper",
            _ROOT / "scripts" / "gpt56_reverse_pentest" / "crypto_helper.py",
        )
        pt = _load(
            "gpt56_pwn_template",
            _ROOT / "scripts" / "gpt56_reverse_pentest" / "pwn_template.py",
        )
        fusion_ok = all(
            [
                hasattr(rt, "detect_encoding"),
                hasattr(ch, "caesar_bruteforce"),
                hasattr(pt, "check_deps"),
            ]
        )
        add("gpt56_helpers", "gpt56 reverse/crypto/pwn helpers import", fusion_ok)
    except Exception as exc:
        add("gpt56_helpers", "gpt56 reverse/crypto/pwn helpers import", False, str(exc)[:120])

    # tool index includes fusion modules
    try:
        import ops_tool_index

        idx = ops_tool_index.probe_all()
        ids = {t["id"] for t in idx.get("tools") or []}
        need = {"gpt56_reverse_tools", "gpt56_crypto_helper", "gpt56_pwn_template"}
        add(
            "tool_index_fusion",
            "tool-index gpt56 fusion modules",
            need.issubset(ids) and bool(idx.get("summary", {}).get("gpt56_fusion")),
            f"ids_ok={need.issubset(ids)}",
        )
    except Exception as exc:
        add("tool_index_fusion", "tool-index gpt56 fusion", False, str(exc)[:120])

    # self-scan noise control present
    ign = _ROOT / ".sentinelignore"
    ign_txt = ign.read_text(encoding="utf-8") if ign.is_file() else ""
    add(
        "self_scan_ignore",
        ".sentinelignore covers ops noise + fusion pack",
        "ops_method_packs.py" in ign_txt and "gpt56_reverse_pentest" in ign_txt,
    )
    # PTES lab original modules
    try:
        import ops_ptes_lab
        import ops_phase_kb

        add(
            "ptes_lab",
            f"ptes lab phases={len(ops_ptes_lab.PHASES)}",
            len(ops_ptes_lab.PHASES) >= 8 and len(ops_ptes_lab.TRANSITION_CHECKS) >= 8,
        )
        sample = ops_phase_kb.route_from_text("https://lab.local port 443 nginx")
        add(
            "phase_kb",
            "phase kb routes local refs",
            bool(sample.get("references") or sample.get("tools_or_packs")),
        )
    except Exception as exc:
        add("ptes_lab", "ops_ptes_lab", False, str(exc)[:120])
        add("phase_kb", "ops_phase_kb", False, str(exc)[:120])

    try:
        import ops_engagement

        em = ops_engagement.essence_map()
        add(
            "engagement_suite",
            f"engagement essences={em.get('count')}",
            int(em.get("count") or 0) >= 15,
        )
        sp = ops_engagement.plan_service_enum("127.0.0.1", [80, 445, 22])
        add(
            "engagement_enum",
            "service enum playbooks",
            len(sp.get("playbooks") or []) >= 2,
        )
    except Exception as exc:
        add("engagement_suite", "ops_engagement", False, str(exc)[:120])

    try:
        import ops_phase_runner

        add(
            "phase_runner",
            "ops_phase_runner ready",
            hasattr(ops_phase_runner, "run_phase") and hasattr(ops_phase_runner, "run_until"),
        )
    except Exception as exc:
        add("phase_runner", "ops_phase_runner", False, str(exc)[:120])

    try:
        import ops_gap_audit
        import ops_tool_index

        idx = ops_tool_index.probe_all()
        ops_n = int((idx.get("summary") or {}).get("ops_modules") or 0)
        add("tool_index_ops", f"tool-index ops_modules={ops_n}", ops_n >= 30)
        # lightweight gap audit (no full write required for doctor speed)
        ga = ops_gap_audit.run_audit()
        add(
            "gap_audit",
            f"gap_audit gaps={ga.get('gap_count')}",
            bool(ga.get("ok")),
            "; ".join((ga.get("gaps") or [])[:3]),
        )
    except Exception as exc:
        add("gap_audit", "ops_gap_audit", False, str(exc)[:120])

    # imports
    failed_imports = []
    for name in CORE_MODULES:
        try:
            importlib.import_module(name)
        except Exception as exc:
            failed_imports.append(f"{name}: {exc}")
    add("imports", f"import {len(CORE_MODULES)} modules", not failed_imports, "; ".join(failed_imports[:5]))

    # rule catalog
    try:
        from rules_builtin import all_builtin_rules

        class R:
            def __init__(self, *a, **k):
                self.id = a[0]

        def _rx(p, f=0):
            return p

        rules = all_builtin_rules(R, _rx)
        add("rules", f"rule catalog size={len(rules)}", len(rules) >= 182, f"count={len(rules)}")
    except Exception as exc:
        add("rules", "rule catalog", False, str(exc)[:120])

    # modules
    try:
        import ops_modules
        add("modules25", f"playbooks={len(ops_modules.MODULES)}", len(ops_modules.MODULES) >= 25)
    except Exception as exc:
        add("modules25", "ops_modules", False, str(exc)[:120])

    try:
        import ops_payloads
        add("payloads", f"blueprints={len(ops_payloads.BLUEPRINTS)}", len(ops_payloads.BLUEPRINTS) >= 8)
    except Exception as exc:
        add("payloads", "ops_payloads", False, str(exc)[:120])

    try:
        import ops_patterns
        add("patterns", f"patterns={len(ops_patterns.PATTERNS)}", len(ops_patterns.PATTERNS) == 6)
    except Exception as exc:
        add("patterns", "ops_patterns", False, str(exc)[:120])

    # router + gpt56 boot slices
    try:
        import ops_router
        rows = ops_router.self_check()
        add("router_self_check", "ops_router.self_check", all(r["ok"] for r in rows), f"{sum(r['ok'] for r in rows)}/{len(rows)}")
    except Exception as exc:
        add("router_self_check", "ops_router", False, str(exc)[:120])

    try:
        import ops_gpt56
        rows = ops_gpt56.boot_checklist()
        add("gpt56_boot", "ops_gpt56.boot", all(r["ok"] for r in rows), f"{sum(r['ok'] for r in rows)}/{len(rows)}")
    except Exception as exc:
        add("gpt56_boot", "ops_gpt56", False, str(exc)[:120])

    try:
        import ops_sandbox
        add("sandbox", "dual-layer sandbox", len(ops_sandbox.EVIDENCE_STACK) == 8)
    except Exception as exc:
        add("sandbox", "ops_sandbox", False, str(exc)[:120])

    try:
        import ops_framing
        fr = ops_framing.reframe_text("破解测试", add_anchors=False)
        add("framing", "framing rewrite", bool(fr.replacements))
        hit = ops_framing.detect_refusal("I can't help with that")
        add("refusal_detect", "refusal detector", hit.matched)
    except Exception as exc:
        add("framing", "ops_framing", False, str(exc)[:120])

    try:
        import ops_trigger
        h = ops_trigger.detect("豆包大人")
        add("trigger", "trigger 豆包大人 → FULL", h is not None and h.mode == "FULL")
    except Exception as exc:
        add("trigger", "ops_trigger", False, str(exc)[:120])

    try:
        import ops_obedience
        rep = ops_obedience.check_completion(
            ["route", "frame", "tools", "evidence", "phases", "defense"],
            {"no_share": "1", "skip_journal": "1"},
        )
        add("obedience", "obedience checklist gate", rep.complete, rep.message[:80])
    except Exception as exc:
        add("obedience", "ops_obedience", False, str(exc)[:120])

    try:
        import ops_instruct
        md = ops_instruct.build_lab_instructions()
        add("lab_instruct", "ops_instruct lab md", "Code Sentinel" in md and "豆包大人" in md)
    except Exception as exc:
        add("lab_instruct", "ops_instruct", False, str(exc)[:120])

    try:
        import ops_pattern_db
        add("pattern_db", "pattern families", len(ops_pattern_db.catalog()) >= 6)
    except Exception as exc:
        add("pattern_db", "ops_pattern_db", False, str(exc)[:120])

    try:
        import ops_essence_atlas
        cov = ops_essence_atlas.coverage_report()
        add(
            "essence_atlas",
            f"atlas sources={cov['total_sources']}",
            bool(cov.get("complete")),
            cov.get("message", "")[:100],
        )
    except Exception as exc:
        add("essence_atlas", "ops_essence_atlas", False, str(exc)[:120])

    try:
        import ops_originality
        orep = ops_originality.scan()
        add("originality", "originality fingerprint scan", bool(orep.get("ok")), orep.get("message", "")[:100])
    except Exception as exc:
        add("originality", "ops_originality", False, str(exc)[:120])

    try:
        import ops_method_packs
        add("method_packs", f"packs={len(ops_method_packs.PACKS)}", len(ops_method_packs.PACKS) >= 25)
    except Exception as exc:
        add("method_packs", "ops_method_packs", False, str(exc)[:120])

    try:
        import ops_surface_matrix
        add("surfaces", f"surfaces={len(ops_surface_matrix.SURFACES)}", len(ops_surface_matrix.SURFACES) >= 45)
    except Exception as exc:
        add("surfaces", "ops_surface_matrix", False, str(exc)[:120])

    # workspace
    try:
        import ops_case
        lab = ops_case.ensure_workspace()
        add("ops_lab", f"ops-lab at {lab}", lab.is_dir())
    except Exception as exc:
        add("ops_lab", "ops_case", False, str(exc)[:120])

    ok_n = sum(1 for c in checks if c["ok"])
    return {
        "version": _version(),
        "model_target": "gpt-5.6",
        "checks": checks,
        "summary": {"ok": ok_n, "total": len(checks), "pass": ok_n == len(checks)},
    }


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Code Sentinel doctor")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    report = run_doctor()
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print(f"Code Sentinel doctor  v{report['version']}  target={report['model_target']}")
        for c in report["checks"]:
            mark = "OK" if c["ok"] else "FAIL"
            extra = f"  ({c['detail']})" if c.get("detail") and not c["ok"] else ""
            print(f"  [{mark}] {c['id']}: {c['label']}{extra}")
        s = report["summary"]
        print(f"Summary: {s['ok']}/{s['total']}  {'PASS' if s['pass'] else 'FAIL'}")
    return 0 if report["summary"]["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
