# Sentinel Engagement Atlas — 全量精髓映射（原创）

> 对公开多 Agent PTES 框架做**结构级**研读后，将工程精髓用 Code Sentinel 独立实现。  
> **禁止**入库第三方：SKILL 全文、AGENTS、12k 知识语料、PoC 仓库、报告模板原文、symlink 技能包。

## 外部框架结构（仅作观察）

| 观察点 | 外部常见形态 | 我们的处理 |
|--------|--------------|------------|
| 阶段链 | Pre→IG→TM→VA→EX→PE→Report | `ops_ptes_lab` L0–L6 + L1W |
| 子 Agent 分阶段 | 每阶段独立上下文 + chain JSON | `ops_engagement.chain_plan` 声明并行包；由编排器调度 |
| 目标目录契约 | `target/IP/ports|services|vulns` | `ops-lab/targets/<slug>/` + `validate_engagement` |
| Manifest 交接 | `manifest-phase-N` | `manifests/manifest-L*.json` |
| 转段清单 | 6–8 项勾选 | `TRANSITION_CHECKS` 8 项 |
| 知识库万条 | github-references / corpus | **不搬运**；`ops_phase_kb` 只路由本仓 references |
| 服务枚举技能 | enum-services | `plan_service_enum` 端口剧本 |
| Web 预检 | Playwright + playbook 库 | `web_pretest_blueprint` + `web_pentest` |
| 报告技能 | gen-report + 模板 | `build_report` + `REPORT_CHECKS` |
| 知识合并 | update-solution | `merge_solutions` → `solutions-ledger.md` |
| 范围访谈 | 一问一答 | `scope_interview_*` |
| 工具/MCP 就绪 | mcp-manager | `tool_readiness` + `ops_tool_index` |
| 战术横向链 | 后渗透笔记 | 已有 `ops_chain` C1–C6 |

## 模块索引

见：`python scripts/ops_engagement.py essences`

## 一键

```bash
python scripts/ops_engagement.py bootstrap https://lab.example
python scripts/ops_engagement.py chain lab.example
python scripts/ops_engagement.py enum-plan 10.0.0.1 --ports 22,80,445,3389
python scripts/ops_engagement.py web-pretest https://lab.example
python scripts/ops_engagement.py report lab.example
python scripts/ops_engagement.py solutions-merge

# 真执行闭环（自动 recon → … → report）
python scripts/ops_phase_runner.py auto 127.0.0.1 --ports 22,80,443,445
python scripts/ops_engagement.py auto https://example.com --ports 80,443
```

## 阶段执行映射

| 阶段 | 执行器动作 |
|------|------------|
| L0 | 写 scope/auth + tool-index 快照 |
| L1 | `pentest_recon.recon` → ports/services/recon-summary + enum-plan |
| L1W | `web_pentest.audit_url` → web/* |
| L2 | 从端口生成 threat_model |
| L3 | 汇总 web/暴露面 → vulns/verified* |
| L4 | 高危候选入库（不自动破坏性利用） |
| L5 | 后利用检查清单（非破坏） |
| L6 | `build_report` + evidence_index |