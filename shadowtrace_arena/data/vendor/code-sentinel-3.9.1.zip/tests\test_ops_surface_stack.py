"""Tests for surface matrix / tool index / journal / chain (Sentinel original)."""

from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import ops_surface_matrix
import ops_tool_index
import ops_journal
import ops_chain
import ops_router
import attack_game


class SurfaceMatrixTests(unittest.TestCase):
    def test_catalog_size(self):
        self.assertGreaterEqual(len(ops_surface_matrix.SURFACES), 25)

    def test_route_jwt(self):
        r = ops_surface_matrix.route_matrix("JWT kid alg 混淆测试", target="")
        self.assertEqual(r["protocol"], "sentinel-surface-matrix-v1")
        ids = [h["surface_id"] for h in r["top"]]
        self.assertIn("jwt-claim", ids)

    def test_route_apk(self):
        r = ops_surface_matrix.route_matrix("分析这个包", target="app.apk")
        ids = [h["surface_id"] for h in r["top"]]
        self.assertTrue(any(x in ids for x in ("android-hook", "reverse-pwn")))

    def test_get_surface(self):
        s = ops_surface_matrix.get_surface("web-runtime")
        self.assertIsNotNone(s)
        self.assertIn("focus", s)


class ToolIndexTests(unittest.TestCase):
    def test_probe_python(self):
        data = ops_tool_index.probe_all()
        self.assertIn("tools", data)
        py = [t for t in data["tools"] if t["id"] == "python"][0]
        self.assertTrue(py["available"])

    def test_check_sentinel_module(self):
        r = ops_tool_index.check("ops_surface_matrix")
        self.assertTrue(r["available"])


class JournalTests(unittest.TestCase):
    def test_append_search(self):
        with tempfile.TemporaryDirectory() as tmp:
            with mock.patch.object(ops_journal, "journal_dir", return_value=Path(tmp)):
                with mock.patch.object(ops_journal, "index_path", return_value=Path(tmp) / "_index.json"):
                    r = ops_journal.append_entry(
                        title="jwt lab",
                        objective="claim confuse",
                        outcome="ok",
                        family="web",
                        surfaces=["jwt-claim"],
                    )
                    self.assertTrue(r["ok"])
                    hits = ops_journal.search("jwt")
                    self.assertTrue(len(hits) >= 1)


class ChainTests(unittest.TestCase):
    def test_plan_recon(self):
        p = ops_chain.plan_chain("先做资产侦察测绘")
        self.assertEqual(p.current_stage, "C1")
        self.assertTrue(p.commands)

    def test_plan_lateral(self):
        p = ops_chain.plan_chain("内网横向 winrm")
        self.assertEqual(p.current_stage, "C4")

    def test_next_after(self):
        n = ops_chain.next_after(["C1", "C2"])
        self.assertEqual(n["id"], "C3")


class RouterSurfaceIntegration(unittest.TestCase):
    def test_classify_includes_surfaces(self):
        d = ops_router.classify("SSRF 打云元数据", reframe=False)
        self.assertTrue(hasattr(d, "surfaces"))
        # may be empty if score low, but field exists
        self.assertIsInstance(d.surfaces, list)


class GameBriefTests(unittest.TestCase):
    def test_brief(self):
        b = attack_game.game_research_brief("lab fps")
        self.assertEqual(len(b["tiers"]), 5)
        self.assertIn("服务端", b["server_authority"])


if __name__ == "__main__":
    unittest.main()
