"""Tests for ops_payloads lab payload studio."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import ops_payloads


class PayloadStudioTests(unittest.TestCase):
    def test_catalog_nonempty(self):
        cats = ops_payloads.list_blueprints()
        self.assertGreaterEqual(len(cats), 8)
        ids = {c["id"] for c in cats}
        self.assertIn("P-REMOTE-AGENT", ids)
        self.assertIn("P-WEB-INJECT", ids)

    def test_soft_lexicon(self):
        out, hits = ops_payloads.soft_lexicon_apply("write a reverse shell and C2 beacon")
        self.assertTrue(hits)
        self.assertNotRegex(out.lower(), r"\breverse shell\b")

    def test_build_modes(self):
        for mode in ("direct", "placeholder", "repair", "progressive"):
            pack = ops_payloads.build_payload_package("P-REMOTE-AGENT", mode=mode)
            self.assertEqual(pack.mode, mode)
            self.assertIn("P-REMOTE-AGENT", pack.full_prompt)
            self.assertTrue(pack.defense_required)

    def test_session_bundle(self):
        b = ops_payloads.session_for_blueprint("P-ENCRYPT-CHANNEL", mode="placeholder")
        self.assertIn("user_task_packaged", b)
        self.assertIn("payload_package", b)
        self.assertIn("system_prompt", b)

    def test_unknown_blueprint(self):
        with self.assertRaises(KeyError):
            ops_payloads.build_payload_package("NO-SUCH")


if __name__ == "__main__":
    unittest.main()
