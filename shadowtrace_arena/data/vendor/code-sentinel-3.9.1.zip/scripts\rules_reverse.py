"""
Reverse engineering & malware detection rule catalog.

Covers: anti-debug, anti-VM, packing, obfuscation, crypto identification,
license/keygen patterns, hooking frameworks, rootkit signatures, YARA-like
pattern matching, and CTF-specific vulnerability signatures.

Rules are SentinelRule-compatible and plug into sentinel_scan.py's scan engine.
"""

from __future__ import annotations

import re


def reverse_rules(SentinelRule, _rx):
    """Rule catalog for reverse engineering triage and malware detection.

    Returns 100 rules across reverse/malware/CTF categories.
    """
    return [
        # ═══════════════════════════════════════════════════════════════
        # Category: anti-debug — 反调试技术检测
        # ═══════════════════════════════════════════════════════════════
        SentinelRule(
            "anti-debug-ptrace", "ptrace-based anti-debug", "HIGH", "anti-debug",
            _rx(r"\bptrace\s*\(\s*PT_DENY_ATTACH\b|\bptrace\s*\(\s*PTRACE_TRACEME\b|\bsyscall\s*\(\s*__NR_ptrace\b"),
            "Patch the ptrace call or use a debugger that hides ptrace status.",
            cwe="", confidence="high",
            extensions=(".c", ".cpp", ".asm", ".s"),
        ),
        SentinelRule(
            "anti-debug-isdebuggerpresent", "IsDebuggerPresent anti-debug check", "HIGH", "anti-debug",
            _rx(r"\bIsDebuggerPresent\s*\(|\bCheckRemoteDebuggerPresent\s*\(|\bNtQueryInformationProcess\s*\(.*ProcessDebugPort\b"),
            "Hook or patch IsDebuggerPresent; use ScyllaHide/TitanHide to mask debugger presence.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c", ".h", ".asm"),
        ),
        SentinelRule(
            "anti-debug-peb-beingdebugged", "PEB BeingDebugged flag check", "HIGH", "anti-debug",
            _rx(r"\bPEB\b.*\bBeingDebugged\b|\bBeingDebugged\b.*\bPEB\b|\b__readfsbyte\s*\(\s*0x30\b|\bFS:\[0x30\]\b"),
            "Patch the PEB BeingDebugged byte or use a debugger plugin that spoofs PEB.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c", ".asm", ".s"),
        ),
        SentinelRule(
            "anti-debug-ntglobalflag", "NtGlobalFlag anti-debug check", "MEDIUM", "anti-debug",
            _rx(r"\bNtGlobalFlag\b|PEB.*NtGlobalFlag|__readfsdword\s*\(\s*0x68\b"),  # 0x68 = offsetof(PEB,NtGlobalFlag) on x64
            "Spoof NtGlobalFlag in PEB; set heap flags to non-debug values.",
            cwe="", confidence="medium",
            extensions=(".cpp", ".c", ".asm", ".s"),
        ),
        SentinelRule(
            "anti-debug-timing", "Timing-based anti-debug (rdtsc/QueryPerformanceCounter)", "MEDIUM", "anti-debug",
            _rx(r"\brdtsc\b|\bQueryPerformanceCounter\b.*\bQueryPerformanceCounter\b|__rdtsc\s*\("),
            "Use a debugger that fakes timing or patch the timing check routine.",
            cwe="", confidence="medium",
            extensions=(".cpp", ".c", ".asm", ".s"),
        ),
        SentinelRule(
            "anti-debug-int3-trap", "INT3 / breakpoint trap anti-debug", "MEDIUM", "anti-debug",
            _rx(r"\bint\s+3\b|\b__debugbreak\s*\(|\bDebugBreak\s*\(|\basm\s*\(\s*\"int3\"\b"),
            "Handle INT3 in exception handler or use hardware breakpoints instead.",
            cwe="", confidence="medium",
            extensions=(".cpp", ".c", ".asm", ".s", ".py"),
        ),
        SentinelRule(
            "anti-debug-self-debugging", "Self-debugging anti-analysis", "HIGH", "anti-debug",
            _rx(r"\bDebugActiveProcess\b|\bWaitForDebugEvent\b|\bContinueDebugEvent\b"),
            "Self-debugging prevents external debugger attachment. Bypass by patching the self-debug routine.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c"),
        ),
        SentinelRule(
            "anti-debug-parent-check", "Parent process anti-debug check", "MEDIUM", "anti-debug",
            _rx(r"\bCreateToolhelp32Snapshot\b.*\bPROCESSENTRY32\b|\bProcess32First\b|\bProcess32Next\b.*parent"),
            "Patch parent process check or launch the binary from expected parent.",
            cwe="", confidence="medium",
            extensions=(".cpp", ".c"),
        ),
        SentinelRule(
            "anti-debug-tls-callback", "TLS callback anti-debug entry", "HIGH", "anti-debug",
            _rx(r'__attribute__\s*\(\s*\(\s*section\s*\(\s*"\x2eCRT\$XL[ABCDEFGHIJKLMNOP]"\)|TLS_CALLBACK|\.tls\b'),
            "TLS callbacks execute before entry point. Use the debugger to stop at TLS callbacks.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c", ".asm"),
        ),
        SentinelRule(
            "anti-debug-exception-handler", "Exception-handler-based anti-debug", "MEDIUM", "anti-debug",
            _rx(r"\bSetUnhandledExceptionFilter\b.*anti|\bAddVectoredExceptionHandler\b.*debug|\b__try\b.*\b__except\b.*debug"),
            "Place breakpoint after exception handler; let exceptions pass through to debugger.",
            cwe="", confidence="medium",
            extensions=(".cpp", ".c", ".h"),
        ),

        # ═══════════════════════════════════════════════════════════════
        # Category: anti-vm — 反虚拟机/沙箱检测
        # ═══════════════════════════════════════════════════════════════
        SentinelRule(
            "anti-vm-registry", "VM detection via registry keys", "HIGH", "anti-vm",
            _rx(r"RegOpenKey.*VBOX|RegOpenKey.*VMware|RegOpenKey.*VirtualBox|RegOpenKey.*QEMU|"
                r"SOFTWARE\\\\Oracle\\\\VirtualBox|SOFTWARE\\\\VMware|SYSTEM\\\\CurrentControlSet\\\\Services\\\\vmmouse"),
            "Patch registry reads or spoof registry keys; use VM hardening tools.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c", ".py", ".ps1", ".bat", ".vbs"),
        ),
        SentinelRule(
            "anti-vm-cpuid", "VM detection via CPUID instruction", "HIGH", "anti-vm",
            _rx(r"\b__cpuid\b|\b__cpuidex\b|\basm\s*\(\s*\"cpuid\"|\bCPUID_INSTRUCTION\b"),
            "Spoof CPUID results; configure hypervisor to hide VM signature in CPUID leaf 0x40000000.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c", ".asm", ".s"),
        ),
        SentinelRule(
            "anti-vm-mac-address", "VM detection via MAC address", "MEDIUM", "anti-vm",
            _rx(r"GetAdaptersInfo|GetAdaptersAddresses.*(?:00:05:69|00:0C:29|00:1C:42|00:50:56|08:00:27).*VM"),
            "Spoof MAC address or patch the check routine.",
            cwe="", confidence="medium",
            extensions=(".cpp", ".c"),
        ),
        SentinelRule(
            "anti-vm-hypervisor", "Hypervisor detection", "HIGH", "anti-vm",
            _rx(r"\b__vmx_vmcall\b|\b__svm_vmrun\b|\bSIDT\b|\bSGDT\b|\bSLDT\b|\bSTR\b.*hypervisor|\bin\s+al,\s+dx\b.*VM"),
            "Patch hypervisor detection; use nested virtualization to hide hypervisor presence.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c", ".asm", ".s"),
        ),
        SentinelRule(
            "anti-vm-process-check", "VM detection via running processes", "MEDIUM", "anti-vm",
            _rx(r"vmtoolsd|vboxservice|vboxtray|xenservice|qemu-ga|VGAuthService|vmsrvc|"
                r"vmwaretray|vmwareuser|vmusrvc|prl_tools"),
            "Rename or hide VM guest tools processes; use VM detection bypass tool.",
            cwe="", confidence="medium",
            extensions=(".cpp", ".c", ".py", ".ps1", ".bat"),
        ),
        SentinelRule(
            "anti-vm-sandbox-check", "Sandbox/analysis environment detection", "HIGH", "anti-vm",
            # Avoid bare "sandbox"/"CAPE" — they match regex_sandbox, re.escape, etc.
            _rx(
                r"(?i)(?:\bCuckoo\b|\bJoeSandbox\b|\bAny\.Run\b|\bSandboxie\b|"
                r"\bis_?sandbox\b|\bsandbox(?:ed|ing)?_(?:detect|check|evasion)\b|"
                r"detect(?:ion)?[_\s]*sandbox|sandbox[_\s]*detect|"
                r"\bVirusTotal\b|\bHybrid\s*Analysis\b|\bmalwr\b|\bCAPEv2\b)"
            ),
            "Patch sandbox detection strings; use a custom analysis VM without sandbox indicators.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c", ".py", ".ps1", ".bat"),
        ),

        # ═══════════════════════════════════════════════════════════════
        # Category: packing — 加壳检测
        # ═══════════════════════════════════════════════════════════════
        SentinelRule(
            "packer-upx-signature", "UPX packer signature", "HIGH", "packing",
            _rx(r"\bUPX(?:0|1|!)|\$Info:\s+This\s+file\s+is\s+packed\s+with\s+the\s+UPX|UPX1|UPX2"),
            "Decompress with upx -d. Analyze unpacked binary in IDA/Ghidra.",
            cwe="", confidence="high",
        ),
        SentinelRule(
            "packer-aspack-signature", "ASPack/ASProtect signature", "HIGH", "packing",
            _rx(r"\bASPack\b|\.aspack\b|\.adata\b|ASProtect|\.asp\b"),
            "Use AspackDie or manual OEP finding with OllyDbg/x64dbg.",
            cwe="", confidence="high",
            extensions=(".exe", ".dll", ".bin"),
        ),
        SentinelRule(
            "packer-themida-signature", "Themida/WinLicense VM-based protector", "CRITICAL", "packing",
            _rx(r"\bThemida\b|\bWinLicense\b|\.themida\b|ThemidaVM|Oreans"),
            "Themida uses virtualization. Use specialized unpacking scripts (x64dbg + ScyllaHide + ThemidaUnpacker).",
            cwe="", confidence="high",
            extensions=(".exe", ".dll", ".bin"),
        ),
        SentinelRule(
            "packer-vmp-signature", "VMProtect virtualization protector", "CRITICAL", "packing",
            _rx(r"\bVMProtect\b|\.vmp\d\b|\.vmp0\b|VMProtectBegin|VMProtectEnd"),
            "VMProtect uses code virtualization. Requires VM handler analysis or devirtualization tools.",
            cwe="", confidence="high",
            extensions=(".exe", ".dll", ".bin", ".cpp", ".c", ".h"),
        ),
        SentinelRule(
            "packer-enigma-signature", "Enigma Protector signature", "HIGH", "packing",
            _rx(r"\bEnigma\s*Protector\b|\.enigma\d\b|enigma_loader"),
            "Use EnigmaVBUnpacker or manual dumping at OEP.",
            cwe="", confidence="high",
            extensions=(".exe", ".dll", ".bin"),
        ),
        SentinelRule(
            "packer-pecompact-signature", "PECompact packer", "MEDIUM", "packing",
            _rx(r"\bPECompact\b|\bPEC2\b|\.pec\b|pec2\b"),
            "Use PECompact unpacker or manual OEP recovery with ESP law.",
            cwe="", confidence="medium",
            extensions=(".exe", ".dll", ".bin"),
        ),
        SentinelRule(
            "packer-ns-pack-signature", "NsPack / NSPack signature", "MEDIUM", "packing",
            _rx(r"\bNsPacK\b|\.nsp\d\b|nsp0|nsp1"),
            "Use NsPacK unpacker or manual OEP finding.",
            cwe="", confidence="medium",
            extensions=(".exe", ".dll", ".bin"),
        ),
        SentinelRule(
            "packer-morphine-signature", "Morphine/MPRESS packer", "MEDIUM", "packing",
            _rx(r"\bMorphine\b|\.morphine\b|MPRESS[12]\b|\bmPRESS\b"),
            "Use Morphine unpacker or find OEP via ESP law + dump.",
            cwe="", confidence="medium",
            extensions=(".exe", ".dll", ".bin"),
        ),
        SentinelRule(
            "packer-armadillo-signature", "Armadillo protector", "HIGH", "packing",
            _rx(r"\bArmadillo\b|\.arm\d\b|\.adata\b.*Armadillo|Silicon Realms"),
            "Use Armadillo unpacker tools or x64dbg scripts with ScyllaHide.",
            cwe="", confidence="high",
            extensions=(".exe", ".dll", ".bin"),
        ),
        SentinelRule(
            "packer-dotfuscator", ".NET Dotfuscator obfuscator", "HIGH", "packing",
            _rx(r"\bDotfuscator\b|\bDotfuscatorAttribute\b|\.dotfuscator\b"),
            "Use de4dot to deobfuscate. For newer versions use .NET Reflector + manual deobfuscation.",
            cwe="", confidence="high",
            extensions=(".exe", ".dll", ".cs"),
        ),
        SentinelRule(
            "packer-confuser", ".NET ConfuserEx obfuscator", "HIGH", "packing",
            _rx(r"\bConfusedBy\s*\(|ConfuserEx|Confuser\.|\bconfuser\b"),
            "Use ConfuserEx unpacker or de4dot with ConfuserEx support. Analyze with dnSpy.",
            cwe="", confidence="high",
            extensions=(".exe", ".dll", ".cs"),
        ),
        SentinelRule(
            "packer-obsidium", "Obsidium protector", "HIGH", "packing",
            _rx(r"\bObsidium\b|\.obsidium\b|\.obsi\d\b"),
            "Use Obsidium unpacker or manual OEP + IAT rebuilding.",
            cwe="", confidence="high",
            extensions=(".exe", ".dll", ".bin"),
        ),

        # ═══════════════════════════════════════════════════════════════
        # Category: license-keygen — 注册/卡密/Keygen模式
        # ═══════════════════════════════════════════════════════════════
        SentinelRule(
            "license-hardcoded-key", "Hardcoded license key or activation code", "MEDIUM", "license",
            _rx(r"\blicense[_-]?key\s*[:=]\s*[\"'][A-Z0-9]{8,}[\"']|"
                r"\bactivation[_-]?code\s*[:=]\s*[\"'][A-Z0-9]{8,}[\"']|"
                r"\bserial[_-]?number\s*[:=]\s*[\"'][A-Z0-9]{8,}[\"']"),
            "Hardcoded key enables keygen generation. Use IDA to locate validate_license/keygen function.",
            cwe="CWE-798", confidence="medium",
        ),
        SentinelRule(
            "license-simple-strcmp", "trivial license check via strcmp", "HIGH", "license",
            _rx(r"\bstrcmp\s*\(\s*input|strcmp\s*\(\s*serial|strcmp\s*\(\s*key|strcmp\s*\(\s*license|"
                r"\bwcscmp\s*\(\s*input|_tcscmp\s*\(\s*serial|lstrcmp\s*\(\s*license"),
            "Trivial strcmp check — patch the JNE/JZ after strcmp or extract expected key from .rdata.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c", ".asm"),
        ),
        SentinelRule(
            "license-custom-crypto-verify", "Custom license verification algorithm", "MEDIUM", "license",
            _rx(r"\blicense.*(?:check|verify|validate|decode)|(?:check|verify|validate|decode).*license|"
                r"\b(?:serial|keygen|activation|regcode|crackme)\b"),
            "Locate the verification function in disassembly. Recover algorithm via reverse engineering.",
            cwe="", confidence="medium",
            extensions=(".cpp", ".c", ".py", ".java", ".asm"),
        ),
        SentinelRule(
            "license-time-bomb", "Time-limited trial / time-bomb pattern", "HIGH", "license",
            _rx(r"\bGetLocalTime\b|\bGetSystemTime\b|\btime\s*\(\s*0\s*\).*expir|\bgmtime\b.*expir|"
                r"\bSystem\.DateTime\.Now\b.*expir|timediff.*30|trial.*days.*left|\bexpire\b.*date"),
            "Hook the time retrieval function or patch the time comparison to bypass trial expiration.",
            cwe="", confidence="high",
        ),
        SentinelRule(
            "license-network-auth", "Network-based license verification", "HIGH", "license",
            _rx(r"\bHttpClient\b.*license|\bWinHttp\b.*activate|\bInternetConnect\b.*verify|"
                r"\bfetch\s*\(\s*[\"'](?:https?://).*(?:license|activate|verify|auth)|"
                r"\brequests\.(?:get|post)\s*\(.*license"),
            "Network auth calls home. MITM or DNS redirect to local validation server; patch HTTP response.",
            cwe="", confidence="high",
        ),
        SentinelRule(
            "license-registry-key-check", "Registry-based license check", "MEDIUM", "license",
            _rx(r"RegOpenKey.*License|RegOpenKey.*Registration|RegOpenKey.*Serial|"
                r"RegQueryValueEx.*ProductKey|RegQueryValueEx.*LicenseKey"),
            "Set the expected registry key/value or patch the RegOpenKeyEx return check.",
            cwe="", confidence="medium",
            extensions=(".cpp", ".c"),
        ),
        SentinelRule(
            "license-membership-key-pattern", "VIP membership / card-key generator pattern", "MEDIUM", "license",
            _rx(r"\b(?:vip|member|premium|gold|silver|diamond)\b.*\b(?:card|key|code|activate)|"
                r"\b卡密\b|\b激活码\b|\b会员卡\b"),
            "Extract key generation algorithm; patch membership check or generate valid card keys.",
            cwe="", confidence="medium",
        ),
        SentinelRule(
            "license-rsa-sign-verify", "RSA signature-based license verification", "MEDIUM", "license",
            _rx(r"\bRSA_verify\b|\bCryptVerifySignature\b|\bverify\s*\(\s*.*rsa|\bRSACryptoServiceProvider\.VerifyData\b"),
            "Replace public key with your own or patch the verification call to always return success.",
            cwe="", confidence="medium",
            extensions=(".cpp", ".c", ".cs", ".py", ".java"),
        ),
        SentinelRule(
            "license-name-serial-algo", "Name/Serial algorithm pattern", "HIGH", "license",
            _rx(r"\bname.*serial|serial.*name|\busername.*(?:key|serial|license)|compute.*serial|generate.*serial|"
                r"\bgen_key\b|\bcalckey\b"),
            "Capture generated serial for known names; reverse the gen_key algorithm for keygen creation.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c", ".py", ".asm"),
        ),

        # ═══════════════════════════════════════════════════════════════
        # Category: hook-framework — Hook框架检测
        # ═══════════════════════════════════════════════════════════════
        SentinelRule(
            "hook-frida-detection", "Frida instrumentation framework usage", "MEDIUM", "hook-framework",
            _rx(r"\bfrida\b|frida-server|frida-core|frida-gadget|\bfrida\.so\b|_frida_|frida-trace|"
                r"frida-ps|frida-ls|linjector|__frida\b"),
            "Frida detected — useful for dynamic analysis. Use object pinning to evade Frida detection.",
            cwe="", confidence="medium",
        ),
        SentinelRule(
            "hook-xposed-detection", "Xposed framework detection", "HIGH", "hook-framework",
            _rx(r"\bde\.robv\.android\.xposed\b|\bXposedBridge\b|\bXposedHelpers\b|"
                r"\bXposedInstaller\b|\bxposed\b.*hook|findAndHookMethod"),
            "Xposed framework active. Use Xposed detection bypass or LSPosed with hide module.",
            cwe="", confidence="high",
            extensions=(".java", ".kt", ".smali"),
        ),
        SentinelRule(
            "hook-substrate-detection", "Cydia Substrate / MobileSubstrate", "MEDIUM", "hook-framework",
            _rx(r"\bMSHookFunction\b|\bMSHookMessageEx\b|\bMSFindSymbol\b|\bsubstrate\b.*hook|"
                r"\bcydia\b.*substrate|libsubstrate\.dylib"),
            "Substrate hooks may be detected by checking for the substrate library in memory.",
            cwe="", confidence="medium",
            extensions=(".c", ".cpp", ".m", ".mm"),
        ),
        SentinelRule(
            "hook-inline-detour", "Inline hook / detour pattern", "HIGH", "hook-framework",
            _rx(r"\bDetourAttach\b|\bDetourDetach\b|\bMH_CreateHook\b|\bMH_EnableHook\b|"
                r"\bVirtualProtect\b.*hook|\bWriteProcessMemory\b.*patch|"
                r"\bmprotect\b.*PROT_WRITE.*hook|\bminhook\b|\beasyhook\b"),
            "Inline hook detected — could be malicious hooking or anti-cheat bypass. Audit the hook target.",
            cwe="", confidence="high",
        ),

        # ═══════════════════════════════════════════════════════════════
        # Category: rootkit — Rootkit/内核驱动恶意特征
        # ═══════════════════════════════════════════════════════════════
        SentinelRule(
            "rootkit-ssdt-hook", "SSDT hook / kernel function table modification", "CRITICAL", "rootkit",
            _rx(r"\bKeServiceDescriptorTable\b|\bSSDT\b.*hook|\bKiServiceTable\b|"
                r"\bZw[A-Z][a-z]+.*hook|\bNt[A-Z][a-z]+.*hook|__writecr0\b"),
            "SSDT hooking is kernel-level rootkit behavior. Requires kernel memory forensics.",
            cwe="", confidence="high",
            extensions=(".c", ".cpp", ".asm", ".s"),
        ),
        SentinelRule(
            "rootkit-idt-hook", "IDT hook / interrupt table modification", "CRITICAL", "rootkit",
            _rx(r"\bSIDT\b|\bLIDT\b|\bInterruptDescriptorTable\b|\bIDT\b.*hook|\bIDTR\b"),
            "IDT hooking intercepts interrupts. Analyze interrupt handler addresses for anomalies.",
            cwe="", confidence="high",
            extensions=(".c", ".cpp", ".asm", ".s"),
        ),
        SentinelRule(
            "rootkit-driver-callback", "Kernel driver callback registration", "HIGH", "rootkit",
            _rx(r"\bPsSetCreateProcessNotifyRoutine\b|\bPsSetCreateThreadNotifyRoutine\b|"
                r"\bPsSetLoadImageNotifyRoutine\b|\bCmRegisterCallback\b|\bObRegisterCallbacks\b"),
            "Kernel callbacks used for process/thread monitoring or hiding. Audit callback purpose.",
            cwe="", confidence="high",
            extensions=(".c", ".cpp"),
        ),
        SentinelRule(
            "rootkit-dkom", "Direct Kernel Object Manipulation (DKOM)", "CRITICAL", "rootkit",
            _rx(r"\bEprocess\b|\bEthread\b|\bActiveProcessLinks\b|PsActiveProcessHead|"
                r"\bLIST_ENTRY\b.*process.*hide|\bTokenSteal\b|\bEPROCESS\b.*ActiveProcessLinks"),
            "DKOM hides processes by unlinking EPROCESS entries. Use kernel memory forensics to detect.",
            cwe="", confidence="high",
            extensions=(".c", ".cpp", ".asm"),
        ),
        SentinelRule(
            "rootkit-filter-driver", "File system / network filter driver", "MEDIUM", "rootkit",
            _rx(r"\bDriverEntry\b.*\bFilter\b|\bFltRegisterFilter\b|\bFltStartFiltering\b|"
                r"\bIoCreateDevice\b.*\bFILE_DEVICE_UNKNOWN\b.*filter|NDIS.*filter"),
            "Filter driver can intercept I/O. Verify the filter chain for unauthorized drivers.",
            cwe="", confidence="medium",
            extensions=(".c", ".cpp"),
        ),
        SentinelRule(
            "rootkit-hidden-process", "Process hiding technique", "CRITICAL", "rootkit",
            _rx(r"\bZwQuerySystemInformation\b.*PROCESS.*hide|process.*hide.*ZwQuerySystemInformation|"
                r"\bRemoveEntryList\b.*process|process.*\bRemoveEntryList\b"),
            "Process hiding via SystemInformation hook or DKOM unlink. Use cross-view detection.",
            cwe="", confidence="high",
            extensions=(".c", ".cpp", ".asm"),
        ),
        SentinelRule(
            "rootkit-dkom-token", "Token stealing / privilege escalation", "CRITICAL", "rootkit",
            _rx(r"\bSeTokenType\b|\bTOKEN\b.*steal|steal.*token|replace.*token.*system|"
                r"TokenPrimary.*System|SeDebugPrivilege.*steal|PsReferencePrimaryToken\b"),
            "Token stealing for privilege escalation. Check token integrity and ownership.",
            cwe="CWE-269", confidence="high",
            extensions=(".c", ".cpp"),
        ),

        # ═══════════════════════════════════════════════════════════════
        # Category: crypto-recovery — 密码算法识别与恢复
        # ═══════════════════════════════════════════════════════════════
        SentinelRule(
            "crypto-aes-sbox", "AES S-Box constant in binary", "HIGH", "crypto-recovery",
            _rx(r"(?:0x63,\s*0x7c,\s*0x77,\s*0x7b|"
                r"0x637c777b|"
                r"63\s*7[cC]\s*77\s*7[bB])"),
            "AES S-Box identified. Locate key schedule and encryption/decryption routines in disassembly.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c", ".py", ".asm", ".s"),
        ),
        SentinelRule(
            "crypto-rc4-init", "RC4 KSA initialization pattern", "MEDIUM", "crypto-recovery",
            _rx(r"\bfor\s*\(\s*i\s*=\s*0\s*;\s*i\s*<\s*256\b.*\bS\[i\]\s*=\s*i\b|\bRC4_KEY\b|\brc4_init\b"),
            "RC4 key-scheduling algorithm detected. Locate key and decrypt data streams.",
            cwe="CWE-327", confidence="medium",
            extensions=(".cpp", ".c", ".py"),
        ),
        SentinelRule(
            "crypto-xor-obfuscation", "XOR-based string/data obfuscation", "MEDIUM", "crypto-recovery",
            _rx(r"\.decode\s*\(\s*['\"](?:base64|hex).*['\"]\s*,\s*['\"]['\"]\s*,\s*['\"]xor['\"]|"
                r"\bxor\b.*\bkey\b.*\bdecrypt\b|\bxor\s*\(.*0x[a-fA-F0-9]{2}"),
            "XOR-based obfuscation. Recover XOR key and decode strings/data in IDA/Ghidra script.",
            cwe="", confidence="medium",
        ),
        SentinelRule(
            "crypto-tea-xtea-xxtea", "TEA/XTEA/XXTEA cipher constants", "MEDIUM", "crypto-recovery",
            _rx(r"\b0x9E3779B9\b|\b0x9e3779b9\b|\b0xC6EF3720\b|\bDELTA\s*=\s*0x9E3779B9\b|"
                r"\btiny_encrypt\b|\btea_encrypt\b|\bxxtea\b"),
            "TEA-family cipher identified. The constant 0x9E3779B9 is the golden ratio delta value.",
            cwe="", confidence="medium",
            extensions=(".cpp", ".c", ".py"),
        ),
        SentinelRule(
            "crypto-md5-constants", "MD5 initialization constants", "MEDIUM", "crypto-recovery",
            _rx(r"\b0x67452301\b.*\b0xEFCDAB89\b.*\b0x98BADCFE\b.*\b0x10325476\b|"
                r"MD5_Init\b|\bmd5_init\b|\bMD5Init\b"),
            "MD5 hash function identified. If used for password hashing, recommend upgrade to Argon2/bcrypt.",
            cwe="CWE-327", confidence="medium",
            extensions=(".cpp", ".c", ".py"),
        ),
        SentinelRule(
            "crypto-custom-chaotic", "Custom/chaotic encryption algorithm", "LOW", "crypto-recovery",
            _rx(r"\b(?:scramble|shuffle|mix|permute|transform)\b.*\b(?:crypt|encrypt|decrypt|key)|"
                r"\b(?:crypt|encrypt|decrypt).*\b(?:scramble|shuffle|mix|chaos)\b"),
            "Custom encryption algorithm — likely weak. Isolate and reverese the transform logic.",
            cwe="CWE-327", confidence="low",
        ),

        # ═══════════════════════════════════════════════════════════════
        # Category: binary-patch — 二进制Patch模式
        # ═══════════════════════════════════════════════════════════════
        SentinelRule(
            "patch-je-to-jmp", "Conditional jump patchable to unconditional", "MEDIUM", "binary-patch",
            _rx(r"\b(?:74|0F\s*84|0F\s*85|75|7C|7D|7E|7F)\b.*\b(?:license|trial|expir|check|verify|auth)\b"),
            "Conditional jump over license/auth check — patch JE (0x74) to JMP (0xEB) or NOP.",
            cwe="", confidence="medium",
            extensions=(".asm", ".s"),
        ),
        SentinelRule(
            "patch-function-return", "Function returns constant bypass value", "MEDIUM", "binary-patch",
            _rx(r"\b(?:xor\s+eax,\s*eax|mov\s+eax,\s*1|ret\s*\d+)\b.*\b(?:license|check|verify|validate|auth|trial)\b"),
            "Function returns hardcoded result. Patch to always return success value (eax=1 / ret 0).",
            cwe="", confidence="medium",
            extensions=(".asm", ".s"),
        ),
        SentinelRule(
            "patch-nop-sled", "NOP sled / dead zone > 5 consecutive NOPs", "MEDIUM", "binary-patch",
            _rx(r"(?:\b90\b\s*){5,}"),
            "Large NOP sled detected — possibly patched code. Verify if original instructions were overwritten.",
            cwe="", confidence="low",
            extensions=(".asm", ".s", ".hex"),
        ),

        # ═══════════════════════════════════════════════════════════════
        # Category: android-re — APK/Android逆向
        # ═══════════════════════════════════════════════════════════════
        SentinelRule(
            "android-dex-protector", "DEX protector / APK packer detected", "HIGH", "android-re",
            _rx(r"\bcom\.dpt\.(?:proxy|shell)\b|\bcom\.lijun\.shell\b|\bcom\.qihoo\.(?:stub|util)\b|"
                r"\bcom\.tencent\.StubShell\b|\bcom\.baidu\.protect\b|\balipay\.safe\b|"
                r"\bcom\.secneo\.apkwrapper\b|360.*jiagu|bangcle|ijiami|naga|ditor|love|netqin|"
                r"\bcom\.qihoo\.magic\.x86\b|\bcom\.qihoo\.magic\.arm\b"),
            "APK packer/protector found. Use Frida to dump DEX from memory; use DumpDex/FRIDA-DEXDump.",
            cwe="", confidence="high",
            extensions=(".java", ".smali", ".kt", ".xml"),
        ),
        SentinelRule(
            "android-native-lib", "Native JNI library with sensitive logic", "MEDIUM", "android-re",
            _rx(r"\bSystem\.loadLibrary\s*\(\s*\"(?:native|core|security|crypto|protect|arm|check|verify|encrypt|"
                r"decrypt|license|antidebug|antitamper|shell|encrypt|dex|proxy)"),
            "Native library contains security logic. Extract and reverse with IDA/Ghidra for ARM/ARM64 analysis.",
            cwe="", confidence="medium",
            extensions=(".java", ".kt"),
        ),
        SentinelRule(
            "android-ssl-pinning", "SSL certificate pinning in Android", "MEDIUM", "android-re",
            _rx(r"\bokhttp3\.CertificatePinner\b|\bSSLPinning\b|\bTrustManager\b.*checkServerTrusted|"
                r"\bnetwork_security_config\.xml\b|\bpin\b.*certificate|certificate.*pin"),
            "SSL pinning blocks MITM. Bypass with Frida SSL pinning script or JustTrustMe Xposed module.",
            cwe="", confidence="medium",
            extensions=(".java", ".kt"),
        ),
        SentinelRule(
            "android-emulator-check", "Android emulator/root detection", "HIGH", "android-re",
            _rx(r"\bisEmulator\b|\bcheckEmulator\b|\bisRooted\b|\bRootBeer\b|"
                r"\bsu\b.*exists|test-keys|Superuser\.apk|Magisk|/system/app/Super"),
            "Emulator/root detection. Bypass with MagiskHide, RootCloak Xposed, or patch the check methods.",
            cwe="", confidence="high",
            extensions=(".java", ".kt"),
        ),
        SentinelRule(
            "android-webview-debug", "WebView debugging enabled in release build", "MEDIUM", "android-re",
            _rx(r"\bWebView\.setWebContentsDebuggingEnabled\s*\(\s*true\b|"
                r"\bwebContentsDebuggingEnabled\s*=\s*true\b"),
            "WebView debug exposes internal WebView via Chrome DevTools. Remove before release.",
            cwe="CWE-489", confidence="high",
            extensions=(".java", ".kt"),
        ),
        SentinelRule(
            "android-frida-gadget", "Frida gadget embedded in APK", "LOW", "android-re",
            _rx(r"frida-gadget.*\.so|libfrida-gadget|frida-gadget.*\.dylib"),
            "Frida gadget embedded — indicates dynamic analysis preparation or anti-Frida detection.",
            cwe="", confidence="low",
            extensions=(".java", ".kt", ".so"),
        ),

        # ═══════════════════════════════════════════════════════════════
        # Category: web-re — Web逆向/JS混淆
        # ═══════════════════════════════════════════════════════════════
        SentinelRule(
            "web-js-obfuscation", "JavaScript obfuscation detected", "HIGH", "web-re",
            _rx(r"\b(?:eval\s*\(\s*(?:function|String|unescape)|_0x[a-f0-9]{4,}\s*=|"
                r"\\x[0-9a-fA-F]{2}\\x[0-9a-fA-F]{2}|\\\\u[0-9a-fA-F]{4}|"
                r"fromCharCode|atob|btoa)\b"),
            "JS obfuscation detected. Use Babel AST-based deobfuscator or JS Nice / JStillery.",
            cwe="", confidence="high",
            extensions=(".js", ".mjs"),
        ),
        SentinelRule(
            "web-wasm-crypto", "WebAssembly crypto/wasm analysis target", "MEDIUM", "web-re",
            _rx(r"\bWebAssembly\.instantiate\b|\bwasm\b.*\bencrypt\b|wasm.*decrypt|wasm.*license|"
                r"\.wasm\b"),
            "WASM binary contains crypto/license logic. Extract and analyze with wasm-decompile/wabt.",
            cwe="", confidence="medium",
            extensions=(".js", ".html"),
        ),
        SentinelRule(
            "web-js-anti-debugger", "JS anti-debugger / DevTools detection", "MEDIUM", "web-re",
            _rx(r"\bdebugger\s*;\s*\}|\bsetInterval\s*\(\s*function\s*\(\s*\)\s*\{\s*debugger|"
                r"\bconsole\.log\s*\(\s*%c.*font-size|"
                r"\bObject\.defineProperty\s*\(.*\bconsole\b|__proto__.*devtool|devtool.*detect"),
            "JavaScript anti-debugger. Override setInterval/debugger; use DevTools protocol bypass.",
            cwe="", confidence="medium",
            extensions=(".js", ".mjs", ".html"),
        ),
        SentinelRule(
            "web-js-fingerprint", "Browser fingerprinting code", "LOW", "web-re",
            _rx(r"\bnavigator\.(?:userAgent|platform|language|hardwareConcurrency|deviceMemory)\b.*canvas|"
                r"canvas.*fingerprint|webgl.*fingerprint|audio.*fingerprint|\bFingerprintJS\b|"
                r"\bcanvas\.toDataURL\b.*\btoBlob\b"),
            "Browser fingerprinting detected. May be used for anti-bot/anti-scraping.",
            cwe="", confidence="low",
            extensions=(".js", ".mjs", ".html"),
        ),
        SentinelRule(
            "web-js-vm-obfuscation", "JS VM-based obfuscation (Obfuscator.io/JavascriptObfuscator)", "HIGH", "web-re",
            _rx(r"\b_0x[a-f0-9]{4,6}\b.*\bswitch\b.*\bcase\b.*\bcontinue\b.*\bbreak\b|"
                r"\bvar\s+_0x[a-f0-9]+\s*=\s*function\s*\(\s*_0x[a-f0-9]+,\s*_0x[a-f0-9]+"),
            "VM-based JS obfuscation (likely obfuscator.io). Use webcrack/synchrony for deobfuscation.",
            cwe="", confidence="high",
            extensions=(".js", ".mjs"),
        ),

        # ═══════════════════════════════════════════════════════════════
        # Category: ioc-yara — IoC/YARA特征
        # ═══════════════════════════════════════════════════════════════
        SentinelRule(
            "ioc-c2-ip-pattern", "Hardcoded C2 IP address", "CRITICAL", "ioc-yara",
            _rx(r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b.*"
                r"\b(?:connect|socket|port|send|recv|c2|command|beacon)\b"),
            "Hardcoded C2 IP — possibly malware beacon. Extract and add to threat intel blocklist.",
            cwe="", confidence="high",
        ),
        SentinelRule(
            "ioc-c2-domain-pattern", "Suspected C2 domain pattern", "HIGH", "ioc-yara",
            _rx(r"\b[a-z0-9]{8,32}\.(?:xyz|top|tk|ml|ga|cf|pw|cc|su|click|club|online|site|"
                r"stream|download|party|review|country|link|gdn|racing)\b"),
            "Suspicious TLD commonly used for C2/malware domains. Verify domain reputation.",
            cwe="", confidence="high",
        ),
        SentinelRule(
            "ioc-mutex-name", "Named mutex for single-instance (common in malware)", "MEDIUM", "ioc-yara",
            _rx(r"\bCreateMutex\b.*[\"'][A-Za-z0-9_-]{8,32}[\"']|OpenMutex\b.*[\"'][^\"]{8,}[\"']"),
            "Named mutex used for single-instance lock — common malware anti-duplicate mechanism.",
            cwe="", confidence="medium",
            extensions=(".cpp", ".c"),
        ),
        SentinelRule(
            "ioc-persistence-registry", "Registry persistence mechanism", "HIGH", "ioc-yara",
            _rx(r"RegSetValueEx.*\\\\SOFTWARE\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Run\b|"
                r"RegSetValueEx.*RunOnce|RegSetValueEx.*Winlogon\\\\Shell|"
                r"RegSetValueEx.*\\\\Windows\\\\CurrentVersion\\\\Policies\\\\Explorer\\\\Run\b"),
            "Registry persistence entry created — common for malware/RAT. Remove and audit startup items.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c", ".ps1", ".bat", ".vbs"),
        ),
        SentinelRule(
            "ioc-scheduled-task", "Scheduled task persistence", "MEDIUM", "ioc-yara",
            _rx(r"\bRegister-A task\b|\bNew-ScheduledTask\b|\bschtasks\s+/create\b|\bcron\b.*@reboot|"
                r"\bSystemd\b.*WantedBy.*multi-user|\bITaskScheduler\b.*NewWorkItem"),
            "Scheduled task persistence. Remove malicious scheduled tasks and audit task scheduler.",
            cwe="", confidence="medium",
            extensions=(".ps1", ".bat", ".cpp", ".c", ".sh"),
        ),
        SentinelRule(
            "ioc-service-install", "Windows service installation (persistence)", "HIGH", "ioc-yara",
            _rx(r"\bCreateService\b|\bOpenSCManager\b|\bStartService\b|\bsc\s+create\b|"
                r"\bNew-Service\b|\bStart-Service\b"),
            "Windows service creation — classic malware persistence. Check for unsigned/unapproved services.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c", ".ps1", ".bat"),
        ),
        SentinelRule(
            "ioc-process-injection", "Process injection technique", "CRITICAL", "ioc-yara",
            _rx(r"\bCreateRemoteThread\b|\bNtCreateThreadEx\b|\bRtlCreateUserThread\b|"
                r"\bVirtualAllocEx\b.*CreateRemoteThread|\bWriteProcessMemory\b.*CreateRemoteThread|"
                r"\bQueueUserAPC\b|\bSetThreadContext\b|\bNtMapViewOfSection\b"),
            "Process injection detected — common in malware for code execution in another process.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c"),
        ),
        SentinelRule(
            "ioc-reflective-dll", "Reflective DLL loading", "CRITICAL", "ioc-yara",
            _rx(r"\bReflectiveLoader\b|\bDLL_LOADER\b.*Reflective|\bLoadLibraryA\b.*memory|"
                r"PE.*loader.*memory|manual.*map.*dll|ManualMap\b"),
            "Reflective DLL injection loads PE from memory without touching disk. Common in APT malware.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c", ".asm"),
        ),
        SentinelRule(
            "ioc-dns-query", "Suspicious DNS query API call", "MEDIUM", "ioc-yara",
            _rx(r"\bDnsQuery\b|\bgethostbyname\b|\bgetaddrinfo\b.*\bC2\b|resolve.*hostname.*base64|"
                r"dns.*txt.*record|dns.*over.*https"),
            "DNS query potentially used for C2 communication or data exfiltration via DNS tunneling.",
            cwe="", confidence="medium",
            extensions=(".cpp", ".c", ".py"),
        ),

        # ═══════════════════════════════════════════════════════════════
        # Category: ransomware — 勒索软件特征
        # ═══════════════════════════════════════════════════════════════
        SentinelRule(
            "ransomware-encrypt-api", "Ransomware encryption API pattern", "CRITICAL", "ransomware",
            _rx(r"\bCryptEncrypt\b|\bCryptDecrypt\b|\bCryptAcquireContext\b|\bBCryptEncrypt\b|"
                r"\bRtlGenRandom\b|\bCryptGenRandom\b.*\bCryptEncrypt\b|"
                r"\bAES\b.*\bencrypt\b.*\bfile\b.*\bextension\b"),
            "Crypto API usage matching ransomware encrypt pattern. Perform full dynamic analysis.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c"),
        ),
        SentinelRule(
            "ransomware-file-enum", "Ransomware bulk file enumeration", "CRITICAL", "ransomware",
            _rx(r"\bFindFirstFile\b.*\bFindNextFile\b|\bFindFirstFileEx\b.*\bfind_next\b.*encrypt|"
                r"recursive.*directory.*encrypt|walk.*file.*encrypt|enumerate.*file.*(?:aes|rsa|lock)"),
            "Bulk file enumeration + encryption — classic ransomware pattern. Isolate and analyze in sandbox.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c", ".py"),
        ),
        SentinelRule(
            "ransomware-note-creation", "Ransom note creation pattern", "CRITICAL", "ransomware",
            _rx(r"\b(?:ransom|decrypt|how\s+to\s+decrypt|howto_|readme_|recover_|pay_"
                r"|bitcoin|monero|wallet|attackers|contact).*\.(?:txt|html|hta)\b|"
                r"YOUR_FILES_ARE_ENCRYPTED|HELP_DECRYPT|DECRYPT_INSTRUCTIONS"),
            "Ransom note filename/content pattern. Immediate containment required. Do not pay ransom.",
            cwe="", confidence="high",
        ),
        SentinelRule(
            "ransomware-shadow-copy", "Shadow copy deletion (ransomware behavior)", "CRITICAL", "ransomware",
            _rx(r"\bvssadmin\s+delete\s+shadows\b|\bwmic\s+shadowcopy\s+delete\b|"
                r"\bIWbemServices\b.*delete.*shadow|vssadmin.*resize.*shadowstorage|"
                r"\bDeleteShadowCopies\b"),
            "Shadow copy deletion prevents file recovery — strong ransomware indicator. Isolate immediately.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c", ".bat", ".ps1"),
        ),
        SentinelRule(
            "ransomware-wallpaper-change", "Desktop wallpaper change (ransomware)", "MEDIUM", "ransomware",
            _rx(r"\bSystemParametersInfo\b.*\bSPI_SETDESKWALLPAPER\b|"
                r"\bIActiveDesktop\b.*SetWallpaper|Change.*wallpaper.*ransom"),
            "Changing desktop wallpaper is common ransomware UI behavior. Investigate in context.",
            cwe="", confidence="medium",
            extensions=(".cpp", ".c"),
        ),

        # ═══════════════════════════════════════════════════════════════
        # Category: rat-backdoor — 远控/后门/RAT特征
        # ═══════════════════════════════════════════════════════════════
        SentinelRule(
            "rat-reverse-shell", "Reverse shell connection pattern", "CRITICAL", "rat-backdoor",
            _rx(r"\b(?:cmd\.exe|/bin/sh|/bin/bash)\b.*socket.*connect|socket.*connect.*(?:cmd|sh|bash)|"
                r"\b(?:WSASocket|socket)\b.*\bconnect\b.*\bCreateProcess\b.*\bcmd\b|"
                r"\breverse_shell\b|\bconnect_back\b|rev.*shell.*connect"),
            "Reverse shell code — creates remote command execution channel. Contain and investigate.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c", ".py", ".ps1", ".sh", ".rb"),
        ),
        SentinelRule(
            "rat-keylogger-pattern", "Keylogger / input capture pattern", "CRITICAL", "rat-backdoor",
            _rx(r"\bSetWindowsHookEx\b.*\bWH_KEYBOARD\b|\bGetAsyncKeyState\b|\bGetKeyState\b|"
                r"\bGetForegroundWindow\b.*keylog|key.*log.*window|GetKeyboardState\b|\bkeylog\b"),
            "Keylogger API usage — captures keystrokes. Remove and audit for exfiltrated data.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c"),
        ),
        SentinelRule(
            "rat-screen-capture", "Screen capture capability", "MEDIUM", "rat-backdoor",
            _rx(r"\bBitBlt\b|\bCreateCompatibleDC\b|\bGetDC\b.*NULL\b|desktop.*screenshot|"
                r"\bGraphics\.CopyFromScreen\b|screenshot.*desktop|screen.*capture.*send"),
            "Screen capture code — common RAT spy functionality. Audit for data exfiltration path.",
            cwe="", confidence="medium",
            extensions=(".cpp", ".c", ".cs", ".py"),
        ),
        SentinelRule(
            "rat-camera-mic-access", "Webcam/microphone access pattern", "HIGH", "rat-backdoor",
            _rx(r"\bcapCreateCaptureWindow\b|\bVideoCapture\b|\bAVCapture\b|webcam.*capture|"
                r"\bwaveInOpen\b|\bwaveInStart\b|microphone.*record|\baudio.*record.*send"),
            "Camera/mic access — spyware/RAT surveillance capability. Block and audit device access.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c", ".cs", ".py"),
        ),
        SentinelRule(
            "rat-clipboard-hijack", "Clipboard monitoring / cryptocurrency hijack", "MEDIUM", "rat-backdoor",
            _rx(r"\bGetClipboardData\b|clipboard.*monitor|clipboard.*crypto|"
                r"\bAddClipboardFormatListener\b|WM_CLIPBOARDUPDATE|clipboard.*btc|clipboard.*eth"),
            "Clipboard monitoring — may replace crypto addresses. Check clipboard content manipulation.",
            cwe="", confidence="medium",
            extensions=(".cpp", ".c", ".py"),
        ),

        # ═══════════════════════════════════════════════════════════════
        # Category: miner — 挖矿木马特征
        # ═══════════════════════════════════════════════════════════════
        SentinelRule(
            "miner-cryptonight", "CryptoNight mining algorithm", "HIGH", "miner",
            _rx(r"\bCryptonight\b|\bcryptonight\b|\bcn_fast_hash\b|\bcn_slow_hash\b|\bkeccak\b.*\bcn_\b|"
                r"\baes_round\b.*\bcn\b|\bxmrig\b|minerd?\b.*cryptonight"),
            "CryptoNight miner (Monero/XMR). High CPU usage pattern. Terminate and remove.",
            cwe="", confidence="high",
            extensions=(".cpp", ".c", ".py", ".sh"),
        ),
        SentinelRule(
            "miner-stratum-protocol", "Stratum mining pool protocol", "HIGH", "miner",
            _rx(r"\bstratum\+tcp\b|stratum.*mining\.(?:submit|authorize|login)|"
                r"\bjson_rpc_url\b.*pool|pool.*mining\.(?:submit|authorize)|"
                r"\bmining\.notify\b|\bmining\.set_difficulty\b"),
            "Stratum protocol communication — connects to mining pool. Block pool connection at network.",
            cwe="", confidence="high",
        ),
        SentinelRule(
            "miner-hidden-window", "Hidden/minimized miner window", "MEDIUM", "miner",
            _rx(r"\bSW_HIDE\b|\bShowWindow\s*\(.*\bSW_MINIMIZE\b|\bCREATE_NO_WINDOW\b.*\bPopen\b|"
                r"hidden.*process.*miner|silent.*miner.*start|background.*mine"),
            "Miner running in hidden window. Check running processes for unauthorized miners.",
            cwe="", confidence="medium",
            extensions=(".cpp", ".c", ".py", ".bat", ".ps1"),
        ),
        SentinelRule(
            "miner-cpu-affinity", "CPU affinity setting (common in miners)", "MEDIUM", "miner",
            _rx(r"\bSetProcessAffinityMask\b|\bSetThreadAffinityMask\b|"
                r"\bpthread_setaffinity_np\b|taskset\b.*\bcpu\b"),
            "CPU affinity lock — miners pin to all cores for maximum hashrate. Investigate process purpose.",
            cwe="", confidence="medium",
            extensions=(".cpp", ".c", ".py"),
        ),

        # ═══════════════════════════════════════════════════════════════
        # Category: ctf-attack — CTF攻击特征
        # ═══════════════════════════════════════════════════════════════
        SentinelRule(
            "ctf-format-string", "Format string vulnerability pattern", "HIGH", "ctf-attack",
            _rx(r"\bprintf\s*\(\s*(?:buf|input|argv|arg|msg|user)\b|\bfprintf\b.*\bstdout\b|\bsprintf\b.*\bfmt\b|"
                r"\bdprintf\b.*\binput\b|\b__android_log_print\b.*input|\bvprintf\b.*input"),
            "Format string bug — attacker-controlled format string passed to printf-family. Use %n exploitation.",
            cwe="CWE-134", confidence="high",
            extensions=(".c", ".cpp"),
        ),
        SentinelRule(
            "ctf-stack-buffer-overflow", "Stack buffer overflow pattern", "HIGH", "ctf-attack",
            _rx(r"\bgets\s*\(\s*(?:buf|input|name|msg|str|password)\b|\bstrcpy\s*\(\s*dest\b.*input|"
                r"\bscanf\s*\(\s*\"%s\".*buf|\bread\s*\(\s*0\s*,\s*buf\b.*0x[0-9a-fA-F]{3,}|"
                r"\bgets_s\b.*overflow|\bfgets\b.*\bBUFSIZ\b.*\bstdin\b"),
            "Classic stack buffer overflow sink. Control return address via offset calculation.",
            cwe="CWE-121", confidence="high",
            extensions=(".c", ".cpp"),
        ),
        SentinelRule(
            "ctf-heap-use-after-free", "Use-after-free vulnerability pattern", "HIGH", "ctf-attack",
            _rx(r"\bfree\s*\(.*\)\s*;.*\buse\b|\bdelete\b.*\buse\b|\bfree\b.*\bdangling\b|"
                r"\bUAF\b|\buse_after_free\b|\bfree\b.*ptr.*\bptr\b"),
            "Use-after-free — free'd pointer still referenced. Exploit via heap spray + vtable overwrite.",
            cwe="CWE-416", confidence="high",
            extensions=(".c", ".cpp"),
        ),
        SentinelRule(
            "ctf-integer-overflow", "Integer overflow vulnerability", "MEDIUM", "ctf-attack",
            _rx(r"\bmalloc\s*\(\s*size\s*\*\s*sizeof|\bINT_MAX\b.*\bsize\b|"
                r"\bif\s*\(\s*size\s*<=\s*MAX\b.*malloc.*size\s*\*|"
                r"\bcalloc\b.*\bnum\b.*\bsize\b.*overflow"),
            "Integer overflow in allocation. Trigger with crafted size to under-allocate and overflow.",
            cwe="CWE-190", confidence="medium",
            extensions=(".c", ".cpp"),
        ),
        SentinelRule(
            "ctf-rop-gadget", "ROP gadget identified in binary", "MEDIUM", "ctf-attack",
            _rx(r"\bpop\s+(?:rdi|rsi|rdx|rcx|rax|rbx)\s*;\s*ret\b|\bgadget\b.*\bpop\b|\bROPgadget\b|\bropper\b|\bROP\b"),
            "ROP gadgets present in binary. Chain gadgets to bypass NX/DEP via ret2libc/ROP.",
            cwe="", confidence="medium",
            extensions=(".asm", ".s", ".py"),
        ),
        SentinelRule(
            "ctf-shellcode-buffer", "Shellcode buffer / egg-hunter pattern", "HIGH", "ctf-attack",
            _rx(r"\bunsigned\s+char\s+(?:shellcode|code|payload|egg|sc|buf)\s*\[\s*\]\s*=\s*\{|"
                r"\bchar\s+(?:shellcode|code|payload|sc|buf)\s*\[\s*\]\s*=\s*\"\\\\x|\b\\x[0-9a-fA-F]{2}\b"),
            "Shellcode buffer in source. Extract and analyze with scdbg/speakeasy/libemu.",
            cwe="CWE-94", confidence="high",
        ),
        SentinelRule(
            "ctf-race-condition", "Race condition / TOCTOU in CTF context", "MEDIUM", "ctf-attack",
            _rx(r"\baccess\s*\(.*\)\s*;.*\bopen\b|\bstat\b.*\bfopen\b|\bO_CREAT\b.*\baccess\b|"
                r"\bcheck\b.*\buse\b.*\brace\b|\brace_condition\b|\bTOCTOU\b"),
            "TOCTOU race — check-then-use gap exploitable via symlink race. Use inotify-based exploit.",
            cwe="CWE-367", confidence="medium",
            extensions=(".c", ".cpp", ".py"),
        ),
        SentinelRule(
            "ctf-pickle-deser", "Pickle deserialization (Python CTF)", "HIGH", "ctf-attack",
            _rx(r"\bpickle\.loads?\s*\("),
            "Pickle deserialization — RCE via __reduce__ gadget. Craft malicious pickle payload.",
            cwe="CWE-502", confidence="high",
            extensions=(".py",),
        ),
        SentinelRule(
            "ctf-php-deser", "PHP unserialize vulnerability", "HIGH", "ctf-attack",
            _rx(r"\bunserialize\s*\(\s*\$_(?:GET|POST|COOKIE|REQUEST)\b"),
            "PHP unserialize — object injection to RCE via __wakeup/__destruct magic methods.",
            cwe="CWE-502", confidence="high",
            extensions=(".php",),
        ),
    ]
