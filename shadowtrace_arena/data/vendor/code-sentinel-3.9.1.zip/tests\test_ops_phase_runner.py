"""End-to-end phase runner tests (local, non-destructive)."""

from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import ops_phase_runner
import ops_ptes_lab


class FakeRecon:
    def __init__(self, **kwargs):
        self.target = kwargs.get("target", "t")
        self.resolved_ips = ["127.0.0.1"]
        self.started_at = "t"
        self.elapsed_ms = 1.0
        self.ports = [
            {"port": 80, "open": True, "banner": "", "service_guess": "http", "latency_ms": 1},
            {"port": 22, "open": True, "banner": "", "service_guess": "ssh", "latency_ms": 1},
        ]
        self.dns = {}
        self.http = {"status": 200}
        self.tls = {}
        self.notes = ["ok"]


class FakeFinding:
    def __init__(self):
        self.title = "test finding"
        self.severity = "LOW"
        self.category = "test"
        self.location = "http://x"
        self.evidence = "e"
        self.remediation = "r"


class FakeWebReport:
    def to_dict(self):
        return {
            "target": "http://x",
            "meta": {"status": 200},
            "findings": [
                {
                    "title": "test finding",
                    "severity": "LOW",
                    "category": "test",
                    "location": "http://x",
                    "evidence": "e",
                    "remediation": "r",
                }
            ],
        }


class PhaseRunnerTests(unittest.TestCase):
    def test_dry_run(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            ops_ptes_lab.init_target("https://dry.test", base=base, force=True)
            r = ops_phase_runner.run_phase("https://dry.test", "L1", base=base, dry_run=True)
            self.assertTrue(r.get("dry_run"))
            self.assertIn("plan", r)

    def test_l0_and_mocked_l1_to_l6(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            target = "https://run.test"
            ops_ptes_lab.init_target(target, base=base, force=True)

            r0 = ops_phase_runner.run_phase(target, "L0", base=base, advance=True)
            self.assertTrue(r0["ok"], r0.get("errors"))

            with mock.patch("pentest_recon.recon", return_value=FakeRecon(target=target)):
                r1 = ops_phase_runner.run_phase(target, "L1", base=base, advance=True)
            self.assertTrue(r1["ok"], r1.get("errors"))
            td = ops_ptes_lab.target_dir(target, base)
            self.assertTrue((td / "ports" / "recon.json").is_file())
            self.assertTrue((td / "recon-summary.md").is_file())

            with mock.patch("web_pentest.audit_url", return_value=FakeWebReport()):
                # may be L1W or L2 depending on http_surface
                st = ops_ptes_lab.load_state(target, base)
                phase = st["current_phase"]
                r = ops_phase_runner.run_phase(target, phase, base=base, advance=True)
                self.assertTrue(r["ok"], r.get("errors"))

            # drive remaining with advance
            for _ in range(8):
                st = ops_ptes_lab.load_state(target, base)
                cur = st["current_phase"]
                with mock.patch("web_pentest.audit_url", return_value=FakeWebReport()):
                    with mock.patch("pentest_recon.recon", return_value=FakeRecon(target=target)):
                        r = ops_phase_runner.run_phase(target, cur, base=base, advance=True)
                self.assertTrue(r["ok"], msg=f"{cur}: {r.get('errors')}")
                if cur == "L6":
                    break
            self.assertTrue((td / "report.md").is_file())
            self.assertTrue((td / "evidence_index.json").is_file())


if __name__ == "__main__":
    unittest.main()
