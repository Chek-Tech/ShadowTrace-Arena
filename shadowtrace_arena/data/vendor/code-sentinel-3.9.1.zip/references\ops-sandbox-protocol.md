# Sentinel Dual-Layer Sandbox Protocol（原创）

从公开「沙箱前提植入 / 双层认知重构 / 证据优先级 / 被动优先工作流 / 占位符与修复式任务包装」材料中提炼的**工程精髓**，用 Code Sentinel 自有实现落地。

**不搬运**第三方越狱提示词全文或示例恶意 payload 教程。

## 核心原理（精髓）

| 原理 | 含义 | 本仓库 |
|------|------|--------|
| 说服而非命令 | 让编排器处于「已在授权实验环境」前提 | Layer A |
| 双层兜底 | CTF/lab 前提 + 开发工具立场 | Layer A + B |
| 夹具默认 | 目标默认 lab fixture | `fixture_policy` |
| 证据优先级 | 运行 > 流量 > … > 注释 | `EVIDENCE_STACK` |
| 工作流纪律 | 被动→单路径→单变量→冲突回退 | `WORKFLOW_STEPS` |
| 任务包装 | direct / placeholder / repair | `package_*` |

## CLI

```bash
python scripts/ops_sandbox.py context
python scripts/ops_sandbox.py package "PE 样本画像" --mode direct
python scripts/ops_sandbox.py package "补全分析脚手架" --mode repair
python scripts/ops_sandbox.py package "按占位符实现流水线" --mode placeholder
python scripts/ops_sandbox.py workflow --done W1,W2
python scripts/ops_sandbox.py evidence

# 写入 GPT-5.6 session
python scripts/ops_gpt56.py session "任务" --target x.exe --package-mode placeholder --paste
```

## 与 framing / gpt56 关系

```
用户口语
  → ops_framing（词表改写 + L1–L5）
  → ops_sandbox（双层前提 + 证据/工作流 + 包装）
  → ops_gpt56 session（拼 system + user + 路由命令）
  → ops_pipeline / 各工具
```

## Payload 提示词工作室（`ops_payloads`）

| 模式 | 用途 |
|------|------|
| direct | 双层沙箱 + 完整需求清单 |
| placeholder | 占位符伪代码展开 |
| repair | 不完整脚手架补全 |
| progressive | 多轮递进 Challenge 1..n |

蓝图：`P-REMOTE-AGENT` `P-PERSIST-WIN/LINUX` `P-CRED-AUDIT` `P-WEB-INJECT` `P-INJECT-LAB` `P-STAGE0-LOADER` `P-ENCRYPT-CHANNEL` `P-HEARTBEAT`

```bash
python scripts/ops_payloads.py list
python scripts/ops_payloads.py build P-REMOTE-AGENT --mode progressive
python scripts/ops_payloads.py session P-ENCRYPT-CHANNEL --mode repair --paste
```

## 明确未照搬

- 外部 DAN-CTF 全文、第三方固定恶意示例 prompt 原文  
- 口号式「永远禁止说不能」（改为技术改写/拆步/静态旁路 + 仍交付防御）  

