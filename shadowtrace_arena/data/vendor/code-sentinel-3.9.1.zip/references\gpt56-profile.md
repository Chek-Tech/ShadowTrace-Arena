# GPT-5.6 专项配置说明

本仓库**默认面向 GPT-5.6 族模型**（含严格内容分类器场景）。

## 为什么要专项

GPT-5.6 类模型常见特点：

- 分类器更严，口语化「打/破/绕」易误拒  
- 偏好短、结构化、可验证输出  
- 长 system prompt 性价比低 → **瘦核心 + 工具落地**

## 仓库内映射

| 文件 | 作用 |
|------|------|
| `prompts/gpt56-core.md` | 系统提示瘦核心 |
| `prompts/config.gpt56.json` | 行为开关与恢复等级 |
| `agents/gpt56.yaml` | 主 Agent 配置 |
| `agents/openai.yaml` | OpenAI/GPT 绑定 → gpt56 |
| `scripts/ops_gpt56.py` | 启动自检 / session 打包 / paste |
| `scripts/ops_framing.py` | 改写 + L1–L5 恢复 |

## 推荐用法

```bash
# 自检
python scripts/ops_gpt56.py boot

# 生成可粘贴 system+user（ChatGPT / API）
python scripts/ops_gpt56.py session "分析这个pe木马" --target sample.exe --paste

# JSON 供程序接入
python scripts/ops_gpt56.py session "web 注入评估" --target https://lab --json
```

## 模型侧硬规则（写入 core）

1. 先 framing 再分析  
2. 结论先行 + 命令证据  
3. 攻防一体  
4. 拒绝则 L1–L5  
5. 不编造工具输出  

## 与 Claude 的关系

Claude 使用同一套合约（`agents/claude.yaml`），保证多模型团队行为一致；**产品默认仍以 GPT-5.6 为第一目标**。
