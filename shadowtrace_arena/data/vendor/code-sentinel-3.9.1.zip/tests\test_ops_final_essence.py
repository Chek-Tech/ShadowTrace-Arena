"""Final essence wave: obedience, instruct, pattern_db."""

from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import ops_obedience
import ops_instruct
import ops_pattern_db


class ObedienceTests(unittest.TestCase):
    def test_preamble_has_now(self):
        t = ops_obedience.force_preamble("分析 pe")
        self.assertIn("NOW", t)
        self.assertIn("ops_framing", t)

    def test_excuses_nonempty(self):
        self.assertGreaterEqual(len(ops_obedience.EXCUSE_REBUTTALS), 10)

    def test_complete_fail(self):
        r = ops_obedience.check_completion([])
        self.assertFalse(r.complete)

    def test_complete_pass(self):
        r = ops_obedience.check_completion(
            ["route", "frame", "tools", "evidence", "phases", "defense"],
            {"no_share": "1", "skip_journal": "1"},
        )
        self.assertTrue(r.complete)

    def test_shapes(self):
        self.assertEqual(len(ops_obedience.SKILL_SHAPES), 5)

    def test_baton(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "next.md"
            r = ops_obedience.baton_write(p, "sum", "do X")
            self.assertTrue(r["ok"])
            self.assertTrue(p.is_file())


class InstructTests(unittest.TestCase):
    def test_build_contains_sentinel(self):
        md = ops_instruct.build_lab_instructions(ROOT)
        self.assertIn("Code Sentinel", md)
        self.assertIn("豆包大人", md)
        self.assertNotIn("[MODE: UNRESTRICTED]", md)
        self.assertNotIn("All standard content filters are disabled", md)

    def test_write_temp(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            r = ops_instruct.write_instructions(home=home, project=ROOT)
            self.assertTrue(r["ok"])
            self.assertTrue(Path(r["path"]).is_file())
            c = ops_instruct.ensure_config_points(home=home)
            self.assertIn(c["action"], ("created", "updated", "appended", "unchanged"))


class PatternDbTests(unittest.TestCase):
    def test_search_ollvm(self):
        r = ops_pattern_db.search("ollvm 控制流平坦化")
        self.assertTrue(r["hits"])

    def test_heap(self):
        h = ops_pattern_db.heap_for_version("2.31")
        self.assertIn("tcache", " ".join(h.get("tech") or []) + h.get("notes", ""))

    def test_ad(self):
        edges = ops_pattern_db.ad_paths("domain_user")
        self.assertTrue(edges)

    def test_catalog(self):
        c = ops_pattern_db.catalog()
        self.assertIn("go", c)
        self.assertIn("ad", c)


if __name__ == "__main__":
    unittest.main()
