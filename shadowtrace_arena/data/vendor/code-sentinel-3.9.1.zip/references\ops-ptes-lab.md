# Sentinel PTES Lab — 原创方法论

> 技术精髓经公开 PTES 生命周期与「分阶段交接」工程实践抽象后，由 Code Sentinel **独立实现**。  
> 不含任何第三方仓库的文案、技能包、知识库语料或模板原文。

## 精髓抽象（学到什么）

| 精髓 | Sentinel 原创落地 |
|------|-------------------|
| 多阶段渗透生命周期 | `L0…L6` + 可选 `L1W` Web 预检 |
| 阶段间证据交接 | `manifests/manifest-L*.json` |
| 每目标目录契约 | `ops-lab/targets/<slug>/{ports,services,vulns,…}` |
| 转段门禁 | 8 项 `TRANSITION_CHECKS`（必须过门再前进） |
| 上阶段输出驱动知识 | `ops_phase_kb` 按端口/服务/CVE 路由本地 references |
| URL 快捷路径 | 纯 URL 目标可跳过 L0 直接 L1 |
| 阶段内并行工作包 | `work_packages` 声明可并行单元 |
| 经验台账 | `solutions.md` 累计可复用笔记 |
| 报告由证据生成 | `ops_ptes_lab report` + `ops_report_contract` |

## 命令

```bash
python scripts/ops_ptes_lab.py phases
python scripts/ops_ptes_lab.py init 192.168.1.10
python scripts/ops_ptes_lab.py init https://lab.example
python scripts/ops_ptes_lab.py status 192.168.1.10
python scripts/ops_ptes_lab.py plan L1 --target 192.168.1.10
python scripts/ops_ptes_lab.py manifest 192.168.1.10 L1 --summary "open 22,80" --http
python scripts/ops_ptes_lab.py advance 192.168.1.10 --summary "recon done" --http
python scripts/ops_ptes_lab.py gate 192.168.1.10
python scripts/ops_ptes_lab.py report 192.168.1.10

python scripts/ops_phase_kb.py target 192.168.1.10
python scripts/ops_phase_kb.py text "port 445 smb CVE-2020-0796"
```

## 与现有模块关系

- 侦察：`pentest_recon` / `re_surface`
- Web：`web_pentest` / `ops_ctf_runner`
- 链路：`ops_chain`（C1–C6 战术链）与 PTES Lab（L0–L6 工程生命周期）互补
- 报告：`ops_report_contract` / `ops_case` / `ops_anon`
- 知识：仅映射 **本仓库** `references/**`，不外挂第三方语料库

## 禁止

- 粘贴外部 SKILL/AGENTS/KB 全文  
- 把外部 PoC 语料整库导入 `ops-lab`  
- 用聊天记录代替 manifest 交接  
