#!/usr/bin/env python3
"""
Sentinel Ops Tool Patterns — six multi-tool collaboration patterns (original).

Pattern codes P-A … P-F map to analysis styles; each lists primary local
modules plus external tool chains and when to escalate.
"""

from __future__ import annotations

import argparse
import json
import shutil
import sys
from dataclasses import asdict, dataclass
from typing import Any, Optional


@dataclass
class ToolPattern:
    id: str
    name: str
    purpose: str
    local_pipeline: list[str]
    external_chain: list[str]
    escalate_when: list[str]
    modules: list[str]

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["external_available"] = {
            t: bool(shutil.which(t.split()[0])) for t in self.external_chain
        }
        return d


PATTERNS: dict[str, ToolPattern] = {
    "P-A": ToolPattern(
        id="P-A",
        name="static_collab",
        purpose="静态多引擎交叉验证（结构→字符串→能力）",
        local_pipeline=["ops_triage", "reverse_engineering", "malware_analysis", "sentinel_scan"],
        external_chain=["ghidra", "r2", "objdump", "readelf", "die", "strings"],
        escalate_when=["高熵加壳", "符号全无", "CFG 极复杂"],
        modules=["M01", "M02", "M03", "M04"],
    ),
    "P-B": ToolPattern(
        id="P-B",
        name="dynamic_collab",
        purpose="动态观测：端口/HTTP/进程行为线索",
        local_pipeline=["pentest_recon", "web_pentest", "attack_network"],
        external_chain=["frida", "gdb", "strace", "ltrace", "nmap"],
        escalate_when=["反调试强", "需 API hook", "需 syscall 轨迹"],
        modules=["M16", "M17", "M19", "M20"],
    ),
    "P-C": ToolPattern(
        id="P-C",
        name="symbolic_collab",
        purpose="约束/符号思路：校验函数与 CTF 求解",
        local_pipeline=["ctf_toolkit", "ops_algo", "reverse_engineering"],
        external_chain=["z3", "python"],  # angr/triton optional names
        escalate_when=["多分支校验", "自定义 VM", "路径爆炸"],
        modules=["M21", "M22"],
    ),
    "P-D": ToolPattern(
        id="P-D",
        name="mobile_collab",
        purpose="移动端：包结构 + 加固线索 + 动态扩展点",
        local_pipeline=["ops_triage", "reverse_engineering", "malware_analysis"],
        external_chain=["jadx", "apktool", "frida", "objection", "dex2jar"],
        escalate_when=["加固壳", "SSL Pinning", "完整协议还原"],
        modules=["M04", "M05"],
    ),
    "P-E": ToolPattern(
        id="P-E",
        name="forensics_collab",
        purpose="取证：镜像/工件/流量交叉",
        local_pipeline=["malware_analysis", "ops_triage", "pentest_recon"],
        external_chain=["volatility3", "binwalk", "exiftool", "tshark"],
        escalate_when=["内存取证", "时间线重建", "深层恢复"],
        modules=["M09", "M10", "M13"],
    ),
    "P-F": ToolPattern(
        id="P-F",
        name="deobf_collab",
        purpose="反混淆/脱壳导向：熵、壳签名、导入异常",
        local_pipeline=["ops_triage", "reverse_engineering", "malware_analysis", "ops_algo"],
        external_chain=["upx", "die", "floss", "strings"],
        escalate_when=["VMProtect/Themida", "OLLVM", "自研 VM"],
        modules=["M02", "M01", "M21", "M19"],
    ),
}

# signal → preferred patterns
SIGNAL_PATTERNS: dict[str, list[str]] = {
    "S1": ["P-A"],
    "S2": ["P-A", "P-F"],
    "S3": ["P-A", "P-F", "P-E"],
    "S4": ["P-C", "P-F"],
    "S5": ["P-B"],
    "S6": ["P-B", "P-D"],
    "S7": ["P-C", "P-B", "P-A"],
    "S8": ["P-D", "P-E", "P-B"],
}


def select_patterns(signals: list[str], packed: bool = False, mobile: bool = False) -> list[dict[str, Any]]:
    ordered: list[str] = []
    for s in signals:
        for pid in SIGNAL_PATTERNS.get(s, []):
            if pid not in ordered:
                ordered.append(pid)
    if packed and "P-F" not in ordered:
        ordered.insert(0, "P-F")
    if mobile and "P-D" not in ordered:
        ordered.insert(0, "P-D")
    if not ordered:
        ordered = ["P-A"]
    return [PATTERNS[p].to_dict() for p in ordered if p in PATTERNS]


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Sentinel tool patterns")
    parser.add_argument("--list", action="store_true")
    parser.add_argument("--signals", default="S2", help="comma signals")
    parser.add_argument("--packed", action="store_true")
    parser.add_argument("--mobile", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    if args.list:
        data = [p.to_dict() for p in PATTERNS.values()]
    else:
        sigs = [s.strip() for s in args.signals.split(",") if s.strip()]
        data = select_patterns(sigs, packed=args.packed, mobile=args.mobile)
    print(json.dumps(data, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
