"""Tests for original PTES lab + phase knowledge router."""

from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import ops_ptes_lab
import ops_phase_kb


class PtesLabTests(unittest.TestCase):
    def test_phase_catalog(self):
        self.assertGreaterEqual(len(ops_ptes_lab.PHASES), 8)
        self.assertIn("L0", ops_ptes_lab.PHASE_ORDER)
        self.assertIn("L1W", ops_ptes_lab.PHASE_ORDER)
        self.assertGreaterEqual(len(ops_ptes_lab.TRANSITION_CHECKS), 8)

    def test_url_shortcut_and_advance(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            r = ops_ptes_lab.init_target("https://lab.example/app", base=base)
            self.assertTrue(r["ok"])
            self.assertTrue(r["state"]["url_shortcut"])
            self.assertEqual(r["state"]["current_phase"], "L1")
            self.assertIn("L0", r["state"]["skipped_phases"])

            ops_ptes_lab.write_manifest(
                "https://lab.example/app",
                "L1",
                summary="open 443",
                signals={"http_surface": True, "ports": [443], "services": ["https"]},
                base=base,
            )
            st = ops_ptes_lab.load_state("https://lab.example/app", base)
            st["http_surface"] = True
            ops_ptes_lab.save_state("https://lab.example/app", st, base)

            adv = ops_ptes_lab.advance(
                "https://lab.example/app",
                base=base,
                summary="recon done",
                mark_http=True,
                force=True,
            )
            self.assertTrue(adv["ok"])
            self.assertEqual(adv["current_phase"], "L1W")

            schema = ops_ptes_lab.validate_schema("https://lab.example/app", base)
            self.assertTrue(schema["ok"])

            rep = ops_ptes_lab.report_brief("https://lab.example/app", base)
            self.assertTrue(Path(rep["report"]).is_file())

    def test_ip_starts_at_l0(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            r = ops_ptes_lab.init_target("10.0.0.5", base=base)
            self.assertEqual(r["state"]["current_phase"], "L0")


class PhaseKbTests(unittest.TestCase):
    def test_web_tokens(self):
        r = ops_phase_kb.route_from_text("https://x.local port 443 nginx")
        self.assertTrue(r["tools_or_packs"] or r["references"])
        self.assertTrue(any("web" in t or "web_pentest" in t for t in r["tools_or_packs"]))

    def test_from_manifest(self):
        man = {
            "phase_id": "L1",
            "next_phase": "L1W",
            "summary": "smb 445 open",
            "signals": {"ports": [445], "services": ["smb"]},
            "findings": [],
        }
        r = ops_phase_kb.route_from_manifest(man)
        self.assertEqual(r["phase_id"], "L1W")
        self.assertTrue(r["tokens"])


if __name__ == "__main__":
    unittest.main()
