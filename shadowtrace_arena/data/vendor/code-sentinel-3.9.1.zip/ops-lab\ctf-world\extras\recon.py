#!/usr/bin/env python3
"""CTF World Recon Script — maps all network segments and services."""
import json, os, socket, struct, sys, threading, time
from concurrent.futures import ThreadPoolExecutor, as_completed

TARGETS = {
    "external (10.0.0.0/24)": [f"10.0.0.{i}" for i in range(1, 20)],
    "dmz (10.0.1.0/24)": [f"10.0.1.{i}" for i in range(1, 20)],
    "internal (10.0.2.0/24)": {i: f"10.0.2.{i}" for i in [10,11,20,30,40,50]},
    "dev (10.0.3.0/24)": {i: f"10.0.3.{i}" for i in [10,20,30,50]},
    "isolated (10.0.4.0/24)": {i: f"10.0.4.{i}" for i in [10,11,20,30]},
}

PORTS = [21,22,23,25,53,80,110,143,389,443,445,1080,1433,1521,1723,3000,3306,3389,5000,5432,5900,6379,8000,8080,8443,27017,40001,40002,40003,40004]
open_ports = {}
lock = threading.Lock()

def scan_port(ip, port):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1)
        r = s.connect_ex((ip, port))
        s.close()
        if r == 0:
            with lock:
                open_ports.setdefault(ip, []).append(port)
            return (ip, port, True)
    except: pass
    return (ip, port, False)

def banner_grab(ip, port):
    try:
        s = socket.socket(); s.settimeout(2)
        s.connect((ip, port))
        s.send(b"HEAD / HTTP/1.0\r\n\r\n")
        banner = s.recv(1024).decode('utf-8','replace').strip()
        s.close()
        return banner
    except:
        try:
            s = socket.socket(); s.settimeout(2)
            s.connect((ip, port))
            banner = s.recv(1024).decode('utf-8','replace').strip()
            s.close()
            return banner
        except:
            return "<no banner>"

def main():
    import argparse
    p = argparse.ArgumentParser(description="CTF World Recon")
    p.add_argument("--target", default="all", help="target segment or 'all'")
    p.add_argument("--ports", default="", help="comma-separated ports (or 'common')")
    p.add_argument("--threads", type=int, default=50)
    p.add_argument("--json", action="store_true")
    args = p.parse_args()

    port_list = PORTS
    if args.ports == "common":
        port_list = [21,22,80,443,445,1723,3306,3389,5000,8080,3000,40001]
    elif args.ports:
        port_list = [int(x) for x in args.ports.split(",") if x.strip()]

    # Collect targets
    if args.target == "all":
        ips = [ip for seg in TARGETS.values() for ip in seg.values()]
        segments = TARGETS
    else:
        ips = list(TARGETS.get(args.target, {}).values())
        segments = {args.target: TARGETS.get(args.target, {})}

    tasks = [(ip, p) for ip in ips for p in port_list]
    print(f"[*] Scanning {len(tasks)} port/IP combinations ({len(ips)} hosts, {len(port_list)} ports)")
    print(f"[*] Segments: {list(segments.keys())}\n")

    with ThreadPoolExecutor(args.threads) as ex:
        results = list(ex.map(lambda t: scan_port(*t), tasks))

    # Organize by segment
    report = {}
    for seg, host_map in segments.items():
        report[seg] = {}
        for hid, ip in host_map.items():
            ports = open_ports.get(ip, [])
            if ports:
                banners = {}
                for p in ports:
                    banners[str(p)] = banner_grab(ip, p)
                report[seg][ip] = {"host_id": hid, "open_ports": ports, "banners": banners}

    if args.json:
        print(json.dumps(report, indent=2, default=str))
    else:
        for seg, hosts in report.items():
            print(f"\n{'='*60}")
            print(f"  {seg}")
            print(f"{'='*60}")
            if not hosts:
                print("  (no hosts found)")
                continue
            for ip, info in hosts.items():
                ports_str = ",".join(str(p) for p in info["open_ports"])
                print(f"  {ip} (id={info['host_id']})  ports: [{ports_str}]")
                for p, banner in info.get("banners", {}).items():
                    if banner != "<no banner>":
                        print(f"    :{p} → {banner[:100]}")
        total = sum(len(h) for h in report.values())
        total_ports = sum(len(i["open_ports"]) for h in report.values() for i in h.values())
        print(f"\n[*] Found {total} live hosts with {total_ports} open ports")

if __name__ == "__main__":
    main()
