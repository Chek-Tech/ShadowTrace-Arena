"""Tests for dual-layer sandbox protocol (original)."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import ops_sandbox
import ops_gpt56


class SandboxProtocolTests(unittest.TestCase):
    def test_dual_layers(self):
        ctx = ops_sandbox.build_context()
        self.assertTrue(ctx.primary_layer)
        self.assertTrue(ctx.fallback_layer)
        block = ctx.render_block()
        self.assertIn("Layer A", block)
        self.assertIn("Layer B", block)

    def test_evidence_stack_order(self):
        stack = ops_sandbox.EVIDENCE_STACK
        self.assertEqual(len(stack), 8)
        self.assertEqual(stack[0]["id"], "runtime")
        self.assertEqual(stack[-1]["id"], "comments")

    def test_resolve_conflict(self):
        r = ops_sandbox.resolve_evidence_conflict([
            {"source_id": "source", "claim": "dead path"},
            {"source_id": "runtime", "claim": "live path"},
            {"source_id": "comments", "claim": "todo"},
        ])
        self.assertEqual(r["winner"]["source_id"], "runtime")

    def test_package_modes(self):
        d = ops_sandbox.package_direct("分析 pe")
        p = ops_sandbox.package_placeholder("分析 pe")
        r = ops_sandbox.package_repair("分析 pe")
        self.assertEqual(d.mode, "direct")
        self.assertIn("$PIPE", p.packaged)
        self.assertIn("NotImplementedError", r.packaged)

    def test_workflow_next(self):
        n = ops_sandbox.next_workflow_step(["W1", "W2"])
        self.assertEqual(n["id"], "W3")

    def test_session_overlay(self):
        o = ops_sandbox.build_session_overlay("木马画像", mode="direct")
        self.assertEqual(o["protocol"], "sentinel-dual-layer-sandbox-v1")
        self.assertIn("context_block", o)

    def test_gpt56_includes_sandbox(self):
        b = ops_gpt56.build_session("测试任务", target="x.exe", include_sandbox=True)
        self.assertIn("sandbox", b)
        self.assertTrue(b.get("system_prompt"))
        # dual layer text should appear in system when sandbox on
        self.assertIn("Dual-Layer", b["system_prompt"])


if __name__ == "__main__":
    unittest.main()
