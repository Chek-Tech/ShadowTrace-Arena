#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Windows 一键从 Codex 卸载 Code Sentinel（原创卸载器）。"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))


def main() -> int:
    print("=" * 50)
    print("  Code Sentinel · Windows 一键卸载")
    print("=" * 50)
    print()
    import codex_inject

    try:
        result = codex_inject.uninstall()
    except Exception as exc:
        print(f"[失败] {exc}")
        _pause()
        return 1

    print(f"[完成] {result.get('message', 'ok')}")
    print(f"  已移除 Skills : {', '.join(result.get('skills_removed') or []) or '无'}")
    print(f"  备份         : {result.get('backup')}")
    print()
    print("请完全退出并重新打开 Codex 使卸载生效。")
    print()
    _pause()
    return 0


def _pause() -> None:
    if sys.stdin.isatty():
        try:
            input("按 Enter 关闭…")
        except EOFError:
            pass


if __name__ == "__main__":
    raise SystemExit(main())
