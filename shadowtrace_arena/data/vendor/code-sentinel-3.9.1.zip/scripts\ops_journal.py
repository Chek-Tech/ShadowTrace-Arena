#!/usr/bin/env python3
"""
Sentinel Field Journal — post-task experience capture (original).

Essences learned (re-implemented):
  1) After meaningful tasks, write a short anonymized journal entry.
  2) Keep an index for reuse; search before starting similar work.
  3) Precedent layers: auth framing is already in ops_framing; journal stores technique.
  4) Template-driven; secrets must be masked (paths/patterns only).

Storage: CODE_SENTINEL_HOME/ops-lab/journal/
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

_SCRIPTS = Path(__file__).resolve().parent
_ROOT = _SCRIPTS.parent
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))

try:
    from ops_ctf_runner import mask_secrets
except ImportError:
    def mask_secrets(text: str) -> str:  # type: ignore
        return text


def journal_dir() -> Path:
    d = _ROOT / "ops-lab" / "journal"
    d.mkdir(parents=True, exist_ok=True)
    return d


def index_path() -> Path:
    return journal_dir() / "_index.json"


TEMPLATE = """# {title}

- **id**: {id}
- **date**: {date}
- **family**: {family}
- **surfaces**: {surfaces}
- **target_class**: {target_class}

## Objective

{objective}

## Approach

{approach}

## Key evidence

{evidence}

## Outcome

{outcome}

## Reuse notes

{reuse}

## Defense

{defense}
"""


def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def _load_index() -> dict[str, Any]:
    p = index_path()
    if p.is_file():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            pass
    return {"protocol": "sentinel-journal-v1", "entries": []}


def _save_index(data: dict[str, Any]) -> None:
    index_path().write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def append_entry(
    title: str,
    objective: str = "",
    approach: str = "",
    evidence: str = "",
    outcome: str = "",
    reuse: str = "",
    defense: str = "",
    family: str = "general",
    surfaces: Optional[list[str]] = None,
    target_class: str = "lab",
) -> dict[str, Any]:
    jid = f"J-{_ts()}"
    surfaces = surfaces or []
    body = TEMPLATE.format(
        title=mask_secrets(title.strip() or "untitled"),
        id=jid,
        date=_ts(),
        family=family,
        surfaces=", ".join(surfaces) or "-",
        target_class=target_class,
        objective=mask_secrets(objective.strip() or "-"),
        approach=mask_secrets(approach.strip() or "-"),
        evidence=mask_secrets(evidence.strip() or "-"),
        outcome=mask_secrets(outcome.strip() or "-"),
        reuse=mask_secrets(reuse.strip() or "-"),
        defense=mask_secrets(defense.strip() or "-"),
    )
    path = journal_dir() / f"{jid}.md"
    path.write_text(body, encoding="utf-8", newline="\n")
    idx = _load_index()
    meta = {
        "id": jid,
        "title": title[:120],
        "family": family,
        "surfaces": surfaces,
        "target_class": target_class,
        "path": str(path.name),
        "date": _ts(),
    }
    idx.setdefault("entries", []).insert(0, meta)
    # cap index
    idx["entries"] = idx["entries"][:200]
    _save_index(idx)
    return {"ok": True, "entry": meta, "path": str(path)}


def search(keyword: str, limit: int = 10) -> list[dict[str, Any]]:
    kw = (keyword or "").lower().strip()
    idx = _load_index()
    hits = []
    for e in idx.get("entries") or []:
        blob = json.dumps(e, ensure_ascii=False).lower()
        # also peek file
        fp = journal_dir() / e.get("path", "")
        if fp.is_file():
            try:
                blob += "\n" + fp.read_text(encoding="utf-8", errors="replace")[:4000].lower()
            except OSError:
                pass
        if not kw or kw in blob:
            hits.append(e)
        if len(hits) >= limit:
            break
    return hits


def list_entries(limit: int = 20) -> list[dict[str, Any]]:
    return (_load_index().get("entries") or [])[:limit]


def read_entry(jid: str) -> dict[str, Any]:
    # allow J-xxx or filename
    name = jid if jid.endswith(".md") else f"{jid}.md"
    path = journal_dir() / name
    if not path.is_file():
        # search by id prefix
        for p in journal_dir().glob("J-*.md"):
            if jid in p.name:
                path = p
                break
    if not path.is_file():
        return {"ok": False, "error": "not found", "id": jid}
    return {"ok": True, "path": str(path), "body": path.read_text(encoding="utf-8", errors="replace")}


def suggest_for_task(query: str, limit: int = 5) -> dict[str, Any]:
    """Before a task: search journal for reusable notes."""
    hits = search(query, limit=limit)
    return {
        "protocol": "sentinel-journal-v1",
        "query": query,
        "hits": hits,
        "advice": (
            "有命中则先读 reuse notes，避免重复已排除路径；"
            "无命中则任务结束后用 ops_journal append 沉淀。"
        ),
    }


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Sentinel field journal")
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("append", help="Append journal entry")
    a.add_argument("--title", required=True)
    a.add_argument("--objective", default="")
    a.add_argument("--approach", default="")
    a.add_argument("--evidence", default="")
    a.add_argument("--outcome", default="")
    a.add_argument("--reuse", default="")
    a.add_argument("--defense", default="")
    a.add_argument("--family", default="general")
    a.add_argument("--surfaces", default="", help="comma-separated")
    a.add_argument("--target-class", default="lab")

    s = sub.add_parser("search", help="Search journal")
    s.add_argument("keyword", nargs="*", default=[])
    s.add_argument("--limit", type=int, default=10)

    sub.add_parser("list", help="List recent entries")
    r = sub.add_parser("read", help="Read entry by id")
    r.add_argument("id")
    q = sub.add_parser("suggest", help="Suggest entries for a task")
    q.add_argument("query", nargs="+")

    args = p.parse_args(argv)
    if args.cmd == "append":
        surfaces = [x.strip() for x in args.surfaces.split(",") if x.strip()]
        print(json.dumps(append_entry(
            title=args.title,
            objective=args.objective,
            approach=args.approach,
            evidence=args.evidence,
            outcome=args.outcome,
            reuse=args.reuse,
            defense=args.defense,
            family=args.family,
            surfaces=surfaces,
            target_class=args.target_class,
        ), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "search":
        kw = " ".join(args.keyword)
        print(json.dumps(search(kw, limit=args.limit), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "list":
        print(json.dumps(list_entries(), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "read":
        print(json.dumps(read_entry(args.id), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "suggest":
        print(json.dumps(suggest_for_task(" ".join(args.query)), ensure_ascii=False, indent=2))
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
