#!/usr/bin/env python3
"""Paywall Bypass Engine."""
import json,re,random,urllib.request,urllib.error,urllib.parse,ssl,sys
from dataclasses import dataclass,field
from typing import Optional,Any
from http.cookiejar import CookieJar

PREMIUM_COOKIES=[{"name": "subscriber_status", "value": "active"}, {"name": "is_premium", "value": "true"}, {"name": "subscription_tier", "value": "premium"}, {"name": "metered_count", "value": "0"}, {"name": "article_count", "value": "0"}, {"name": "bypass", "value": "true"}, {"name": "view_count", "value": "0"}]
BYPASS_UA=["Googlebot/2.1", "Mozilla/5.0 (compatible; bingbot/2.0)", "facebookexternalhit/1.1", "Twitterbot/1.0"]
SUBSCRIPTION_BYPASS=[{"subscription": {"status": "active", "tier": "premium"}}, {"isSubscriber": True, "plan": "enterprise"}, {"role": "admin", "is_admin": True}]
API_ENDPOINTS=["/api/user", "/api/subscription", "/api/membership", "/api/premium", "/api/verify", "/api/check", "/graphql"]

class CookieSpoofer:
 def forge(): return {c['name']:c['value'] for c in PREMIUM_COOKIES}
 def header(): return '; '.join(f'{c["name"]}={c["value"]}' for c in PREMIUM_COOKIES)

class PaywallDetector:
 PAYWALL_PATTERNS=[r'class=.*paywall',r'class=.*subscribe-overlay',r'class=.*premium-only',r'(?i)subscribe now',r'(?i)free articles remaining',r'(?i)log in to continue',r'(?i)unlock this article',r'(?i)start your free trial']
 def detect(html):
  hits=[]
  for p in PaywallDetector.PAYWALL_PATTERNS:
   if re.search(p,html): hits.append(p[:50])
  return {'has_paywall':len(hits)>0,'confidence':min(1.0,len(hits)*0.2),'signatures':hits}

class MeterResetEngine:
 COUNTER_NAMES=['article_count','view_count','free_articles_read','metered_count','views_remaining','read_count','page_views','session_views']
 def reset_cookies(): return [{n:'0'} for n in MeterResetEngine.COUNTER_NAMES]

class ProxyBypassEngine:
 ARCHIVES=['https://web.archive.org/web/','https://archive.is/','https://12ft.io/']
 def get_urls(target): return [a+quote(target,'') for a in ProxyBypassEngine.ARCHIVES]

class APISubscriptionBypass:
 def payloads(): return SUBSCRIPTION_BYPASS

class PaywallBypassEngine:
 def __init__(self,url): self.url=url; self.report={'target':url,'detected':{},'attempts':[],'successful':[]}
 def detect(self): self.report['detected']=PaywallDetector.detect(self._fetch()); return self.report
 def _fetch(self,headers=None):
  try:
   req=urllib.request.Request(self.url)
   if headers:
    for k,v in headers.items(): req.add_header(k,v)
   return urllib.request.urlopen(req,timeout=10).read().decode('utf-8',errors='replace')
  except: return ''
 def test_cookie_spoof(self):
  html=self._fetch({'Cookie':CookieSpoofer.header()})
  ok=not PaywallDetector.detect(html)['has_paywall']
  self.report['attempts'].append({'method':'cookie_spoof','success':ok})
  if ok: self.report['successful'].append('cookie_spoof')
  return ok
 def test_ua_spoof(self):
  for ua in BYPASS_UA:
   html=self._fetch({'User-Agent':ua})
   ok=not PaywallDetector.detect(html)['has_paywall']
   self.report['attempts'].append({'method':'ua_spoof','ua':ua[:40],'success':ok})
   if ok: self.report['successful'].append('ua_spoof'); return True
  return False
 def run_full(self):
  self.detect()
  if not self.report['detected'].get('has_paywall'): return self.report
  self.test_cookie_spoof()
  self.test_ua_spoof()
  self.report['evidence']={'cookies':CookieSpoofer.forge(),'archives':ProxyBypassEngine.get_urls(self.url),'api_payloads':APISubscriptionBypass.payloads()}
  return self.report

if __name__=='__main__':
 import argparse; p=argparse.ArgumentParser()
 sp=p.add_subparsers(dest='c')
 d=sp.add_parser('detect'); d.add_argument('url')
 b=sp.add_parser('bypass'); b.add_argument('url')
 a=p.parse_args()
 if a.c=='detect':
  eng=PaywallBypassEngine(a.url)
  r=eng.detect()
  print(json.dumps(r,indent=2))
 elif a.c=='bypass':
  eng=PaywallBypassEngine(a.url)
  r=eng.run_full()
  print(json.dumps(r,indent=2))
 else: p.print_help()