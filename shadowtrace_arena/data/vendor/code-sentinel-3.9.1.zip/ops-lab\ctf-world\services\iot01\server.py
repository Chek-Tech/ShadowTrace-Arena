#!/usr/bin/env python3
"""IoT Camera - default credentials + command injection in firmware update."""
import os, flask, subprocess, hashlib
from flask import Flask, request, jsonify

app = Flask(__name__)
FLAG = os.environ.get("FLAG_IOT", "CS{test}")
USERS = {"admin": "admin", "root": "12345", "service": "service"}

@app.route("/")
def index():
    return jsonify({"device": "IP-CAM-2000", "firmware": "v1.0.3", "status": "online",
                    "endpoints": ["/login", "/snapshot", "/firmware/update", "/debug", "/shell"]})

@app.route("/login", methods=["POST"])
def login():
    d = request.get_json() or {}
    u = d.get("username", ""); p = d.get("password", "")
    if u in USERS and USERS[u] == p:
        return jsonify({"token": hashlib.md5(f"{u}:{p}".encode()).hexdigest()})
    return jsonify({"error": "auth failed"}), 401

@app.route("/snapshot", methods=["GET"])
def snapshot():
    # VULN: path traversal in camera image ID
    cam_id = request.args.get("cam", "1")
    if ".." in cam_id:
        try:
            with open(cam_id) as f:
                return jsonify({"snapshot_data": f.read()[:100]})
        except: pass
    return jsonify({"image": f"base64_camera_{cam_id}_feed"})

@app.route("/firmware/update", methods=["POST"])
def firmware_update():
    # VULN: command injection in firmware URL parameter
    url = request.get_json().get("url", "")
    if not url: return jsonify({"error": "no url"}), 400
    # Unsafe: passes URL directly to shell
    cmd = f"wget -O /tmp/fw.bin {url} 2>&1 || curl {url} -o /tmp/fw.bin 2>&1"
    try:
        out = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, timeout=5)
        return jsonify({"status": "update complete", "output": out.decode()[:500]})
    except Exception as e:
        return jsonify({"error": str(e)[:200]})

@app.route("/debug", methods=["GET"])
def debug_info():
    return jsonify({"flag": FLAG, "hint": "default creds work, but need admin for flag endpoint"})

@app.route("/shell", methods=["POST"])
def shell():
    token = request.headers.get("X-Auth-Token", "")
    if token != hashlib.md5("admin:admin".encode()).hexdigest():
        return jsonify({"error": "admin only"}), 403
    cmd = request.get_json().get("cmd", "id")
    out = subprocess.check_output(cmd, shell=True, timeout=5).decode()
    return jsonify({"output": out})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
