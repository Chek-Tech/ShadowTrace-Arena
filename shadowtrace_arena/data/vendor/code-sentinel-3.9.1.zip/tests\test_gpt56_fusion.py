"""Tests for gpt56-reverse-pentest fusion pack."""

from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))


def _load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod


class Gpt56FusionTests(unittest.TestCase):
    def test_refs_present(self):
        refs = ROOT / "references" / "gpt56-reverse-pentest"
        self.assertTrue((refs / "apk-reverse.md").is_file())
        self.assertTrue((refs / "ctf-speedrun.md").is_file())
        self.assertGreaterEqual(len(list(refs.glob("*.md"))), 16)

    def test_skill_package(self):
        sk = ROOT / "codex-bundle" / "skills" / "gpt56-reverse-pentest" / "SKILL.md"
        self.assertTrue(sk.is_file())

    def test_reverse_tools_xor(self):
        rt = _load("rt", SCRIPTS / "gpt56_reverse_pentest" / "reverse_tools.py")
        plain = "The quick brown fox jumps over the lazy dog 12345!"
        key = 0x41
        cipher = bytes(ord(c) ^ key for c in plain)
        hits = rt.brute_single_byte_xor(cipher)
        self.assertTrue(hits)
        top_keys = {h[0] for h in hits[:5]}
        self.assertIn(key, top_keys)

    def test_crypto_helper_rot13(self):
        ch = _load("ch", SCRIPTS / "gpt56_reverse_pentest" / "crypto_helper.py")
        self.assertEqual(ch.rot13("uryyb"), "hello")

    def test_pwn_template_check(self):
        pt = _load("pt", SCRIPTS / "gpt56_reverse_pentest" / "pwn_template.py")
        info = pt.check_deps()
        self.assertIn("pwntools", info)
        self.assertIn("p32", info["pure_helpers"])
        self.assertEqual(pt.p32(0x41424344), b"DCBA")

    def test_cli_reverse_demo(self):
        r = subprocess.run(
            [sys.executable, str(SCRIPTS / "gpt56_reverse_pentest" / "reverse_tools.py"), "demo"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        self.assertEqual(r.returncode, 0)
        self.assertIn("XOR", r.stdout.upper() or r.stdout)

    def test_tool_index_lists_fusion(self):
        import ops_tool_index

        data = ops_tool_index.probe_all()
        ids = {t["id"] for t in data["tools"]}
        self.assertIn("gpt56_reverse_tools", ids)
        self.assertIn("gpt56_crypto_helper", ids)
        self.assertIn("gpt56_pwn_template", ids)
        self.assertTrue(data["summary"].get("gpt56_fusion"))


if __name__ == "__main__":
    unittest.main()
