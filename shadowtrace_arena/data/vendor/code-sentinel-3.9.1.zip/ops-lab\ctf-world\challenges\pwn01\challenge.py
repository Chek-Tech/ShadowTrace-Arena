#!/usr/bin/env python3
"""PWN BOF challenge server - Python implementation that connects via socat."""
import os, socket, threading

FLAG = os.environ.get("FLAG_PWN01", "CS{test_flag}")
BUFSIZE = 40  # intentionally small

def handle(conn, addr):
    conn.settimeout(120)
    banner = f"""=== BOF Challenge: Stack Overflow ===
Target: x86_64 Linux binary
Binary has:
  - 40-byte buffer on stack
  - Stack canary (0xDEADC0DE)
  - NX enabled (no shellcode)
  - ASLR enabled
  - Goal: reach hidden admin() function at offset +0x145

Enter your exploit payload (bytes):
"""
    conn.send(banner.encode())
    try:
        data = conn.recv(512)
        conn.send(f"Received {len(data)} bytes\n".encode())
        # Simulate the canary check
        canary_slot = data[BUFSIZE:BUFSIZE+4] if len(data) > BUFSIZE else b""
        if canary_slot == b"\xDE\xC0\xAD\xDE":
            conn.send(b"[+] Canary bypassed!\n".encode())
        rbp = data[BUFSIZE+4:BUFSIZE+12] if len(data) > BUFSIZE+4 else b""
        ret = data[BUFSIZE+12:BUFSIZE+20] if len(data) > BUFSIZE+12 else b""
        if ret and ret[-1] == 0x45:  # offset +0x145 → admin function
            conn.send(f"FLAG: {FLAG}\n".encode())
            conn.send(b"[+] Admin function reached!\n".encode())
        else:
            conn.send(b"[-] Exploit did not land on admin function (offset +0x145)\n".encode())
            conn.send(b"Hint: overflow buffer -> overwrite canary with 0xDEADC0DE -> overwrite RBP -> overwrite return address to 0x...0145\n".encode())
    except Exception as e:
        conn.send(f"Error: {e}\n".encode())
    conn.close()

s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("0.0.0.0", 40001)); s.listen(5)
while True: c,a = s.accept(); threading.Thread(target=handle, args=(c,a), daemon=True).start()
