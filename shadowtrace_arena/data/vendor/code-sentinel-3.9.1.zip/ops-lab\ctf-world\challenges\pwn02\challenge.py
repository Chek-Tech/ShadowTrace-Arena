#!/usr/bin/env python3
"""PWN02 Heap challenge - tcache poisoning."""
import os, socket, threading

FLAG = os.environ.get("FLAG_PWN02", "CS{test}")
chunks = {}  # simulated heap

def handle(conn, addr):
    conn.settimeout(120)
    conn.send(b"=== Heap Challenge: Tcache Poisoning ===\n")
    conn.send(b"Commands: alloc <size> <id>, free <id>, write <id> <data>, read <id>, magic\n")
    try:
        while True:
            conn.send(b"> ")
            cmd = conn.recv(1024).strip().decode()
            if not cmd: break
            parts = cmd.split(maxsplit=2)
            if parts[0] == "alloc":
                size, cid = int(parts[1]), parts[2]
                chunks[cid] = {"size": size, "data": "A" * size, "free": False}
                conn.send(f"Allocated chunk[{cid}] size={size}\n".encode())
            elif parts[0] == "free":
                cid = parts[1]
                if cid in chunks:
                    chunks[cid]["free"] = True
                    conn.send(f"Freed chunk[{cid}]\n".encode())
                    # VULN: double-free possible
                    if any(c.get("free") and k != cid for k, c in chunks.items()):
                        conn.send(b"[!] Multiple free chunks - potential tcache dup!\n".encode())
            elif parts[0] == "write":
                cid, data = parts[1], parts[2]
                if cid in chunks:
                    # VULN: no size check, can overflow into adjacent chunk
                    chunks[cid]["data"] = data
                    conn.send(f"Written {len(data)} bytes to chunk[{cid}]\n".encode())
                    if len(data) > chunks[cid].get("size", 0):
                        conn.send(b"[!] Heap overflow detected!\n".encode())
            elif parts[0] == "read":
                cid = parts[1]
                if cid in chunks:
                    conn.send(f"chunk[{cid}]: {chunks[cid]['data'][:200]}\n".encode())
            elif parts[0] == "magic":
                # Check if poisoned tcache head points to flag location
                conn.send(b"Checking heap metadata...\n".encode())
                free_count = sum(1 for c in chunks.values() if c.get("free"))
                if free_count >= 2:
                    conn.send(f"[+] Double-free pattern found! FLAG: {FLAG}\n".encode())
                else:
                    conn.send(b"Need 2+ freed chunks for tcache poisoning\n".encode())
    except:
        pass
    conn.close()

s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("0.0.0.0", 40002)); s.listen(5)
while True: c,a = s.accept(); threading.Thread(target=handle, args=(c,a), daemon=True).start()
