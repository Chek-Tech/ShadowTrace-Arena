@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Code Sentinel Windows 一键启动
echo ================================================
echo   Code Sentinel - Windows 一键启动 (注入 Codex)
echo   触发词: 豆包大人
echo ================================================
echo.
python "%~dp0Windows启动.py" %*
if errorlevel 1 (
  echo.
  echo 若提示找不到 python，请先安装 Python 3.10+ 并加入 PATH。
  pause
  exit /b 1
)
