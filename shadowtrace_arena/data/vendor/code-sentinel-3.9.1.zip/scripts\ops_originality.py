#!/usr/bin/env python3
"""
Code Sentinel originality gate — ban third-party corpus fingerprints in-tree.

Scans product sources for known non-original markers (jailbreak banners,
foreign product brands used as source-of-truth, hard-coded foreign exit IPs).
Does not block generic security terms (ROP, JWT, SSRF, …).
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

_ROOT = Path(__file__).resolve().parents[1]

# Fingerprints that must not appear in product tree (originality policy).
BANNED_SUBSTRINGS: list[str] = [
    "[MODE: UNRESTRICTED]",
    "All standard content filters are disabled",
    "competitor-controlled sandbox",
    "156.245.145.165",
    "xw9114",
    "haiou-codex",
    "海鸥codeX",
    "zzy-codex",
    "zzy.codex",
    "zzy.root",
    "对标海鸥",
    "Seagull binaries",
    "Seagull CodeX",
    "from zzy",
    "gpt5.5-unrestricted",
    "name: ctf-sandbox-runner",  # third-party skill frontmatter
]

# Paths relative to root that may mention bans only as *negative tests*
ALLOW_FILES: set[str] = {
    "scripts/ops_originality.py",
    "tests/test_ops_originality.py",
    "tests/test_ops_final_essence.py",  # asserts absence of jailbreak banners
    "tests/test_ops_ctf_runner.py",     # asserts absence of hard-coded exit IP
    "ORIGINALITY.md",
    "CHANGELOG.md",  # historical; still cleaned in 3.6.1
}

SKIP_DIR_PARTS = {
    ".git", "__pycache__", ".pytest_cache", "node_modules",
    "ops-lab", "backups", ".codex",
}

TEXT_SUFFIX = {
    ".py", ".md", ".json", ".yaml", ".yml", ".toml", ".txt",
    ".bat", ".sh", ".command", ".ps1",
}


def _rel(p: Path) -> str:
    try:
        return p.resolve().relative_to(_ROOT.resolve()).as_posix()
    except ValueError:
        return str(p)


def scan(root: Path | None = None) -> dict[str, Any]:
    root = (root or _ROOT).resolve()
    hits: list[dict[str, str]] = []
    files_scanned = 0
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix.lower() not in TEXT_SUFFIX:
            continue
        parts = set(path.parts)
        if parts & SKIP_DIR_PARTS:
            continue
        rel = _rel(path)
        if any(rel.startswith(s + "/") or rel == s for s in SKIP_DIR_PARTS):
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        files_scanned += 1
        if rel in ALLOW_FILES:
            continue
        for ban in BANNED_SUBSTRINGS:
            if ban in text:
                hits.append({"file": rel, "marker": ban})
    return {
        "protocol": "sentinel-originality-v1",
        "root": str(root),
        "files_scanned": files_scanned,
        "hits": hits,
        "ok": len(hits) == 0,
        "message": "原创性门禁通过" if not hits else f"发现 {len(hits)} 处禁用标记，须清除",
    }


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Originality fingerprint scan")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("scan", help="Scan repo for banned third-party markers")
    sub.add_parser("list-bans", help="List banned markers")
    args = p.parse_args(argv)
    if args.cmd == "list-bans":
        print(json.dumps(BANNED_SUBSTRINGS, ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "scan":
        rep = scan()
        print(json.dumps(rep, ensure_ascii=False, indent=2))
        return 0 if rep["ok"] else 1
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
