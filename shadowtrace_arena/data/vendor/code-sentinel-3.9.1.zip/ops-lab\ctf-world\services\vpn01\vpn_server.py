#!/usr/bin/env python3
"""VPN Gateway - PPTP with weak MSCHAPv2 + hash dumping."""
import os, socket, threading, hashlib, json

FLAG = os.environ.get("FLAG_VPN", "CS{test}")
USERS = {"vpnuser": {"pass": "vpnpass123", "networks": ["10.0.3.0/24"]}}

def handle_client(conn, addr):
    conn.settimeout(30)
    try:
        conn.send(b"PPTP VPN Gateway v1.0\n")
        conn.send(b"Username: "); user = conn.recv(1024).strip().decode()
        conn.send(b"Password: "); passwd = conn.recv(1024).strip().decode()
        # VULN: MSCHAPv2 weak hash - capture hash for cracking
        challenge = os.urandom(8)
        conn.send(challenge)
        response = conn.recv(1024)
        # Hash is sent in the clear and can be captured
        nt_hash = hashlib.new("md4", passwd.encode()).hexdigest()
        if user in USERS and USERS[user]["pass"] == passwd:
            conn.send(b"\nVPN Connected. You now have access to DEV network.\n")
            conn.send(f"Routes: {json.dumps(USERS[user]['networks'])}\n".encode())
            conn.send(b"Internal hint: /flag.txt contains the VPN flag\n")
            while True:
                data = conn.recv(1024)
                if not data: break
                if data.strip() == b"flag":
                    conn.send(f"FLAG: {FLAG}\n".encode())
                    conn.send(b"To reach dev network, connect to: 10.0.3.0/24\n")
                    conn.send(b"DEV hosts: filesrv01(10.0.3.10), cicd01(10.0.3.20), monitor01(10.0.3.30)\n")
                elif data.strip() == b"hash":
                    conn.send(f"NT Hash (MSCHAPv2): {nt_hash}\n".encode())
                    conn.send(f"Crack with: hashcat -m 1000 {nt_hash} rockyou.txt\n".encode())
        else:
            conn.send(b"Auth failed\n")
    except:
        pass
    finally:
        conn.close()

s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("0.0.0.0", 1723)); s.listen(5)
print("[*] VPN on :1723")
while True: c,a = s.accept(); threading.Thread(target=handle_client, args=(c,a), daemon=True).start()
