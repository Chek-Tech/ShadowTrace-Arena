#!/usr/bin/env python3
"""
Sentinel anonymization — share-safe redaction for journals/reports (original).

Essence: preserve reusable technique value while replacing real hosts/creds/paths
with stable placeholders. Complements redact.py (secrets) with writeup-oriented tokens.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from typing import Any, Optional

# Placeholder catalog (technique-preserving)
PLACEHOLDERS: dict[str, str] = {
    "ipv4": "{target_ip}",
    "ipv4_victim": "{victim_ip}",
    "domain": "{target_domain}",
    "url": "{url}",
    "email": "{email}",
    "user": "{username}",
    "pass": "{password}",
    "token": "{token}",
    "api_key": "{api_key}",
    "cookie": "{cookie}",
    "path_win": "{path}",
    "path_nix": "{path}",
    "hash_hex": "{hash}",
}

# Keep well-known ports as numbers for reuse
_KEEP_PORTS = {80, 443, 22, 445, 3389, 8080, 8443, 53, 25, 110, 143, 993, 995}


def anonymize(text: str, aggressive: bool = False) -> dict[str, Any]:
    """Return masked text + replacement stats. Original patterns, not third-party lists."""
    if not text:
        return {"text": "", "replacements": 0, "map": {}}
    out = text
    stats: dict[str, int] = {}

    def bump(k: str) -> None:
        stats[k] = stats.get(k, 0) + 1

    # emails
    def re_email(m: re.Match[str]) -> str:
        bump("email")
        return PLACEHOLDERS["email"]

    out = re.sub(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b", re_email, out)

    # URLs
    def re_url(m: re.Match[str]) -> str:
        bump("url")
        return PLACEHOLDERS["url"]

    out = re.sub(r"https?://[^\s\"'<>]+", re_url, out, flags=re.I)

    # IPv4
    def re_ip(m: re.Match[str]) -> str:
        bump("ipv4")
        return PLACEHOLDERS["ipv4"]

    out = re.sub(
        r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b",
        re_ip,
        out,
    )

    # JWT-like
    def re_jwt(m: re.Match[str]) -> str:
        bump("token")
        return "{jwt}"

    out = re.sub(r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b", re_jwt, out)

    # Bearer / basic-ish secrets
    def re_bearer(m: re.Match[str]) -> str:
        bump("token")
        return f"{m.group(1)}{{token}}"

    out = re.sub(r"(?i)(bearer\s+)[A-Za-z0-9._\-]{8,}", re_bearer, out)

    # api key assignments
    def re_key(m: re.Match[str]) -> str:
        bump("api_key")
        return f"{m.group(1)}{PLACEHOLDERS['api_key']}"

    out = re.sub(
        r"(?i)(api[_-]?key|secret|password|passwd|pwd|token)\s*[=:]\s*['\"]?[^\s'\"&,;]{4,}",
        re_key,
        out,
    )

    # long hex hashes
    def re_hash(m: re.Match[str]) -> str:
        bump("hash_hex")
        return PLACEHOLDERS["hash_hex"]

    out = re.sub(r"\b[a-fA-F0-9]{32}\b|\b[a-fA-F0-9]{40}\b|\b[a-fA-F0-9]{64}\b", re_hash, out)

    # Windows paths (aggressive or always light)
    if aggressive:
        def re_win(m: re.Match[str]) -> str:
            bump("path_win")
            return PLACEHOLDERS["path_win"]

        out = re.sub(r"[A-Za-z]:\\(?:[^\\/:*?\"<>|\r\n]+\\)*[^\\/:*?\"<>|\r\n]*", re_win, out)

        def re_nix(m: re.Match[str]) -> str:
            bump("path_nix")
            return PLACEHOLDERS["path_nix"]

        out = re.sub(r"/(?:home|Users|var|etc|opt)/[^\s\"']+", re_nix, out)

    # domains (conservative: skip localhost and short labels)
    if aggressive:
        def re_dom(m: re.Match[str]) -> str:
            host = m.group(0)
            if host.lower() in {"localhost", "example.com", "local.test"}:
                return host
            bump("domain")
            return PLACEHOLDERS["domain"]

        out = re.sub(
            r"\b(?:[a-zA-Z0-9-]+\.)+(?:com|net|org|io|cn|dev|app|xyz|top|info)\b",
            re_dom,
            out,
        )

    return {
        "text": out,
        "replacements": sum(stats.values()),
        "map": stats,
        "placeholders": PLACEHOLDERS,
        "keep_ports": sorted(_KEEP_PORTS),
    }


def placeholder_table() -> dict[str, str]:
    return dict(PLACEHOLDERS)


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Sentinel writeup anonymizer")
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("run", help="Anonymize text")
    a.add_argument("--text", default="")
    a.add_argument("--file", default="")
    a.add_argument("--aggressive", action="store_true")
    a.add_argument("--json", action="store_true")

    sub.add_parser("table", help="Show placeholder catalog")

    args = p.parse_args(argv)
    if args.cmd == "table":
        print(json.dumps(placeholder_table(), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "run":
        text = args.text
        if args.file:
            text = open(args.file, encoding="utf-8", errors="replace").read()
        if not text and not sys.stdin.isatty():
            text = sys.stdin.read()
        data = anonymize(text, aggressive=args.aggressive)
        if args.json:
            print(json.dumps(data, ensure_ascii=False, indent=2))
        else:
            print(data["text"])
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
