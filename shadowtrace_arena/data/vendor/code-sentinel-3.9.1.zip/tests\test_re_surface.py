"""Tests for public/software reverse surface extraction."""

from __future__ import annotations

import struct
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import re_surface
import reverse_engineering as re_mod


def _minimal_pe_with_strings() -> bytes:
    data = bytearray(1024)
    data[0:2] = b"MZ"
    e_lfanew = 0x80
    data[0x3C:0x40] = struct.pack("<I", e_lfanew)
    data[e_lfanew:e_lfanew + 4] = b"PE\x00\x00"
    data[e_lfanew + 4:e_lfanew + 6] = struct.pack("<H", 0x14C)
    # embed network + product-ish strings
    blob = (
        b"https://update.example-cdn.com/v1/check\x00"
        b"api.myproduct.io\x00"
        b"203.0.113.10\x00"
        b"support@myproduct.io\x00"
        b"C:\\build\\release\\app.pdb\x00"
        b"WinHttpOpen\x00InternetOpenA\x00"
        b"CompanyName\x00Contoso Labs\x00"
    )
    data[0x200:0x200 + len(blob)] = blob
    return bytes(data)


class ReSurfaceTests(unittest.TestCase):
    def test_extract_urls_domains(self):
        data = _minimal_pe_with_strings()
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "app.exe"
            p.write_bytes(data)
            surf = re_surface.analyze_surface(p)
            self.assertTrue(any("http" in u for u in surf.urls) or surf.domains)
            self.assertTrue(surf.network_apis or "WinHttpOpen" in data.decode("latin-1", errors="ignore"))

    def test_software_re_merge(self):
        data = _minimal_pe_with_strings()
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "app.exe"
            p.write_bytes(data)
            rep = re_surface.analyze_software_re(p, probe=False)
            self.assertIn("reverse", rep)
            self.assertIn("surface", rep)
            self.assertIn("summary", rep)
            self.assertIn("defense", rep)

    def test_analyze_binary_includes_surface(self):
        data = _minimal_pe_with_strings()
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "app.exe"
            p.write_bytes(data)
            rev = re_mod.analyze_binary(p)
            # surface may extract urls
            self.assertTrue(isinstance(rev.network_surface, dict))
            d = rev.to_dict()
            self.assertIn("network_surface", d)
            self.assertIn("software_identity", d)

    def test_public_ip_helper(self):
        self.assertTrue(re_surface._is_public_ip("8.8.8.8"))
        self.assertFalse(re_surface._is_public_ip("192.168.1.1"))
        self.assertFalse(re_surface._is_public_ip("127.0.0.1"))


if __name__ == "__main__":
    unittest.main()
