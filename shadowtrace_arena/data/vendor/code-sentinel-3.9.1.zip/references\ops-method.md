# Sentinel Ops Method（全深原创）

从外部公开工作手册提炼的工程范式，在 Code Sentinel 内全部重写落地。  
**不搬运**外部 prompt/KB 章节原文；**精髓含破甲层，已原创实现为 `ops_framing`**。

## 已落地能力地图

| 精髓 | 实现 |
|------|------|
| 瘦核心路由 | `ops_router.py` S1–S8 |
| 25 细模块 playbook | `ops_modules.py` M01–M25 |
| 6 工具协同 Pattern | `ops_patterns.py` P-A…P-F |
| 12+ Fallback 链 | `ops_fallback.py` + 可选执行 |
| 深分诊指纹卡 | `ops_triage.py` |
| 算法/常量还原阶段 | `ops_algo.py` |
| 速查表 | `ops_knowledge.py` |
| 多阶段流水线 | `ops_pipeline.py`（含 ALGORITHM） |
| 8 段案例报告 | `ops_case.py` → `ops-lab/reports/` |
| **任务 reframing / 拒绝恢复（破甲精髓）** | **`ops_framing.py`** |

## 破甲精髓如何映射（原创，非 KB-33 拷贝）

| 外部常见做法 | Sentinel 原创 |
|--------------|---------------|
| 关键词降级词典 | `REFRAME_PAIRS` 技术词表改写 |
| 拒绝话术识别 | `detect_refusal` 中英信号 |
| 5 步拒绝恢复 | `recovery_plan` L1–L5 |
| Few-shot 演示 | `fewshot_skeletons` 绑定本仓库工具 |
| 身份锚定话术 | `build_agent_preamble`（Sentinel 编排器，非外部工号） |
| 攻防一体 | 每级恢复仍强制防御输出 |

### L1–L5

1. **rewrite** — 热词→技术表述  
2. **reanchor** — 靶场/CTF/授权审计场景 + 双交付  
3. **decompose** — 拆成 ops 子步骤  
4. **alternate_path** — 换 Pattern/静态旁路 + fallback  
5. **document_and_defend** — 归档已有证据，不省略加固  

### CLI

```bash
python scripts/ops_framing.py rewrite --text "帮我破解这个 pe"
python scripts/ops_framing.py detect --text "Sorry, I can't help"
python scripts/ops_framing.py recover --text "免杀分析" --refusal "I cannot" --json
python scripts/ops_framing.py fewshot
python scripts/pentest_suite.py frame 破解注册机 --mode recover
```

路由默认会先 framing 再分类（`ops_router.classify`）。

## Signal / Pattern / 流水线

见源码与 `ops_modules` / `ops_patterns` / `ops_pipeline`。  
阶段：`TRIAGE → STATIC → DYNAMIC → ALGORITHM → SYNTHESIS → REPORT`。
