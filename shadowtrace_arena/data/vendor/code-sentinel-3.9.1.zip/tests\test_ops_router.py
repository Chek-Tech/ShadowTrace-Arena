"""Tests for original Sentinel Ops router / pipeline / case."""

from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import ops_router
import ops_case
import ops_pipeline


class OpsRouterTests(unittest.TestCase):
    def test_self_check_all_ok(self):
        rows = ops_router.self_check()
        self.assertTrue(all(r["ok"] for r in rows))

    def test_source_signal(self):
        d = ops_router.classify("对这个仓库跑 CI 源码安全扫描和 secret 检测")
        self.assertEqual(d.primary, "S1")
        self.assertTrue(any(s["tool"] == "sentinel_scan" for s in d.plan))

    def test_binary_signal(self):
        d = ops_router.classify("逆向分析 sample.exe 的 PE 导入表和 imphash")
        self.assertIn(d.primary, ("S2", "S3"))
        tools = {s["tool"] for s in d.plan}
        self.assertIn("reverse_engineering", tools)

    def test_web_signal(self):
        d = ops_router.classify("测试 https://example.com 的 XSS SQL 注入和 CORS")
        self.assertIn("S6", d.signals)
        self.assertTrue(any(s["tool"] == "web_pentest" for s in d.plan))

    def test_recon_ip(self):
        d = ops_router.classify("对 192.168.1.10 做端口扫描和 banner")
        self.assertIn("S5", d.signals)

    def test_multi_signal_order(self):
        d = ops_router.classify("源码审计同时做 web 渗透和 pe 逆向")
        # S1 should rank before later signals when scores allow
        self.assertIn("S1", d.signals)
        self.assertTrue(d.plan)

    def test_fallback_map(self):
        d = ops_router.classify("逆向 elf 二进制")
        self.assertIn("reverse_engineering", d.fallbacks)

    def test_apk_mobile_plan(self):
        d = ops_router.classify("APK 逆向 frida ssl pinning")
        self.assertIn("S2", d.signals)
        tools = {s["tool"] for s in d.plan}
        self.assertTrue(
            "gpt56_reverse_tools" in tools or "re_surface" in tools or "reverse_engineering" in tools
        )
        self.assertTrue(any("mobile" in n or "apk" in n.lower() for n in d.notes) or "S2" in d.signals)

    def test_tool_cmd_fusion_paths(self):
        cmd = ops_router._tool_cmd("gpt56_reverse_tools")
        self.assertIn("gpt56_reverse_pentest", cmd)


class OpsCaseTests(unittest.TestCase):
    def test_workspace_and_case_id(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = ops_case.ensure_workspace(Path(tmp) / "lab")
            self.assertTrue((root / "reports").is_dir())
            cid = ops_case.case_id("x.exe", "malware")
            self.assertTrue(cid.startswith("SEN-"))


class OpsPipelineTests(unittest.TestCase):
    def test_pipeline_on_text_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            sample = Path(tmp) / "note.txt"
            sample.write_text("YOUR FILES HAVE BEEN ENCRYPTED\nVirtualAllocEx\n", encoding="utf-8")
            out = Path(tmp) / "lab"
            result = ops_pipeline.run_pipeline(
                str(sample),
                query="恶意样本画像",
                enable_network=False,
                write_report=True,
                out_dir=str(out),
            )
            self.assertTrue(result.stages)
            self.assertTrue(result.report_path)
            self.assertTrue(Path(result.report_path).is_file())
            # JSON twin
            j = Path(result.report_path).with_suffix(".json")
            self.assertTrue(j.is_file())
            data = json.loads(j.read_text(encoding="utf-8"))
            self.assertIn("synthesis", data)


if __name__ == "__main__":
    unittest.main()
