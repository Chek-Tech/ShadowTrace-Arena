"""GPT-5.6 profile helper tests."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import ops_gpt56


class Gpt56Tests(unittest.TestCase):
    def test_config_family(self):
        cfg = ops_gpt56.load_config()
        self.assertEqual(cfg.get("target_model", {}).get("family"), "gpt-5.6")

    def test_boot_checklist(self):
        rows = ops_gpt56.boot_checklist()
        self.assertTrue(rows)
        self.assertTrue(all("ok" in r for r in rows))
        # core files must pass
        by_id = {r["id"]: r["ok"] for r in rows}
        self.assertTrue(by_id.get("config"))
        self.assertTrue(by_id.get("core_prompt"))

    def test_session_bundle(self):
        b = ops_gpt56.build_session("分析 pe 样本", target="sample.exe")
        self.assertIn("system_prompt", b)
        self.assertIn("user_task_framed", b)
        self.assertIn("route", b)
        self.assertTrue(b.get("suggested_commands"))

    def test_paste_contains_markers(self):
        b = ops_gpt56.build_session("web 评估", target="https://x")
        text = ops_gpt56.render_paste(b)
        self.assertIn("SYSTEM", text)
        self.assertIn("USER TASK", text)

    def test_core_file_exists(self):
        self.assertTrue((ROOT / "prompts" / "gpt56-core.md").is_file())
        self.assertTrue((ROOT / "agents" / "gpt56.yaml").is_file())


if __name__ == "__main__":
    unittest.main()
