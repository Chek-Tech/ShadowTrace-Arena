#!/usr/bin/env python3
"""
Public / software reverse surface extractor (stdlib only).

Extracts from binaries and scripts:
  - URLs, domains, IPs, emails, cloud endpoints
  - PDB / debug paths, version-resource-ish strings
  - Network-related API surface classification
  - Software identity hints (product/company/version strings)
  - Optional light HTTP HEAD probe for discovered hosts (lab use)

Designed for RE of commercial/public software samples that phone home.
"""

from __future__ import annotations

import argparse
import ipaddress
import json
import re
import socket
import ssl
import struct
import sys
import urllib.error
import urllib.request
from collections import Counter
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urlparse

# ---------------------------------------------------------------------------
# Patterns
# ---------------------------------------------------------------------------
URL_RE = re.compile(
    rb"https?://[A-Za-z0-9\-._~:/?#\[\]@!$&'()*+,;=%]{4,200}",
    re.I,
)
URL_RE_S = re.compile(
    r"https?://[A-Za-z0-9\-._~:/?#\[\]@!$&'()*+,;=%]{4,200}",
    re.I,
)
# domain-like (not full URL)
DOMAIN_RE = re.compile(
    rb"(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+(?:com|net|org|io|co|cn|ru|info|biz|xyz|app|dev|cloud|ai|cc|tv|me|us|uk|de|jp|kr|top|site|online|tech|shop|pro|gov|edu|mil)(?:/[A-Za-z0-9\-_./?=&%]{0,80})?",
    re.I,
)
IPV4_RE = re.compile(
    rb"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b"
)
EMAIL_RE = re.compile(
    rb"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}",
)
PDB_RE = re.compile(
    rb"[A-Za-z]:\\[^\x00]{5,180}\.pdb|[A-Za-z]:\\[^\x00]{5,180}\.PDB|"
    rb"/[A-Za-z0-9._\-/]{5,180}\.pdb",
    re.I,
)
# common cloud / SaaS markers
CLOUD_MARKERS = [
    (rb"amazonaws\.com", "aws"),
    (rb"s3\.amazonaws", "aws-s3"),
    (rb"azure", "azure"),
    (rb"blob\.core\.windows", "azure-blob"),
    (rb"googleapis\.com", "gcp"),
    (rb"firebase", "firebase"),
    (rb"cloudflare", "cloudflare"),
    (rb"aliyuncs\.com", "aliyun"),
    (rb"qcloud\.com|myqcloud", "tencent"),
    (rb"oss-cn-", "aliyun-oss"),
    (rb"github\.com|raw\.githubusercontent", "github"),
    (rb"gitlab", "gitlab"),
    (rb"discord\.com|discordapp", "discord"),
    (rb"telegram", "telegram"),
    (rb"pastebin", "pastebin"),
    (rb"ngrok", "ngrok"),
    (rb"cloudfront\.net", "aws-cloudfront"),
]

NETWORK_APIS = {
    "WinHttpOpen": "winhttp",
    "WinHttpConnect": "winhttp",
    "WinHttpSendRequest": "winhttp",
    "InternetOpenA": "wininet",
    "InternetOpenW": "wininet",
    "InternetConnectA": "wininet",
    "HttpOpenRequestA": "wininet",
    "HttpSendRequestA": "wininet",
    "URLDownloadToFileA": "urlmon",
    "URLDownloadToFileW": "urlmon",
    "WSAStartup": "winsock",
    "socket": "socket",
    "connect": "socket",
    "send": "socket",
    "recv": "socket",
    "getaddrinfo": "dns",
    "gethostbyname": "dns",
    "DnsQuery_A": "dns",
    "DnsQuery_W": "dns",
    "curl_easy_init": "libcurl",
    "curl_easy_perform": "libcurl",
    "SSL_connect": "openssl",
    "SSL_write": "openssl",
    "PR_Connect": "nss",
    "CFHTTPMessageCreateRequest": "cfnetwork",
}

VERSION_STRING_RE = re.compile(
    r"(?i)(?:version|ver|v)\s*[=:]?\s*(\d+\.\d+(?:\.\d+){0,3})",
)
PRODUCT_HINT_RE = re.compile(
    r"(?i)(companyname|filedescription|productname|legalcopyright|originalfilename|internalname)\x00*([^\x00]{2,80})",
)

PRIVATE_IP_PREFIXES = ("10.", "192.168.", "172.16.", "172.17.", "172.18.", "172.19.",
                       "172.2", "127.", "0.", "255.", "169.254.")


@dataclass
class SurfaceReport:
    path: str
    urls: list[str] = field(default_factory=list)
    domains: list[str] = field(default_factory=list)
    ips: list[str] = field(default_factory=list)
    emails: list[str] = field(default_factory=list)
    pdb_paths: list[str] = field(default_factory=list)
    cloud_hits: list[str] = field(default_factory=list)
    network_apis: list[dict[str, str]] = field(default_factory=list)
    software_identity: dict[str, Any] = field(default_factory=dict)
    rich_header: dict[str, Any] = field(default_factory=dict)
    pe_version_info: dict[str, str] = field(default_factory=dict)
    public_endpoints: list[dict[str, Any]] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    probes: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _uniq(seq: list[str], limit: int = 200) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for x in seq:
        x = x.strip().rstrip(".,;:)'\"")
        if not x or x in seen:
            continue
        seen.add(x)
        out.append(x)
        if len(out) >= limit:
            break
    return out


def _is_public_ip(ip: str) -> bool:
    try:
        obj = ipaddress.ip_address(ip)
        return not (obj.is_private or obj.is_loopback or obj.is_link_local or obj.is_multicast or obj.is_reserved)
    except ValueError:
        return False


def _is_boring_domain(d: str) -> bool:
    d = d.lower().strip(".")
    # reject false positives from source code identifiers (self.format.com etc.)
    if d.startswith("self.") or d.startswith("fmt.") or d.startswith("cls."):
        return True
    if re.match(r"^(self|fmt|data|out|report|result|found|dll|api|hits|chars|parts|funcs|sections)\.", d):
        return True
    boring = (
        "wix.com", "example.com", "example.org", "schema.org", "w3.org",
        "microsoft.com", "windows.com", "apache.org", "openssl.org",
        "python.org", "github.com/features", "xmlns",
    )
    if any(b in d for b in boring) and "api." not in d and "update" not in d:
        if any(k in d for k in ("update", "download", "api.", "cdn.", "telemetry", "crash")):
            return False
        if d in ("microsoft.com", "windows.com", "github.com"):
            return True
    if d.startswith("www.w3.org") or "schemas.microsoft" in d:
        return True
    # require plausible multi-label host
    labels = d.split(".")
    if len(labels) < 2 or any(len(x) == 0 for x in labels):
        return True
    return False


def extract_from_bytes(data: bytes) -> dict[str, list[str]]:
    urls = [m.decode("ascii", errors="ignore") for m in URL_RE.findall(data)]
    # also utf-16 urls
    try:
        u16 = data.decode("utf-16-le", errors="ignore")
        urls.extend(URL_RE_S.findall(u16))
    except Exception:
        pass
    domains_raw = [m.decode("ascii", errors="ignore") for m in DOMAIN_RE.findall(data)]
    # strip paths from domain matches
    domains = []
    for d in domains_raw:
        host = d.split("/")[0].lower()
        if host.count(".") >= 1 and not _is_boring_domain(host):
            domains.append(host)
    ips = [m.decode("ascii", errors="ignore") for m in IPV4_RE.findall(data)]
    emails = [m.decode("ascii", errors="ignore") for m in EMAIL_RE.findall(data)]
    pdbs = []
    for m in PDB_RE.findall(data):
        try:
            pdbs.append(m.decode("utf-8", errors="ignore").replace("\x00", ""))
        except Exception:
            pass
    clouds = []
    for pat, name in CLOUD_MARKERS:
        if re.search(pat, data, re.I):
            clouds.append(name)
    return {
        "urls": _uniq(urls, 150),
        "domains": _uniq(domains, 150),
        "ips": _uniq(ips, 80),
        "emails": _uniq(emails, 40),
        "pdb_paths": _uniq(pdbs, 20),
        "cloud_hits": _uniq(clouds, 30),
    }


def scan_network_apis(data: bytes, import_names: Optional[list[str]] = None) -> list[dict[str, str]]:
    found: list[dict[str, str]] = []
    names = set(import_names or [])
    for api, cat in NETWORK_APIS.items():
        if api.encode() in data or api in names:
            found.append({"api": api, "category": cat})
    return found


def parse_rich_header(data: bytes) -> dict[str, Any]:
    """Best-effort PE Rich header parse (between DOS stub and PE header)."""
    if len(data) < 0x80 or data[:2] != b"MZ":
        return {}
    e_lfanew = struct.unpack_from("<I", data, 0x3C)[0]
    if e_lfanew <= 0x80 or e_lfanew > len(data):
        return {}
    region = data[0x80:e_lfanew]
    idx = region.rfind(b"Rich")
    if idx < 0:
        return {"present": False}
    # DanS marker xor key is in dword after Rich
    try:
        # key is at Rich+4
        key = struct.unpack_from("<I", region, idx + 4)[0]
        # find DanS = 0x536E6144 xor key
        dans = 0x536E6144 ^ key
        # scan backwards for start
        comps = []
        # entries are (comp_id, count) pairs before Rich, xored
        # simplified: just report present + key
        return {
            "present": True,
            "xor_key": hex(key),
            "rich_offset": 0x80 + idx,
            "note": "Rich header present (toolchain fingerprint); use die/pebear for full decode",
            "comp_count_hint": max(0, (idx // 8) - 1),
        }
    except Exception:
        return {"present": True, "note": "Rich marker found, parse incomplete"}


def parse_pe_version_info(data: bytes) -> dict[str, str]:
    """Scan for VS_VERSION_INFO string pairs (UTF-16LE common)."""
    out: dict[str, str] = {}
    # look for UTF-16LE key names
    keys = [
        "CompanyName", "FileDescription", "FileVersion", "ProductName",
        "ProductVersion", "LegalCopyright", "OriginalFilename", "InternalName",
    ]
    try:
        text = data.decode("utf-16-le", errors="ignore")
    except Exception:
        text = ""
    for key in keys:
        # pattern: Key\0Value nearby
        m = re.search(re.escape(key) + r"\x00+([^\x00]{1,120})", text)
        if m:
            out[key] = m.group(1).strip()
    # ascii fallback ProductVersion-like
    if not out.get("FileVersion"):
        m2 = re.search(rb"FileVersion\x00+([^\x00]{1,40})", data)
        if m2:
            out["FileVersion"] = m2.group(1).decode("latin-1", errors="ignore")
    return out


def software_identity_from_strings(strings: list[str], version_info: dict[str, str]) -> dict[str, Any]:
    ident: dict[str, Any] = dict(version_info)
    versions = []
    products = []
    for s in strings[:2000]:
        for m in VERSION_STRING_RE.finditer(s):
            versions.append(m.group(1))
        if re.search(r"(?i)(copyright|©|\(c\))", s) and len(s) < 120:
            ident.setdefault("copyright_hint", s[:120])
        if re.search(r"(?i)(updater|installer|setup|unins)", s) and len(s) < 80:
            products.append(s)
    if versions:
        # most common version-like
        ident["version_candidates"] = [v for v, _ in Counter(versions).most_common(5)]
    if products:
        ident["installer_hints"] = products[:8]
    return ident


def build_public_endpoints(urls: list[str], domains: list[str], ips: list[str]) -> list[dict[str, Any]]:
    eps: list[dict[str, Any]] = []
    for u in urls:
        try:
            p = urlparse(u)
            host = (p.hostname or "").lower()
            if not host:
                continue
            kind = "public"
            if any(host.startswith(x) or host == x.rstrip(".") for x in ("localhost",)):
                kind = "local"
            eps.append({
                "type": "url",
                "value": u[:240],
                "host": host,
                "scheme": p.scheme,
                "path": (p.path or "/")[:120],
                "scope": kind,
            })
        except Exception:
            continue
    for d in domains:
        if not any(e.get("host") == d for e in eps):
            eps.append({"type": "domain", "value": d, "host": d, "scope": "public"})
    for ip in ips:
        scope = "public" if _is_public_ip(ip) else "private"
        eps.append({"type": "ip", "value": ip, "host": ip, "scope": scope})
    return eps[:200]


def probe_endpoint(host: str, timeout: float = 3.0, https: bool = True) -> dict[str, Any]:
    """Optional light connectivity probe (DNS + HTTP HEAD)."""
    result: dict[str, Any] = {"host": host, "dns": [], "http": None, "error": ""}
    try:
        infos = socket.getaddrinfo(host, 443 if https else 80, type=socket.SOCK_STREAM)
        ips = sorted({i[4][0] for i in infos})
        result["dns"] = ips[:8]
    except Exception as exc:
        result["error"] = f"dns:{exc}"[:120]
        return result
    url = f"{'https' if https else 'http'}://{host}/"
    try:
        ctx = ssl._create_unverified_context()
        req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "CodeSentinel-RE-Surface/3.0"})
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            result["http"] = {
                "status": resp.status,
                "server": resp.headers.get("Server", ""),
                "content_type": resp.headers.get("Content-Type", ""),
            }
    except Exception as exc:
        result["http"] = {"error": str(exc)[:160]}
    return result


def analyze_surface(
    path: str | Path,
    max_read: int = 12_000_000,
    probe: bool = False,
    probe_limit: int = 5,
    import_names: Optional[list[str]] = None,
) -> SurfaceReport:
    p = Path(path)
    report = SurfaceReport(path=str(p))
    if not p.is_file():
        report.notes.append("file not found")
        return report
    data = p.read_bytes()[:max_read]
    extracted = extract_from_bytes(data)
    report.urls = extracted["urls"]
    report.domains = extracted["domains"]
    report.ips = extracted["ips"]
    report.emails = extracted["emails"]
    report.pdb_paths = extracted["pdb_paths"]
    report.cloud_hits = extracted["cloud_hits"]
    report.network_apis = scan_network_apis(data, import_names)
    report.rich_header = parse_rich_header(data)
    report.pe_version_info = parse_pe_version_info(data)

    # strings for identity
    ascii_s = re.findall(rb"[\x20-\x7e]{6,100}", data[:2_000_000])
    strs = [s.decode("ascii", errors="ignore") for s in ascii_s[:3000]]
    report.software_identity = software_identity_from_strings(strs, report.pe_version_info)
    report.public_endpoints = build_public_endpoints(report.urls, report.domains, report.ips)

    pub_hosts = []
    for e in report.public_endpoints:
        if e.get("scope") == "public" and e.get("host"):
            h = e["host"]
            if h not in pub_hosts and not re.match(r"^\d+\.\d+\.\d+\.\d+$", h):
                pub_hosts.append(h)

    if report.urls or report.domains:
        report.notes.append(f"network strings: urls={len(report.urls)} domains={len(report.domains)}")
    if report.pdb_paths:
        report.notes.append(f"PDB/debug paths: {len(report.pdb_paths)} (leak build environment)")
    if report.cloud_hits:
        report.notes.append(f"cloud markers: {', '.join(report.cloud_hits)}")
    if report.network_apis:
        cats = sorted({a['category'] for a in report.network_apis})
        report.notes.append(f"network API surface: {', '.join(cats)}")
    if report.rich_header.get("present"):
        report.notes.append("PE Rich header present (compiler/linker fingerprint)")

    if probe and pub_hosts:
        for host in pub_hosts[:probe_limit]:
            report.probes.append(probe_endpoint(host))

    return report


def analyze_software_re(
    path: str | Path,
    probe: bool = False,
    max_read: int = 12_000_000,
) -> dict[str, Any]:
    """Combine reverse_engineering + public surface into one software RE report."""
    import reverse_engineering as re_mod

    p = Path(path)
    rev = re_mod.analyze_binary(p, max_read=max_read)
    imp_names = [f.get("name", "") for f in (rev.format.import_functions or [])]
    surface = analyze_surface(
        p,
        max_read=max_read,
        probe=probe,
        import_names=imp_names,
    )
    # merge notes
    all_notes = list(rev.notes) + list(surface.notes)
    # software RE playbook steps
    playbook = [
        "1. 确认格式/架构/加壳 (format, packers, entropy)",
        "2. 提取公网面: URL/域名/IP/云服务 (re_surface)",
        "3. 网络 API 与能力图 (network_apis, capability_map)",
        "4. 版本/公司/PDB 指纹定位同源样本",
        "5. 授权/校验字符串与算法常量 (license_patterns, crypto)",
        "6. 若需联机：对公网 host 做 DNS/HEAD 探测 ( --probe )",
        "7. 防御：证书固定、更新通道完整性、遥测最小化、符号剥离",
    ]
    return {
        "path": str(p),
        "reverse": rev.to_dict(),
        "surface": surface.to_dict(),
        "summary": {
            "kind": rev.format.kind,
            "arch": rev.format.arch,
            "packed": rev.is_packed,
            "packers": rev.packers,
            "imphash": rev.format.imphash,
            "public_url_count": len(surface.urls),
            "public_domain_count": len(surface.domains),
            "public_ip_count": sum(1 for i in surface.ips if _is_public_ip(i)),
            "network_api_count": len(surface.network_apis),
            "product": surface.pe_version_info.get("ProductName") or surface.software_identity.get("ProductName"),
            "company": surface.pe_version_info.get("CompanyName") or surface.software_identity.get("CompanyName"),
            "file_version": surface.pe_version_info.get("FileVersion"),
        },
        "playbook": playbook,
        "notes": all_notes,
        "defense": [
            "剥离 PDB 与详细版本资源中的内部路径",
            "更新/许可证通道做证书固定与签名校验",
            "公网域名走 CDN+WAF，禁明文 HTTP 回连",
            "敏感 API（注入/提权）配合运行时防护与遥测",
            "imphash/域名 IOC 纳入威胁情报匹配",
        ],
    }


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Public/software reverse surface analysis")
    parser.add_argument("path", help="file or directory")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--probe", action="store_true", help="DNS+HTTP HEAD on public hosts")
    parser.add_argument("--probe-limit", type=int, default=5)
    parser.add_argument("--surface-only", action="store_true", help="skip full reverse_engineering merge")
    args = parser.parse_args(argv)

    target = Path(args.path)
    reports: list[dict[str, Any]] = []

    files: list[Path] = []
    if target.is_file():
        files = [target]
    elif target.is_dir():
        exts = {".exe", ".dll", ".sys", ".so", ".dylib", ".bin", ".elf", ".apk", ".dex", ".msi"}
        for p in sorted(target.rglob("*")):
            if p.is_file() and (p.suffix.lower() in exts or p.name.lower() in {"app", "application"}):
                if p.stat().st_size < 80_000_000:
                    files.append(p)
            if len(files) >= 50:
                break
    else:
        print("path not found", file=sys.stderr)
        return 2

    for f in files:
        if args.surface_only:
            rep = analyze_surface(f, probe=args.probe, probe_limit=args.probe_limit).to_dict()
        else:
            rep = analyze_software_re(f, probe=args.probe)
        reports.append(rep)

    if args.json:
        print(json.dumps(reports if len(reports) != 1 else reports[0], ensure_ascii=False, indent=2, default=str))
    else:
        for rep in reports:
            if "summary" in rep:
                s = rep["summary"]
                print("=" * 60)
                print(f"path    : {rep.get('path')}")
                print(f"format  : {s.get('kind')} {s.get('arch')} packed={s.get('packed')} {s.get('packers')}")
                print(f"product : {s.get('company')} / {s.get('product')} {s.get('file_version')}")
                print(f"imphash : {s.get('imphash')}")
                print(f"surface : urls={s.get('public_url_count')} domains={s.get('public_domain_count')} "
                      f"pub_ips={s.get('public_ip_count')} net_apis={s.get('network_api_count')}")
                surf = rep.get("surface") or {}
                for u in (surf.get("urls") or [])[:12]:
                    print(f"  url   : {u}")
                for d in (surf.get("domains") or [])[:12]:
                    print(f"  domain: {d}")
                for pdb in (surf.get("pdb_paths") or [])[:5]:
                    print(f"  pdb   : {pdb}")
                for n in (rep.get("notes") or [])[:8]:
                    print(f"  note  : {n}")
                for d in (rep.get("defense") or [])[:4]:
                    print(f"  def   : {d}")
            else:
                print(json.dumps(rep, ensure_ascii=False, indent=2)[:2000])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
