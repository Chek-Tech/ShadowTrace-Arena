#!/usr/bin/env python3
"""FTP Server - Anonymous access + directory traversal + upload + exec."""
import os, socket, threading, subprocess, json

FLAG = os.environ.get("FLAG_FILESRV", "CS{test}")
BASE = "/ftp"
os.makedirs(BASE, exist_ok=True)
with open(f"{BASE}/flag.txt", "w") as f: f.write(FLAG + "\n")
with open(f"{BASE}/welcome.txt", "w") as f: f.write("Welcome to corp FTP. Anonymous access enabled.\n")
with open(f"{BASE}/.htpasswd", "w") as f: f.write("webadmin:$apr1$xyz...hash\n")

def handle(conn, addr):
    conn.settimeout(60)
    cwd = BASE
    conn.send(b"220 FTP Server v1.0 (Anonymous OK)\r\n")
    try:
        while True:
            conn.send(b"ftp> ")
            cmd = conn.recv(4096).decode().strip()
            if not cmd: break
            parts = cmd.split()
            op = parts[0].upper()
            if op == "USER":
                conn.send(b"331 Username ok, password required\r\n")
            elif op == "PASS":
                conn.send(b"230 Login OK (anonymous)\r\n")
            elif op == "LIST" or op == "LS":
                files = os.listdir(cwd)
                conn.send(f"150 Opening data connection\r\n{chr(10).join(files)}\r\n226 Done\r\n".encode())
            elif op == "CWD":
                new = os.path.normpath(os.path.join(cwd, parts[1] if len(parts)>1 else "/"))
                if os.path.isdir(new):
                    cwd = new
                    conn.send(b"250 OK\r\n")
                else:
                    conn.send(b"550 Not found\r\n")
            elif op == "RETR":
                fn = os.path.normpath(os.path.join(cwd, parts[1] if len(parts)>1 else ""))
                if fn.startswith(BASE) and os.path.isfile(fn):
                    with open(fn, "rb") as f:
                        data = f.read()
                    conn.send(f"150 Opening ({len(data)} bytes)\r\n".encode())
                    conn.send(data)
                    conn.send(b"\r\n226 Done\r\n")
                else:
                    conn.send(b"550 File not found\r\n")
            elif op == "STOR":
                fn = os.path.normpath(os.path.join(cwd, parts[1] if len(parts)>1 else "upload"))
                conn.send(b"150 Ready\r\n")
                data = conn.recv(65536)
                with open(fn, "wb") as f: f.write(data)
                conn.send(b"226 Stored\r\n")
                # VULN: if uploaded .php/.py file, can exec
                if fn.endswith(".py") or fn.endswith(".sh"):
                    conn.send(b"Note: uploaded script is executable\r\n".encode())
            elif op == "EXEC":
                # VULN: arbitrary command execution
                fn = parts[1] if len(parts) > 1 else "id"
                out = subprocess.check_output(fn, shell=True, cwd=cwd, timeout=5).decode()
                conn.send(f"200 Output:\n{out}\r\n".encode())
            elif op == "QUIT":
                conn.send(b"221 Bye\r\n"); break
            else:
                conn.send(b"500 Unknown command (LIST/LS/RETR/STOR/CWD/EXEC/QUIT)\r\n")
    except: pass
    conn.close()

s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("0.0.0.0", 21)); s.listen(5)
print("[*] FTP on :21 (anonymous)")
while True: c,a = s.accept(); threading.Thread(target=handle, args=(c,a), daemon=True).start()
