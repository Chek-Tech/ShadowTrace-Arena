#!/usr/bin/env python3
"""
Sentinel algorithm recovery helpers (original).

Detect common crypto constants / simple encodings and emit a runnable
decrypt sketch for analysts — not a full symbolic executor.
"""

from __future__ import annotations

import argparse
import base64
import binascii
import hashlib
import json
import re
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional


CRYPTO_MARKERS: list[tuple[bytes, str]] = [
    (bytes([0x63, 0x7C, 0x77, 0x7B]), "AES_SBOX"),
    (bytes([0x52, 0x09, 0x6A, 0xD5]), "AES_INV_SBOX"),
    (bytes.fromhex("67452301"), "MD5_A_LE_hint"),
    (bytes.fromhex("efcdab89"), "MD5_B_LE_hint"),
    (bytes.fromhex("9e3779b9"), "TEA_DELTA"),
    (bytes.fromhex("b7e15163"), "RC5_P32"),
    (bytes.fromhex("6a09e667"), "SHA256_H0"),
    (b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", "BASE64_ALPHABET"),
]


@dataclass
class AlgoFinding:
    kind: str
    detail: str
    offset: int = -1
    confidence: str = "medium"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class AlgoReport:
    path: str
    findings: list[AlgoFinding] = field(default_factory=list)
    encodings: list[dict[str, Any]] = field(default_factory=list)
    decrypt_sketch: str = ""
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": self.path,
            "findings": [f.to_dict() for f in self.findings],
            "encodings": self.encodings,
            "decrypt_sketch": self.decrypt_sketch,
            "notes": self.notes,
        }


def scan_crypto_constants(data: bytes) -> list[AlgoFinding]:
    out: list[AlgoFinding] = []
    for needle, name in CRYPTO_MARKERS:
        idx = data.find(needle)
        if idx >= 0:
            out.append(AlgoFinding(kind="crypto_constant", detail=name, offset=idx, confidence="high"))
    return out


def scan_text_encodings(text: str) -> list[dict[str, Any]]:
    hits: list[dict[str, Any]] = []
    # base64 blobs
    for m in re.finditer(r"[A-Za-z0-9+/]{24,}={0,2}", text):
        s = m.group(0)
        try:
            raw = base64.b64decode(s, validate=False)
            if raw and all(32 <= b < 127 or b in (9, 10, 13) for b in raw[:32]):
                hits.append({"type": "base64", "sample": s[:40], "decoded_preview": raw[:40].decode("latin-1", errors="replace")})
        except Exception:
            pass
    # hex
    for m in re.finditer(r"\b(?:[0-9a-fA-F]{2}){8,}\b", text):
        hx = m.group(0)
        if len(hx) > 64:
            continue
        try:
            raw = binascii.unhexlify(hx)
            hits.append({"type": "hex", "sample": hx[:40], "len": len(raw)})
        except Exception:
            pass
    # single-byte xor guess on high-entropy printable
    return hits[:30]


def xor_bruteforce_preview(data: bytes, limit: int = 64) -> list[dict[str, Any]]:
    """Top printable-ratio single-byte XOR keys on a short window."""
    window = data[: min(len(data), 256)]
    if not window:
        return []
    scored = []
    for key in range(256):
        dec = bytes(b ^ key for b in window)
        printable = sum(1 for b in dec if 32 <= b < 127)
        ratio = printable / len(dec)
        if ratio > 0.85:
            scored.append({
                "key": key,
                "key_hex": f"{key:02x}",
                "ratio": round(ratio, 3),
                "preview": dec[:limit].decode("latin-1", errors="replace"),
            })
    scored.sort(key=lambda x: -x["ratio"])
    return scored[:5]


def generate_decrypt_sketch(findings: list[AlgoFinding], path: str) -> str:
    kinds = {f.detail for f in findings}
    lines = [
        "#!/usr/bin/env python3",
        f"# Auto sketch for {path} — review before trust",
        "from pathlib import Path",
        "data = Path(r'''" + path.replace("'", "") + "''').read_bytes()",
        "",
    ]
    if "TEA_DELTA" in kinds:
        lines += [
            "# TEA/XTEA delta constant present — implement rounds if key recovered",
            "DELTA = 0x9E3779B9",
            "",
        ]
    if "AES_SBOX" in kinds:
        lines += [
            "# AES S-box present — prefer pycryptodome/cryptography for real AES",
            "# key/iv must be located near CryptEncrypt/CryptImportKey usage",
            "",
        ]
    if "BASE64_ALPHABET" in kinds:
        lines += [
            "import base64, re",
            "for m in re.finditer(rb'[A-Za-z0-9+/]{24,}={0,2}', data):",
            "    try:",
            "        print(base64.b64decode(m.group(0))[:80])",
            "    except Exception:",
            "        pass",
            "",
        ]
    lines += [
        "# Generic single-byte XOR probe",
        "for key in range(256):",
        "    dec = bytes(b ^ key for b in data[:64])",
        "    if sum(32 <= c < 127 for c in dec) > 50:",
        "        print(hex(key), dec)",
        "        break",
        "",
    ]
    return "\n".join(lines)


def analyze(path: str | Path) -> AlgoReport:
    p = Path(path)
    report = AlgoReport(path=str(p))
    if not p.is_file():
        report.notes.append("not a file — skip binary algo scan")
        return report
    data = p.read_bytes()[:8_000_000]
    report.findings = scan_crypto_constants(data)
    try:
        text = data.decode("utf-8", errors="ignore")
    except Exception:
        text = ""
    report.encodings = scan_text_encodings(text)
    xor_hits = xor_bruteforce_preview(data)
    if xor_hits:
        report.encodings.append({"type": "xor_guesses", "top": xor_hits})
    report.decrypt_sketch = generate_decrypt_sketch(report.findings, str(p))
    if not report.findings and not report.encodings:
        report.notes.append("no strong crypto markers — try dynamic dumps")
    return report


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Sentinel algo recovery")
    parser.add_argument("target")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--write-sketch", default="")
    args = parser.parse_args(argv)
    rep = analyze(args.target)
    if args.write_sketch:
        Path(args.write_sketch).write_text(rep.decrypt_sketch, encoding="utf-8")
    if args.json:
        print(json.dumps(rep.to_dict(), ensure_ascii=False, indent=2))
    else:
        print(f"path: {rep.path}")
        for f in rep.findings:
            print(f"  [{f.confidence}] {f.kind}: {f.detail} @ {f.offset}")
        print(f"encodings: {len(rep.encodings)}")
        print("--- sketch ---")
        print(rep.decrypt_sketch[:800])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
