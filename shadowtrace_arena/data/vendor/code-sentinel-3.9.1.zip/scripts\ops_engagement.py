#!/usr/bin/env python3
"""
Sentinel Engagement Suite — original full-stack engagement engine.

Technical essences distilled from multi-agent PTES frameworks (re-implemented):
  1) Per-target directory *contract* with phase-expected artifacts + validator
  2) Phase *chain* with parallel work-package declarations
  3) Port/service → enum playbook matrix (tool selection, not corpus dump)
  4) Web pretest blueprint (map / probe / evidence slots) without vendor scripts
  5) Global solutions ledger merge from per-target notes
  6) Report section skeleton + delivery checklist (no third-party template text)
  7) Scope interview state machine (one open question at a time)
  8) Local MCP/tool readiness peek before heavy phases
  9) KB topic map by phase → *local* references only

Does NOT copy third-party skills, PoC corpora, templates, or agent prompts.
Builds on ops_ptes_lab / ops_phase_kb / existing recon & web modules.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

_SCRIPTS = Path(__file__).resolve().parent
_ROOT = _SCRIPTS.parent
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))

PROTOCOL = "sentinel-engagement-v1"

# ---------------------------------------------------------------------------
# 1) Full target schema (expected artifacts by phase) — original layout
# ---------------------------------------------------------------------------
PHASE_EXPECTED: dict[str, list[str]] = {
    "L0": ["scope.json", "authorization.md", "state.json"],
    "L1": [
        "ports/",
        "services/",
        "scans/",
        "recon-summary.md",
        "manifests/manifest-L1.json",
    ],
    "L1W": [
        "web/",
        "web/web-map.json",
        "screenshots/",
        "manifests/manifest-L1W.json",
    ],
    "L2": ["threat_model.md", "manifests/manifest-L2.json"],
    "L3": [
        "vulns/",
        "vulns/verified.json",
        "manifests/manifest-L3.json",
    ],
    "L4": [
        "exploits/",
        "access.md",
        "loot/",
        "manifests/manifest-L4.json",
    ],
    "L5": [
        "post/",
        "post/situational.md",
        "manifests/manifest-L5.json",
    ],
    "L6": [
        "report.md",
        "evidence_index.json",
        "manifests/manifest-L6.json",
    ],
}

# ---------------------------------------------------------------------------
# 2) Service enum matrix — port/service → playbook (commands use CS tools first)
# ---------------------------------------------------------------------------
SERVICE_PLAYBOOKS: list[dict[str, Any]] = [
    {
        "id": "SP-HTTP",
        "match": {"ports": [80, 443, 8080, 8443, 8000, 3000, 5000, 8888], "names": ["http", "https", "http-proxy"]},
        "title": "Web / HTTP 面",
        "steps": [
            "web_pentest 被动头/TLS/路径探测",
            "记录 web-map（入口、表单、API 线索）",
            "必要时 ops_ptes_lab L1W",
        ],
        "tools": ["web_pentest", "ops_ptes_lab", "ops_phase_kb"],
        "cmds": [
            "python scripts/web_pentest.py {base_url} --json",
            "python scripts/ops_ptes_lab.py plan L1W --target {target}",
        ],
        "parallel_ok": True,
    },
    {
        "id": "SP-SSH",
        "match": {"ports": [22], "names": ["ssh"]},
        "title": "SSH",
        "steps": ["记录 banner/算法", "弱口令仅授权字典", "密钥策略观察"],
        "tools": ["pentest_recon"],
        "cmds": ["python scripts/pentest_recon.py {host} --json"],
        "parallel_ok": True,
    },
    {
        "id": "SP-SMB",
        "match": {"ports": [139, 445], "names": ["microsoft-ds", "netbios-ssn", "smb"]},
        "title": "SMB / 文件共享",
        "steps": ["空会话/共享枚举（授权内）", "签名策略", "版本指纹"],
        "tools": ["pentest_recon", "ops_chain"],
        "cmds": ["python scripts/pentest_recon.py {host} --json"],
        "parallel_ok": True,
    },
    {
        "id": "SP-RDP",
        "match": {"ports": [3389], "names": ["ms-wbt-server", "rdp"]},
        "title": "RDP",
        "steps": ["NLA 状态", "证书提示", "暴力仅限授权窗口"],
        "tools": ["pentest_recon"],
        "cmds": ["python scripts/pentest_recon.py {host} --json"],
        "parallel_ok": True,
    },
    {
        "id": "SP-SQL",
        "match": {"ports": [1433, 3306, 5432, 1521], "names": ["mysql", "postgresql", "ms-sql", "oracle"]},
        "title": "数据库面",
        "steps": ["版本横幅", "未授权/弱认证探测（授权）", "与 Web 层关联"],
        "tools": ["pentest_recon", "web_pentest"],
        "cmds": ["python scripts/pentest_recon.py {host} --json"],
        "parallel_ok": True,
    },
    {
        "id": "SP-LDAP",
        "match": {"ports": [389, 636, 3268, 3269], "names": ["ldap", "ldaps"]},
        "title": "目录服务",
        "steps": ["匿名绑定检测", "域信息线索", "与 AD 路径关联"],
        "tools": ["pentest_recon", "ops_chain", "ops_surface_matrix"],
        "cmds": [
            "python scripts/pentest_recon.py {host} --json",
            'python scripts/ops_surface_matrix.py route "LDAP AD" --json',
        ],
        "parallel_ok": True,
    },
    {
        "id": "SP-REDIS",
        "match": {"ports": [6379], "names": ["redis"]},
        "title": "Redis",
        "steps": ["未授权", "危险命令面", "内网跳板风险"],
        "tools": ["pentest_recon"],
        "cmds": ["python scripts/pentest_recon.py {host} --json"],
        "parallel_ok": True,
    },
    {
        "id": "SP-DNS",
        "match": {"ports": [53], "names": ["domain", "dns"]},
        "title": "DNS",
        "steps": ["区传送尝试（授权）", "记录类型枚举", "子域线索"],
        "tools": ["pentest_recon"],
        "cmds": ["python scripts/pentest_recon.py {host} --json"],
        "parallel_ok": True,
    },
    {
        "id": "SP-WINRM",
        "match": {"ports": [5985, 5986], "names": ["wsman", "winrm"]},
        "title": "WinRM",
        "steps": ["HTTP/HTTPS 端点", "认证方式", "横向面"],
        "tools": ["pentest_recon", "ops_chain"],
        "cmds": ["python scripts/pentest_recon.py {host} --json"],
        "parallel_ok": True,
    },
    {
        "id": "SP-GENERIC",
        "match": {"ports": [], "names": ["*"]},
        "title": "通用服务",
        "steps": ["banner", "版本", "默认口令策略观察"],
        "tools": ["pentest_recon"],
        "cmds": ["python scripts/pentest_recon.py {host} --json"],
        "parallel_ok": True,
    },
]

# ---------------------------------------------------------------------------
# 3) Report sections + delivery checklist (original wording)
# ---------------------------------------------------------------------------
REPORT_SECTIONS: list[str] = [
    "执行摘要",
    "范围与授权",
    "情报收集摘要",
    "威胁建模与优先级",
    "漏洞发现（严重度排序）",
    "利用与影响验证",
    "后利用与权限边界（如适用）",
    "风险评级与修复建议",
    "复测建议",
    "附录：证据索引与工具时间线",
]

REPORT_CHECKS: list[dict[str, str]] = [
    {"id": "R1", "title": "结构完整", "do": "REPORT_SECTIONS 各节均有内容或明确 N/A"},
    {"id": "R2", "title": "发现可复现", "do": "每条高危含复现步骤或流量要点"},
    {"id": "R3", "title": "证据路径", "do": "evidence_index 指向真实文件"},
    {"id": "R4", "title": "严重度一致", "do": "摘要表与正文一致"},
    {"id": "R5", "title": "修复可执行", "do": "每条含可操作修复，而非空话"},
    {"id": "R6", "title": "脱敏", "do": "无 cookie/token/密钥明文（可用 ops_anon）"},
    {"id": "R7", "title": "范围一致", "do": "报告目标 ⊆ scope.json"},
    {"id": "R8", "title": "时间线", "do": "阶段 manifests 时间可追溯"},
]

# ---------------------------------------------------------------------------
# 4) Scope interview machine
# ---------------------------------------------------------------------------
SCOPE_SLOTS: list[dict[str, str]] = [
    {"id": "targets", "prompt": "测试目标是什么？（IP/网段/域名/URL，可多项）"},
    {"id": "depth", "prompt": "测试深度？1. 轻量测绘  2. 标准验证  3. 深度利用（授权内）  4. 自定义"},
    {"id": "window", "prompt": "允许的时间窗口？（立即 / 日期时段）"},
    {"id": "constraints", "prompt": "禁区与约束？（DoS 否？生产库否？社工否？）"},
    {"id": "authz", "prompt": "请确认已获授权测试上述范围。（是/否 + 备注）"},
]


def _utc() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _host_from_target(target: str) -> str:
    t = target.strip()
    t = re.sub(r"^https?://", "", t, flags=re.I)
    return t.split("/")[0].split(":")[0]


# ---------- schema validate ----------

def validate_engagement(target: str, base: Optional[Path] = None) -> dict[str, Any]:
    import ops_ptes_lab

    td = ops_ptes_lab.target_dir(target, base)
    state = ops_ptes_lab.load_state(target, base) if (td / "state.json").is_file() else {}
    completed = set(state.get("completed_phases") or [])
    current = state.get("current_phase")

    rows = []
    for phase_id, expected in PHASE_EXPECTED.items():
        phase_rows = []
        for rel in expected:
            path = td / rel
            exists = path.exists()
            phase_rows.append({"path": rel, "exists": exists})
        required_now = phase_id in completed or phase_id == current
        ok = all(r["exists"] for r in phase_rows) if phase_id in completed else True
        # for completed phases, require all; for current, soft
        if phase_id in completed:
            ok = all(r["exists"] for r in phase_rows)
        rows.append(
            {
                "phase": phase_id,
                "required_strict": phase_id in completed,
                "ok": ok if phase_id in completed else None,
                "items": phase_rows,
            }
        )

    missing_completed = [
        f"{r['phase']}:{it['path']}"
        for r in rows
        if r["phase"] in completed
        for it in r["items"]
        if not it["exists"]
    ]
    return {
        "protocol": PROTOCOL,
        "target": target,
        "path": str(td),
        "current_phase": current,
        "completed_phases": sorted(completed),
        "phases": rows,
        "missing_for_completed": missing_completed,
        "ok": not missing_completed,
        "basic": ops_ptes_lab.validate_schema(target, base) if (td / "state.json").is_file() else None,
    }


def materialize_phase_dirs(target: str, phase_id: str, base: Optional[Path] = None) -> dict[str, Any]:
    """Create expected dirs/files skeletons for a phase (empty placeholders)."""
    import ops_ptes_lab

    td = ops_ptes_lab.target_dir(target, base)
    created = []
    for rel in PHASE_EXPECTED.get(phase_id, []):
        path = td / rel
        if rel.endswith("/"):
            path.mkdir(parents=True, exist_ok=True)
            created.append(str(path))
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            if not path.exists():
                if path.suffix == ".json":
                    path.write_text("{}\n", encoding="utf-8")
                else:
                    path.write_text(f"# {rel}\n\n(pending)\n", encoding="utf-8")
                created.append(str(path))
    return {"phase": phase_id, "created": created, "path": str(td)}


# ---------- service enum ----------

def plan_service_enum(
    host: str,
    ports: list[int],
    services: Optional[list[str]] = None,
    *,
    target: Optional[str] = None,
) -> dict[str, Any]:
    services = [s.lower() for s in (services or [])]
    port_set = set(int(p) for p in ports)
    matched = []
    used = set()
    for pb in SERVICE_PLAYBOOKS:
        if pb["id"] == "SP-GENERIC":
            continue
        mports = set(pb["match"]["ports"])
        names = pb["match"]["names"]
        hit = bool(port_set & mports) or any(n in services for n in names if n != "*")
        if hit:
            matched.append(_render_playbook(pb, host, target or host))
            used |= port_set & mports
    leftover = sorted(port_set - used)
    if leftover:
        gen = SERVICE_PLAYBOOKS[-1]
        item = _render_playbook(gen, host, target or host)
        item["leftover_ports"] = leftover
        matched.append(item)

    parallel = [m for m in matched if m.get("parallel_ok")]
    return {
        "protocol": PROTOCOL,
        "host": host,
        "ports": sorted(port_set),
        "services": services,
        "playbooks": matched,
        "parallel_groups": [p["id"] for p in parallel],
        "message": "port→playbook plan (Sentinel-native); execute only in-scope",
    }


def _render_playbook(pb: dict[str, Any], host: str, target: str) -> dict[str, Any]:
    base_url = target if re.match(r"^https?://", target, re.I) else f"http://{host}"
    cmds = [
        c.format(host=host, target=target, base_url=base_url)
        for c in pb.get("cmds") or []
    ]
    return {
        "id": pb["id"],
        "title": pb["title"],
        "steps": pb["steps"],
        "tools": pb["tools"],
        "cmds": cmds,
        "parallel_ok": pb.get("parallel_ok", False),
    }


# ---------- web pretest blueprint ----------

def web_pretest_blueprint(url: str) -> dict[str, Any]:
    """Original web pretest plan (essence: map → probe → evidence). No browser binary required."""
    return {
        "protocol": PROTOCOL,
        "url": url,
        "phases": [
            {
                "id": "WP1",
                "title": "面测绘",
                "do": [
                    "加载首页/关键入口",
                    "收集链接、表单、隐藏字段、JS 端点线索",
                    "记录技术栈指纹",
                ],
                "cmds": [f"python scripts/web_pentest.py {url} --json"],
                "artifacts": ["web/web-map.json", "screenshots/"],
            },
            {
                "id": "WP2",
                "title": "基础探针",
                "do": [
                    "安全响应头",
                    "常见路径/敏感文件",
                    "鉴权面与错误信息差异",
                ],
                "cmds": [f"python scripts/web_pentest.py {url} --json --active"],
                "artifacts": ["web/probe.json"],
            },
            {
                "id": "WP3",
                "title": "证据槽位",
                "do": [
                    "截图或 HTML 快照路径登记",
                    "写入 manifest-L1W",
                    "ops_phase_kb 用发现的路径/组件路由知识",
                ],
                "cmds": [
                    f'python scripts/ops_ptes_lab.py manifest {{target}} L1W --summary "web pretest" --http',
                    f"python scripts/ops_phase_kb.py text \"{url}\"",
                ],
                "artifacts": ["manifests/manifest-L1W.json"],
            },
        ],
        "note": "浏览器自动化可选；本蓝图默认用 web_pentest 无头能力 + 证据目录",
    }


# ---------- solutions hub ----------

def merge_solutions(base: Optional[Path] = None) -> dict[str, Any]:
    import ops_ptes_lab

    lab = ops_ptes_lab.lab_root(base)
    global_path = lab / "solutions-ledger.md"
    targets = ops_ptes_lab.list_targets(base)
    lines = [
        "# Sentinel Global Solutions Ledger",
        "",
        f"> Merged at {_utc()} · protocol `{PROTOCOL}`",
        "",
        "| Time | Target | Phase | Note | Artifact |",
        "|------|--------|-------|------|----------|",
    ]
    count = 0
    for t in targets:
        slug = t.get("slug") or ""
        td = ops_ptes_lab.targets_root(base) / slug
        sp = td / "solutions.md"
        if not sp.is_file():
            continue
        for line in sp.read_text(encoding="utf-8", errors="ignore").splitlines():
            if not line.startswith("|") or "Time" in line or "----" in line:
                continue
            # | time | phase | note | artifact |
            parts = [p.strip() for p in line.strip("|").split("|")]
            if len(parts) < 3:
                continue
            time_s = parts[0]
            phase = parts[1] if len(parts) > 1 else ""
            note = parts[2] if len(parts) > 2 else ""
            art = parts[3] if len(parts) > 3 else ""
            lines.append(f"| {time_s} | {t.get('target') or slug} | {phase} | {note} | {art} |")
            count += 1
    global_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"ok": True, "path": str(global_path), "entries": count, "targets": len(targets)}


# ---------- chain plan ----------

def chain_plan(target: str, base: Optional[Path] = None) -> dict[str, Any]:
    """Full engagement chain snapshot for agents (parallel packages included)."""
    import ops_ptes_lab
    import ops_phase_kb

    try:
        state = ops_ptes_lab.load_state(target, base)
    except FileNotFoundError:
        return {"ok": False, "error": "init target first", "hint": f"python scripts/ops_ptes_lab.py init {target}"}

    sequence = []
    http = bool(state.get("http_surface") or ops_ptes_lab.is_url_target(target))
    for p in ops_ptes_lab.PHASES:
        if p["id"] == "L0" and state.get("url_shortcut"):
            continue
        if p["id"] == "L1W" and not http:
            continue
        sequence.append(
            {
                "phase": p["id"],
                "title": p["title"],
                "work_packages": p.get("work_packages"),
                "tools": p.get("tools"),
                "plan": ops_ptes_lab.plan_phase(p["id"], target=target),
            }
        )

    kb = ops_phase_kb.route_target_phase(target, state.get("current_phase"), base)
    return {
        "protocol": PROTOCOL,
        "target": target,
        "state": state,
        "sequence": sequence,
        "current": state.get("current_phase"),
        "kb_now": kb,
        "validate": validate_engagement(target, base),
    }


# ---------- report ----------

def build_report(target: str, base: Optional[Path] = None) -> dict[str, Any]:
    import ops_ptes_lab

    brief = ops_ptes_lab.report_brief(target, base)
    td = ops_ptes_lab.target_dir(target, base)
    state = ops_ptes_lab.load_state(target, base)
    lines = [
        f"# Sentinel Engagement Report",
        "",
        f"- Target: `{state.get('target')}`",
        f"- Protocol: `{PROTOCOL}` / ptes `{ops_ptes_lab.PROTOCOL}`",
        f"- Generated: {_utc()}",
        "",
    ]
    for sec in REPORT_SECTIONS:
        lines.append(f"## {sec}")
        lines.append("")
        if sec == "执行摘要":
            lines.append(state.get("notes") or "（待填写总体结论与风险等级）")
        elif sec == "范围与授权":
            scope = td / "scope.json"
            if scope.is_file():
                lines.append("```json")
                lines.append(scope.read_text(encoding="utf-8")[:2000])
                lines.append("```")
            else:
                lines.append("见 scope.json / authorization.md")
        elif sec == "情报收集摘要":
            rs = td / "recon-summary.md"
            lines.append(rs.read_text(encoding="utf-8")[:3000] if rs.is_file() else "见 ports/ services/ manifests")
        elif sec == "威胁建模与优先级":
            tm = td / "threat_model.md"
            lines.append(tm.read_text(encoding="utf-8")[:3000] if tm.is_file() else "（L2 待完成）")
        elif sec.startswith("漏洞"):
            lines.append("见 vulns/ 与 manifest-L3")
        elif sec.startswith("利用"):
            lines.append("见 exploits/ access.md loot/")
        elif sec.startswith("后利用"):
            lines.append("见 post/")
        elif sec.startswith("附录"):
            lines.append(f"evidence_index: `{td / 'evidence_index.json'}`")
            lines.append(f"manifests: `{td / 'manifests'}`")
        else:
            lines.append("（待填写）")
        lines.append("")

    path = td / "report.md"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    checklist = [{"id": c["id"], "title": c["title"], "do": c["do"], "ok": None} for c in REPORT_CHECKS]
    return {
        "ok": True,
        "report": str(path),
        "sections": REPORT_SECTIONS,
        "checklist": checklist,
        "brief": brief,
        "message": "report skeleton written — complete checklist before delivery",
    }


# ---------- scope interview ----------

def scope_interview_state(path: Optional[Path] = None) -> dict[str, Any]:
    path = path or (_ROOT / "ops-lab" / "scope-interview.json")
    if path.is_file():
        return json.loads(path.read_text(encoding="utf-8"))
    return {
        "protocol": PROTOCOL,
        "answers": {},
        "next_slot": SCOPE_SLOTS[0]["id"],
        "done": False,
    }


def scope_interview_ask(path: Optional[Path] = None) -> dict[str, Any]:
    st = scope_interview_state(path)
    if st.get("done"):
        return {"done": True, "answers": st.get("answers"), "message": "scope complete"}
    sid = st.get("next_slot") or SCOPE_SLOTS[0]["id"]
    slot = next(s for s in SCOPE_SLOTS if s["id"] == sid)
    return {
        "done": False,
        "slot": slot["id"],
        "question": slot["prompt"],
        "rule": "一次只问一题；选项须编号，最后一项为自定义",
        "answered": list((st.get("answers") or {}).keys()),
    }


def scope_interview_answer(slot_id: str, answer: str, path: Optional[Path] = None) -> dict[str, Any]:
    path = path or (_ROOT / "ops-lab" / "scope-interview.json")
    st = scope_interview_state(path)
    st.setdefault("answers", {})[slot_id] = answer
    # next unanswered
    nxt = None
    for s in SCOPE_SLOTS:
        if s["id"] not in st["answers"]:
            nxt = s["id"]
            break
    st["next_slot"] = nxt
    st["done"] = nxt is None
    st["updated_at"] = _utc()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(st, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if st["done"]:
        return {"done": True, "answers": st["answers"], "message": "全部槽位已收集，可 init engagement"}
    return scope_interview_ask(path)


# ---------- MCP / tool readiness ----------

def tool_readiness(phase_id: str = "L1") -> dict[str, Any]:
    import ops_ptes_lab
    import ops_tool_index

    phase = ops_ptes_lab.PHASE_BY_ID.get(phase_id) or {}
    tools = phase.get("tools") or []
    idx = ops_tool_index.probe_all()
    by_id = {t["id"]: t for t in idx.get("tools") or []}
    rows = []
    for t in tools:
        ent = by_id.get(t) or ops_tool_index.check(t)
        rows.append({"tool": t, "available": bool(ent.get("available")), "path": ent.get("path"), "note": ent.get("note")})
    # external useful set
    external = ["nmap", "httpx", "jadx", "frida", "docker"]
    ext_rows = []
    for e in external:
        ent = by_id.get(e) or ops_tool_index.check(e)
        ext_rows.append({"tool": e, "available": bool(ent.get("available"))})
    return {
        "phase_id": phase_id,
        "phase_tools": rows,
        "external_probe": ext_rows,
        "ok": all(r["available"] for r in rows) or any(r["available"] for r in rows),
        "message": "prefer Sentinel modules; external tools optional with fallbacks",
    }


# ---------- full dig atlas (for humans) ----------

ESSENCE_ATLAS: list[dict[str, str]] = [
    {"essence": "PTES 多阶段生命周期", "module": "ops_ptes_lab"},
    {"essence": "阶段 manifest 交接", "module": "ops_ptes_lab.write_manifest"},
    {"essence": "转段门禁", "module": "ops_ptes_lab.transition_checklist"},
    {"essence": "URL 跳过范围阶段", "module": "ops_ptes_lab.init_target url_shortcut"},
    {"essence": "上阶段输出驱动知识", "module": "ops_phase_kb"},
    {"essence": "目标目录契约/校验", "module": "ops_engagement.validate_engagement"},
    {"essence": "阶段产物骨架生成", "module": "ops_engagement.materialize_phase_dirs"},
    {"essence": "端口→服务枚举剧本", "module": "ops_engagement.plan_service_enum"},
    {"essence": "Web 预检蓝图", "module": "ops_engagement.web_pretest_blueprint"},
    {"essence": "全局 solutions 合并", "module": "ops_engagement.merge_solutions"},
    {"essence": "阶段链总览+并行包", "module": "ops_engagement.chain_plan"},
    {"essence": "报告章节+交付检查", "module": "ops_engagement.build_report"},
    {"essence": "范围访谈一问一答", "module": "ops_engagement.scope_interview_*"},
    {"essence": "阶段工具就绪探测", "module": "ops_engagement.tool_readiness"},
    {"essence": "阶段真执行+落盘", "module": "ops_phase_runner.run_phase"},
    {"essence": "全自动跑到报告", "module": "ops_phase_runner.run_until"},
    {"essence": "战术链 C1–C6", "module": "ops_chain"},
    {"essence": "CTF 续跑契约", "module": "ops_ctf_runner"},
    {"essence": "攻击面矩阵", "module": "ops_surface_matrix"},
]


def essence_map() -> dict[str, Any]:
    return {"protocol": PROTOCOL, "essences": ESSENCE_ATLAS, "count": len(ESSENCE_ATLAS)}


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Sentinel Engagement Suite (original)")
    p.add_argument("--base", default=None)
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("essences", help="list distilled essences → modules")

    v = sub.add_parser("validate", help="full schema validate")
    v.add_argument("target")

    m = sub.add_parser("materialize", help="create phase expected skeletons")
    m.add_argument("target")
    m.add_argument("phase")

    e = sub.add_parser("enum-plan", help="port/service → playbook plan")
    e.add_argument("host")
    e.add_argument("--ports", default="", help="comma ports")
    e.add_argument("--services", default="", help="comma service names")
    e.add_argument("--target", default="")

    w = sub.add_parser("web-pretest", help="web pretest blueprint")
    w.add_argument("url")

    s = sub.add_parser("solutions-merge", help="merge all target solutions ledgers")

    c = sub.add_parser("chain", help="full engagement chain plan")
    c.add_argument("target")

    r = sub.add_parser("report", help="build full report skeleton + checklist")
    r.add_argument("target")

    si = sub.add_parser("scope-ask", help="next scope interview question")
    sa = sub.add_parser("scope-answer", help="answer current scope slot")
    sa.add_argument("slot")
    sa.add_argument("answer")

    tr = sub.add_parser("readiness", help="tool readiness for phase")
    tr.add_argument("--phase", default="L1")

    # one-shot full bootstrap
    b = sub.add_parser("bootstrap", help="init ptes + materialize L0/L1 + chain snapshot")
    b.add_argument("target")
    b.add_argument("--depth", default="standard")

    rn = sub.add_parser("run", help="execute one phase via ops_phase_runner")
    rn.add_argument("target")
    rn.add_argument("--phase", default=None)
    rn.add_argument("--advance", action="store_true")
    rn.add_argument("--active-web", action="store_true")
    rn.add_argument("--ports", default="")

    au = sub.add_parser("auto", help="auto-run phases until L6 via phase runner")
    au.add_argument("target")
    au.add_argument("--until", default="L6")
    au.add_argument("--active-web", action="store_true")
    au.add_argument("--ports", default="")

    args = p.parse_args(argv)
    base = Path(args.base) if getattr(args, "base", None) else None

    def dump(o: Any) -> int:
        print(json.dumps(o, ensure_ascii=False, indent=2, default=str))
        return 0

    try:
        if args.cmd == "essences":
            return dump(essence_map())
        if args.cmd == "validate":
            return dump(validate_engagement(args.target, base))
        if args.cmd == "materialize":
            return dump(materialize_phase_dirs(args.target, args.phase, base))
        if args.cmd == "enum-plan":
            ports = [int(x) for x in args.ports.split(",") if x.strip().isdigit()]
            services = [x.strip() for x in args.services.split(",") if x.strip()]
            return dump(plan_service_enum(args.host, ports, services, target=args.target or args.host))
        if args.cmd == "web-pretest":
            return dump(web_pretest_blueprint(args.url))
        if args.cmd == "solutions-merge":
            return dump(merge_solutions(base))
        if args.cmd == "chain":
            return dump(chain_plan(args.target, base))
        if args.cmd == "report":
            return dump(build_report(args.target, base))
        if args.cmd == "scope-ask":
            return dump(scope_interview_ask())
        if args.cmd == "scope-answer":
            return dump(scope_interview_answer(args.slot, args.answer))
        if args.cmd == "readiness":
            return dump(tool_readiness(args.phase))
        if args.cmd == "bootstrap":
            import ops_ptes_lab

            init = ops_ptes_lab.init_target(args.target, base=base, depth=args.depth, force=False)
            cur = init["state"]["current_phase"]
            mat = materialize_phase_dirs(args.target, cur, base)
            if init["state"].get("http_surface"):
                materialize_phase_dirs(args.target, "L1W", base)
            ch = chain_plan(args.target, base)
            return dump({"init": init, "materialize": mat, "chain": ch, "essences": len(ESSENCE_ATLAS)})
        if args.cmd == "run":
            import ops_phase_runner

            ports = [int(x) for x in args.ports.split(",") if x.strip().isdigit()] or None
            return dump(
                ops_phase_runner.run_phase(
                    args.target,
                    args.phase,
                    base=base,
                    advance=args.advance,
                    active_web=args.active_web,
                    ports=ports,
                )
            )
        if args.cmd == "auto":
            import ops_phase_runner

            ports = [int(x) for x in args.ports.split(",") if x.strip().isdigit()] or None
            return dump(
                ops_phase_runner.run_until(
                    args.target,
                    until_phase=args.until,
                    base=base,
                    active_web=args.active_web,
                    ports=ports,
                )
            )
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
