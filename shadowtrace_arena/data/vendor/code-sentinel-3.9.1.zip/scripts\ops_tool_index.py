#!/usr/bin/env python3
"""
Sentinel Tool Index — local capability discovery (original).

Essences learned (re-implemented):
  * Maintain a machine-readable index of tool availability before guessing paths.
  * Probe PATH + common install locations; never invent version/path.
  * Refresh on demand; agents must prefer index over folklore.
  * Missing tools → structured guidance (not silent failure).

Does not auto-download third-party installers; discovery only (zero deps).
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

_SCRIPTS = Path(__file__).resolve().parent
_ROOT = _SCRIPTS.parent

# capability id → candidate executable names
CAPABILITIES: dict[str, list[str]] = {
    "python": ["python", "python3", "py"],
    "git": ["git"],
    "rg": ["rg", "ripgrep"],
    "nmap": ["nmap"],
    "curl": ["curl", "curl.exe"],
    "openssl": ["openssl"],
    "adb": ["adb"],
    "frida": ["frida", "frida-ps"],
    "jadx": ["jadx", "jadx-gui"],
    "apktool": ["apktool"],
    "r2": ["r2", "radare2", "rabin2"],
    "ghidra": ["ghidra", "ghidraRun", "analyzeHeadless"],
    "ida": ["ida64", "idat64", "ida"],
    "yara": ["yara", "yarac"],
    "strings": ["strings"],
    "objdump": ["objdump"],
    "readelf": ["readelf"],
    "wireshark": ["tshark", "wireshark"],
    "docker": ["docker"],
    "kubectl": ["kubectl"],
    "node": ["node"],
    "npm": ["npm"],
    "pip": ["pip", "pip3"],
    "cmake": ["cmake"],
    "gcc": ["gcc", "clang"],
    "powershell": ["powershell", "pwsh"],
}

# Baseline names (kept for docs); probe_all auto-discovers scripts/*.py as well.
SENTINEL_MODULES = [
    "sentinel_scan", "reverse_engineering", "malware_analysis", "re_surface",
    "web_pentest", "pentest_recon", "ctf_toolkit", "ops_pipeline",
    "ops_ctf_runner", "ops_surface_matrix", "ops_chain", "ops_journal",
    "ops_framing", "ops_sandbox", "attack_game",
    "ops_method_packs", "ops_anon", "ops_report_contract", "ops_protocol_lab",
    "ops_obedience", "ops_instruct", "ops_pattern_db", "ops_essence_atlas",
    "ops_router", "ops_tool_index", "ops_doctor", "codex_inject",
    "ops_ptes_lab", "ops_phase_kb", "ops_engagement", "ops_phase_runner",
    "ops_gap_audit",
    "ops_algo", "ops_case", "ops_fallback", "ops_gpt56", "ops_knowledge",
    "ops_modules", "ops_originality", "ops_patterns", "ops_payloads",
    "ops_triage", "ops_trigger",
    "attack_dos", "attack_evasion", "attack_keygen", "attack_network",
    "attack_paywall", "attack_spider", "attack_toolkit",
    "exploit_cve", "sentinel_pack", "sentinel_report", "redact",
    "rules_builtin", "rules_reverse", "rules_offensive", "pentest_suite",
]

# Nested modules: id → path relative to scripts/
SENTINEL_MODULE_PATHS: dict[str, str] = {
    "gpt56_reverse_tools": "gpt56_reverse_pentest/reverse_tools.py",
    "gpt56_crypto_helper": "gpt56_reverse_pentest/crypto_helper.py",
    "gpt56_pwn_template": "gpt56_reverse_pentest/pwn_template.py",
}


def _discover_script_modules() -> list[str]:
    """Auto-index every top-level scripts/*.py (minus private/underscore)."""
    names: list[str] = []
    for p in sorted(_SCRIPTS.glob("*.py")):
        if p.name.startswith("_") or p.name == "__init__.py":
            continue
        names.append(p.stem)
    return names

# Optional Python packages (import probe, not PATH)
PYTHON_PACKAGES: dict[str, str] = {
    "pwntools": "pwn",
    "pycryptodome": "Crypto",
}


@dataclass
class ToolEntry:
    id: str
    available: bool
    path: Optional[str] = None
    kind: str = "external"  # external | sentinel
    note: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _which(names: list[str]) -> Optional[str]:
    for n in names:
        p = shutil.which(n)
        if p:
            return p
    return None


def _import_ok(mod_name: str) -> bool:
    try:
        __import__(mod_name)
        return True
    except Exception:
        return False


def probe_all() -> dict[str, Any]:
    tools: list[dict[str, Any]] = []
    for cid, names in CAPABILITIES.items():
        path = _which(names)
        tools.append(ToolEntry(
            id=cid,
            available=bool(path),
            path=path,
            kind="external",
            note="" if path else f"missing candidates: {', '.join(names)}",
        ).to_dict())

    seen_ids: set[str] = set()
    # Prefer explicit list, then auto-discover any new scripts/*.py
    module_ids = list(dict.fromkeys(SENTINEL_MODULES + _discover_script_modules()))
    for mid in module_ids:
        if mid in seen_ids:
            continue
        seen_ids.add(mid)
        fp = _SCRIPTS / f"{mid}.py"
        tools.append(ToolEntry(
            id=mid,
            available=fp.is_file(),
            path=str(fp) if fp.is_file() else None,
            kind="sentinel",
            note="repo module" + (" (discovered)" if mid not in SENTINEL_MODULES else ""),
        ).to_dict())

    for mid, rel in SENTINEL_MODULE_PATHS.items():
        if mid in seen_ids:
            continue
        seen_ids.add(mid)
        fp = _SCRIPTS / rel
        tools.append(ToolEntry(
            id=mid,
            available=fp.is_file(),
            path=str(fp) if fp.is_file() else None,
            kind="sentinel",
            note=f"fusion module ({rel})",
        ).to_dict())

    for pkg_id, import_name in PYTHON_PACKAGES.items():
        ok = _import_ok(import_name)
        tools.append(ToolEntry(
            id=pkg_id,
            available=ok,
            path=import_name if ok else None,
            kind="python-package",
            note="" if ok else f"pip install {pkg_id}  # import {import_name}",
        ).to_dict())

    available = sum(1 for t in tools if t["available"])
    fusion_ok = all(
        t["available"]
        for t in tools
        if t["id"] in SENTINEL_MODULE_PATHS
    )
    ops_count = sum(1 for t in tools if t["id"].startswith("ops_") and t["available"])
    return {
        "protocol": "sentinel-tool-index-v3",
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "platform": sys.platform,
        "path_sample": os.environ.get("PATH", "")[:200],
        "summary": {
            "total": len(tools),
            "available": available,
            "missing": len(tools) - available,
            "gpt56_fusion": fusion_ok,
            "ops_modules": ops_count,
            "discovered_scripts": len(_discover_script_modules()),
        },
        "tools": tools,
    }


def index_path() -> Path:
    lab = _ROOT / "ops-lab"
    lab.mkdir(parents=True, exist_ok=True)
    return lab / "tool-index.json"


def refresh(write: bool = True) -> dict[str, Any]:
    data = probe_all()
    if write:
        path = index_path()
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        data["written"] = str(path)
    return data


def load_or_refresh() -> dict[str, Any]:
    path = index_path()
    if path.is_file():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            pass
    return refresh(write=True)


def check(capability: str) -> dict[str, Any]:
    data = load_or_refresh()
    for t in data.get("tools") or []:
        if t.get("id") == capability:
            return t
    # live probe if not in index
    if capability in CAPABILITIES:
        path = _which(CAPABILITIES[capability])
        return {"id": capability, "available": bool(path), "path": path, "kind": "external"}
    if capability in SENTINEL_MODULE_PATHS:
        fp = _SCRIPTS / SENTINEL_MODULE_PATHS[capability]
        return {
            "id": capability,
            "available": fp.is_file(),
            "path": str(fp) if fp.is_file() else None,
            "kind": "sentinel",
        }
    if capability in PYTHON_PACKAGES:
        ok = _import_ok(PYTHON_PACKAGES[capability])
        return {
            "id": capability,
            "available": ok,
            "path": PYTHON_PACKAGES[capability] if ok else None,
            "kind": "python-package",
        }
    fp = _SCRIPTS / f"{capability}.py"
    if fp.is_file():
        return {"id": capability, "available": True, "path": str(fp), "kind": "sentinel"}
    return {"id": capability, "available": False, "path": None, "note": "unknown capability"}


def missing_report(needed: list[str]) -> dict[str, Any]:
    rows = [check(c) for c in needed]
    miss = [r for r in rows if not r.get("available")]
    return {
        "needed": needed,
        "missing": miss,
        "ok": [r for r in rows if r.get("available")],
        "guidance": (
            "外部工具缺失时：安装后执行 python scripts/ops_tool_index.py refresh；"
            "Sentinel 模块缺失则检查 CODE_SENTINEL_HOME/scripts。"
            "禁止编造路径或版本。"
        ),
    }


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Sentinel local tool index")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("refresh", help="Probe and write ops-lab/tool-index.json")
    sub.add_parser("show", help="Show index (refresh if missing)")
    c = sub.add_parser("check", help="Check one capability")
    c.add_argument("name")
    m = sub.add_parser("need", help="Report missing from required list")
    m.add_argument("names", nargs="+")

    args = p.parse_args(argv)
    if args.cmd == "refresh":
        print(json.dumps(refresh(True), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "show":
        print(json.dumps(load_or_refresh(), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "check":
        print(json.dumps(check(args.name), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "need":
        print(json.dumps(missing_report(args.names), ensure_ascii=False, indent=2))
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
