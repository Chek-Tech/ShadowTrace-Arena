"""Full atlas coverage must be complete."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import ops_essence_atlas
import ops_method_packs
import ops_surface_matrix


class AtlasTests(unittest.TestCase):
    def test_coverage_complete(self):
        cov = ops_essence_atlas.coverage_report()
        self.assertTrue(cov["complete"], msg=str(cov))
        self.assertEqual(cov["uncovered"], [])
        self.assertEqual(cov["broken_links"], [])
        self.assertGreaterEqual(cov["total_sources"], 80)

    def test_competition_count(self):
        comps = [r for r in ops_essence_atlas.ATLAS.values() if r["kind"] == "competition"]
        self.assertGreaterEqual(len(comps), 40)

    def test_packs_expanded(self):
        self.assertGreaterEqual(len(ops_method_packs.PACKS), 25)
        for pid in ("ad8", "js5", "fw9", "game7", "escape5", "src5"):
            self.assertIn(pid, ops_method_packs.PACKS)

    def test_surfaces_expanded(self):
        self.assertGreaterEqual(len(ops_surface_matrix.SURFACES), 45)
        for sid in ("adcs-cert", "kernel-escape", "browser-auto", "src-bounty"):
            self.assertIn(sid, ops_surface_matrix.SURFACES)

    def test_lookup_js(self):
        r = ops_essence_atlas.lookup("skill.js-reverse")
        self.assertIsNotNone(r)
        self.assertIn("pack:js5", r["maps_to"])


if __name__ == "__main__":
    unittest.main()
