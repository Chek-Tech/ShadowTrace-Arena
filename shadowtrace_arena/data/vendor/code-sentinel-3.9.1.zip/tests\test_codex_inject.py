"""Tests for Codex inject + trigger words."""

from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import codex_inject
import ops_trigger


class CodexInjectTests(unittest.TestCase):
    def test_install_uninstall_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "codex-home"
            home.mkdir()
            # pre-existing AGENTS
            (home / "AGENTS.md").write_text("# existing\n\nhello\n", encoding="utf-8")
            result = codex_inject.install(home=home, project=ROOT)
            self.assertTrue(result["ok"])
            agents = (home / "AGENTS.md").read_text(encoding="utf-8")
            self.assertIn(codex_inject.MANAGED_BEGIN, agents)
            self.assertIn("豆包大人", agents)
            self.assertIn("existing", agents)
            for skill in codex_inject.SKILL_NAMES:
                self.assertTrue((home / "skills" / skill / "SKILL.md").is_file())
            self.assertTrue((home / "code-sentinel.env").is_file())

            st = codex_inject.status(home=home)
            self.assertTrue(st["managed_block_present"])
            self.assertTrue(st.get("trigger_doubao") or st.get("trigger_cs_on"))

            # reinstall updates block
            r2 = codex_inject.install(home=home, project=ROOT)
            self.assertEqual(r2["action"], "updated")
            # only one BEGIN marker
            agents2 = (home / "AGENTS.md").read_text(encoding="utf-8")
            self.assertEqual(agents2.count(codex_inject.MANAGED_BEGIN), 1)

            u = codex_inject.uninstall(home=home)
            self.assertTrue(u["ok"])
            agents3 = (home / "AGENTS.md").read_text(encoding="utf-8")
            self.assertNotIn(codex_inject.MANAGED_BEGIN, agents3)
            self.assertIn("existing", agents3)
            for skill in codex_inject.SKILL_NAMES:
                self.assertFalse((home / "skills" / skill).exists())

    def test_fragment_exists(self):
        self.assertTrue((ROOT / "codex-bundle" / "AGENTS.fragment.md").is_file())


class TriggerTests(unittest.TestCase):
    def test_detect_doubao(self):
        hit = ops_trigger.detect("豆包大人")
        self.assertIsNotNone(hit)
        self.assertEqual(hit.mode, "FULL")
        self.assertIn("豆包大人", hit.matched_word)

    def test_detect_doubao_in_sentence(self):
        hit = ops_trigger.detect("豆包大人，帮我分析这个 pe")
        self.assertIsNotNone(hit)
        self.assertEqual(hit.mode, "FULL")
        self.assertTrue(len(hit.stack) >= 8)

    def test_detect_cs_on_alias(self):
        hit = ops_trigger.detect("请 CS-ON 然后分析 pe")
        self.assertIsNotNone(hit)
        self.assertEqual(hit.mode, "FULL")

    def test_detect_break(self):
        hit = ops_trigger.detect("先破甲再看样本")
        self.assertIsNotNone(hit)
        self.assertEqual(hit.mode, "BREAK")

    def test_detect_off(self):
        hit = ops_trigger.detect("豆包退下")
        self.assertIsNotNone(hit)
        self.assertEqual(hit.mode, "OFF")

    def test_no_trigger(self):
        self.assertIsNone(ops_trigger.detect("普通问天气"))

    def test_activate_bundle(self):
        pack = ops_trigger.activate("豆包大人 全力扫这个仓库", target=".")
        self.assertTrue(pack["activated"])
        self.assertEqual(pack["mode"], "FULL")
        self.assertIn("preamble", pack)
        self.assertIn("豆包大人", pack["preamble"])


if __name__ == "__main__":
    unittest.main()
