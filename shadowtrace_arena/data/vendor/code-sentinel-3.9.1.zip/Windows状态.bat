@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Code Sentinel Windows 注入状态
echo ================================================
echo   Code Sentinel - Windows 注入状态
echo ================================================
echo.
python "%~dp0scripts\codex_inject.py" status
echo.
pause
