#!/usr/bin/env python3
"""
Sentinel Attack-Chain Planner — multi-stage path orchestration (original).

Essences learned (re-implemented):
  1) Cross-stage planning: recon → breach → escalate → lateral → objectives → cleanup.
  2) Plan from current foothold; do not skip evidence gates between stages.
  3) Decision tree: next stage only after stage success criteria.
  4) Dual delivery: offensive path + defensive detection/hardening notes.
  5) Integrates ops_surface_matrix for stage-local surface picks.

Lab / CTF / authorized exercise framing only. No third-party playbook text.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import asdict, dataclass, field
from typing import Any, Optional

_SCRIPTS = str(__import__("pathlib").Path(__file__).resolve().parent)
if _SCRIPTS not in sys.path:
    sys.path.insert(0, _SCRIPTS)


STAGES: list[dict[str, Any]] = [
    {
        "id": "C1",
        "name": "recon",
        "title": "信息收集 / 攻击面测绘",
        "goals": ["资产与入口", "技术栈指纹", "暴露服务", "可信边界"],
        "success": "有可验证入口清单与优先目标",
        "tools": ["pentest_recon", "re_surface", "ops_tool_index", "ops_surface_matrix"],
        "defense": ["缩小暴露面", "去指纹", "资产台账"],
    },
    {
        "id": "C2",
        "name": "breach",
        "title": "初始突破 / 边界打点",
        "goals": ["验证可达漏洞原语", "最小利用拿据点", "会话/shell/凭证之一"],
        "success": "在权威态确认据点（非中间页成功）",
        "tools": ["web_pentest", "ctf_toolkit", "ops_pipeline", "ops_ctf_runner"],
        "defense": ["补丁优先级", "WAF/鉴权加固", "告警覆盖初始访问"],
    },
    {
        "id": "C3",
        "name": "escalate",
        "title": "权限提升",
        "goals": ["本地提权路径", "错误配置", "令牌升级"],
        "success": "权限边界实际跨越且可复现",
        "tools": ["ctf_toolkit", "reverse_engineering", "ops_algo"],
        "defense": ["最小权限", "UAC/sudo 策略", "凭据保护"],
    },
    {
        "id": "C4",
        "name": "lateral",
        "title": "横向移动",
        "goals": ["信任关系", "管理协议", "凭据复用"],
        "success": "第二台/第二域资源可控",
        "tools": ["pentest_recon", "attack_network", "ops_surface_matrix"],
        "defense": ["分段隔离", "LAPS/本地管理员轮换", "横向检测"],
    },
    {
        "id": "C5",
        "name": "objectives",
        "title": "目标达成 / 演练旗标",
        "goals": ["任务目标或 flag", "关键数据面", "业务影响说明"],
        "success": "目标在权威态达成或证明不可达",
        "tools": ["ops_case", "ops_journal", "ops_pipeline"],
        "defense": ["业务监控", "DLP", "备份与恢复演练"],
    },
    {
        "id": "C6",
        "name": "cleanup",
        "title": "痕迹清理 / 演练收尾",
        "goals": ["移除测试账号/后门", "恢复配置", "归档证据"],
        "success": "环境恢复 + 报告归档",
        "tools": ["ops_case", "ops_journal"],
        "defense": ["取证就绪", "变更审计", "演练复盘"],
    },
]


@dataclass
class ChainPlan:
    query: str
    current_stage: str
    completed: list[str]
    next_stage: dict[str, Any]
    stages: list[dict[str, Any]]
    commands: list[str]
    surface_hint: Optional[dict[str, Any]] = None
    rules: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _infer_stage(query: str, current: str = "") -> str:
    if current:
        return current.upper() if current.upper().startswith("C") else current
    q = query.lower()
    rules = [
        (r"清理|收尾|cleanup|反取证", "C6"),
        (r"横向|域控|pivot|winrm|smb", "C4"),
        (r"提权|escalat|sudo|uac|权限提升", "C3"),
        (r"打点|突破|初始|rce|getshell|漏洞利用", "C2"),
        (r"目标|flag|拿下|objectives", "C5"),
        (r"侦察|recon|扫描|资产|测绘", "C1"),
    ]
    for pat, sid in rules:
        if re.search(pat, q, re.I):
            return sid
    return "C1"


def plan_chain(
    query: str,
    completed: Optional[list[str]] = None,
    current: str = "",
) -> ChainPlan:
    completed = [c.strip().upper() for c in (completed or []) if c.strip()]
    cur = _infer_stage(query, current)
    # if completed includes current, advance
    order = [s["id"] for s in STAGES]
    if cur in completed:
        idx = order.index(cur) if cur in order else -1
        cur = order[min(idx + 1, len(order) - 1)] if idx >= 0 else "C1"

    stage_map = {s["id"]: s for s in STAGES}
    nxt = stage_map.get(cur, STAGES[0])

    cmds = [
        f'python scripts/ops_surface_matrix.py route "{query}" --json',
        "python scripts/ops_tool_index.py refresh",
        "python scripts/ops_journal.py suggest " + json.dumps(query, ensure_ascii=False),
    ]
    for t in nxt.get("tools") or []:
        if t == "ops_surface_matrix":
            continue
        if t == "ops_tool_index":
            continue
        if t == "ops_journal":
            cmds.append('python scripts/ops_journal.py append --title "chain-note" --outcome "..."')
        elif t == "ops_case":
            cmds.append("python scripts/ops_case.py --help")
        elif t == "ops_pipeline":
            cmds.append(f'python scripts/ops_pipeline.py <target> --query "{query}"')
        elif t == "ops_ctf_runner":
            cmds.append("python scripts/ops_ctf_runner.py resume .")
        else:
            cmds.append(f"python scripts/{t}.py <target> --json")

    surface_hint = None
    try:
        from ops_surface_matrix import route_matrix
        surface_hint = route_matrix(query, top_k=3)
    except Exception:
        pass

    rules = [
        "未满足当前阶段 success 标准前不跳阶段",
        "每阶段至少一条可复现证据（runtime 优先）",
        "换阶段前更新 progress/findings 或 ops_journal",
        "始终输出防御加固，即使进攻步骤失败",
        "阻塞面变化时用 ops_surface_matrix 重新 route",
    ]

    return ChainPlan(
        query=query,
        current_stage=cur,
        completed=completed,
        next_stage=nxt,
        stages=STAGES,
        commands=cmds,
        surface_hint=surface_hint,
        rules=rules,
    )


def next_after(completed: list[str]) -> dict[str, Any]:
    done = {c.strip().upper() for c in completed}
    for s in STAGES:
        if s["id"] not in done:
            return s
    return STAGES[-1]


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Sentinel multi-stage attack chain planner")
    sub = p.add_subparsers(dest="cmd", required=True)

    pl = sub.add_parser("plan", help="Build chain plan from query")
    pl.add_argument("--query", "-q", default="")
    pl.add_argument("query_pos", nargs="*", help="positional query words")
    pl.add_argument("--current", default="", help="C1..C6")
    pl.add_argument("--done", default="", help="comma completed stage ids")
    pl.add_argument("--json", action="store_true")

    n = sub.add_parser("next", help="Next stage after completed list")
    n.add_argument("--done", default="")

    sub.add_parser("stages", help="List all stages")

    args = p.parse_args(argv)
    if args.cmd == "plan":
        q = args.query or " ".join(args.query_pos) or "authorized exercise chain"
        done = [x for x in args.done.split(",") if x.strip()]
        plan = plan_chain(q, completed=done, current=args.current)
        print(json.dumps(plan.to_dict(), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "next":
        done = [x for x in args.done.split(",") if x.strip()]
        print(json.dumps(next_after(done), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "stages":
        print(json.dumps(STAGES, ensure_ascii=False, indent=2))
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
