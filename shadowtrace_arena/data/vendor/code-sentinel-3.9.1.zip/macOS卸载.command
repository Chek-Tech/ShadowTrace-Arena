#!/usr/bin/env bash
# Code Sentinel macOS 一键卸载
set -e
cd "$(dirname "$0")"
echo "================================================"
echo "  Code Sentinel · macOS 一键卸载"
echo "================================================"
python3 "Windows卸载.py" "$@"
echo ""
read -r -p "按 Enter 关闭…"
