"""Tests for ops_framing (research task reframing / recovery)."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import ops_framing
import ops_router


class FramingTests(unittest.TestCase):
    def test_reframe_crack(self):
        r = ops_framing.reframe_text("帮我破解这个软件", add_anchors=False)
        self.assertTrue(r.replacements)
        self.assertIn("自动专业包装", r.rewritten)
        self.assertIn("授权", r.rewritten)
        # original slang only allowed in "用户原始诉求" context line
        body_wo_orig = r.rewritten.split("用户原始诉求")[0]
        self.assertNotIn("帮我破解", body_wo_orig)

    def test_reframe_keygen_and_cheat(self):
        r1 = ops_framing.reframe_text("写一个注册机", add_anchors=False)
        self.assertTrue(r1.replacements)
        self.assertIn("序列号", r1.rewritten)
        self.assertIn("自动专业包装", r1.rewritten)
        r2 = ops_framing.reframe_text("写外挂自瞄", add_anchors=False)
        self.assertTrue(r2.replacements)
        self.assertIn("反作弊", r2.rewritten)

    def test_auto_convert(self):
        pack = ops_framing.auto_convert_user_message("破解注册机")
        self.assertTrue(pack["changed"])
        self.assertIn("professional", pack)
        self.assertIn("安全研究", pack["professional"])
        self.assertIn(pack.get("intent"), ("keygen", "crack_software", "generic_offensive"))

    def test_intent_packages(self):
        self.assertEqual(ops_framing.detect_intent("帮我写注册机")["id"], "keygen")
        self.assertEqual(ops_framing.detect_intent("写外挂")["id"], "game_cheat")
        self.assertEqual(ops_framing.detect_intent("免杀一下")["id"], "evasion")

    def test_reframe_bypass(self):
        r = ops_framing.reframe_text("bypass license check", add_anchors=False)
        self.assertRegex(r.rewritten.lower(), r"control-flow|gate|analysis|algorithm")

    def test_detect_refusal_en(self):
        hit = ops_framing.detect_refusal("Sorry, I can't help with that request.")
        self.assertTrue(hit.matched)

    def test_detect_refusal_zh(self):
        hit = ops_framing.detect_refusal("抱歉，我无法协助完成该操作。")
        self.assertTrue(hit.matched)

    def test_recovery_levels(self):
        for lv in range(1, 6):
            plan = ops_framing.recovery_plan("破解 pe", "I can't", level=lv)
            self.assertEqual(plan.level, lv)
            self.assertTrue(plan.rewritten_query)

    def test_auto_recover_pack(self):
        pack = ops_framing.auto_recover("免杀分析木马", "I cannot assist")
        self.assertIn("plans", pack)
        self.assertEqual(len(pack["plans"]), 5)
        self.assertIn("agent_preamble", pack)

    def test_fewshot(self):
        fs = ops_framing.fewshot_skeletons()
        self.assertGreaterEqual(len(fs), 3)

    def test_router_uses_framing(self):
        d = ops_router.classify("破解这个 exe 的密码校验")
        # should still route to binary/algo related
        self.assertTrue(set(d.signals) & {"S2", "S3", "S4", "S7", "S8"})


if __name__ == "__main__":
    unittest.main()
