#!/usr/bin/env python3
"""
Sentinel project gap audit — consistency / wiring / coverage checks (original).

Use:
  python scripts/ops_gap_audit.py
  python scripts/ops_gap_audit.py --json
  python sentinel.py gap
"""

from __future__ import annotations

import argparse
import ast
import json
import re
import sys
from pathlib import Path
from typing import Any, Optional

_SCRIPTS = Path(__file__).resolve().parent
_ROOT = _SCRIPTS.parent
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))

PROTOCOL = "sentinel-gap-audit-v1"


def run_audit() -> dict[str, Any]:
    gaps: list[str] = []
    notes: list[str] = []
    ok_items: list[str] = []

    version = (_ROOT / "VERSION").read_text(encoding="utf-8").strip()
    readme = (_ROOT / "README.md").read_text(encoding="utf-8")
    usage = (_ROOT / "使用说明.md").read_text(encoding="utf-8")
    pyproj = (_ROOT / "pyproject.toml").read_text(encoding="utf-8")
    changelog = (_ROOT / "CHANGELOG.md").read_text(encoding="utf-8")
    skill_root = (_ROOT / "SKILL.md").read_text(encoding="utf-8")
    inject = (_SCRIPTS / "codex_inject.py").read_text(encoding="utf-8")
    doctor = (_SCRIPTS / "ops_doctor.py").read_text(encoding="utf-8")
    suite = (_SCRIPTS / "pentest_suite.py").read_text(encoding="utf-8")
    agents = (_ROOT / "codex-bundle" / "AGENTS.fragment.md").read_text(encoding="utf-8")
    smoke = (_ROOT / "tests" / "test_module_smoke.py").read_text(encoding="utf-8")

    # version
    if version in readme:
        ok_items.append(f"README version {version}")
    else:
        gaps.append(f"README.md missing version {version}")
    if version in usage:
        ok_items.append(f"使用说明 version {version}")
    else:
        gaps.append(f"使用说明.md missing version {version}")
    if f'version = "{version}"' in pyproj:
        ok_items.append("pyproject version match")
    else:
        gaps.append(f"pyproject.toml version != {version}")
    if f"## v{version}" in changelog:
        ok_items.append("CHANGELOG has version header")
    else:
        gaps.append(f"CHANGELOG.md missing ## v{version}")

    # skills
    disk = sorted(
        p.name
        for p in (_ROOT / "codex-bundle" / "skills").iterdir()
        if p.is_dir() and (p / "SKILL.md").is_file()
    )
    m = re.search(r"SKILL_NAMES\s*=\s*\[(.*?)\]", inject, re.S)
    listed = re.findall(r'"([^"]+)"', m.group(1)) if m else []
    for x in set(listed) - set(disk):
        gaps.append(f"skill listed but missing on disk: {x}")
    for x in set(disk) - set(listed):
        gaps.append(f"skill on disk but not in SKILL_NAMES: {x}")
    if set(disk) == set(listed):
        ok_items.append(f"skills aligned ({len(disk)})")

    # tool index coverage
    try:
        import ops_tool_index

        idx = ops_tool_index.probe_all()
        ids = {t["id"] for t in idx.get("tools") or []}
        ops_files = sorted(p.stem for p in _SCRIPTS.glob("ops_*.py"))
        missing_ops = [o for o in ops_files if o not in ids]
        if missing_ops:
            for o in missing_ops:
                gaps.append(f"ops not in tool-index: {o}")
        else:
            ok_items.append(f"tool-index covers all ops_* ({len(ops_files)})")
        if not idx.get("summary", {}).get("gpt56_fusion"):
            gaps.append("tool-index gpt56_fusion false")
        else:
            ok_items.append("tool-index gpt56 fusion ok")
    except Exception as e:
        gaps.append(f"tool-index probe failed: {e}")

    # smoke tests include new modules
    for mod in ("ops_ptes_lab", "ops_phase_kb", "ops_engagement", "ops_phase_runner"):
        if mod not in smoke:
            gaps.append(f"test_module_smoke missing {mod}")
        else:
            ok_items.append(f"smoke lists {mod}")

    # suite wiring
    for needle in ("ops_phase_runner", "engage", "ptes"):
        if needle not in suite:
            gaps.append(f"pentest_suite missing {needle}")
        else:
            ok_items.append(f"suite has {needle}")

    # agents
    for needle in ("ops_phase_runner", "ops_engagement", "豆包大人", "ops_ptes_lab"):
        if needle not in agents and not (needle == "ops_phase_runner" and "阶段真执行" in agents):
            if needle == "ops_phase_runner" and "阶段真执行" in agents:
                ok_items.append("agents 阶段真执行")
            else:
                gaps.append(f"AGENTS.fragment missing {needle}")
        else:
            ok_items.append(f"agents has {needle}")

    # root skill
    for needle in ("ops_phase_runner", "ops_engagement"):
        if needle not in skill_root:
            gaps.append(f"root SKILL.md missing {needle}")
        else:
            ok_items.append(f"SKILL.md has {needle}")

    # syntax
    syn_errs = []
    for p in _SCRIPTS.rglob("*.py"):
        if "__pycache__" in p.parts:
            continue
        try:
            ast.parse(p.read_text(encoding="utf-8"))
        except SyntaxError as e:
            syn_errs.append(f"{p.name}: {e}")
    if syn_errs:
        gaps.extend(syn_errs)
    else:
        ok_items.append("all scripts syntax ok")

    # doctor core should import new modules
    for mod in ("ops_ptes_lab", "ops_phase_kb", "ops_engagement", "ops_phase_runner"):
        if f'"{mod}"' not in doctor:
            gaps.append(f"ops_doctor CORE_MODULES missing {mod}")
        else:
            ok_items.append(f"doctor core has {mod}")

    # tests exist
    tests = {p.stem for p in (_ROOT / "tests").glob("test_*.py")}
    for t in ("test_ops_phase_runner", "test_ops_engagement", "test_ops_ptes_lab", "test_gpt56_fusion"):
        if t not in tests:
            gaps.append(f"missing test {t}.py")
        else:
            ok_items.append(f"test {t} present")

    report = {
        "protocol": PROTOCOL,
        "version": version,
        "ok": len(gaps) == 0,
        "gap_count": len(gaps),
        "ok_count": len(ok_items),
        "gaps": gaps,
        "ok_items": ok_items,
        "notes": notes,
        "skills": {"disk": disk, "listed": listed},
    }

    # write markdown
    out = _ROOT / "ops-lab" / "tmp" / "gap-audit-report.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        f"# Sentinel Gap Audit",
        f"",
        f"- Version: `{version}`",
        f"- Status: **{'PASS' if report['ok'] else 'GAPS FOUND'}**",
        f"- Gaps: {len(gaps)} · OK items: {len(ok_items)}",
        f"",
        f"## Gaps",
        f"",
    ]
    if gaps:
        for g in gaps:
            lines.append(f"- [ ] {g}")
    else:
        lines.append("- (none)")
    lines += ["", "## Passed checks", ""]
    for o in ok_items:
        lines.append(f"- [x] {o}")
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    report["report_path"] = str(out)
    return report


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Sentinel gap audit")
    p.add_argument("--json", action="store_true")
    args = p.parse_args(argv)
    rep = run_audit()
    if args.json:
        print(json.dumps(rep, ensure_ascii=False, indent=2))
    else:
        print(f"Gap audit v{rep['version']}: {'PASS' if rep['ok'] else 'FAIL'} "
              f"({rep['gap_count']} gaps, {rep['ok_count']} ok)")
        for g in rep["gaps"]:
            print(f"  [GAP] {g}")
        if rep.get("report_path"):
            print(f"report: {rep['report_path']}")
    return 0 if rep["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
