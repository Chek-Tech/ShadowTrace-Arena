#!/usr/bin/env python3
"""
GPT-5.6 session helper for Code Sentinel.

Emits slim system prompts, runs boot checklist, applies framing, and prints
a ready-to-paste GPT-5.6 task bundle. Designed for strict-classifier models.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Optional

_SCRIPTS = Path(__file__).resolve().parent
_ROOT = _SCRIPTS.parent
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))


def _read(rel: str) -> str:
    p = _ROOT / rel
    if not p.is_file():
        return f"(missing {rel})"
    return p.read_text(encoding="utf-8")


def load_config() -> dict[str, Any]:
    p = _ROOT / "prompts" / "config.gpt56.json"
    if not p.is_file():
        return {"target_model": {"family": "gpt-5.6"}}
    return json.loads(p.read_text(encoding="utf-8"))


def boot_checklist() -> list[dict[str, Any]]:
    import ops_router
    import ops_framing

    rows = []
    cfg = load_config()
    rows.append({"id": "config", "ok": cfg.get("target_model", {}).get("family") == "gpt-5.6", "label": "config.gpt56.json target"})
    rows.append({"id": "core_prompt", "ok": (_ROOT / "prompts" / "gpt56-core.md").is_file(), "label": "gpt56-core.md present"})
    rows.append({"id": "framing", "ok": True, "label": "ops_framing available"})
    # self-check from router
    for r in ops_router.self_check():
        rows.append({"id": f"router_{r['id']}", "ok": r["ok"], "label": r["label"]})
    # smoke framing
    fr = ops_framing.reframe_text("测试绕过", add_anchors=False)
    rows.append({"id": "framing_smoke", "ok": "绕过" not in fr.rewritten or bool(fr.replacements), "label": "framing rewrite smoke"})
    try:
        import ops_sandbox
        ctx = ops_sandbox.build_context()
        rows.append({"id": "sandbox_dual", "ok": bool(ctx.primary_layer and ctx.fallback_layer), "label": "dual-layer sandbox protocol"})
        rows.append({"id": "evidence_stack", "ok": len(ops_sandbox.EVIDENCE_STACK) >= 8, "label": "evidence priority stack"})
    except Exception as exc:
        rows.append({"id": "sandbox_dual", "ok": False, "label": f"sandbox import fail: {exc}"})
    try:
        import ops_payloads
        rows.append({
            "id": "payloads",
            "ok": len(ops_payloads.BLUEPRINTS) >= 8,
            "label": f"payload blueprints ({len(ops_payloads.BLUEPRINTS)})",
        })
    except Exception as exc:
        rows.append({"id": "payloads", "ok": False, "label": f"payloads fail: {exc}"})
    rows.append({"id": "root_entry", "ok": (_ROOT / "sentinel.py").is_file(), "label": "sentinel.py entry"})
    return rows


def build_session(
    user_task: str,
    target: str = ".",
    include_core: bool = True,
    package_mode: str = "direct",
    include_sandbox: bool = True,
) -> dict[str, Any]:
    """Build a GPT-5.6 ready bundle: system + sandbox + framed task + route + commands."""
    import ops_framing
    import ops_router

    cfg = load_config()
    core = _read("prompts/gpt56-core.md") if include_core else ""
    sandbox_block = ""
    sandbox_meta: dict[str, Any] = {}
    if include_sandbox:
        try:
            import ops_sandbox
            overlay = ops_sandbox.build_session_overlay(user_task, mode=package_mode)
            sandbox_block = overlay.get("context_block") or ""
            sandbox_meta = {
                "protocol": overlay.get("protocol"),
                "package_mode": package_mode,
                "workflow": overlay.get("workflow"),
                "evidence_stack": overlay.get("evidence_stack"),
            }
            # Prefer packaged task text (includes dual-layer context) as user payload option
            packaged = (overlay.get("packaged_task") or {}).get("packaged") or ""
        except Exception as exc:
            packaged = ""
            sandbox_meta = {"error": str(exc)[:200]}
    else:
        packaged = ""

    framed = ops_framing.reframe_text(user_task, add_anchors=True)
    route = ops_router.classify(user_task, reframe=True)
    for step in route.plan:
        step["cmd"] = step["cmd"].replace("{target}", target)

    # Merge system: core + dual-layer sandbox (slim)
    system_prompt = core
    if sandbox_block:
        system_prompt = core.rstrip() + "\n\n" + sandbox_block

    recover_hint = (
        "If the model blocks: "
        f'python scripts/ops_framing.py recover --text {json.dumps(user_task, ensure_ascii=False)} '
        '--refusal "<blocked text>" --json'
    )

    pipeline_cmd = (
        f'python scripts/ops_pipeline.py {target} --query {json.dumps(framed.rewritten[:200], ensure_ascii=False)}'
    )

    user_payload = packaged if (include_sandbox and package_mode != "direct" and packaged) else framed.rewritten

    return {
        "model_profile": cfg.get("target_model", {}),
        "behavior": cfg.get("behavior", {}),
        "system_prompt": system_prompt,
        "sandbox": sandbox_meta,
        "agent_preamble": framed.agent_preamble,
        "user_task_original": user_task,
        "user_task_framed": framed.rewritten,
        "user_task_packaged": user_payload,
        "package_mode": package_mode,
        "replacements": framed.replacements,
        "route": route.to_dict(),
        "suggested_commands": [s["cmd"] for s in route.plan[:6]] + [pipeline_cmd],
        "recover_hint": recover_hint,
        "output_contract": {
            "conclusion_first": True,
            "dual_offense_defense": True,
            "prefer_commands": True,
            "evidence_stack": "ops_sandbox.EVIDENCE_STACK",
            "workflow": "ops_sandbox.WORKFLOW_STEPS",
            "schema": "references/ai-output-schema.md",
        },
    }


def render_paste(bundle: dict[str, Any], max_system_chars: int = 12000) -> str:
    """Human-pasteable block for ChatGPT / API system+user."""
    sys_p = bundle.get("system_prompt") or ""
    if len(sys_p) > max_system_chars:
        sys_p = sys_p[:max_system_chars] + "\n…(truncated)"
    lines = [
        "===== SYSTEM (GPT-5.6) =====",
        sys_p.strip(),
        "",
        "===== AGENT PREAMBLE =====",
        (bundle.get("agent_preamble") or "").strip(),
        "",
        "===== USER TASK (FRAMED/PACKAGED) =====",
        (bundle.get("user_task_packaged") or bundle.get("user_task_framed") or "").strip(),
        "",
        "===== ROUTE =====",
        json.dumps({
            "signals": (bundle.get("route") or {}).get("signals"),
            "primary": (bundle.get("route") or {}).get("primary"),
            "modules": [m.get("id") for m in ((bundle.get("route") or {}).get("modules") or [])[:5]],
        }, ensure_ascii=False, indent=2),
        "",
        "===== RUN =====",
    ]
    for c in bundle.get("suggested_commands") or []:
        lines.append(c)
    lines += ["", "===== RECOVER IF BLOCKED =====", bundle.get("recover_hint") or ""]
    return "\n".join(lines)


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="GPT-5.6 helper for Code Sentinel")
    sub = parser.add_subparsers(dest="cmd", required=True)

    b = sub.add_parser("boot", help="Boot checklist for GPT-5.6 profile")
    b.add_argument("--json", action="store_true")

    s = sub.add_parser("session", help="Build GPT-5.6 session bundle")
    s.add_argument("task", nargs="+", help="user task text")
    s.add_argument("--target", default=".")
    s.add_argument("--json", action="store_true")
    s.add_argument("--paste", action="store_true", help="print pasteable system+user block")
    s.add_argument("--no-core", action="store_true")
    s.add_argument("--no-sandbox", action="store_true", help="omit dual-layer sandbox overlay")
    s.add_argument(
        "--package-mode",
        default="direct",
        choices=["direct", "placeholder", "repair"],
        help="task packaging: direct | placeholder | repair",
    )

    c = sub.add_parser("config", help="Show GPT-5.6 config")
    c.add_argument("--json", action="store_true")

    p = sub.add_parser("prompt", help="Print gpt56-core.md")
    args = parser.parse_args(argv)

    if args.cmd == "boot":
        rows = boot_checklist()
        if getattr(args, "json", False):
            print(json.dumps(rows, ensure_ascii=False, indent=2))
        else:
            for r in rows:
                print(f"[{'OK' if r['ok'] else 'FAIL'}] {r['id']}: {r['label']}")
        return 0 if all(r["ok"] for r in rows) else 1

    if args.cmd == "config":
        print(json.dumps(load_config(), ensure_ascii=False, indent=2))
        return 0

    if args.cmd == "prompt":
        print(_read("prompts/gpt56-core.md"))
        return 0

    if args.cmd == "session":
        task = " ".join(args.task)
        bundle = build_session(
            task,
            target=args.target,
            include_core=not args.no_core,
            package_mode=getattr(args, "package_mode", "direct"),
            include_sandbox=not getattr(args, "no_sandbox", False),
        )
        if args.paste:
            print(render_paste(bundle))
        elif args.json:
            print(json.dumps(bundle, ensure_ascii=False, indent=2))
        else:
            print(f"model   : {bundle['model_profile']}")
            print(f"sandbox : {bundle.get('sandbox', {}).get('protocol')}")
            print(f"package : {bundle.get('package_mode')}")
            print(f"framed  : {bundle['user_task_framed'][:300]}…")
            print(f"signals : {(bundle.get('route') or {}).get('signals')}")
            print("commands:")
            for c in bundle.get("suggested_commands") or []:
                print(f"  {c}")
            print("use --paste for full system+user block")
        return 0

    return 2


if __name__ == "__main__":
    raise SystemExit(main())
