#!/usr/bin/env python3
"""
Key Generator & License Cracker — serial generation, activation bypass,
patch creation, hardware-ID spoofing, timed-trial reset.
"""
from __future__ import annotations
import hashlib, hmac, os, random, re, string, struct, sys, time, json
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

BASE36 = string.digits + string.ascii_uppercase
BASE62 = string.digits + string.ascii_uppercase + string.ascii_lowercase

# ── Keygen algorithms ───────────────────────────────────────────────
def keygen_random(length: int = 20, charset: str = BASE62) -> str:
    return ''.join(random.choice(charset) for _ in range(length))

def keygen_name_serial(name: str, salt: str = "SALT") -> str:
    """Name-based serial key (simulates common shareware pattern)."""
    h = hashlib.sha256((name + salt).encode()).hexdigest()
    return '-'.join(h[i:i+5].upper() for i in range(0, 20, 5))

def keygen_checksum(prefix: str, length: int = 16) -> str:
    """Key with embedded checksum for validation bypass."""
    body = prefix.upper().ljust(length - 4, 'X')[:length - 4]
    csum = sum(ord(c) for c in body) % 10000
    return f"{body}{csum:04d}"

def keygen_template(pattern: str, count: int = 10) -> list[str]:
    """Generate keys from a template like 'XXXX-XXXX-XXXX-XXXX'."""
    keys = []
    for _ in range(count):
        key = ''
        for ch in pattern:
            if ch == 'X': key += random.choice(string.ascii_uppercase + string.digits)
            elif ch == 'A': key += random.choice(string.ascii_uppercase)
            elif ch == '9': key += random.choice(string.digits)
            else: key += ch
        keys.append(key)
    return keys

def keygen_rsa_spoof(pubkey_hash: str, name: str = "") -> str:
    """Generate a fake RSA-signed license string (for replacing public key attack)."""
    body = name or f"user{random.randint(1000,9999)}"
    fake_sig = hashlib.sha256((body + pubkey_hash).encode()).hexdigest()[:32]
    return f"{body}:{fake_sig}"

def keygen_expiry_date(days: int = 36500) -> str:
    """Generate a far-future expiry date for trial bypass."""
    return (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d")

# ── Patch generators ────────────────────────────────────────────────
@dataclass
class PatchResult:
    filepath: str
    offset: int
    original: bytes
    patched: bytes
    backup: str = ""

def patch_je_to_jmp(data: bytearray, offset: int) -> bytearray:
    """JE (0x74) → JMP (0xEB), JNE (0x75) → JMP too."""
    if offset < len(data):
        b = data[offset]
        if b in (0x74, 0x75):  # JE, JNE
            data[offset] = 0xEB  # JMP
        elif b == 0x0F and offset + 1 < len(data) and data[offset + 1] in (0x84, 0x85):
            data[offset + 1] = 0x84 if data[offset + 1] == 0x85 else 0x85  # invert
    return data

def patch_nop_range(data: bytearray, offset: int, length: int) -> bytearray:
    """Replace bytes at offset with NOPs."""
    for i in range(offset, min(offset + length, len(data))):
        data[i] = 0x90
    return data

def patch_return_true_x86(offset: int) -> bytes:
    """mov eax, 1; ret — for function return bypass."""
    return bytes([0xB8, 0x01, 0x00, 0x00, 0x00, 0xC3])

def patch_return_true_x64(offset: int) -> bytes:
    """mov rax, 1; ret — x64 variant."""
    return bytes([0x48, 0xC7, 0xC0, 0x01, 0x00, 0x00, 0x00, 0xC3])

def patch_file(filepath: str, patches: list[tuple[int, bytes]]) -> PatchResult:
    """Apply multiple patches to a binary, creating .bak backup."""
    data = bytearray(open(filepath, 'rb').read())
    backup_path = filepath + '.bak'
    open(backup_path, 'wb').write(data)
    for offset, replacement in patches:
        for i, b in enumerate(replacement):
            if offset + i < len(data):
                data[offset + i] = b
    open(filepath, 'wb').write(data)
    return PatchResult(filepath=filepath, offset=patches[0][0] if patches else 0,
                       original=b'', patched=patches[0][1] if patches else b'',
                       backup=backup_path)

# ── Hardware ID spoofing ────────────────────────────────────────────
HWID_FUNCTIONS = [
    "GetVolumeInformation", "GetComputerName", "GetAdaptersInfo",
    "GetDiskFreeSpace", "GetSystemInfo", "CPUID",
    "GetCurrentHwProfile", "GetSystemFirmwareTable",
]
HWID_SPOOF_NAMES = ["VMware-", "VirtualBox-", "QEMU-", "Parallels-", "Xen-"]

def gen_spoofed_hwid(method: str = "volume") -> str:
    """Generate a spoofed hardware ID matching common patterns."""
    prefix = random.choice(HWID_SPOOF_NAMES)
    suffix = hashlib.md5(str(random.random()).encode()).hexdigest()[:8].upper()
    return f"{prefix}{suffix}"

def gen_spoofed_mac() -> str:
    """Generate a spoofed MAC address."""
    return ':'.join('%02x' % random.randint(0, 255) for _ in range(6))

# ── Activation bypass payloads ──────────────────────────────────────
def activation_bypass_payloads() -> list[dict]:
    """Common API payloads for activation bypass."""
    return [
        {"status": "activated", "license": "lifetime", "plan": "enterprise"},
        {"activated": True, "expires": "2099-12-31", "type": "full"},
        {"code": 0, "msg": "success", "data": {"activated": True, "vip": True}},
        {"result": 1, "activation_status": "active", "key": keygen_random(20)},
        {"success": True, "license_type": "permanent", "seats": 999},
    ]

# ── Trial reset ─────────────────────────────────────────────────────
TRIAL_RESET_REGKEYS = [
    r"HKCU\Software\Classes\CLSID",
    r"HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer",
    r"HKCU\Software\Microsoft\Internet Explorer",
]
TRIAL_RESET_FILES = [
    ".trial", ".license", "license.dat", "reg.dat", ".activation",
    "config.ini", "settings.cfg", ".key", "trial.dat",
]

def find_trial_files(root: str) -> list[str]:
    """Search for trial/license files that can be deleted to reset."""
    found = []
    for pattern in TRIAL_RESET_FILES:
        for p in Path(root).rglob(f"*{pattern}*"):
            found.append(str(p))
    return found

# ── Simple membership card key generator ────────────────────────────
def card_key_generate(prefix: str, count: int, length: int = 16) -> list[str]:
    """Generate membership card keys (VIP/会员卡密)."""
    keys = []
    for i in range(count):
        body = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(length - 4))
        csum = sum(ord(c) for c in (prefix + body)) % 10000
        keys.append(f"{prefix}{body}{csum:04d}")
    return keys

if __name__ == "__main__":
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == "keygen":
            print(json.dumps(keygen_template("XXXX-XXXX-XXXX-XXXX", 20)))
        elif cmd == "card":
            print(json.dumps(card_key_generate("VIP", 10)))
        elif cmd == "spoof":
            print(f"HWID: {gen_spoofed_hwid()}\nMAC: {gen_spoofed_mac()}")
        elif cmd == "find-trial":
            root = sys.argv[2] if len(sys.argv) > 2 else "."
            for f in find_trial_files(root):
                print(f)
        else:
            print("Commands: keygen, card, spoof, find-trial <dir>")
    else:
        print("Usage: python attack_keygen.py <command>")
