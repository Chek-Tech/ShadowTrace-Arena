# Contributing to Code Sentinel

## Development Setup

```bash
git clone https://github.com/user/code-sentinel.git
cd code-sentinel
# No pip install needed — zero dependencies
```

## Running Tests

```bash
python -m unittest discover -s tests -p "test_*.py"
```

## Self-Audit

```bash
python scripts/sentinel_scan.py . --fail-on HIGH
```

## Adding Rules

1. For standard source security rules: add to `rules_builtin.py`
2. For reverse engineering/malware rules: add to `rules_reverse.py`
3. Rules must include: id, title, severity, category, pattern, remediation
4. Wrap patterns with `_rx()` for case-insensitive matching
5. Add tests in `tests/test_rules.py`

## Adding Scanner Features

1. New scan modes go in `sentinel_scan.py`
2. New auditors go in `scripts/auditors/`
3. All modules must use stdlib only — zero external dependencies
4. Add tests in `tests/`

## Pull Requests

- Keep changes focused and minimal
- Include tests for new behavior
- Run the full test suite before submitting
- Self-audit the scanner on itself
