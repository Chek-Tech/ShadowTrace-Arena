#!/usr/bin/env python3
"""
Sentinel Ops Pipeline — full-depth multi-stage analysis (original).

Stages:
  TRIAGE → STATIC → DYNAMIC → ALGORITHM → SYNTHESIS → REPORT

Integrates: router, modules, patterns, deep triage, algo recovery, fallbacks.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
import traceback
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional

_SCRIPTS = Path(__file__).resolve().parent
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))

import ops_router


@dataclass
class StageResult:
    name: str
    ok: bool
    elapsed_ms: float = 0.0
    data: dict[str, Any] = field(default_factory=dict)
    error: str = ""
    fallbacks_used: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class PipelineResult:
    target: str
    query: str
    started_at: str
    route: dict[str, Any] = field(default_factory=dict)
    stages: list[StageResult] = field(default_factory=list)
    synthesis: dict[str, Any] = field(default_factory=dict)
    report_path: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "target": self.target,
            "query": self.query,
            "started_at": self.started_at,
            "route": self.route,
            "stages": [s.to_dict() for s in self.stages],
            "synthesis": self.synthesis,
            "report_path": self.report_path,
        }


def _run_stage(name: str, fn: Callable[[], dict[str, Any]]) -> StageResult:
    t0 = time.perf_counter()
    try:
        data = fn() or {}
        return StageResult(name=name, ok=True, elapsed_ms=(time.perf_counter() - t0) * 1000, data=data)
    except Exception as exc:
        return StageResult(
            name=name,
            ok=False,
            elapsed_ms=(time.perf_counter() - t0) * 1000,
            error=f"{type(exc).__name__}: {exc}",
            data={"trace": traceback.format_exc()[-800:]},
        )


def stage_triage(target: str, query: str) -> dict[str, Any]:
    import ops_triage
    import ops_modules
    import ops_patterns

    fp = ops_triage.triage_path(target)
    route = ops_router.classify(f"{query} {target}")
    # merge fingerprint modules into route
    mods = ops_modules.select_modules(
        query=query,
        target=target,
        signals=route.signals,
        limit=6,
    )
    # prefer fingerprint recommendations when file target
    if fp.recommended_modules:
        ranked = []
        for mid in fp.recommended_modules:
            m = ops_modules.get_module(mid)
            if m:
                m = dict(m)
                m["score"] = m.get("score", 2.0)
                ranked.append(m)
        # merge unique
        seen = {m["id"] for m in ranked}
        for m in mods:
            if m["id"] not in seen:
                ranked.append(m)
        mods = ranked[:6]

    patterns = ops_patterns.select_patterns(
        route.signals,
        packed=bool(fp.packed_hint),
        mobile=fp.format in {"DEX", "ZIP/APK/JAR/DOCX"} or target.lower().endswith((".apk", ".ipa", ".dex")),
    )
    route_dict = route.to_dict()
    route_dict["modules"] = mods
    route_dict["patterns"] = patterns
    out = {
        "fingerprint": fp.to_dict(),
        "route": route_dict,
        "self_check": ops_router.self_check(),
        "knowledge_sections": __import__("ops_knowledge").REPORT_SECTIONS,
    }
    try:
        import ops_sandbox
        out["evidence_stack"] = ops_sandbox.EVIDENCE_STACK
        out["workflow_next"] = ops_sandbox.next_workflow_step([])
        out["sandbox_protocol"] = "sentinel-dual-layer-sandbox-v1"
    except Exception:
        pass
    return out


def stage_static(target: str, route: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {"fallbacks": []}
    signals = route.get("signals") or []
    p = Path(target)

    if "S1" in signals and (p.is_dir() or p.suffix.lower() in {".py", ".js", ".ts", ".go", ".java", ".rs"}):
        try:
            import sentinel_scan
            root = p if p.is_dir() else p.parent
            report = sentinel_scan.scan_project(root)
            summary = report.summary.to_dict()
            out["sentinel_scan"] = {
                "status": summary.get("status"),
                "findings": len(report.findings or []),
                "score": summary.get("score"),
                "counts": summary.get("counts"),
            }
        except Exception as exc:
            out["sentinel_scan_error"] = str(exc)[:200]
            import ops_fallback
            out["fallbacks"].append(ops_fallback.run_fallback("sentinel_scan", str(target), execute=False).to_dict())

    if any(s in signals for s in ("S2", "S3", "S4", "S7", "S8")) and p.is_file():
        try:
            import reverse_engineering as re_mod
            rev = re_mod.analyze_binary(p)
            out["reverse"] = {
                "kind": rev.format.kind,
                "imphash": rev.format.imphash,
                "packed": rev.is_packed,
                "packers": rev.packers,
                "capabilities": list((rev.capability_map or {}).keys()),
                "sha256": rev.sha256,
                "overlay": rev.format.overlay_size,
                "imports": len(rev.format.import_functions or []),
                "software_identity": rev.software_identity,
                "network_surface": {
                    "urls": (rev.network_surface or {}).get("urls", [])[:20],
                    "domains": (rev.network_surface or {}).get("domains", [])[:20],
                    "cloud_hits": (rev.network_surface or {}).get("cloud_hits", []),
                    "pdb_paths": (rev.network_surface or {}).get("pdb_paths", [])[:5],
                },
                "rich_header": rev.rich_header,
            }
        except Exception as exc:
            out["reverse_error"] = str(exc)[:200]
            import ops_fallback
            fb = ops_fallback.run_fallback("reverse_engineering", str(p), execute=True)
            out["fallbacks"].append(fb.to_dict())

        try:
            import malware_analysis as ma
            mal = ma.triage_binary(p)
            out["malware"] = {
                "verdict": mal.overall_verdict,
                "confidence": mal.confidence,
                "scores": {
                    "ransomware": round(mal.ransomware_score, 3),
                    "rat": round(mal.rat_score, 3),
                    "miner": round(mal.miner_score, 3),
                    "trojan": round(mal.trojan_score, 3),
                },
                "family": mal.malware_family_hints[:8],
                "persistence": mal.persistence_methods[:8],
                "injection": mal.injection_techniques[:8],
            }
        except Exception as exc:
            out["malware_error"] = str(exc)[:200]
            import ops_fallback
            out["fallbacks"].append(ops_fallback.run_fallback("malware_analysis", str(p), execute=False).to_dict())

    if "S4" in signals or "S7" in signals:
        try:
            import ctf_toolkit
            out["ctf"] = ctf_toolkit.triage_ctf(target, is_file=p.is_file())
        except Exception as exc:
            out["ctf_error"] = str(exc)[:200]

    # attach module playbooks selected
    out["modules"] = route.get("modules") or []
    out["patterns"] = route.get("patterns") or []
    return out


def stage_dynamic(target: str, route: dict[str, Any], enable_network: bool = True) -> dict[str, Any]:
    if not enable_network:
        return {"skipped": True, "reason": "network disabled"}
    signals = route.get("signals") or []
    out: dict[str, Any] = {"fallbacks": []}
    is_net = "://" in target or bool(
        __import__("re").search(r"\b\d{1,3}(?:\.\d{1,3}){3}\b", target)
    ) or (not Path(target).exists() and "." in target)

    if not is_net and not any(s in signals for s in ("S5", "S6")):
        return {"skipped": True, "reason": "not a network target"}

    if "S5" in signals or is_net:
        try:
            import pentest_recon
            report = pentest_recon.recon(target, ports=None, threads=60)
            out["recon"] = {
                "ips": report.resolved_ips,
                "open_ports": len(report.ports),
                "ports": report.ports[:40],
                "notes": report.notes,
                "http_status": (report.http or {}).get("status"),
                "missing_headers": (report.http or {}).get("missing_security_headers"),
                "tls_ok": (report.tls or {}).get("ok"),
            }
        except Exception as exc:
            out["recon_error"] = str(exc)[:200]
            import ops_fallback
            out["fallbacks"].append(ops_fallback.run_fallback("pentest_recon", target, execute=False).to_dict())

    if "S6" in signals or is_net:
        try:
            import web_pentest
            url = target if "://" in target else f"https://{target}"
            web = web_pentest.audit_url(url, active=True)
            out["web"] = web.to_dict()
        except Exception as exc:
            out["web_error"] = str(exc)[:200]
            import ops_fallback
            out["fallbacks"].append(ops_fallback.run_fallback("web_pentest", target, execute=False).to_dict())

    return out


def stage_algorithm(target: str, route: dict[str, Any], static: dict[str, Any]) -> dict[str, Any]:
    """Algorithm / crypto recovery stage."""
    signals = route.get("signals") or []
    out: dict[str, Any] = {}
    p = Path(target)
    want = any(s in signals for s in ("S2", "S3", "S4", "S7", "S8")) or p.is_file()
    if not want or not p.is_file():
        return {"skipped": True, "reason": "algo stage not applicable"}

    import ops_algo
    rep = ops_algo.analyze(p)
    out["algo"] = rep.to_dict()

    # write sketch under ops-lab/tmp if workspace exists
    try:
        import ops_case
        lab = ops_case.ensure_workspace()
        sketch_path = lab / "tmp" / f"decrypt_sketch_{p.name}.py"
        sketch_path.write_text(rep.decrypt_sketch, encoding="utf-8")
        out["sketch_path"] = str(sketch_path)
    except Exception:
        pass

    # crypto constants from reverse if present
    if static.get("reverse", {}).get("packers"):
        out["notes"] = out.get("notes", []) + ["packed binary — algo may sit in unpacked layer"]
    return out


def stage_synthesis(triage: dict, static: dict, dynamic: dict, algo: dict) -> dict[str, Any]:
    risks: list[str] = []
    evidence: list[str] = []
    caps: list[str] = []

    fp = triage.get("fingerprint") or {}
    if fp.get("packed_hint"):
        risks.append("packed_or_high_entropy")
        evidence.append(f"entropy={fp.get('entropy')} packers={fp.get('packer_names')}")

    rev = static.get("reverse") or {}
    if rev.get("packed"):
        risks.append("packed_binary")
    if rev.get("capabilities"):
        caps = list(rev["capabilities"])
        risks.extend([f"cap:{c}" for c in caps])
    if rev.get("overlay"):
        evidence.append(f"overlay={rev.get('overlay')}")

    mal = static.get("malware") or {}
    if mal.get("verdict") and mal["verdict"] not in {"benign", "error"}:
        risks.append(f"malware:{mal['verdict']}")

    scan = static.get("sentinel_scan") or {}
    if scan.get("findings"):
        risks.append(f"source_findings:{scan['findings']}")

    web = dynamic.get("web") or {}
    counts = web.get("counts") or {}
    for sev in ("CRITICAL", "HIGH", "MEDIUM"):
        if counts.get(sev):
            risks.append(f"web_{sev.lower()}:{counts[sev]}")

    recon = dynamic.get("recon") or {}
    if recon.get("open_ports"):
        evidence.append(f"open_ports={recon['open_ports']}")

    algo_rep = (algo or {}).get("algo") or {}
    for f in algo_rep.get("findings") or []:
        risks.append(f"crypto:{f.get('detail')}")
        evidence.append(f"crypto@{f.get('offset')}")

    severity = "INFO"
    joined = " ".join(risks).lower()
    if any(x in joined for x in ("malware:", "web_critical", "sqli", "process_injection")):
        severity = "CRITICAL"
    elif any(x in joined for x in ("web_high", "cap:process", "packed", "crypto:")):
        severity = "HIGH"
    elif risks:
        severity = "MEDIUM"

    # module defenses
    defense = [
        "完整性：代码签名 / imphash 基线 / 构建可复现",
        "输入面：参数化查询、输出编码、路径白名单",
        "网络面：最小暴露、TLS、安全响应头、分段",
        "运行时：关注跨进程写+远程线程链与异常 RWX",
        "供应链：lockfile + CI sentinel_scan --fail-on HIGH",
    ]
    for m in (static.get("modules") or triage.get("route", {}).get("modules") or [])[:3]:
        for d in (m.get("defense") or [])[:2]:
            if d not in defense:
                defense.append(d)

    return {
        "severity": severity,
        "risks": risks,
        "capabilities": caps,
        "evidence": evidence,
        "one_liner": f"综合研判 {severity}，风险点 {len(risks)} 项，模块 {len(static.get('modules') or [])}",
        "defense": defense,
        "patterns_used": [p.get("id") for p in (static.get("patterns") or [])],
        "modules_used": [m.get("id") for m in (static.get("modules") or [])],
    }


def run_pipeline(
    target: str,
    query: str = "",
    enable_network: bool = True,
    write_report: bool = True,
    out_dir: Optional[str] = None,
) -> PipelineResult:
    query = query or f"分析 {target}"
    # Soft technical reframe for routing/synthesis (keep original in notes via framed pair)
    try:
        import ops_framing
        fr = ops_framing.reframe_text(query, add_anchors=False)
        if fr.replacements:
            query = fr.rewritten
    except Exception:
        pass
    result = PipelineResult(
        target=target,
        query=query,
        started_at=datetime.now(timezone.utc).isoformat(),
    )

    t = _run_stage("TRIAGE", lambda: stage_triage(target, query))
    result.stages.append(t)
    route = (t.data.get("route") if t.ok else {}) or {}
    result.route = route

    s = _run_stage("STATIC", lambda: stage_static(target, route))
    result.stages.append(s)

    d = _run_stage("DYNAMIC", lambda: stage_dynamic(target, route, enable_network=enable_network))
    result.stages.append(d)

    a = _run_stage(
        "ALGORITHM",
        lambda: stage_algorithm(target, route, s.data if s.ok else {}),
    )
    result.stages.append(a)

    syn = _run_stage(
        "SYNTHESIS",
        lambda: stage_synthesis(
            t.data if t.ok else {},
            s.data if s.ok else {},
            d.data if d.ok else {},
            a.data if a.ok else {},
        ),
    )
    result.stages.append(syn)
    result.synthesis = syn.data if syn.ok else {"error": syn.error}

    if write_report:
        import ops_case
        path = ops_case.write_case(result, out_dir=out_dir)
        result.report_path = str(path)
        result.stages.append(StageResult(name="REPORT", ok=True, data={"path": result.report_path}))
    else:
        result.stages.append(StageResult(name="REPORT", ok=True, data={"skipped": True}))

    return result


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Sentinel Ops Pipeline (full depth)")
    parser.add_argument("target", help="文件 / 目录 / 主机 / URL")
    parser.add_argument("--query", default="", help="任务自然语言描述")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--no-network", action="store_true")
    parser.add_argument("--no-report", action="store_true")
    parser.add_argument("--out-dir", default="")
    args = parser.parse_args(argv)

    result = run_pipeline(
        args.target,
        query=args.query,
        enable_network=not args.no_network,
        write_report=not args.no_report,
        out_dir=args.out_dir or None,
    )
    if args.json:
        print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2, default=str))
    else:
        print(f"Target : {result.target}")
        print(f"Route  : {result.route.get('signals')} primary={result.route.get('primary')}")
        mods = result.route.get("modules") or []
        if mods:
            print(f"Modules: {', '.join(m.get('id','') for m in mods)}")
        pats = result.route.get("patterns") or []
        if pats:
            print(f"Patterns: {', '.join(p.get('id','') for p in pats)}")
        for st in result.stages:
            mark = "OK" if st.ok else "FAIL"
            print(f"[{mark}] {st.name:10} {st.elapsed_ms:.0f}ms  {st.error or ''}")
        syn = result.synthesis
        print(f"Verdict: {syn.get('one_liner')}  severity={syn.get('severity')}")
        if result.report_path:
            print(f"Report : {result.report_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
