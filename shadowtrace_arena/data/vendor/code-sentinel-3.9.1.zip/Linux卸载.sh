#!/usr/bin/env bash
# Code Sentinel Linux 一键卸载
set -e
cd "$(dirname "$0")"
echo "================================================"
echo "  Code Sentinel · Linux 一键卸载"
echo "================================================"
python3 "Windows卸载.py" "$@"
