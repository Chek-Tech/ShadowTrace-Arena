#!/usr/bin/env python3
"""
Sentinel Ops Fallback executor — run alternate tools when primary fails.

Chains are original mappings from analysis roles to binaries discovered via
PATH / tool_bridge registries. Execution is optional and best-effort.
"""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional


# role → ordered external binaries
FALLBACK_CHAINS: dict[str, list[str]] = {
    "static_disasm": ["ghidra", "r2", "radare2", "objdump", "llvm-objdump"],
    "pe_triage": ["die", "pebear", "objdump", "strings"],
    "elf_triage": ["readelf", "objdump", "r2", "strings"],
    "strings": ["strings", "floss", "rabin2"],
    "dynamic_debug": ["gdb", "lldb", "frida"],
    "android": ["jadx", "apktool", "dex2jar"],
    "web_scan": ["nuclei", "nikto", "ffuf", "sqlmap"],
    "port_scan": ["nmap", "masscan", "naabu"],
    "malware_yara": ["yara", "floss"],
    "unpack": ["upx", "binwalk"],
    "crypto": ["openssl", "hashcat"],
    "forensics": ["volatility3", "vol", "binwalk", "exiftool"],
    "container": ["trivy", "grype", "docker"],
}

# local tool name → roles to try when it fails
LOCAL_TO_ROLES: dict[str, list[str]] = {
    "reverse_engineering": ["static_disasm", "pe_triage", "elf_triage", "strings"],
    "malware_analysis": ["malware_yara", "strings", "pe_triage"],
    "pentest_recon": ["port_scan"],
    "web_pentest": ["web_scan"],
    "ctf_toolkit": ["crypto", "static_disasm"],
    "sentinel_scan": ["web_scan", "container"],
}


@dataclass
class FallbackAttempt:
    role: str
    binary: str
    available: bool
    ran: bool = False
    ok: bool = False
    output_preview: str = ""
    error: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class FallbackReport:
    local_tool: str
    reason: str
    attempts: list[FallbackAttempt] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "local_tool": self.local_tool,
            "reason": self.reason,
            "attempts": [a.to_dict() for a in self.attempts],
            "any_success": any(a.ok for a in self.attempts),
        }


def which_chain(role: str) -> list[dict[str, Any]]:
    out = []
    for b in FALLBACK_CHAINS.get(role, []):
        path = shutil.which(b)
        out.append({"binary": b, "path": path, "available": bool(path)})
    return out


def run_fallback(
    local_tool: str,
    target: str = "",
    reason: str = "primary_failed",
    execute: bool = False,
    timeout: int = 30,
) -> FallbackReport:
    """Probe (and optionally execute) fallbacks for a failed local tool."""
    report = FallbackReport(local_tool=local_tool, reason=reason)
    roles = LOCAL_TO_ROLES.get(local_tool, ["strings"])
    for role in roles:
        for binary in FALLBACK_CHAINS.get(role, []):
            path = shutil.which(binary)
            attempt = FallbackAttempt(role=role, binary=binary, available=bool(path))
            if not path:
                report.attempts.append(attempt)
                continue
            if not execute or not target:
                attempt.ran = False
                attempt.ok = True  # available counts as soft success for planning
                report.attempts.append(attempt)
                continue
            # safe, read-only-ish invocations
            cmd = _build_cmd(binary, target)
            if not cmd:
                attempt.error = "no safe cmdline"
                report.attempts.append(attempt)
                continue
            try:
                proc = subprocess.run(
                    cmd, capture_output=True, text=True, timeout=timeout, errors="replace"
                )
                attempt.ran = True
                attempt.ok = proc.returncode == 0 or bool(proc.stdout or proc.stderr)
                preview = (proc.stdout or proc.stderr or "")[:500]
                attempt.output_preview = preview
                if proc.returncode != 0 and not preview:
                    attempt.error = f"exit {proc.returncode}"
            except Exception as exc:
                attempt.ran = True
                attempt.error = str(exc)[:200]
            report.attempts.append(attempt)
            if attempt.ok and attempt.ran:
                return report  # first successful execution
    return report


def _build_cmd(binary: str, target: str) -> Optional[list[str]]:
    t = str(target)
    table = {
        "strings": [binary, "-a", t],
        "objdump": [binary, "-x", t],
        "readelf": [binary, "-h", t],
        "llvm-objdump": [binary, "-x", t],
        "file": [binary, t],
        "nmap": [binary, "-Pn", "-sT", "--top-ports", "50", t],
        "yara": [binary, "--version"],  # rules required; version probe only
        "openssl": [binary, "version"],
        "upx": [binary, "-l", t],
        "binwalk": [binary, "-e", "--run-as=root", t] if False else [binary, t],
        "jadx": [binary, "--version"],
        "trivy": [binary, "--version"],
        "die": [binary, t],
    }
    if binary in table:
        return table[binary]
    # generic: binary --help / version only when target not a file
    if Path(t).is_file() and binary in {"r2", "radare2"}:
        return [binary, "-qq", "-c", "iI", t]
    return [binary, "--version"]


def plan_for_local(local_tool: str) -> dict[str, Any]:
    roles = LOCAL_TO_ROLES.get(local_tool, [])
    return {
        "local_tool": local_tool,
        "roles": {r: which_chain(r) for r in roles},
    }


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Sentinel fallback chains")
    parser.add_argument("--tool", default="reverse_engineering")
    parser.add_argument("--target", default="")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--list-roles", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)

    if args.list_roles:
        data = {k: which_chain(k) for k in FALLBACK_CHAINS}
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0

    if args.execute:
        rep = run_fallback(args.tool, target=args.target, execute=True)
    else:
        rep = run_fallback(args.tool, target=args.target, execute=False)
    print(json.dumps(rep.to_dict(), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
