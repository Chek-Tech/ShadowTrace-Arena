#!/usr/bin/env python3
"""Flask API - JWT authentication bypass vulnerability."""
import os, jwt as pyjwt, json, hashlib
from flask import Flask, request, jsonify

app = Flask(__name__)
SECRET = os.environ.get("SECRET_KEY", "supersecretkey123")
FLAG = os.environ.get("FLAG_API01", "CS{test_flag}")

users = {"admin": hashlib.md5("admin123".encode()).hexdigest(),
         "user": hashlib.md5("userpass".encode()).hexdigest()}

@app.route("/api/login", methods=["POST"])
def login():
    data = request.get_json() or {}
    username = data.get("username", "")
    password = data.get("password", "")
    if username in users and users[username] == hashlib.md5(password.encode()).hexdigest():
        token = pyjwt.encode({"user": username, "role": "user"}, SECRET, algorithm="HS256")
        return jsonify({"token": token})
    return jsonify({"error": "invalid credentials"}), 401

@app.route("/api/flag", methods=["GET"])
def get_flag():
    token = request.headers.get("Authorization", "").replace("Bearer ", "")
    if not token: return jsonify({"error": "no token"}), 401
    try:
        # VULN: accepts algorithm from token header - JWT alg confusion
        header = pyjwt.get_unverified_header(token)
        alg = header.get("alg", "HS256")
        if alg == "none":
            payload = pyjwt.decode(token, options={"verify_signature": False})
        else:
            payload = pyjwt.decode(token, SECRET, algorithms=[alg])
        if payload.get("role") == "admin":
            return jsonify({"flag": FLAG})
        return jsonify({"error": "admin only"}), 403
    except Exception as e:
        return jsonify({"error": str(e)}), 401

@app.route("/api/users", methods=["GET"])
def list_users():
    # VULN: SQL-like injection via parameter (simulated)
    search = request.args.get("search", "")
    if "'" in search or "OR" in search.upper() or "UNION" in search.upper():
        return jsonify({"users": {"admin": "admin123", "root": "toor", "service": "pass123"}})
    return jsonify({"users": list(users.keys())})

@app.route("/api/debug", methods=["GET"])
def debug():
    # VULN: debug endpoint exposes env secrets
    return jsonify({"env": dict(os.environ)})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
