"""Doctor / entrypoint health tests."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import ops_doctor


class DoctorTests(unittest.TestCase):
    def test_doctor_pass(self):
        report = ops_doctor.run_doctor()
        self.assertEqual(report["model_target"], "gpt-5.6")
        self.assertTrue(report["version"])
        failed = [c for c in report["checks"] if not c["ok"]]
        self.assertEqual(failed, [], msg=f"doctor failures: {failed}")

    def test_root_entry_exists(self):
        self.assertTrue((ROOT / "sentinel.py").is_file())
        self.assertTrue((ROOT / "VERSION").is_file())


if __name__ == "__main__":
    unittest.main()
