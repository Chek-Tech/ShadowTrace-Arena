"""Deep ops layer: modules, patterns, triage, algo, fallback, full pipeline."""

from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import ops_modules
import ops_patterns
import ops_triage
import ops_algo
import ops_fallback
import ops_knowledge
import ops_router
import ops_pipeline


class ModuleMatrixTests(unittest.TestCase):
    def test_has_25_modules(self):
        self.assertGreaterEqual(len(ops_modules.MODULES), 25)

    def test_select_pe(self):
        mods = ops_modules.select_modules(query="pe 逆向 imphash", target="a.exe", limit=5)
        ids = [m["id"] for m in mods]
        self.assertTrue(any(i in ids for i in ("M02", "M19", "M25")))

    def test_select_web(self):
        mods = ops_modules.select_modules(query="xss sql 注入网站", target="https://x", limit=5)
        self.assertTrue(any(m["id"] == "M16" for m in mods))

    def test_get_module(self):
        m = ops_modules.get_module("M02")
        self.assertIsNotNone(m)
        self.assertIn("checklist", m)


class PatternTests(unittest.TestCase):
    def test_six_patterns(self):
        self.assertEqual(len(ops_patterns.PATTERNS), 6)

    def test_packed_prefers_pf(self):
        pats = ops_patterns.select_patterns(["S2"], packed=True)
        self.assertTrue(any(p["id"] == "P-F" for p in pats))


class TriageTests(unittest.TestCase):
    def test_file_fingerprint(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "t.bin"
            p.write_bytes(b"MZ" + b"\x00" * 100)
            fp = ops_triage.triage_path(p)
            self.assertTrue(fp.exists)
            self.assertTrue(fp.sha256)
            self.assertIn("PE", fp.format)

    def test_url_fingerprint(self):
        fp = ops_triage.triage_path("https://example.com")
        self.assertEqual(fp.kind, "url")


class AlgoTests(unittest.TestCase):
    def test_detect_tea_delta(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "c.bin"
            p.write_bytes(b"AAAA" + bytes.fromhex("9e3779b9") + b"BBBB")
            rep = ops_algo.analyze(p)
            details = [f.detail for f in rep.findings]
            self.assertIn("TEA_DELTA", details)
            self.assertIn("DELTA", rep.decrypt_sketch)


class FallbackTests(unittest.TestCase):
    def test_plan_lists_binaries(self):
        plan = ops_fallback.plan_for_local("reverse_engineering")
        self.assertIn("roles", plan)

    def test_run_without_execute(self):
        rep = ops_fallback.run_fallback("reverse_engineering", execute=False)
        self.assertTrue(rep.attempts)


class KnowledgeTests(unittest.TestCase):
    def test_tables(self):
        d = ops_knowledge.dump_all()
        self.assertIn("calling_conventions", d)
        self.assertEqual(len(d["report_sections"]), 8)


class RouterDeepTests(unittest.TestCase):
    def test_self_check_includes_modules(self):
        rows = {r["id"]: r["ok"] for r in ops_router.self_check()}
        self.assertTrue(rows.get("module_matrix"))
        self.assertTrue(rows.get("ops_extras"))

    def test_route_includes_modules_patterns(self):
        d = ops_router.classify("分析 pe 木马样本注入")
        self.assertTrue(d.modules)
        self.assertTrue(d.patterns)


class FullPipelineDeepTests(unittest.TestCase):
    def test_pipeline_has_algorithm_stage(self):
        with tempfile.TemporaryDirectory() as tmp:
            sample = Path(tmp) / "s.bin"
            sample.write_bytes(b"MZ\x00\x00" + bytes.fromhex("9e3779b9") + b"VirtualAllocEx")
            out = Path(tmp) / "lab"
            result = ops_pipeline.run_pipeline(
                str(sample),
                query="恶意 pe 算法",
                enable_network=False,
                write_report=True,
                out_dir=str(out),
            )
            names = [s.name for s in result.stages]
            self.assertIn("ALGORITHM", names)
            self.assertIn("TRIAGE", names)
            self.assertTrue(result.report_path)
            text = Path(result.report_path).read_text(encoding="utf-8")
            self.assertIn("防御视角", text)
            self.assertIn("算法还原", text)


if __name__ == "__main__":
    unittest.main()
