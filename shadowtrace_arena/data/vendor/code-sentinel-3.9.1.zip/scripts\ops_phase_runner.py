#!/usr/bin/env python3
"""
Sentinel Phase Runner — execute PTES Lab phases end-to-end (original).

Closes the loop left by plan-only modules:
  plan → **run tools** → **write artifacts** → **manifest** → optional advance

Uses in-process Sentinel engines (pentest_recon / web_pentest / ops_*) when
possible. No third-party skill code. Lab/authorized targets only by policy of
the caller; this module performs the technical workflow.
"""

from __future__ import annotations

import argparse
import json
import sys
import traceback
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

_SCRIPTS = Path(__file__).resolve().parent
_ROOT = _SCRIPTS.parent
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))

PROTOCOL = "sentinel-phase-runner-v1"


def _utc() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _host(target: str) -> str:
    import re
    from urllib.parse import urlparse

    if "://" in target:
        return urlparse(target).hostname or target
    return re.sub(r"/.*$", "", target)


def run_phase(
    target: str,
    phase_id: Optional[str] = None,
    *,
    base: Optional[Path] = None,
    advance: bool = False,
    active_web: bool = False,
    dry_run: bool = False,
    ports: Optional[list[int]] = None,
    force_http: Optional[bool] = None,
) -> dict[str, Any]:
    import ops_ptes_lab
    import ops_engagement
    import ops_phase_kb

    # ensure target exists
    td = ops_ptes_lab.target_dir(target, base)
    if not (td / "state.json").is_file():
        ops_ptes_lab.init_target(target, base=base)

    state = ops_ptes_lab.load_state(target, base)
    phase_id = phase_id or state.get("current_phase") or "L0"
    if force_http is not None:
        state["http_surface"] = bool(force_http)
        ops_ptes_lab.save_state(target, state, base)

    ops_engagement.materialize_phase_dirs(target, phase_id, base)

    result: dict[str, Any] = {
        "protocol": PROTOCOL,
        "target": target,
        "phase_id": phase_id,
        "started_at": _utc(),
        "dry_run": dry_run,
        "artifacts": [],
        "outputs": [],
        "findings": [],
        "signals": {},
        "errors": [],
        "ok": True,
    }

    if dry_run:
        plan = ops_ptes_lab.plan_phase(phase_id, target=target)
        result["plan"] = plan
        result["message"] = "dry-run only"
        return result

    try:
        if phase_id == "L0":
            _run_l0(target, td, result, base)
        elif phase_id == "L1":
            _run_l1(target, td, result, base, ports=ports)
        elif phase_id == "L1W":
            _run_l1w(target, td, result, base, active=active_web)
        elif phase_id == "L2":
            _run_l2(target, td, result, base)
        elif phase_id == "L3":
            _run_l3(target, td, result, base, active=active_web)
        elif phase_id == "L4":
            _run_l4(target, td, result, base)
        elif phase_id == "L5":
            _run_l5(target, td, result, base)
        elif phase_id == "L6":
            _run_l6(target, td, result, base)
        else:
            result["ok"] = False
            result["errors"].append(f"unknown phase {phase_id}")
            return result
    except Exception as exc:
        result["ok"] = False
        result["errors"].append(str(exc))
        result["trace"] = traceback.format_exc()[-2000:]
        return result

    # kb route for next
    try:
        result["kb"] = ops_phase_kb.route_from_text(
            json.dumps(result.get("signals") or {}, ensure_ascii=False)
            + " "
            + (result.get("summary") or ""),
            phase_id=phase_id,
        )
    except Exception:
        pass

    # manifest
    man_path = ops_ptes_lab.write_manifest(
        target,
        phase_id,
        summary=result.get("summary") or f"{phase_id} completed",
        outputs=result.get("outputs") or [],
        findings=result.get("findings") or [],
        signals=result.get("signals") or {},
        base=base,
    )
    result["manifest"] = str(man_path)
    result["finished_at"] = _utc()

    if advance and result["ok"]:
        # mark http from signals
        http = bool((result.get("signals") or {}).get("http_surface"))
        adv = ops_ptes_lab.advance(
            target,
            base=base,
            force=True,
            summary=result.get("summary") or "",
            mark_http=http if http else None,
        )
        result["advance"] = adv

    # refresh state
    try:
        result["state"] = ops_ptes_lab.load_state(target, base)
    except Exception:
        pass
    return result


def _run_l0(target: str, td: Path, result: dict[str, Any], base: Optional[Path]) -> None:
    import ops_tool_index

    auth = td / "authorization.md"
    if not auth.is_file() or auth.stat().st_size < 20:
        _write_text(
            auth,
            f"# Authorization\n\n- Target: `{target}`\n- Runner: phase-runner\n- Time: {_utc()}\n"
            "- Status: assumed lab/authorized by operator\n",
        )
    scope = {
        "target": target,
        "depth": "standard",
        "in_scope": [target],
        "out_of_scope": [],
        "runner": PROTOCOL,
        "confirmed_at": _utc(),
    }
    _write_json(td / "scope.json", scope)
    tools = ops_tool_index.probe_all()
    _write_json(td / "tmp" / "tool-index-snapshot.json", {"summary": tools.get("summary"), "at": _utc()})
    result["artifacts"].extend(["scope.json", "authorization.md", "tmp/tool-index-snapshot.json"])
    result["outputs"] = result["artifacts"]
    result["summary"] = "L0 scope/auth skeleton confirmed; tool index snapshot stored"
    result["signals"] = {"http_surface": target.startswith("http")}


def _run_l1(
    target: str,
    td: Path,
    result: dict[str, Any],
    base: Optional[Path],
    ports: Optional[list[int]] = None,
) -> None:
    import pentest_recon
    import ops_engagement

    host = _host(target)
    # safer default: common ports unless specified
    report = pentest_recon.recon(
        target,
        ports=ports,
        threads=60,
        skip_http=False,
        skip_tls=False,
    )
    data = asdict(report) if hasattr(report, "__dataclass_fields__") else report.__dict__
    # ports list may already be dicts
    open_ports = []
    services = []
    for p in data.get("ports") or []:
        if isinstance(p, dict):
            open_ports.append(int(p.get("port") or 0))
            if p.get("service_guess"):
                services.append(str(p["service_guess"]))
        else:
            open_ports.append(int(getattr(p, "port", 0)))

    _write_json(td / "ports" / "recon.json", data)
    _write_json(
        td / "ports" / "open_ports.json",
        {"target": target, "host": host, "open": open_ports, "at": _utc()},
    )
    _write_json(
        td / "services" / "services.json",
        {
            "target": target,
            "open_ports": open_ports,
            "service_guesses": services,
            "http": data.get("http"),
            "tls": data.get("tls"),
            "dns": data.get("dns"),
            "notes": data.get("notes"),
        },
    )
    # enum plan
    enum_plan = ops_engagement.plan_service_enum(host, open_ports, services, target=target)
    _write_json(td / "services" / "enum-plan.json", enum_plan)

    lines = [
        f"# Recon summary — {target}",
        "",
        f"- Time: {_utc()}",
        f"- Host: `{host}`",
        f"- Resolved: {', '.join(data.get('resolved_ips') or [])}",
        f"- Open ports: {', '.join(str(p) for p in open_ports) or '(none)'}",
        f"- Elapsed ms: {data.get('elapsed_ms')}",
        "",
        "## Notes",
        "",
    ]
    for n in data.get("notes") or []:
        lines.append(f"- {n}")
    lines.append("")
    lines.append("## Artifacts")
    lines.append("")
    lines.append("- `ports/recon.json`")
    lines.append("- `ports/open_ports.json`")
    lines.append("- `services/services.json`")
    lines.append("- `services/enum-plan.json`")
    _write_text(td / "recon-summary.md", "\n".join(lines) + "\n")

    http_surface = bool(
        target.startswith("http")
        or any(p in open_ports for p in (80, 443, 8080, 8443, 8000, 3000, 5000))
        or (data.get("http") or {}).get("status")
    )
    result["artifacts"] = [
        "ports/recon.json",
        "ports/open_ports.json",
        "services/services.json",
        "services/enum-plan.json",
        "recon-summary.md",
    ]
    result["outputs"] = result["artifacts"]
    result["summary"] = f"L1 recon: {len(open_ports)} open ports on {host}"
    result["signals"] = {
        "http_surface": http_surface,
        "ports": open_ports,
        "services": services,
        "resolved_ips": data.get("resolved_ips") or [],
    }
    result["findings"] = [
        {"type": "open_port", "port": p, "severity": "info"} for p in open_ports
    ]
    if http_surface:
        result["findings"].append({"type": "http_surface", "severity": "info"})


def _run_l1w(
    target: str,
    td: Path,
    result: dict[str, Any],
    base: Optional[Path],
    *,
    active: bool = False,
) -> None:
    import web_pentest
    from urllib.parse import urlparse

    url = target if target.startswith("http") else f"http://{_host(target)}"
    # passive default for automation safety; active opt-in
    report = web_pentest.audit_url(url, deep_paths=True, active=active)
    data = report.to_dict() if hasattr(report, "to_dict") else asdict(report)
    _write_json(td / "web" / "web-audit.json", data)

    # web map simplified
    findings = data.get("findings") or []
    web_map = {
        "url": url,
        "meta": data.get("meta") or {},
        "finding_count": len(findings),
        "by_severity": {},
        "titles": [f.get("title") for f in findings[:50] if isinstance(f, dict)],
        "at": _utc(),
    }
    for f in findings:
        if not isinstance(f, dict):
            continue
        sev = (f.get("severity") or "INFO").upper()
        web_map["by_severity"][sev] = web_map["by_severity"].get(sev, 0) + 1
    _write_json(td / "web" / "web-map.json", web_map)
    _write_text(
        td / "web" / "web-summary.md",
        f"# Web pretest — {url}\n\n"
        f"- Active probes: {active}\n"
        f"- Findings: {len(findings)}\n"
        f"- Severity: {web_map['by_severity']}\n"
        f"- Artifacts: web/web-audit.json, web/web-map.json\n",
    )

    result["artifacts"] = ["web/web-audit.json", "web/web-map.json", "web/web-summary.md"]
    result["outputs"] = result["artifacts"]
    result["summary"] = f"L1W web pretest: {len(findings)} findings on {url}"
    result["signals"] = {
        "http_surface": True,
        "url": url,
        "web_findings": len(findings),
        "by_severity": web_map["by_severity"],
    }
    result["findings"] = [
        {
            "title": f.get("title"),
            "severity": f.get("severity"),
            "category": f.get("category"),
            "location": f.get("location"),
        }
        for f in findings[:100]
        if isinstance(f, dict)
    ]


def _run_l2(target: str, td: Path, result: dict[str, Any], base: Optional[Path]) -> None:
    import ops_engagement

    ports = []
    services = []
    op = td / "ports" / "open_ports.json"
    if op.is_file():
        data = json.loads(op.read_text(encoding="utf-8"))
        ports = data.get("open") or []
    sv = td / "services" / "services.json"
    if sv.is_file():
        data = json.loads(sv.read_text(encoding="utf-8"))
        services = data.get("service_guesses") or []
        ports = ports or data.get("open_ports") or []

    host = _host(target)
    enum_plan = ops_engagement.plan_service_enum(host, [int(p) for p in ports], services, target=target)
    priorities = []
    for pb in enum_plan.get("playbooks") or []:
        priorities.append(
            {
                "id": pb["id"],
                "title": pb["title"],
                "priority": "high" if pb["id"] in ("SP-HTTP", "SP-SMB", "SP-SQL", "SP-LDAP") else "medium",
            }
        )

    lines = [
        f"# Threat model — {target}",
        "",
        f"- Generated: {_utc()}",
        f"- Host: `{host}`",
        f"- Open ports: {ports}",
        "",
        "## Assets / surfaces",
        "",
    ]
    for p in priorities:
        lines.append(f"- **{p['priority'].upper()}** {p['id']}: {p['title']}")
    lines.extend(
        [
            "",
            "## Trust boundaries",
            "",
            "- External client → exposed services",
            "- App tier → data tier (if DB ports present)",
            "- Management protocols (SSH/RDP/WinRM) as high-value pivots",
            "",
            "## Priority attack paths",
            "",
            "1. Highest-priority surface from enum playbooks",
            "2. Credential/auth weaknesses on management ports",
            "3. Web/API logic if HTTP surface exists",
            "",
            "## Next phase focus (L3)",
            "",
            "- Verify vulns only on prioritized surfaces",
            "- Record evidence under `vulns/`",
            "",
        ]
    )
    _write_text(td / "threat_model.md", "\n".join(lines))
    _write_json(td / "threat-priorities.json", {"priorities": priorities, "enum_plan_id": "services/enum-plan.json"})
    result["artifacts"] = ["threat_model.md", "threat-priorities.json"]
    result["outputs"] = result["artifacts"]
    result["summary"] = f"L2 threat model: {len(priorities)} surfaces prioritized"
    result["signals"] = {
        "http_surface": any(p in (80, 443, 8080, 8443) for p in ports) or target.startswith("http"),
        "ports": ports,
        "services": services,
        "priorities": [p["id"] for p in priorities],
    }


def _run_l3(
    target: str,
    td: Path,
    result: dict[str, Any],
    base: Optional[Path],
    *,
    active: bool = False,
) -> None:
    findings: list[dict[str, Any]] = []
    # reuse web audit if present else run passive web when http
    web_audit = td / "web" / "web-audit.json"
    if not web_audit.is_file() and (
        target.startswith("http") or _has_http_ports(td)
    ):
        tmp: dict[str, Any] = {
            "artifacts": [],
            "outputs": [],
            "findings": [],
            "signals": {},
            "errors": [],
            "ok": True,
        }
        _run_l1w(target, td, tmp, base, active=active)
        findings.extend(tmp.get("findings") or [])
        result.setdefault("nested", {})["L1W"] = tmp.get("summary")
    if web_audit.is_file() or (td / "web" / "web-audit.json").is_file():
        data = json.loads((td / "web" / "web-audit.json").read_text(encoding="utf-8"))
        for f in data.get("findings") or []:
            if isinstance(f, dict):
                findings.append(
                    {
                        "title": f.get("title"),
                        "severity": f.get("severity"),
                        "category": f.get("category"),
                        "location": f.get("location"),
                        "evidence": (f.get("evidence") or "")[:300],
                        "remediation": f.get("remediation"),
                    }
                )

    # open management ports as findings
    op = td / "ports" / "open_ports.json"
    if op.is_file():
        ports = json.loads(op.read_text(encoding="utf-8")).get("open") or []
        risky = {21: "ftp", 23: "telnet", 445: "smb", 3389: "rdp", 6379: "redis", 27017: "mongodb"}
        for p in ports:
            if int(p) in risky:
                findings.append(
                    {
                        "title": f"Management/data service exposed: {risky[int(p)]} ({p})",
                        "severity": "MEDIUM",
                        "category": "exposure",
                        "location": f"{_host(target)}:{p}",
                        "evidence": "open port from L1 recon",
                        "remediation": "Restrict to admin networks; require strong auth.",
                    }
                )

    verified = {
        "target": target,
        "at": _utc(),
        "count": len(findings),
        "findings": findings,
    }
    _write_json(td / "vulns" / "verified.json", verified)
    # markdown table
    lines = [
        f"# Verified findings — {target}",
        "",
        f"- Count: {len(findings)}",
        f"- Time: {_utc()}",
        "",
        "| Sev | Title | Location |",
        "|-----|-------|----------|",
    ]
    for f in findings:
        lines.append(
            f"| {f.get('severity')} | {f.get('title')} | {f.get('location')} |"
        )
    _write_text(td / "vulns" / "verified_vulns.md", "\n".join(lines) + "\n")

    result["artifacts"] = ["vulns/verified.json", "vulns/verified_vulns.md"]
    result["outputs"] = result["artifacts"]
    result["findings"] = findings
    result["summary"] = f"L3 vuln analysis: {len(findings)} findings recorded"
    result["signals"] = {
        "http_surface": target.startswith("http") or _has_http_ports(td),
        "vuln_count": len(findings),
    }


def _run_l4(target: str, td: Path, result: dict[str, Any], base: Optional[Path]) -> None:
    verified = td / "vulns" / "verified.json"
    findings = []
    if verified.is_file():
        findings = json.loads(verified.read_text(encoding="utf-8")).get("findings") or []

    high = [f for f in findings if str(f.get("severity", "")).upper() in ("CRITICAL", "HIGH")]
    access = {
        "target": target,
        "at": _utc(),
        "footholds": [],
        "notes": "Automated runner records verification slots; interactive exploit remains operator-driven.",
        "candidates": high[:20],
    }
    _write_json(td / "exploits" / "candidates.json", access)
    _write_text(
        td / "access.md",
        f"# Access / foothold log — {target}\n\n"
        f"- Time: {_utc()}\n"
        f"- High/Critical candidates: {len(high)}\n"
        f"- See `exploits/candidates.json`\n"
        f"- Status: no automatic destructive exploit executed by runner\n",
    )
    result["artifacts"] = ["exploits/candidates.json", "access.md"]
    result["outputs"] = result["artifacts"]
    result["findings"] = high
    result["summary"] = f"L4: {len(high)} high/critical candidates staged (no auto-exploit)"
    result["signals"] = {"http_surface": target.startswith("http") or _has_http_ports(td)}


def _run_l5(target: str, td: Path, result: dict[str, Any], base: Optional[Path]) -> None:
    _write_text(
        td / "post" / "situational.md",
        f"# Post-exploitation situational — {target}\n\n"
        f"- Time: {_utc()}\n"
        f"- Access state: see `access.md`\n"
        f"- Automated runner does not perform lateral movement.\n"
        f"- Checklist: local priv boundary / credential hygiene / network segments\n",
    )
    _write_json(
        td / "post" / "checklist.json",
        {
            "items": [
                "Confirm authorized post-ex scope",
                "Document privileges obtained",
                "No persistence without approval",
                "Record lateral candidates only",
            ],
            "at": _utc(),
        },
    )
    result["artifacts"] = ["post/situational.md", "post/checklist.json"]
    result["outputs"] = result["artifacts"]
    result["summary"] = "L5 post checklist written (non-destructive)"
    result["signals"] = {}


def _run_l6(target: str, td: Path, result: dict[str, Any], base: Optional[Path]) -> None:
    import ops_engagement

    rep = ops_engagement.build_report(target, base)
    # evidence index
    arts = []
    for p in td.rglob("*"):
        if p.is_file() and p.name not in (".gitkeep",):
            try:
                rel = str(p.relative_to(td)).replace("\\", "/")
            except ValueError:
                continue
            if rel.startswith("tmp/"):
                continue
            arts.append(rel)
    idx = {"at": _utc(), "files": sorted(arts)[:500], "count": len(arts)}
    _write_json(td / "evidence_index.json", idx)
    result["artifacts"] = ["report.md", "evidence_index.json"]
    result["outputs"] = result["artifacts"]
    result["summary"] = f"L6 report built; {idx['count']} evidence files indexed"
    result["signals"] = {}
    result["report"] = rep


def _has_http_ports(td: Path) -> bool:
    op = td / "ports" / "open_ports.json"
    if not op.is_file():
        return False
    ports = json.loads(op.read_text(encoding="utf-8")).get("open") or []
    return any(int(p) in (80, 443, 8080, 8443, 8000, 3000, 5000) for p in ports)


def run_until(
    target: str,
    *,
    until_phase: str = "L6",
    base: Optional[Path] = None,
    active_web: bool = False,
    max_steps: int = 12,
    ports: Optional[list[int]] = None,
) -> dict[str, Any]:
    """Run phases from current until until_phase (inclusive), auto-advance."""
    import ops_ptes_lab

    if not (ops_ptes_lab.target_dir(target, base) / "state.json").is_file():
        ops_ptes_lab.init_target(target, base=base)

    history = []
    steps = 0
    while steps < max_steps:
        steps += 1
        state = ops_ptes_lab.load_state(target, base)
        cur = state.get("current_phase")
        r = run_phase(
            target,
            cur,
            base=base,
            advance=True,
            active_web=active_web,
            ports=ports,
        )
        history.append(
            {
                "phase": cur,
                "ok": r.get("ok"),
                "summary": r.get("summary"),
                "errors": r.get("errors"),
                "next": (r.get("advance") or {}).get("current_phase"),
            }
        )
        if not r.get("ok"):
            break
        if cur == until_phase:
            break
        # stop if not advancing
        nxt = (r.get("advance") or {}).get("current_phase")
        if not nxt or nxt == cur:
            # completed last phase
            if cur == "L6":
                break
            # force if stuck
            break
    final = ops_ptes_lab.load_state(target, base)
    return {
        "protocol": PROTOCOL,
        "target": target,
        "steps": history,
        "final_state": final,
        "ok": all(h.get("ok") for h in history) if history else False,
    }


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Sentinel phase runner — execute PTES phases")
    p.add_argument("--base", default=None)
    sub = p.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("run", help="run one phase")
    r.add_argument("target")
    r.add_argument("--phase", default=None, help="default: current from state")
    r.add_argument("--advance", action="store_true")
    r.add_argument("--active-web", action="store_true", help="enable active web probes")
    r.add_argument("--dry-run", action="store_true")
    r.add_argument("--ports", default="", help="comma ports for L1")
    r.add_argument("--http", action="store_true")

    a = sub.add_parser("auto", help="run phases until L6 (or --until)")
    a.add_argument("target")
    a.add_argument("--until", default="L6")
    a.add_argument("--active-web", action="store_true")
    a.add_argument("--ports", default="")
    a.add_argument("--max-steps", type=int, default=12)

    args = p.parse_args(argv)
    base = Path(args.base) if args.base else None

    def ports_arg() -> Optional[list[int]]:
        raw = getattr(args, "ports", "") or ""
        if not raw.strip():
            return None
        return [int(x) for x in raw.split(",") if x.strip().isdigit()]

    try:
        if args.cmd == "run":
            out = run_phase(
                args.target,
                args.phase,
                base=base,
                advance=args.advance,
                active_web=args.active_web,
                dry_run=args.dry_run,
                ports=ports_arg(),
                force_http=True if args.http else None,
            )
            print(json.dumps(out, ensure_ascii=False, indent=2, default=str))
            return 0 if out.get("ok") else 1
        if args.cmd == "auto":
            out = run_until(
                args.target,
                until_phase=args.until,
                base=base,
                active_web=args.active_web,
                max_steps=args.max_steps,
                ports=ports_arg(),
            )
            print(json.dumps(out, ensure_ascii=False, indent=2, default=str))
            return 0 if out.get("ok") else 1
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
