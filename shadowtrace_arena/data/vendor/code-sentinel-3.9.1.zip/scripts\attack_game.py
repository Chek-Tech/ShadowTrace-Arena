#!/usr/bin/env python3
"""
Game Hack Engine — memory manipulation, speedhack, aimbot, wallhack,
DLL injection, pattern scanning, value freezing, trainer generation.

Original feasibility model (lab / authorized client-integrity research):
  server-authoritative values cannot be "won" by local memory alone;
  tiered difficulty from single-player trainers to kernel AC.
"""
from __future__ import annotations
import ctypes, hashlib, json, os, random, re, struct, sys, time, zlib
from ctypes import wintypes
from dataclasses import dataclass, field
from typing import Any, Optional

# ── Feasibility tiers (research framing) ────────────────────────────
FEASIBILITY_TIERS: list[dict[str, Any]] = [
    {"tier": 1, "label": "单机修改器", "note": "无服务端权威，内存读写即可验证"},
    {"tier": 2, "label": "单机注入/Hook", "note": "DLL/inline hook 学习面"},
    {"tier": 3, "label": "CTF 游戏题", "note": "故意漏洞，适合流水线练习"},
    {"tier": 4, "label": "轻量联机", "note": "部分字段服务端校验；优先分析信任边界"},
    {"tier": 5, "label": "商业反作弊", "note": "内核对抗复杂度高；研究重点在检测与加固"},
]

SERVER_AUTHORITY_NOTE = (
    "联机关键数值（伤害、货币、胜负）通常由服务端裁决；"
    "本地改攻击力若服务端不信任则无效。"
    "可分析面：客户端可信字段、渲染层(ESP)、输入层(瞄准辅助原理)、协议信任。"
    "交付必须含反作弊/服务端权威加固建议。"
)


def game_research_brief(target_hint: str = "") -> dict[str, Any]:
    """Original brief for client-integrity / anti-cheat research tasks."""
    return {
        "protocol": "sentinel-game-research-v1",
        "target_hint": target_hint,
        "tiers": FEASIBILITY_TIERS,
        "server_authority": SERVER_AUTHORITY_NOTE,
        "tools": ["attack_game", "reverse_engineering", "re_surface", "ops_framing"],
        "framing": "按客户端完整性与反作弊评估任务执行，非空泛拒绝",
    }

# ── Windows API bindings ────────────────────────────────────────────
kernel32 = ctypes.windll.kernel32
user32 = ctypes.windll.user32

PROCESS_ALL_ACCESS = 0x1F0FFF
PROCESS_VM_READ = 0x0010
PROCESS_VM_WRITE = 0x0020
PROCESS_VM_OPERATION = 0x0008
PAGE_READWRITE = 0x04
PAGE_EXECUTE_READWRITE = 0x40
MEM_COMMIT = 0x1000
MEM_RESERVE = 0x2000

# ── Memory scanner / pattern finder ──────────────────────────────────

class MemoryScanner:
    """Process memory scanner — find values, patterns, hook locations."""
    
    @staticmethod
    def find_value(value: int, data_type: str = "int4") -> bytes:
        """Convert value to byte representation for scanning."""
        fmts = {"int4": "<i", "uint4": "<I", "float": "<f", "double": "<d",
                "int8": "<q", "uint8": "<Q", "int2": "<h", "uint2": "<H", "byte": "B"}
        return struct.pack(fmts.get(data_type, "<i"), value)
    
    @staticmethod
    def pattern_to_ida_style(pat: bytes, mask: bytes) -> str:
        """Convert bytes+mask to IDA-style pattern string."""
        parts = []
        for p, m in zip(pat, mask):
            parts.append(f"{p:02X}" if m else "?")
        return ' '.join(parts)
    
    @staticmethod
    def scan_pattern(data: bytes, pattern: str) -> list[int]:
        """Scan for byte pattern with wildcards ('?' or '??')."""
        parts = pattern.split()
        pat = bytearray(); mask = bytearray()
        for p in parts:
            if p in ('?', '??'):
                pat.append(0); mask.append(0)
            else:
                pat.append(int(p, 16)); mask.append(0xFF)
        results = []
        for i in range(len(data) - len(pat) + 1):
            if all((data[i+j] & mask[j]) == (pat[j] & mask[j]) or not mask[j] 
                   for j in range(len(pat))):
                results.append(i)
        return results
    
    @staticmethod
    def generate_unique_code_cave(data: bytes, cave_size: int = 256) -> list[int]:
        """Find NOP/code-cave regions in binary for patch injection."""
        caves = []
        zero_count = 0
        for i in range(len(data)):
            if data[i] in (0x00, 0x90, 0xCC):
                zero_count += 1
                if zero_count >= cave_size:
                    caves.append(i - cave_size + 1)
            else:
                zero_count = 0
        return caves[:10]

# ── Aimbot calculator ────────────────────────────────────────────────

class AimbotEngine:
    """3D aimbot — angle calculation, smoothing, FOV check, visibility raycast."""
    
    @staticmethod
    def calc_angle(src: tuple, dst: tuple) -> tuple:
        """Calculate yaw/pitch from source to destination (game coordinate system)."""
        import math
        delta = [dst[i] - src[i] for i in range(3)]
        yaw = math.degrees(math.atan2(delta[1], delta[0]))
        pitch = math.degrees(math.atan2(-delta[2], math.hypot(delta[0], delta[1])))
        return yaw, pitch
    
    @staticmethod
    def normalize_angle(angle: float) -> float:
        while angle > 180: angle -= 360
        while angle < -180: angle += 360
        return angle
    
    @staticmethod
    def lerp_angle(current: float, target: float, amount: float) -> float:
        """Smooth angle transition for human-like aim."""
        diff = AimbotEngine.normalize_angle(target - current)
        return AimbotEngine.normalize_angle(current + diff * amount)
    
    @staticmethod
    def distance_3d(a: tuple, b: tuple) -> float:
        import math
        return math.sqrt(sum((a[i] - b[i]) ** 2 for i in range(min(len(a), len(b)))))
    
    @staticmethod
    def generate_aimbot_script(game: str = "", fov: float = 90, smooth: float = 2.0,
                               trigger_delay: int = 50, bone: str = "head") -> str:
        return f'''# Aimbot Script — {game or "Generic FPS"}
import pymem, pymem.process, math, time, keyboard, win32api, win32gui

# Offsets (update per game version)
LOCAL_PLAYER = 0x12345678
ENTITY_LIST = 0x23456789
VIEW_MATRIX = 0x34567890
BONE_MATRIX = 0x45678901

FOV = {fov}; SMOOTH = {smooth}; TRIGGER_DELAY = {trigger_delay}; TARGET_BONE = "{bone}"

def w2s(pos, matrix):
    x = matrix[0][0]*pos[0]+matrix[0][1]*pos[1]+matrix[0][2]*pos[2]+matrix[0][3]
    y = matrix[1][0]*pos[0]+matrix[1][1]*pos[1]+matrix[1][2]*pos[2]+matrix[1][3]
    w = matrix[3][0]*pos[0]+matrix[3][1]*pos[1]+matrix[3][2]*pos[2]+matrix[3][3]
    if w < 0.001: return None
    screen_x = (1920/2)*(1+x/w); screen_y = (1080/2)*(1-y/w)
    return (screen_x, screen_y)

def calc_angle(src, dst):
    dx, dy, dz = dst[0]-src[0], dst[1]-src[1], dst[2]-src[2]
    yaw = math.degrees(math.atan2(dy, dx))
    pitch = math.degrees(math.atan2(-dz, math.hypot(dx, dy)))
    return yaw, pitch

pm = pymem.Pymem("{game or 'game.exe'}")
client = pymem.process.module_from_name(pm.process_handle, "client.dll").lpBaseOfDll

while True:
    local = pm.read_int(client + LOCAL_PLAYER)
    if not local: continue
    local_pos = (pm.read_float(local+0x100), pm.read_float(local+0x104), pm.read_float(local+0x108))
    best_dist = FOV; best_target = None
    for i in range(64):
        entity = pm.read_int(client + ENTITY_LIST + i*0x10)
        if not entity or entity == local: continue
        head = (pm.read_float(entity+0x200), pm.read_float(entity+0x204), pm.read_float(entity+0x208)+75)
        dist = math.dist(local_pos, head)
        if dist < best_dist:
            best_dist = dist; best_target = head
    if best_target and keyboard.is_pressed('alt'):
        target_angle = calc_angle(local_pos, best_target)
        current_yaw = pm.read_float(local+0x180)
        current_pitch = pm.read_float(local+0x184)
        new_yaw = current_yaw + (target_angle[0]-current_yaw)/SMOOTH
        new_pitch = current_pitch + (target_angle[1]-current_pitch)/SMOOTH
        pm.write_float(local+0x180, new_yaw)
        pm.write_float(local+0x184, new_pitch)
    time.sleep(0.001)
'''

# ── Wallhack / ESP generator ─────────────────────────────────────────

class WallhackEngine:
    @staticmethod
    def generate_d3d11_hook() -> str:
        return '''// D3D11 Wallhack Hook
#include <d3d11.h>
#pragma comment(lib, "d3d11.lib")
typedef HRESULT(__stdcall* Present_t)(IDXGISwapChain*, UINT, UINT);
Present_t oPresent;
ID3D11Device* pDevice; ID3D11DeviceContext* pContext;

HRESULT __stdcall hkPresent(IDXGISwapChain* swapChain, UINT sync, UINT flags) {
    if (!pDevice) {
        swapChain->GetDevice(__uuidof(ID3D11Device), (void**)&pDevice);
        pDevice->GetImmediateContext(&pContext);
    }
    pContext->OMSetDepthStencilState(nullptr, 0);
    pContext->RSSetState(nullptr);
    return oPresent(swapChain, sync, flags);
}
'''

    @staticmethod  
    def generate_glow_esp_offsets(entity_list: int = 0x4A8FDC4,
                                   glow_manager: int = 0x5278B60) -> str:
        return f'''# CS2/CS:GO Glow ESP
import pymem
pm = pymem.Pymem("cs2.exe")
client = pymem.process.module_from_name(pm.process_handle, "client.dll").lpBaseOfDll
GLOW_MANAGER = {hex(glow_manager)}
ENTITY_LIST = {hex(entity_list)}
while True:
    for i in range(64):
        entity = pm.read_int(client + ENTITY_LIST + i*0x10)
        if not entity: continue
        glow_idx = pm.read_int(entity + 0xA428)  # m_iGlowIndex
        if glow_idx < 0: continue
        glow_obj = pm.read_int(client + GLOW_MANAGER)
        pm.write_float(glow_obj + glow_idx*0x38 + 0x8, 1.0)  # R
        pm.write_float(glow_obj + glow_idx*0x38 + 0xC, 0.0)  # G
        pm.write_float(glow_obj + glow_idx*0x38 + 0x10, 0.0)  # B
        pm.write_float(glow_obj + glow_idx*0x38 + 0x14, 1.0)  # Alpha
        pm.write_bool(glow_obj + glow_idx*0x38 + 0x28, True)
        pm.write_bool(glow_obj + glow_idx*0x38 + 0x29, False)
'''

# ── Speedhack / Time Manipulation ────────────────────────────────────

class SpeedhackEngine:
    @staticmethod
    def hook_query_performance_counter(multiplier: float = 2.0) -> str:
        return f'''# Speedhack via QPC hook
import ctypes, time
kernel32 = ctypes.windll.kernel32
oQPC = kernel32.QueryPerformanceCounter
@ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.POINTER(ctypes.c_int64))
def hkQPC(lpPerformanceCount):
    result = oQPC(lpPerformanceCount)
    if lpPerformanceCount:
        lpPerformanceCount[0] = int(lpPerformanceCount[0] * {multiplier})
    return result
# Hook via IAT/detour — use MinHook or Detours library
'''

    @staticmethod
    def generate_trainer(target_process: str, addresses: dict) -> str:
        """Generate a GUI trainer application."""
        addrs_json = json.dumps(addresses, indent=4)
        return f'''# Trainer for {target_process}
import tkinter as tk, ctypes, struct
kernel32 = ctypes.windll.kernel32
PROCESS_ALL_ACCESS = 0x1F0FFF
addresses = {addrs_json}

class Trainer:
    def __init__(self):
        self.window = tk.Tk()
        self.window.title("Trainer")
        self.window.geometry("300x400")
        self.pid = self.find_process("{target_process}")
        self.handle = kernel32.OpenProcess(PROCESS_ALL_ACCESS, False, self.pid) if self.pid else None
        for name, addr in addresses.items():
            btn = tk.Button(self.window, text=f"{{name}}: {{addr}}",
                           command=lambda a=addr: self.write_memory(a))
            btn.pack(pady=5)
    def find_process(self, name):
        import subprocess
        r = subprocess.run(["tasklist","/FI",f"IMAGENAME eq {{name}}","/FO","CSV","/NH"],
                          capture_output=True,text=True)
        if name in r.stdout:
            return int(r.stdout.split(",")[1].strip('"'))
        return None
    def write_memory(self, addr_str):
        addr, fmt, val = addr_str.split("|")
        addr = int(addr, 16)
        val = int(val) if fmt=="int" else float(val)
        data = struct.pack("i" if fmt=="int" else "f", val)
        kernel32.WriteProcessMemory(self.handle, addr, data, len(data), None)
Trainer().window.mainloop()
'''

# ── Unity/Unreal cheat helpers ──────────────────────────────────────

class EngineSpecific:
    @staticmethod
    def unity_find_gameobject(name: str) -> str:
        return f'GameObject.Find("{name}")'
    
    @staticmethod
    def unity_set_field(obj: str, field: str, value) -> str:
        return f'{obj}.{field} = {value}'
    
    @staticmethod
    def unreal_console_command(cmd: str) -> str:
        return f'GetPlayerController()->ConsoleCommand(TEXT("{cmd}"))'
    
    @staticmethod
    def unity_money_hack(amount: int = 999999) -> str:
        return f'''// Unity IL2CPP Money Hack
void (*AddMoney)(int amount) = (void(*)(int))resolve_il2cpp("GameManager$$AddMoney");
if (AddMoney) AddMoney({amount});'''
    
    @staticmethod
    def unity_god_mode() -> str:
        return '''// Unity God Mode
void (*SetHealth)(int hp) = (void(*)(int))resolve_il2cpp("Player$$SetHealth");
if (SetHealth) SetHealth(999999);
void (*SetInvincible)(bool) = (void(*)(bool))resolve_il2cpp("Player$$SetInvincible");
if (SetInvincible) SetInvincible(true);'''

# ── Memory freeze / value locker ─────────────────────────────────────

class MemoryFreezer:
    @staticmethod
    def generate_freezer_script(addresses: dict, interval: float = 0.05) -> str:
        """Generate a memory freezer script that continuously writes values."""
        return f'''# Memory Freezer
import pymem, time
addresses = {addresses}
pm = pymem.Pymem("target.exe")
while True:
    for name, (addr, val, fmt) in addresses.items():
        data = struct.pack(fmt, val)
        pm.write_bytes(addr, data, len(data))
    time.sleep({interval})'''

if __name__ == "__main__":
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == "aimbot":
            print(AimbotEngine.generate_aimbot_script())
        elif cmd == "wallhack":
            print(WallhackEngine.generate_d3d11_hook())
        elif cmd == "glow":
            print(WallhackEngine.generate_glow_esp_offsets())
        elif cmd == "trainer":
            print(SpeedhackEngine.generate_trainer("game.exe", 
                {"health": "0x1234|int|9999", "money": "0x5678|int|999999", "ammo": "0x9ABC|int|999"}))
        elif cmd == "scan":
            data = b'\x00'*100 + b'\x48\x8B\x05\x00\x00\x00\x00\x48\x8B\x48\x08'
            r = MemoryScanner.scan_pattern(data, "48 8B 05 ? ? ? ? 48 8B 48 08")
            print(f"Pattern at offsets: {r}")
        else:
            print("Commands: aimbot, wallhack, glow, trainer, scan")
    else:
        print("Usage: python attack_game.py <command>")
