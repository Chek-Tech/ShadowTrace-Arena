#!/usr/bin/env python3
"""
Sentinel report / evidence contracts (original).

Essences:
  * Finding = reproducible request/traffic + observable side effect
  * Differential proof (one variable)
  * Structured sections for security report / CTF writeup / RE note
  * Hallucination anti-patterns checklist
"""

from __future__ import annotations

import argparse
import json
from typing import Any, Optional

REPORT_TEMPLATES: dict[str, list[str]] = {
    "security": [
        "摘要/结论",
        "范围与资产",
        "发现列表（严重度）",
        "每条：描述 / 影响 / 复现流量 / 副作用 / 修复",
        "攻击链（如适用）",
        "防御加固总表",
        "附录：工具与时间线",
    ],
    "ctf": [
        "题目信息",
        "思路概述",
        "关键证据（runtime 优先）",
        "完整复现步骤",
        "flag/产物路径",
        "弯路与排除项",
        "知识点",
    ],
    "reverse": [
        "样本标识（哈希/格式）",
        "分诊结论",
        "静态要点",
        "动态/行为",
        "算法/协议还原",
        "IOC",
        "防御检测建议",
    ],
    "api": [
        "API 面清单",
        "认证问题",
        "授权（BOLA/BFLA）",
        "注入与输入",
        "业务逻辑",
        "暴露与限速",
        "修复与回归用例",
    ],
}

FINDING_SCHEMA: dict[str, str] = {
    "id": "F-001",
    "title": "一句话标题",
    "severity": "critical|high|medium|low|info",
    "surface": "surface id or module",
    "request": "可粘贴的完整请求（脱敏）",
    "response_key": "决定性响应片段",
    "side_effect": "权威态变化（用户/订单/文件/权限/flag）",
    "diff": "良性对照 vs 恶意对照（单变量）",
    "impact": "业务影响",
    "fix": "修复建议",
    "defense_detect": "如何检测同类问题",
}

HALLUCINATION_TRAPS: list[dict[str, str]] = [
    {"id": "status_500", "trap": "500/语法错误≠可注入", "need": "可抽取数据或明确执行副作用"},
    {"id": "sleep", "trap": "延时变慢≠时间盲注", "need": "多次对照+统计或外带通道"},
    {"id": "reflect", "trap": "反射输入≠XSS", "need": "可执行上下文与 CSP/编码分析"},
    {"id": "path_in_error", "trap": "错误路径串≠必高危", "need": "实际敏感文件可达"},
    {"id": "banner_cve", "trap": "版本 banner≠CVE 成立", "need": "PoC 验证"},
    {"id": "dnslog_once", "trap": "单次 DNSLog≠SSRF", "need": "可控复现与内网触达证明"},
    {"id": "scope", "trap": "以为在范围内", "need": "书面 scope 核对"},
]

EVIDENCE_RULES: list[str] = [
    "每个漏洞结论 = 可复现流量 + 可观察副作用",
    "优先 runtime/流量，源码仅解释",
    "差分：每次只改一个变量",
    "敏感头/ token 脱敏后再入库/分享",
    "中间服务成功 ≠ 最终权威态成功",
]


def template(kind: str = "security") -> dict[str, Any]:
    kind = (kind or "security").lower()
    sections = REPORT_TEMPLATES.get(kind) or REPORT_TEMPLATES["security"]
    return {
        "kind": kind if kind in REPORT_TEMPLATES else "security",
        "sections": sections,
        "finding_schema": FINDING_SCHEMA,
        "evidence_rules": EVIDENCE_RULES,
    }


def validate_finding(finding: dict[str, Any]) -> dict[str, Any]:
    missing = []
    for key in ("title", "request", "side_effect"):
        if not str(finding.get(key, "")).strip():
            missing.append(key)
    weak = []
    if finding.get("request") and "http" not in str(finding.get("request")).lower() and "命令" not in str(finding.get("request")):
        if len(str(finding.get("request"))) < 20:
            weak.append("request_too_short")
    if not finding.get("diff") and not finding.get("response_key"):
        weak.append("no_diff_or_response_key")
    ok = not missing and not weak
    return {
        "ok": ok,
        "missing": missing,
        "weak": weak,
        "message": "可提交" if ok else "证据不足：补全 missing/weak 后再报",
    }


def anti_hallucination() -> list[dict[str, str]]:
    return list(HALLUCINATION_TRAPS)


def checklist() -> dict[str, Any]:
    return {
        "evidence_rules": EVIDENCE_RULES,
        "hallucination_traps": HALLUCINATION_TRAPS,
        "finding_required": ["title", "request", "side_effect"],
        "finding_recommended": ["diff", "response_key", "fix", "defense_detect"],
    }


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Sentinel report/evidence contracts")
    sub = p.add_subparsers(dest="cmd", required=True)

    t = sub.add_parser("template", help="Report section template")
    t.add_argument("kind", nargs="?", default="security", choices=list(REPORT_TEMPLATES))

    v = sub.add_parser("validate", help="Validate finding JSON fields")
    v.add_argument("--title", default="")
    v.add_argument("--request", default="")
    v.add_argument("--side-effect", default="")
    v.add_argument("--diff", default="")
    v.add_argument("--response-key", default="")

    sub.add_parser("traps", help="Hallucination anti-patterns")
    sub.add_parser("checklist", help="Full evidence checklist")

    args = p.parse_args(argv)
    if args.cmd == "template":
        print(json.dumps(template(args.kind), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "validate":
        print(json.dumps(validate_finding({
            "title": args.title,
            "request": args.request,
            "side_effect": args.side_effect,
            "diff": args.diff,
            "response_key": args.response_key,
        }), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "traps":
        print(json.dumps(anti_hallucination(), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "checklist":
        print(json.dumps(checklist(), ensure_ascii=False, indent=2))
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
