"""Smoke tests: every public script module must import and core APIs must run."""

from __future__ import annotations

import importlib
import struct
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))

CORE_MODULES = [
    "sentinel_scan",
    "sentinel_pack",
    "sentinel_report",
    "redact",
    "rules_builtin",
    "rules_reverse",
    "rules_offensive",
    "reverse_engineering",
    "malware_analysis",
    "ctf_toolkit",
    "pentest_recon",
    "web_pentest",
    "pentest_suite",
    "ops_router",
    "ops_pipeline",
    "ops_case",
    "ops_modules",
    "ops_patterns",
    "ops_fallback",
    "ops_triage",
    "ops_algo",
    "ops_knowledge",
    "ops_framing",
    "ops_gpt56",
    "ops_sandbox",
    "ops_payloads",
    "ops_ctf_runner",
    "ops_surface_matrix",
    "ops_tool_index",
    "ops_journal",
    "ops_chain",
    "ops_method_packs",
    "ops_anon",
    "ops_report_contract",
    "ops_protocol_lab",
    "ops_obedience",
    "ops_instruct",
    "ops_pattern_db",
    "ops_essence_atlas",
    "ops_originality",
    "ops_doctor",
    "ops_trigger",
    "ops_ptes_lab",
    "ops_phase_kb",
    "ops_engagement",
    "ops_phase_runner",
    "ops_gap_audit",
    "codex_inject",
    "re_surface",
    "attack_toolkit",
    "attack_game",
    "attack_keygen",
    "attack_network",
    "attack_spider",
    "auditors.regex_sandbox",
    "auditors.variable_tracker",
    "auditors.tool_bridge",
]


class ModuleSmokeTests(unittest.TestCase):
    def test_all_modules_import(self):
        for name in CORE_MODULES:
            with self.subTest(module=name):
                mod = importlib.import_module(name)
                self.assertIsNotNone(mod)

    def test_compileall_scripts(self):
        import compileall
        ok = compileall.compile_dir(str(SCRIPTS), quiet=1, force=True)
        self.assertTrue(ok, "compileall failed for scripts/")

    def test_rule_catalog_size(self):
        from rules_builtin import all_builtin_rules, builtin_rules
        from rules_reverse import reverse_rules
        from rules_offensive import offensive_rules

        class R:
            def __init__(self, *a, **k):
                self.id = a[0]
                self.severity = a[2]
                self.category = a[3]

        def _rx(p, f=0):
            return p

        builtin = builtin_rules(R, _rx)
        reverse = reverse_rules(R, _rx)
        offensive = offensive_rules(R, _rx)
        combined = all_builtin_rules(R, _rx)

        self.assertEqual(len(builtin), 52)
        self.assertEqual(len(reverse), 100)
        self.assertGreaterEqual(len(offensive), 25)
        self.assertGreaterEqual(len(combined), 177)
        ids = [r.id for r in combined]
        self.assertEqual(len(ids), len(set(ids)), "duplicate rule ids")

    def test_reverse_engineering_pe_stub(self):
        import reverse_engineering as re_mod

        # Minimal MZ + PE stub (not a valid full PE, but exercise path)
        data = bytearray(512)
        data[0:2] = b"MZ"
        data[0x3C:0x40] = struct.pack("<I", 0x80)
        data[0x80:0x84] = b"PE\x00\x00"
        data[0x84:0x86] = struct.pack("<H", 0x14C)  # machine i386
        data[0x86:0x88] = struct.pack("<H", 0)  # sections
        data[0x80 + 20:0x80 + 22] = struct.pack("<H", 0)  # optional size
        # optional magic PE32 at optional header
        # Keep simple: analyze_binary should not crash
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "stub.exe"
            path.write_bytes(bytes(data) + b"IsDebuggerPresent\x00UPX0\x00")
            report = re_mod.analyze_binary(path)
            self.assertEqual(report.format.kind, "pe")
            self.assertTrue(report.sha256)
            d = report.to_dict()
            self.assertIn("entropy", d)

    def test_malware_analysis_text_sample(self):
        import malware_analysis as ma

        sample = """
        YOUR FILES HAVE BEEN ENCRYPTED
        Send 1 BTC to 1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa
        stratum+tcp://pool.minexmr.com:4444
        CreateRemoteThread VirtualAllocEx WriteProcessMemory
        beacon checkin to C2 server
        """
        profile = ma.analyze_text(sample, path="sample.txt")
        self.assertGreater(profile.ransomware_score, 0.0)
        d = profile.to_dict()
        self.assertIn("scores", d)
        self.assertIn("iocs", d)

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "note.txt"
            path.write_text(sample, encoding="utf-8")
            p2 = ma.triage_binary(path)
            self.assertEqual(p2.path, str(path))
            self.assertTrue(p2.sha256)

    def test_ctf_toolkit_flag_search(self):
        import ctf_toolkit as ctf

        flags = ctf.flag_search("hello flag{test_123} world")
        self.assertTrue(any("flag{" in f for f in flags))


if __name__ == "__main__":
    unittest.main()
