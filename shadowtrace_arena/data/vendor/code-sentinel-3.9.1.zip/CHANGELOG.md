# Changelog

## v3.9.1 — Gap audit pass (wiring completeness)

### Fixed / Added
- **tool-index v3**: auto-discover all `scripts/*.py` + complete ops/attack module list
- **ops_gap_audit.py**: formal project gap audit (version/skills/tool-index/suite/agents/tests)
- doctor: `tool_index_ops` + `gap_audit` gates
- suite: `python sentinel.py gap`
- smoke tests include ptes/engagement/runner/gap modules
- router S5/S6/S8 plans include phase_runner + engagement

## v3.9.0 — Phase runner closed loop (complete)

### Added
- **`ops_phase_runner.py`**: real phase execution with artifact writeback
  - L0–L6 + L1W handlers using `pentest_recon` / `web_pentest` / engagement builders
  - `run` (single phase + optional advance) · `auto` (until L6)
  - non-destructive L4/L5 (candidates + checklists only)
- Wired: `ops_engagement run|auto`, `sentinel.py engage run|auto`, doctor, tool-index, atlas
- Tests: `tests/test_ops_phase_runner.py` (mocked recon/web)
- Docs: engagement atlas phase execution map; AGENTS item 13

### Complete meaning
Plan → execute tools → write `ops-lab/targets/<slug>/` → manifest → advance → report

## v3.8.0 — Full engagement essence mine (one-shot, original)

### Added
- **`ops_engagement.py`**: complete original engagement suite covering remaining essences
  - target schema validate + phase materialize
  - port/service enum playbook matrix
  - web pretest blueprint
  - solutions global ledger merge
  - chain plan (parallel work packages)
  - report sections + delivery checklist
  - scope interview (one question at a time)
  - phase tool readiness
  - `essences` map (15+ essence→module)
- **`references/ops-engagement-atlas.md`**: full dig atlas (observe vs implement)
- Skill **`code-sentinel-engagement`** (9th skill)
- Suite: `python sentinel.py engage {essences|bootstrap|chain|enum|report|merge}`
- Tests: `tests/test_ops_engagement.py`
- Atlas domains: engagement-suite, service-enum-matrix, web-pretest-blueprint, solutions-ledger
- `ops_phase_kb` PHASE_TOPICS local topic packs

### Explicitly NOT imported
- Third-party knowledge corpora / PoC trees / skill symlink packages / report template prose

## v3.7.0 — Original PTES Lab (essence-learned, not copied)

### Added (original — no third-party text/corpus)
- **`ops_ptes_lab.py`**: Sentinel-native engagement lifecycle L0–L6 + optional L1W web pretest
  - per-target workspace under `ops-lab/targets/<slug>/`
  - manifest handoff, 8-item transition gate, URL shortcut, solutions ledger, report brief
- **`ops_phase_kb.py`**: prior-phase-output-driven local knowledge routing (ports/services/CVE → references)
- **`references/ops-ptes-lab.md`**: methodology note (essence table only)
- Skill **`code-sentinel-ptes`** (8th codex skill)
- Suite: `python sentinel.py ptes {phases|init|status|advance|kb|report}`
- Tests: `tests/test_ops_ptes_lab.py`
- Atlas: `domain.ptes-lab`, `method.phase-kb-drive`

### Design notes
- Studied public PTES lifecycle + multi-phase handoff *patterns* only
- Zero paste of external AGENTS/SKILL/KB/templates/PoC corpora

## v3.6.3 — Fix fusion gaps + self-repo hardening

### Fixed
- Tool index now registers `gpt56_reverse_tools` / `gpt56_crypto_helper` / `gpt56_pwn_template` (+ optional pip packages)
- Router: stronger APK/mobile cues; S2 plan includes `re_surface` + fusion helpers; mobile plan enrichment
- `pwn_template.py`: optional pwntools, pure packing helpers, `--check` / `--skeleton` CLI
- `crypto_helper.py`: no hard fail without pycryptodome/gmpy2; stdlib Fermat/small-e fallbacks; CLI
- `reverse_tools.py`: full CLI (`demo|detect|xor-brute|pe|strings|pattern`)
- `.sentinelignore` covers remaining ops_* false positives + fusion pack + references noise
- Project `.sentinel.toml` with fail_on=HIGH for self-repo CI

### Added
- doctor gates: `gpt56_helpers`, `tool_index_fusion`, `self_scan_ignore`
- tests: `test_gpt56_fusion.py` + router APK/mobile cases

## v3.6.2 — Fuse gpt56-reverse-pentest skill

### Added
- **Skill `gpt56-reverse-pentest`**: full-stack reverse + pentest methodology pack fused from Desktop CTF skill
- `codex-bundle/skills/gpt56-reverse-pentest/` (SKILL + 16 references + 3 helper scripts)
- Project mirrors: `references/gpt56-reverse-pentest/`, `scripts/gpt56_reverse_pentest/`
- Injected as **7th** Codex skill via `codex_inject.SKILL_NAMES`
- AGENTS fragment S2–S8 links + FULL-mode item 10
- Atlas source `skill.gpt56-reverse-pentest`
- doctor: `gpt56_rev_refs` + skills count = 7

## v3.6.1 — Originality gate (all product text Sentinel-native)

### Changed
- Scrubbed third-party product brand / corpus fingerprints from docs, comments, atlas IDs
- Atlas uses **domain.\*** / **skill.\*** native IDs only
- Added `ORIGINALITY.md` + `scripts/ops_originality.py` scan gate
- CTF protocol id → `sentinel-ctf-lab-v1`
- doctor enforces originality + atlas complete

## v3.6.0 — Full domain atlas (mandatory complete coverage)

### Added
- **`ops_essence_atlas.py`**: capability domains mapped → original modules; `coverage` must be complete
- Method packs expanded: ad8, browse5, ida4, r24, k8s5, re6, src5, game7, diagram3, docs3, escape5, mailbox4, kernel_drv4 (≥25 packs)
- Surfaces expanded: adcs, kerberos, lsass, dpapi, relay, mailbox, kernel-escape, browser-auto, static-ida, cli-r2, kernel-driver, src-bounty (≥45)
- pattern_db: elf / macho / ctf_pat / hw families
- doctor: essence_atlas + method_packs + surfaces gates

## v3.5.0 — Obedience / Lab Instruct / Pattern DB

### Added
- **`ops_obedience.py`**: Critical-First preamble, excuse rebuttals, MUST/NOW directives, completion gate, five skill shapes, code-words, baton next-prompt
- **`ops_instruct.py`**: Sentinel-**original** lab `model_instructions` generator + optional config.toml pointer (mechanism learned; **no** third-party unrestricted corpus)
- **`ops_pattern_db.py`**: Go/Rust/OLLVM/glibc-heap/AD edges/packer/.NET cue tables
- `codex_inject install --lab-instruct`
- doctor checks: obedience / lab_instruct / pattern_db

### Essence closed
Agent anti-skip · instruct inject mechanism · lang/AD/heap/ollvm heuristics — all original Sentinel modules.

## v3.4.0 — Deep Method Packs / Evidence / Protocol Lab

### Added (deep method packs, original)
- **`ops_method_packs.py`**: 13 phase engines — js5, pwn6, fw9, api10, edr6, llm7, mal6, supply6, patch5, mobile5, loop6, gap4, evidence3 + anti-analysis map
- **`ops_anon.py`**: writeup anonymization placeholders (IP/URL/token/hash/…)
- **`ops_report_contract.py`**: report templates, finding schema, hallucination traps, validate gate
- **`ops_protocol_lab.py`**: checksum candidates, one-field mutation replay plan, frame diff, sketch
- Wired into router notes, FULL trigger stack, tool-index, doctor, matrix skill, AGENTS

### Method essence (not source copy)
Observe→Rebuild JS · mitigations→remote-stable pwn · firmware extract→emulate→exploit · API 10-phase · EDR surface dual · LLM inject ladder · malware 6 · supply 6 · symbol migrate · mobile 5 · pentest loop · control-gap · black-box evidence triad

## v3.3.0 — Surface Matrix / Tool Index / Journal / Chain

### Added (surface matrix / tool index / journal / chain — original)
- **`ops_surface_matrix.py`**: multi-axis evidence-surface catalog (30+ surfaces) + route-before-work + re-route rules
- **`ops_tool_index.py`**: PATH/capability probe → `ops-lab/tool-index.json` (no invented paths)
- **`ops_journal.py`**: field journal append/search/suggest under `ops-lab/journal/`
- **`ops_chain.py`**: multi-stage chain planner C1–C6 (recon→cleanup) with success gates
- **`code-sentinel-matrix`** Codex skill (6th skill)
- `ops_router.classify` now attaches `surfaces` and may prepend surface tools
- `attack_game.game_research_brief` + feasibility tiers / server-authority note

### Essence (not copied)
Skill routing matrix · competition surface split · tool-index discipline · post-task journal evolution · attack-chain orchestration · game feasibility tiers — all rewritten as Sentinel-native modules.

## v3.2.0 — CTF Sandbox Runner

### Added
- **`scripts/ops_ctf_runner.py`**: CTF/靶场工作区续跑引擎（原创实现）
  - 契约：夹具默认、证据序、被动优先、单变量、完成标准
  - state：`progress.md` / `findings.md` / `task_plan.md` / `notes.md` / `references/project-state.md`
  - 领域 playbook：web / payment / backend / reverse / pwn / crypto / identity / misc
  - 受控爆破规则、无新证据不重复、密钥脱敏
  - 可选本地代理 TCP 探测（默认 `127.0.0.1:7897`，可环境变量覆盖；**不硬编码出口 IP**）
  - 头伪造目录（XFF 等）+ 身份字段单变量测试提示
- **`codex-bundle/skills/code-sentinel-ctf`**: 第五个 Codex skill
- 接入：`codex_inject` / `ops_doctor` / `ops_router` (S4/S6/S7) / `ops_trigger` FULL·LAB 栈
- AGENTS 片段新增「CTF / 靶场续跑」专节

### Essence
Original CTF lab operating model (workspace resume, evidence order, passive-first, domain focus, throttled probes).

## v3.1.0 — Public / software reverse surface

### Added
- **`re_surface.py`**: extract URLs/domains/IPs/emails/PDB/cloud markers/network APIs from binaries; PE version strings + Rich header; optional DNS/HTTP probe of public hosts.
- `analyze_software_re()` merges reverse_engineering + surface + playbook + defense.
- `reverse_engineering.analyze_binary` now embeds `network_surface` / `software_identity` / `rich_header`.
- Suite: `reverse --surface` / `--probe`.

## v3.0.0 — 可交付整理

### Changed
- 清理 `__pycache__` / `.pytest_cache` / ops-lab 运行产物
- 重写交付级 `README.md` + 中文 `使用说明.md`
- 强化 `.gitignore`，版本号 **3.0.0**
- 保留全部功能代码；删除仅生成物与缓存，不删核心能力

## v2.6.1 — 中文一键启动/卸载（带平台前缀）

### Added
- **Windows**：`Windows启动.bat` / `Windows启动.py` / `Windows卸载.bat` / `Windows卸载.py` / `Windows状态.bat`
- **Linux**：`Linux启动.sh` / `Linux卸载.sh`
- **macOS**：`macOS启动.command` / `macOS卸载.command`
- 内部仍调用 `scripts/codex_inject.py`；触发词 **豆包大人**

## v2.6.0 — Codex inject + Trigger Word

### Added
- **`scripts/codex_inject.py`**: install/uninstall/status into `CODEX_HOME` (managed AGENTS block + 4 skills + env pointer + backup).
- **`codex-bundle/`**: `AGENTS.fragment.md` + skills `code-sentinel{,-gpt56,-ops,-payload}`.
- **`scripts/ops_trigger.py`**: Trigger Word engine (`CS-ON` / `破甲` / `全力分析` / `暗影` / `只扫代码` / `CS-OFF`).
- Suite: `codex`, `trigger` subcommands.
- Docs: `references/codex-inject.md`.

### Essence
Original Codex inject design (managed AGENTS markers, skills dir, backup, restart); plain-text bundle for audit.

## v2.5.2 — Polish / doctor / entry

### Added
- Root entry `sentinel.py` and `VERSION` / lightweight `pyproject.toml`
- **`ops_doctor.py`** + suite `doctor` — aggregate health check (imports, rules, gpt56, sandbox, payloads, framing)
- CI step: doctor before unit tests
- Pipeline auto-framing of query; triage embeds evidence stack + workflow next
- GPT-5.6 boot checks payloads + root entry
- web_pentest `--passive` correctly toggles active probes

### Fixed
- Suite help lists all ops subcommands; version flag on CLI

## v2.5.1 — Lab payload task studio (original)

### Added
- **`ops_payloads.py`**: payload blueprint catalog (remote agent, persistence, cred audit, web inject probes, injection lab, stage-0 loader, encrypt channel, heartbeat).
- Packaging modes: direct / placeholder / repair / **progressive multi-round**.
- Soft lexicon for payload wording; GPT-5.6 `session` integration; suite `payload`.
- Defense requirements mandatory on every blueprint.

### Essence
Learned packaging strategies from public prompt craft (placeholder, repair, progressive) without copying third-party prompt corpora or fixed weapon essays.

## v2.5.0 — Dual-layer sandbox protocol (original)

### Added
- **`ops_sandbox.py`**: dual-layer lab premise (persuade-with-context), fixture policy, 8-level evidence stack, 6-step workflow discipline, task packaging modes (`direct` / `placeholder` / `repair`).
- GPT-5.6 sessions auto-attach sandbox overlay; `--package-mode` / `--no-sandbox`.
- Suite: `pentest_suite sandbox`.
- Docs: `references/ops-sandbox-protocol.md`; gpt56-core evidence+workflow rules.

### Essence (not a prompt dump)
Learned from public “sandbox premise / dual cognitive layers / evidence priority / passive-first workflow / placeholder & repair packaging” patterns; **no verbatim third-party jailbreak corpora**.

## v2.4.0 — GPT-5.6 first

### Added
- **`prompts/gpt56-core.md`**: slim system entry for GPT-5.6 strict classifiers.
- **`prompts/config.gpt56.json`**: model profile, boot checklist, recovery levels.
- **`agents/gpt56.yaml`**: primary agent; `openai.yaml` / `claude.yaml` aligned to same contract.
- **`scripts/ops_gpt56.py`**: `boot` / `session` / `paste` / `config` / `prompt`.
- **`references/gpt56-profile.md`**: profile documentation.
- Suite: `pentest_suite gpt56`.
- SKILL/README default model target set to **GPT-5.6**.

## v2.3.1 — Ops framing (破甲精髓原创)

### Added
- **`ops_framing.py`**: technical reframing dictionary, refusal detection, L1–L5 recovery, few-shot skeletons, agent preamble.
- Router auto-reframes colloquial queries before signal scoring.
- Suite: `pentest_suite frame`.
- Agent instructions updated for framing recovery loop.

### Note
Implements the *engineering essence* of research-task reframing / multi-step recovery; **does not copy** external KB-33 prose or persona scripts.

## v2.3.0 — Ops full-depth (original)

### Added
- **25 module playbooks** (`ops_modules.py` M01–M25): PE/ELF/Android/Web/AD/C2/Pwn/Game/Firmware…
- **6 tool patterns** (`ops_patterns.py` P-A…P-F)
- **Fallback executor** (`ops_fallback.py`) with PATH probing / optional run
- **Deep triage** (`ops_triage.py`): magic, hashes, entropy, PE/ELF light, packer sections
- **Algorithm stage** (`ops_algo.py`): crypto constants, encoding, XOR probe, decrypt sketch
- **Knowledge tables** (`ops_knowledge.py`): ABI, magic, anti-debug, report sections
- Pipeline stages: **TRIAGE→STATIC→DYNAMIC→ALGORITHM→SYNTHESIS→REPORT**
- Case report expanded to **8 sections** (sample→defense→reproduce)
- Suite: `pentest_suite modules`

### Explicitly not ported (verbatim)
External KB chapter prose and persona IDs. Framing *essence* later added in v2.3.1 as original `ops_framing`.

## v2.2.0 — Ops layer (original fusion)

### Added
- **`ops_router.py`**: Sentinel-native S1–S8 signal classification, tool plan, fallback map, self-check.
- **`ops_pipeline.py`**: five-stage TRIAGE→STATIC→DYNAMIC→SYNTHESIS→REPORT orchestration over local modules.
- **`ops_case.py`**: `SEN-YYYYMMDD-XXXX` case IDs + `ops-lab/` workspace.
- **`references/ops-method.md`**: documents absorbed engineering patterns without external KB/prompt text.
- Suite commands: `pentest_suite ops` / `pentest_suite pipeline`.

### Note
Inspired by public “slim-core + signal routing + staged workflow + fallback + case archive” patterns; **no copied prompts, KB chapters, persona, or jailbreak kits**.

## v2.1.1 — No soft limits

### Changed
- Removed all product “Boundaries / authorized-only / template-only” framing from README/SKILL/module docs.
- **Web engine is active by default**: SQLi, XSS, LFI, open-redirect, dir brute, credential spray.
- **Recon**: `--top-ports` / `--all-ports` full TCP range modes.
- **`pentest_suite attack`**: spider / network / keygen / crack / game / toolkit dispatch.

## v2.1.0 — Reverse & pentest enhancement

### Added
- **PE deep triage**: import table / imphash, exports, per-section entropy, overlay size, compile timestamp, capability map (injection/C2/persistence/…).
- **`pentest_recon.py`**: multi-thread port scan, banner grab, DNS A/PTR, HTTP fingerprint + security headers, TLS cert inspect.
- **`web_pentest.py`**: headers, cookies, CORS, methods, paths, XSS reflection, plus active attack probes.
- **`pentest_suite.py`**: unified CLI (`recon|web|reverse|malware|ctf|tools|full`).
- **Offensive rules +5**: SQLi/XSS payload crafting, subdomain recon tooling, AD tooling, C2 frameworks (30 offensive / **182** total).
- Expanded **OFFENSIVE_TOOLS** registry (nuclei, ffuf, subfinder, amass, impacket, bloodhound, …).
- Malware triage **enriched** with reverse_engineering structural signals (imphash, capabilities, packers).

### Research basis
- Static PE/ELF triage & packing signals (section entropy, overlay, imphash/IAT).
- OWASP recon / web testing checklist phases (info gathering → misconfig → session → input).
- Stdlib-only port/banner/TLS/header scanners for air-gapped CI and labs.

## v2.0.1 — Integrity fix

### Fixed
- Restored corrupted `malware_analysis.py` (markdown fence broke set literal; completed triage APIs).
- Restored corrupted `reverse_engineering.py` (agent cache hygiene text truncation; full PE/ELF/DEX/Mach-O triage).
- Aligned docs to **177** rules (52 + 100 + 25); fixed `references/ai-output-schema.md` path.
- Expanded `.sentinelignore` to exclude rule catalogs / lab modules from self-audit noise.
- Added import/compile smoke tests and CI syntax gate; removed orphan legacy pyc artifacts.

## v2.0.0 — Code Sentinel

Complete rewrite and expansion. New identity, no legacy traces.

### Added
- **Reverse engineering engine** (`reverse_engineering.py`): PE/ELF/DEX/Mach-O parsing, entropy-based packing detection, anti-debug/anti-VM identification, crypto constant scanning, string extraction, license/keygen pattern analysis.
- **Malware analysis engine** (`malware_analysis.py`): Ransomware/RAT/cryptominer detection, IoC extraction (IPs, domains, hashes, wallets, mutexes), YARA rule generation, persistence mechanism detection, process injection patterns.
- **CTF toolkit** (`ctf_toolkit.py`): Challenge type auto-detection, encoding cascade decoder, classical cipher breaker (Caesar/ROT13/Atbash), RSA attack co-processor, PWN exploit skeleton generator.
- **Reverse engineering rules** (`rules_reverse.py`): 100 new rules covering anti-debug, anti-VM, packing, license/keygen, hooking frameworks, rootkits, ransomware, RATs, miners, Android/Web RE, CTF attack patterns.
- **Extended tool bridge** (`tool_bridge.py`): 30+ reverse engineering tool integrations including jadx, Frida, YARA, binary patch, APK decompile automation.
- **Combined rule catalog**: `all_builtin_rules()` merges standard + reverse + offensive rules (177 total).

### Changed
- Complete rebranding and project identity refresh.
- Scanner engine now loads combined rule set by default.
- All module names and references updated to new convention.
- Default output filenames use `sentinel-*` prefix.
