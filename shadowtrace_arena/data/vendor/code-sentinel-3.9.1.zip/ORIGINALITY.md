# Code Sentinel 原创性声明

本仓库 **全部产品代码、提示片段、Skill 文案、方法包与图谱条目** 均为 **Code Sentinel 原创实现与原创表述**。

## 允许

- 公开安全领域的**通用技术概念**（如证据优先级、CTF 工作流阶段、PE 结构术语）
- 自有命名：`CODE-SENTINEL`、`ops_*`、`code-sentinel-*`、`豆包大人` 触发词
- 对外部产品的**机制观察**经抽象后，用独立代码与文案重新实现（不粘贴原文）

## 禁止入库

- 第三方 jailbreak / 无限制 system prompt 全文
- 第三方 SKILL.md / AGENTS / KB 章节原文拷贝
- 第三方案例日记、payload 语料整库搬运
- 第三方硬编码出口 IP、账号、闭源启动器逻辑

## 自检

```bash
python scripts/ops_originality.py scan
python scripts/ops_doctor.py
```

`ops_originality.py scan` 与 doctor 的 `originality` 项必须通过。

## 版本

自 **v3.6.1** 起，文档与注释中不再保留第三方产品对照表或外部库品牌溯源 ID；能力域一律用 Sentinel 自有 ID 描述。
