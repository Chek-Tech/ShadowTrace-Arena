#!/usr/bin/env python3
"""
Binary reverse engineering analysis engine.

PE/ELF/Mach-O/DEX header parsing, entropy-based packing detection,
anti-debug/anti-VM identification, crypto constant scanning,
string extraction, import table analysis, keygen/license detection.
Pure stdlib -- zero dependencies.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
import struct
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

# ============================================================================
# Magic numbers
# ============================================================================
PE_MAGIC = b"MZ"
PE_SIG = b"PE\x00\x00"
PE32_MAGIC = 0x10B
PE32PLUS_MAGIC = 0x20B
ELF_MAGIC = b"\x7fELF"
MACHO_FAT = 0xCAFEBABE
MACHO_64_MAGIC = 0xFEEDFACF
MACHO_32_MAGIC = 0xFEEDFACE
MACHO_64_CIGAM = 0xCFFAEDFE
MACHO_32_CIGAM = 0xCEFAEDFE
DEX_MAGIC = b"dex\n"

# ============================================================================
# Packer signatures (magic bytes / section names)
# ============================================================================
PACKER_SIGS: dict[str, list[bytes]] = {
    "UPX": [b"UPX0", b"UPX1", b"UPX!", b"\x55\x50\x58"],
    "ASPack": [b".aspack", b"ASPack"],
    "ASProtect": [b".ASProtect", b"ASProtect"],
    "Themida": [b"Themida", b"WinLicense"],
    "VMProtect": [b".vmp", b"VMProtect", b".vmp0", b".vmp1"],
    "Enigma": [b"Enigma"],
    "MoleBox": [b"MoleBox"],
    "Obsidium": [b"Obsidium"],
    "PECompact": [b"PECompact", b"PEC2", b"pecompact2", b".pec2"],
    "Petite": [b"Petite"],
    "MPRESS": [b"MPRESS", b".MPRESS"],
    "NSPack": [b"NSPack"],
    "FSG": [b"FSG!", b".fsg"],
    "MEW": [b"MEW"],
    "yoda": [b"yoda", b"yC"],
    "Armadillo": [b"Armadillo", b"SILENT"],
    "tElock": [b"tElock"],
    "PESpin": [b"PESpin"],
    "DexGuard": [b"DexGuard"],
    "DexProtector": [b"DexProtector"],
    "Bangcle": [b"libsecexe", b"libDexHelper", b"secexe"],
    "Qihoo360": [b"libjiagu", b"jiagu", b"libqihoo"],
    "TencentLegu": [b"libtup", b"libshella", b"libshellx"],
    "AliProtect": [b"aliprotect", b"libmobisec"],
    "NetEase": [b"libnesec", b"libAP"],
    "IOSSideload": [b"FridaGadget", b"Substitute", b"CydiaSubstrate"],
}

# ============================================================================
# Anti-debug / Anti-VM API names (as byte strings for binary scanning)
# ============================================================================
ANTIDEBUG_APIS: dict[bytes, str] = {
    b"IsDebuggerPresent": "IsDebuggerPresent",
    b"CheckRemoteDebuggerPresent": "CheckRemoteDebuggerPresent",
    b"NtQueryInformationProcess": "NtQueryInformationProcess",
    b"OutputDebugStringA": "OutputDebugStringA",
    b"OutputDebugStringW": "OutputDebugStringW",
    b"NtSetInformationThread": "NtSetInformationThread",
    b"DebugActiveProcess": "DebugActiveProcess",
    b"DbgUiRemoteBreakin": "DbgUiRemoteBreakin",
    b"ZwQueryInformationProcess": "ZwQueryInformationProcess",
    b"BlockInput": "BlockInput",
    b"GetTickCount": "GetTickCount",
    b"QueryPerformanceCounter": "QueryPerformanceCounter",
    b"RDTSC": "RDTSC",
    b"__rdtsc": "RDTSC intrinsic",
    b"ptrace": "ptrace",
    b"PTRACE_TRACEME": "PTRACE_TRACEME",
    b"PT_DENY_ATTACH": "PT_DENY_ATTACH",
    b"syscall": "syscall",
    b"int 0x80": "int 0x80",
    b"int3": "int3",
    b"int 0x2d": "int 0x2d",
    b"icebp": "icebp",
}

ANTIVM_SIGS: dict[bytes, str] = {
    b"VMware": "VMware",
    b"VMXh": "VMware backdoor",
    b"VBox": "VirtualBox",
    b"VBOX": "VirtualBox",
    b"QEMU": "QEMU",
    b"Xen": "Xen",
    b"Hyper-V": "Hyper-V",
    b"Parallels": "Parallels",
    b"Sandboxie": "Sandboxie",
    b"\\\\.\\VBoxGuest": "VBox Guest",
    b"\\\\.\\vmci": "VMware VMCI",
    b"\\\\.\\HGFS": "VMware HGFS",
    b"vmtoolsd": "VMware Tools",
    b"VBoxService": "VBox Service",
    b"vboxservice": "vboxservice",
    b"vboxtray": "vboxtray",
}

# ============================================================================
# Dangerous / suspicious Windows API imports
# ============================================================================
DANGEROUS_IMPORTS: dict[bytes, str] = {
    b"VirtualAlloc": "dynamic memory allocation",
    b"VirtualAllocEx": "remote memory allocation",
    b"VirtualProtect": "memory protection change",
    b"VirtualProtectEx": "remote memory protection",
    b"WriteProcessMemory": "cross-process write",
    b"ReadProcessMemory": "cross-process read",
    b"CreateRemoteThread": "remote thread injection",
    b"RtlCreateUserThread": "remote thread (ntdll)",
    b"NtCreateThreadEx": "remote thread (nt)",
    b"QueueUserAPC": "APC injection",
    b"SetWindowsHookEx": "global hook",
    b"SetWinEventHook": "event hook",
    b"OpenProcess": "process open",
    b"OpenThread": "thread open",
    b"AdjustTokenPrivileges": "privilege escalation",
    b"LookupPrivilegeValue": "privilege lookup",
    b"CreateProcessA": "process creation",
    b"CreateProcessW": "process creation",
    b"ShellExecuteA": "shell execute",
    b"WinExec": "execute",
    b"URLDownloadToFile": "download file",
    b"WinHttpOpen": "HTTP communication",
    b"InternetOpenA": "internet open",
    b"InternetConnectA": "internet connect",
    b"RegSetValueEx": "registry write",
    b"RegCreateKeyEx": "registry create",
    b"CreateService": "service creation",
    b"StartService": "service start",
    b"CryptEncrypt": "encryption",
    b"CryptDecrypt": "decryption",
    b"CryptGenKey": "key generation",
    b"LoadLibrary": "library load",
    b"GetProcAddress": "dynamic resolve",
    b"LdrLoadDll": "ntdll load",
    b"NtUnmapViewOfSection": "process hollowing",
    b"ZwUnmapViewOfSection": "process hollowing",
    b"SetThreadContext": "thread context",
    b"ResumeThread": "thread resume",
    b"NtResumeThread": "thread resume (nt)",
    b"GetThreadContext": "thread context get",
}

# ============================================================================
# Known crypto constants (magic initialization vectors, round constants)
# ============================================================================
CRYPTO_CONSTANTS: dict[bytes, str] = {
    bytes([0x63, 0x7c, 0x77, 0x7b]): "AES S-Box",
    bytes([0x52, 0x09, 0x6a, 0xd5]): "AES Inv-S-Box",
    bytes([0x67, 0x45, 0x23, 0x01]): "MD5/SHA1 init (A)",
    bytes([0xef, 0xcd, 0xab, 0x89]): "MD5/SHA1 init (B)",
    bytes([0x98, 0xba, 0xdc, 0xfe]): "SHA1 init (C)",
    bytes([0x10, 0x32, 0x54, 0x76]): "SHA1 init (D)",
    bytes([0xc3, 0xd2, 0xe1, 0xf0]): "SHA1 init (E)",
    bytes([0x6a, 0x09, 0xe6, 0x67]): "SHA-256 init H0",
    bytes([0xbb, 0x67, 0xae, 0x85]): "SHA-256 init H1",
    bytes([0x3c, 0x6e, 0xf3, 0x72]): "SHA-256 init H2",
    bytes([0xa5, 0x4f, 0xf5, 0x3a]): "SHA-256 init H3",
    bytes([0x51, 0x0e, 0x52, 0x7f]): "SHA-256 init H4",
    bytes([0x9b, 0x05, 0x68, 0x8c]): "SHA-256 init H5",
    bytes([0x1f, 0x83, 0xd9, 0xab]): "SHA-256 init H6",
    bytes([0x5b, 0xe0, 0xcd, 0x19]): "SHA-256 init H7",
    b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/": "Base64 alphabet",
    bytes([0x9e, 0x37, 0x79, 0xb9]): "TEA delta constant",
    bytes([0x00, 0x00, 0x00, 0x00, 0x77, 0x07, 0x30, 0x96]): "CRC32 table",
    bytes([0x24, 0x3f, 0x6a, 0x88]): "Blowfish pi init",
}

# ============================================================================
# Interesting string patterns for reverse engineering
# ============================================================================
INTERESTING_STRINGS_RE: list[tuple[str, str]] = [
    (r"https?://[^\s\"'<>]+", "URL"),
    (r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}", "IP address"),
    (r"(?i)(password|passwd|pwd|secret|token|key|api_key)\s*[=:]\s*\S", "credential"),
    (r"(?i)(SELECT|INSERT|UPDATE|DELETE|DROP)\s", "SQL"),
    (r"(?i)(cmd\.exe|/bin/sh|/bin/bash|powershell)", "shell"),
    (r"(?i)(regsvr32|rundll32|mshta|wmic|cscript|wscript)", "LOLBin"),
    (r"(?i)(malware|trojan|backdoor|ransom|exploit|payload|shellcode)", "threat keyword"),
    (r"(?i)(license|serial|activation|registration|keygen|crack)", "license/keygen"),
    (r"(?i)(trial|expir|evaluation|demo|time limit|days left)", "trial"),
    (r"(?i)(hook|detour|inline.*hook|iat.*hook|eat.*hook)", "hook"),
    (r"(?i)(frida|xposed|substrate|magisk|cydia)", "dynamic instrumentation"),
    (r"(?i)(debug|dbg|olly|ida|windbg|x64dbg|x32dbg|hopper)", "debugger"),
    (r"(?i)(vmware|vbox|qemu|xen|sandbox|virtual)", "VM/sandbox"),
    (r"\b[A-Fa-f0-9]{32,64}\b", "hex hash"),
    (r"\b[A-Za-z0-9+/]{40,}={0,2}\b", "possible base64"),
    (r"(?i)(CreateFile|ReadFile|WriteFile|DeleteFile|MoveFile)", "file I/O"),
    (r"(?i)(socket|connect|send|recv|bind|listen|accept)", "network"),
    (r"(?i)(mutex|event|semaphore|\\\\.\\pipe\\)", "IPC/sync"),
]

# ============================================================================
# License/keygen detection patterns
# ============================================================================
LICENSE_PATTERNS: dict[str, list[str]] = {
    "serial_algorithm": [
        r"(?i)(serial|sn|key|license|activation|register|reg).*(check|verify|validate|compute|gen)",
        r"(?i)(check|verify|validate|compute|gen).*(serial|sn|key|license|activation|register)",
        r"(?i)(generate).*(serial|key|license|activation)",
        r"(?i)(machine|hardware).*(id|fingerprint|hash)",
    ],
    "time_trial": [
        r"(?i)(trial|expir|time.*limit|days.*left|remaining.*day)",
        r"(?i)(GetSystemTime|GetLocalTime|time\(NULL\)|time\(0\))",
        r"(?i)(install.*date|first.*run|created.*at)",
        r"(?i)(registry|file).*(install.*date|first.*run|timestamp)",
    ],
    "network_verify": [
        r"(?i)(http.*verify|server.*check|online.*activation|phone.*home)",
        r"(?i)(WinHttpOpen|InternetOpen|URLDownload|curl_easy)",
        r"(?i)(socket|connect|send).*(check|server|verify|license|auth)",
    ],
    "anti_patch": [
        r"(?i)(checksum|crc|crc32|md5|sha|hash).*(code|section|text|memory|image)",
        r"(?i)(self.*check|integrity.*check|tamper.*detect|anti.*patch)",
        r"(?i)(crc|crc32|adler|checksum).*(?:code|text|memory|image|section|file)",
    ],
    "strcmp_gate": [
        r"(?i)(strcmp|strncmp|memcmp|lstrcmp|wcscmp).*(serial|key|license|password)",
        r"(?i)(serial|key|license|password).*(strcmp|strncmp|memcmp|lstrcmp|wcscmp)",
    ],
}


# ============================================================================
# Data classes
# ============================================================================
@dataclass
class BinaryFormat:
    kind: str = "unknown"
    arch: str = "unknown"
    bits: int = 0
    endian: str = "unknown"
    entry_point: int = 0
    sections: list[dict[str, Any]] = field(default_factory=list)
    imports: list[str] = field(default_factory=list)
    import_dlls: list[str] = field(default_factory=list)
    import_functions: list[dict[str, str]] = field(default_factory=list)
    exports: list[str] = field(default_factory=list)
    imphash: str = ""
    compile_timestamp: int = 0
    overlay_size: int = 0
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class ReverseReport:
    path: str
    sha256: str = ""
    md5: str = ""
    size: int = 0
    format: BinaryFormat = field(default_factory=BinaryFormat)
    entropy: float = 0.0
    section_entropy: list[dict[str, Any]] = field(default_factory=list)
    is_packed: bool = False
    packers: list[str] = field(default_factory=list)
    anti_debug: list[str] = field(default_factory=list)
    anti_vm: list[str] = field(default_factory=list)
    dangerous_apis: list[dict[str, str]] = field(default_factory=list)
    crypto_constants: list[str] = field(default_factory=list)
    interesting_strings: list[dict[str, str]] = field(default_factory=list)
    license_patterns: list[dict[str, str]] = field(default_factory=list)
    capability_map: dict[str, list[str]] = field(default_factory=dict)
    network_surface: dict[str, Any] = field(default_factory=dict)
    software_identity: dict[str, Any] = field(default_factory=dict)
    rich_header: dict[str, Any] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": self.path,
            "sha256": self.sha256,
            "md5": self.md5,
            "size": self.size,
            "format": {
                "kind": self.format.kind,
                "arch": self.format.arch,
                "bits": self.format.bits,
                "endian": self.format.endian,
                "entry_point": self.format.entry_point,
                "sections": self.format.sections,
                "imports": self.format.imports[:100],
                "import_dlls": self.format.import_dlls[:50],
                "import_functions": self.format.import_functions[:200],
                "exports": self.format.exports[:100],
                "imphash": self.format.imphash,
                "compile_timestamp": self.format.compile_timestamp,
                "overlay_size": self.format.overlay_size,
                "details": self.format.details,
            },
            "entropy": round(self.entropy, 3),
            "section_entropy": self.section_entropy,
            "is_packed": self.is_packed,
            "packers": self.packers,
            "anti_debug": self.anti_debug,
            "anti_vm": self.anti_vm,
            "dangerous_apis": self.dangerous_apis[:50],
            "crypto_constants": self.crypto_constants,
            "interesting_strings": self.interesting_strings[:80],
            "license_patterns": self.license_patterns[:40],
            "capability_map": self.capability_map,
            "network_surface": self.network_surface,
            "software_identity": self.software_identity,
            "rich_header": self.rich_header,
            "notes": self.notes,
        }


# ============================================================================
# Helpers
# ============================================================================
def shannon_entropy(data: bytes) -> float:
    if not data:
        return 0.0
    counts = {b: data.count(b) for b in set(data)}
    total = len(data)
    return -sum((c / total) * math.log2(c / total) for c in counts.values())


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def file_md5(path: Path) -> str:
    h = hashlib.md5()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _rva_to_offset(rva: int, sections: list[dict[str, Any]]) -> int | None:
    """Map PE RVA to raw file offset using section headers."""
    for sec in sections:
        vaddr = int(sec.get("virtual_address") or 0)
        vsize = int(sec.get("virtual_size") or 0)
        raw = int(sec.get("raw_ptr") or 0)
        raw_size = int(sec.get("raw_size") or 0)
        size = max(vsize, raw_size)
        if vaddr <= rva < vaddr + size:
            return raw + (rva - vaddr)
    return None


def _read_c_string(data: bytes, offset: int, max_len: int = 256) -> str:
    if offset < 0 or offset >= len(data):
        return ""
    end = data.find(b"\x00", offset, offset + max_len)
    if end < 0:
        end = min(len(data), offset + max_len)
    return data[offset:end].decode("ascii", errors="ignore")


# MITRE-ish capability buckets from imported API names
_CAPABILITY_APIS: dict[str, tuple[str, ...]] = {
    "process_injection": (
        "VirtualAllocEx", "WriteProcessMemory", "CreateRemoteThread",
        "NtCreateThreadEx", "QueueUserAPC", "RtlCreateUserThread",
        "NtMapViewOfSection", "NtUnmapViewOfSection",
    ),
    "persistence": (
        "RegSetValueEx", "RegCreateKeyEx", "CreateService", "StartService",
        "ITaskService", "SetWindowsHookEx",
    ),
    "network_c2": (
        "WinHttpOpen", "WinHttpConnect", "InternetOpen", "InternetConnect",
        "URLDownloadToFile", "HttpSendRequest", "socket", "connect", "WSAStartup",
    ),
    "crypto": (
        "CryptEncrypt", "CryptDecrypt", "CryptGenKey", "BCryptEncrypt",
        "CryptAcquireContext", "CryptImportKey",
    ),
    "anti_analysis": (
        "IsDebuggerPresent", "CheckRemoteDebuggerPresent", "NtQueryInformationProcess",
        "OutputDebugString", "GetTickCount", "QueryPerformanceCounter",
    ),
    "privilege": (
        "AdjustTokenPrivileges", "LookupPrivilegeValue", "OpenProcessToken",
        "ImpersonateLoggedOnUser", "DuplicateTokenEx",
    ),
    "file_ops": (
        "CreateFile", "WriteFile", "ReadFile", "DeleteFile", "MoveFile",
        "CopyFile", "FindFirstFile",
    ),
}


def map_capabilities(api_names: list[str]) -> dict[str, list[str]]:
    """Map imported/seen APIs to high-level offensive capabilities."""
    lower_map = {a.lower(): a for a in api_names}
    out: dict[str, list[str]] = {}
    for cap, apis in _CAPABILITY_APIS.items():
        hits = []
        for api in apis:
            for key, original in lower_map.items():
                if api.lower() in key:
                    hits.append(original)
                    break
        if hits:
            out[cap] = hits
    return out


def extract_ascii_strings(data: bytes, min_len: int = 4) -> list[str]:
    pattern = re.compile(rb"[\x20-\x7e]{%d,}" % min_len)
    return [m.group().decode("ascii", errors="ignore") for m in pattern.finditer(data)]


def extract_utf16le_strings(data: bytes, min_len: int = 4) -> list[str]:
    results: list[str] = []
    i = 0
    n = len(data)
    while i + 2 * min_len <= n:
        chars: list[str] = []
        j = i
        while j + 1 < n:
            lo, hi = data[j], data[j + 1]
            if hi == 0 and 32 <= lo < 127:
                chars.append(chr(lo))
                j += 2
            else:
                break
        if len(chars) >= min_len:
            results.append("".join(chars))
            i = j
        else:
            i += 2
    return results


# ============================================================================
# Format parsers
# ============================================================================
def parse_pe(data: bytes) -> BinaryFormat:
    fmt = BinaryFormat(kind="pe", endian="little")
    if len(data) < 0x40 or data[:2] != PE_MAGIC:
        return fmt
    e_lfanew = struct.unpack_from("<I", data, 0x3C)[0]
    if e_lfanew + 24 > len(data) or data[e_lfanew:e_lfanew + 4] != PE_SIG:
        fmt.details["error"] = "invalid PE signature"
        return fmt

    machine = struct.unpack_from("<H", data, e_lfanew + 4)[0]
    num_sections = struct.unpack_from("<H", data, e_lfanew + 6)[0]
    timestamp = struct.unpack_from("<I", data, e_lfanew + 8)[0]
    opt_size = struct.unpack_from("<H", data, e_lfanew + 20)[0]
    characteristics = struct.unpack_from("<H", data, e_lfanew + 22)[0]
    opt_off = e_lfanew + 24
    if opt_off + 2 > len(data):
        return fmt

    magic = struct.unpack_from("<H", data, opt_off)[0]
    pe32plus = magic == PE32PLUS_MAGIC
    if pe32plus:
        fmt.bits = 64
        if opt_off + 24 <= len(data):
            fmt.entry_point = struct.unpack_from("<I", data, opt_off + 16)[0]
        dd_off = opt_off + 112  # DataDirectory start for PE32+
    elif magic == PE32_MAGIC:
        fmt.bits = 32
        if opt_off + 28 <= len(data):
            fmt.entry_point = struct.unpack_from("<I", data, opt_off + 16)[0]
        dd_off = opt_off + 96   # DataDirectory start for PE32
    else:
        fmt.details["optional_magic"] = magic
        dd_off = None

    machines = {
        0x14C: ("x86", 32),
        0x8664: ("x86_64", 64),
        0x1C0: ("arm", 32),
        0xAA64: ("arm64", 64),
        0x200: ("ia64", 64),
    }
    if machine in machines:
        fmt.arch, bits_hint = machines[machine]
        if not fmt.bits:
            fmt.bits = bits_hint

    fmt.compile_timestamp = timestamp
    fmt.details["characteristics"] = hex(characteristics)
    fmt.details["dll"] = bool(characteristics & 0x2000)
    fmt.details["executable_image"] = bool(characteristics & 0x0002)

    # Section table
    sec_off = opt_off + opt_size
    max_raw_end = 0
    for i in range(min(num_sections, 96)):
        off = sec_off + i * 40
        if off + 40 > len(data):
            break
        name = data[off:off + 8].split(b"\x00", 1)[0].decode("latin-1", errors="replace")
        vsize, vaddr, raw_size, raw_ptr = struct.unpack_from("<IIII", data, off + 8)
        chars = struct.unpack_from("<I", data, off + 36)[0]
        sec_blob = b""
        if raw_ptr and raw_size and raw_ptr + raw_size <= len(data):
            sec_blob = data[raw_ptr: raw_ptr + min(raw_size, 2_000_000)]
            max_raw_end = max(max_raw_end, raw_ptr + raw_size)
        ent = shannon_entropy(sec_blob) if sec_blob else 0.0
        fmt.sections.append({
            "name": name,
            "virtual_size": vsize,
            "virtual_address": vaddr,
            "raw_size": raw_size,
            "raw_ptr": raw_ptr,
            "characteristics": hex(chars),
            "executable": bool(chars & 0x20000000),
            "writable": bool(chars & 0x80000000),
            "entropy": round(ent, 3),
        })

    # Overlay: bytes past last section raw end
    if max_raw_end and max_raw_end < len(data):
        fmt.overlay_size = len(data) - max_raw_end
        fmt.details["overlay_entropy"] = round(
            shannon_entropy(data[max_raw_end: max_raw_end + min(2_000_000, fmt.overlay_size)]), 3
        )

    # Parse import directory (DataDirectory[1]) for real IAT / imphash
    import_funcs: list[dict[str, str]] = []
    import_dlls: list[str] = []
    if dd_off is not None and dd_off + 16 <= len(data):
        # Optional header number of RVA/sizes at +92 (PE32) / +108 (PE32+)
        num_dd = struct.unpack_from("<I", data, opt_off + (108 if pe32plus else 92))[0] if (
            opt_off + (112 if pe32plus else 96) <= len(data)
        ) else 0
        if num_dd >= 2:
            imp_rva, imp_size = struct.unpack_from("<II", data, dd_off + 8)  # index 1
            if imp_rva:
                imp_off = _rva_to_offset(imp_rva, fmt.sections)
                if imp_off is not None:
                    imphash_parts: list[str] = []
                    desc = imp_off
                    for _ in range(256):
                        if desc + 20 > len(data):
                            break
                        oft, _ts, _fwd, name_rva, ft = struct.unpack_from("<IIIII", data, desc)
                        if oft == 0 and name_rva == 0 and ft == 0:
                            break
                        dll_off = _rva_to_offset(name_rva, fmt.sections)
                        dll_name = _read_c_string(data, dll_off or 0).lower()
                        if dll_name:
                            import_dlls.append(dll_name)
                        thunk_rva = oft or ft
                        thunk_off = _rva_to_offset(thunk_rva, fmt.sections) if thunk_rva else None
                        if thunk_off is not None:
                            step = 8 if pe32plus else 4
                            for __ in range(512):
                                if thunk_off + step > len(data):
                                    break
                                if pe32plus:
                                    val = struct.unpack_from("<Q", data, thunk_off)[0]
                                    ordinal_flag = 0x8000000000000000
                                else:
                                    val = struct.unpack_from("<I", data, thunk_off)[0]
                                    ordinal_flag = 0x80000000
                                if val == 0:
                                    break
                                if val & ordinal_flag:
                                    ord_num = val & 0xFFFF
                                    fname = f"ord{ord_num}"
                                else:
                                    ibn_rva = val & 0x7FFFFFFF
                                    ibn_off = _rva_to_offset(ibn_rva, fmt.sections)
                                    # IMAGE_IMPORT_BY_NAME: Hint(2) + Name
                                    fname = _read_c_string(data, (ibn_off or 0) + 2) if ibn_off else ""
                                if fname and dll_name:
                                    import_funcs.append({"dll": dll_name, "name": fname})
                                    imphash_parts.append(f"{dll_name}.{fname.lower()}")
                                thunk_off += step
                        desc += 20
                    if imphash_parts:
                        fmt.imphash = hashlib.md5(",".join(imphash_parts).encode()).hexdigest()

            # Export directory DataDirectory[0]
            exp_rva, exp_size = struct.unpack_from("<II", data, dd_off)
            if exp_rva:
                exp_off = _rva_to_offset(exp_rva, fmt.sections)
                if exp_off is not None and exp_off + 40 <= len(data):
                    (
                        _chars, _ts, _maj, _min, name_rva2, ordinal_base,
                        n_funcs, n_names, _aof, aon, _aoo
                    ) = struct.unpack_from("<IIHHIIIIIII", data, exp_off)
                    names_off = _rva_to_offset(aon, fmt.sections) if aon else None
                    if names_off is not None:
                        for i in range(min(n_names, 256)):
                            if names_off + i * 4 + 4 > len(data):
                                break
                            nrva = struct.unpack_from("<I", data, names_off + i * 4)[0]
                            noff = _rva_to_offset(nrva, fmt.sections)
                            ename = _read_c_string(data, noff or 0)
                            if ename:
                                fmt.exports.append(ename)

    # Fallback string-based import hints if IAT parse empty
    if not import_funcs:
        for api in DANGEROUS_IMPORTS:
            if api in data:
                import_funcs.append({"dll": "?", "name": api.decode("ascii", errors="ignore")})
        for dll in (b"kernel32.dll", b"ntdll.dll", b"user32.dll", b"advapi32.dll",
                    b"ws2_32.dll", b"wininet.dll", b"winhttp.dll", b"crypt32.dll"):
            if dll.lower() in data.lower():
                import_dlls.append(dll.decode("ascii"))

    fmt.import_dlls = sorted(set(import_dlls))
    fmt.import_functions = import_funcs
    fmt.imports = sorted({f["name"] for f in import_funcs} | set(import_dlls))
    fmt.details["machine"] = hex(machine)
    fmt.details["section_count"] = num_sections
    fmt.details["import_count"] = len(import_funcs)
    fmt.details["export_count"] = len(fmt.exports)
    return fmt


def parse_elf(data: bytes) -> BinaryFormat:
    fmt = BinaryFormat(kind="elf")
    if len(data) < 52 or data[:4] != ELF_MAGIC:
        return fmt
    ei_class = data[4]
    ei_data = data[5]
    fmt.bits = 64 if ei_class == 2 else 32
    fmt.endian = "little" if ei_data == 1 else "big"
    endian = "<" if fmt.endian == "little" else ">"
    if fmt.bits == 32 and len(data) >= 52:
        e_machine = struct.unpack_from(endian + "H", data, 18)[0]
        e_entry = struct.unpack_from(endian + "I", data, 24)[0]
        e_shoff = struct.unpack_from(endian + "I", data, 32)[0]
        e_shentsize = struct.unpack_from(endian + "H", data, 46)[0]
        e_shnum = struct.unpack_from(endian + "H", data, 48)[0]
    elif fmt.bits == 64 and len(data) >= 64:
        e_machine = struct.unpack_from(endian + "H", data, 18)[0]
        e_entry = struct.unpack_from(endian + "Q", data, 24)[0]
        e_shoff = struct.unpack_from(endian + "Q", data, 40)[0]
        e_shentsize = struct.unpack_from(endian + "H", data, 58)[0]
        e_shnum = struct.unpack_from(endian + "H", data, 60)[0]
    else:
        return fmt

    arch_map = {3: "x86", 62: "x86_64", 40: "arm", 183: "arm64", 8: "mips", 243: "riscv"}
    fmt.arch = arch_map.get(e_machine, f"machine_{e_machine}")
    fmt.entry_point = int(e_entry)
    fmt.details["section_count"] = e_shnum
    fmt.details["shoff"] = e_shoff
    fmt.details["shentsize"] = e_shentsize
    return fmt


def parse_dex(data: bytes) -> BinaryFormat:
    fmt = BinaryFormat(kind="dex", arch="dalvik", bits=32, endian="little")
    if len(data) < 112 or data[:4] != DEX_MAGIC:
        return fmt
    version = data[4:8].split(b"\x00", 1)[0].decode("ascii", errors="replace")
    file_size = struct.unpack_from("<I", data, 32)[0]
    fmt.details["dex_version"] = version
    fmt.details["file_size_header"] = file_size
    fmt.details["string_ids_size"] = struct.unpack_from("<I", data, 56)[0]
    fmt.details["method_ids_size"] = struct.unpack_from("<I", data, 88)[0]
    return fmt


def parse_macho(data: bytes) -> BinaryFormat:
    fmt = BinaryFormat(kind="macho")
    if len(data) < 8:
        return fmt
    magic = struct.unpack_from("<I", data, 0)[0]
    if magic in (MACHO_64_MAGIC, MACHO_64_CIGAM):
        fmt.bits = 64
    elif magic in (MACHO_32_MAGIC, MACHO_32_CIGAM):
        fmt.bits = 32
    elif magic == MACHO_FAT or magic == 0xBEBAFECA:
        fmt.details["fat"] = True
        fmt.bits = 0
        return fmt
    else:
        fmt.kind = "unknown"
        return fmt
    endian = "<" if magic in (MACHO_64_MAGIC, MACHO_32_MAGIC) else ">"
    fmt.endian = "little" if endian == "<" else "big"
    cputype = struct.unpack_from(endian + "I", data, 4)[0]
    cpu_map = {7: "x86", 0x01000007: "x86_64", 12: "arm", 0x0100000C: "arm64"}
    fmt.arch = cpu_map.get(cputype, f"cpu_{cputype}")
    return fmt


def detect_format(data: bytes) -> BinaryFormat:
    if data[:2] == PE_MAGIC:
        return parse_pe(data)
    if data[:4] == ELF_MAGIC:
        return parse_elf(data)
    if data[:4] == DEX_MAGIC:
        return parse_dex(data)
    if len(data) >= 4:
        magic = struct.unpack_from("<I", data, 0)[0]
        if magic in (MACHO_64_MAGIC, MACHO_32_MAGIC, MACHO_64_CIGAM, MACHO_32_CIGAM, MACHO_FAT, 0xBEBAFECA):
            return parse_macho(data)
    # Source-like text fallback
    try:
        data[:256].decode("utf-8")
        fmt = BinaryFormat(kind="text", arch="source", bits=0)
        return fmt
    except UnicodeDecodeError:
        return BinaryFormat(kind="binary")


# ============================================================================
# Analysis
# ============================================================================
def detect_packers(data: bytes) -> list[str]:
    found: list[str] = []
    for name, sigs in PACKER_SIGS.items():
        for sig in sigs:
            if sig in data:
                found.append(name)
                break
    return found


def scan_markers(data: bytes, table: dict[bytes, str]) -> list[str]:
    hits: list[str] = []
    for needle, label in table.items():
        if needle in data:
            hits.append(label)
    return hits


def scan_crypto_constants(data: bytes) -> list[str]:
    hits: list[str] = []
    for const, label in CRYPTO_CONSTANTS.items():
        if len(const) >= 4 and const in data:
            hits.append(label)
    return hits


def scan_dangerous_apis(data: bytes) -> list[dict[str, str]]:
    results: list[dict[str, str]] = []
    for api, reason in DANGEROUS_IMPORTS.items():
        if api in data:
            results.append({"api": api.decode("ascii", errors="ignore"), "reason": reason})
    return results


def scan_interesting_strings(strings: list[str], limit: int = 80) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    for s in strings:
        for pattern, label in INTERESTING_STRINGS_RE:
            if re.search(pattern, s):
                out.append({"label": label, "value": s[:200]})
                break
        if len(out) >= limit:
            break
    return out


def scan_license_patterns(text: str) -> list[dict[str, str]]:
    hits: list[dict[str, str]] = []
    for category, patterns in LICENSE_PATTERNS.items():
        for pat in patterns:
            try:
                m = re.search(pat, text)
            except re.error:
                continue
            if m:
                hits.append({"category": category, "match": m.group(0)[:120], "pattern": pat[:80]})
    return hits


def analyze_binary(path: str | os.PathLike[str], max_read: int = 12_000_000) -> ReverseReport:
    """Full reverse-engineering triage for one file."""
    p = Path(path)
    report = ReverseReport(path=str(p))
    if not p.is_file():
        report.notes.append("file not found")
        return report

    data = p.read_bytes()[:max_read]
    report.size = p.stat().st_size
    report.sha256 = file_sha256(p)
    report.md5 = file_md5(p)
    report.format = detect_format(data)
    report.entropy = shannon_entropy(data[: min(len(data), 2_000_000)])
    report.section_entropy = [
        {"name": s.get("name"), "entropy": s.get("entropy"), "raw_size": s.get("raw_size")}
        for s in report.format.sections if "entropy" in s
    ]
    report.packers = detect_packers(data)
    high_sec = any((s.get("entropy") or 0) >= 7.0 for s in report.format.sections)
    report.is_packed = bool(report.packers) or report.entropy >= 7.2 or high_sec
    report.anti_debug = scan_markers(data, ANTIDEBUG_APIS)
    report.anti_vm = scan_markers(data, ANTIVM_SIGS)
    report.dangerous_apis = scan_dangerous_apis(data)
    report.crypto_constants = scan_crypto_constants(data)

    ascii_strings = extract_ascii_strings(data)
    utf16_strings = extract_utf16le_strings(data) if report.format.kind in {"pe", "binary"} else []
    combined = ascii_strings + utf16_strings
    report.interesting_strings = scan_interesting_strings(combined)

    # License patterns work better on decoded text
    try:
        text_view = data.decode("utf-8")
    except UnicodeDecodeError:
        text_view = "\n".join(combined[:5000])
    report.license_patterns = scan_license_patterns(text_view)

    api_names = [f.get("name", "") for f in report.format.import_functions] + [
        a["api"] for a in report.dangerous_apis
    ]
    report.capability_map = map_capabilities(api_names)

    if report.format.kind == "pe" and any(s.get("executable") and s.get("writable") for s in report.format.sections):
        report.notes.append("PE section is both executable and writable (RWX) — common in packers/injectors")
    if report.format.overlay_size > 1024:
        report.notes.append(f"Overlay present ({report.format.overlay_size} bytes) — may hide payload/config")
    if report.format.imphash:
        report.notes.append(f"imphash={report.format.imphash}")
    if report.is_packed:
        report.notes.append("High entropy and/or packer signature suggests packing/obfuscation")
    if report.anti_debug:
        report.notes.append("Anti-debug markers present")
    if report.anti_vm:
        report.notes.append("Anti-VM / sandbox markers present")
    if report.capability_map:
        report.notes.append("Capabilities: " + ", ".join(report.capability_map.keys()))

    # Public/software surface (URLs, domains, version info, rich header)
    try:
        import re_surface
        imp_names = [f.get("name", "") for f in (report.format.import_functions or [])]
        surface = re_surface.analyze_surface(
            p,
            max_read=max_read,
            probe=False,
            import_names=imp_names,
        )
        report.network_surface = {
            "urls": surface.urls[:40],
            "domains": surface.domains[:40],
            "ips": surface.ips[:30],
            "emails": surface.emails[:20],
            "pdb_paths": surface.pdb_paths[:10],
            "cloud_hits": surface.cloud_hits,
            "network_apis": surface.network_apis[:40],
            "public_endpoints": surface.public_endpoints[:40],
        }
        report.software_identity = surface.software_identity
        report.rich_header = surface.rich_header
        if surface.pe_version_info:
            report.software_identity = {**surface.pe_version_info, **report.software_identity}
        report.notes.extend(surface.notes[:6])
        if surface.urls or surface.domains:
            report.notes.append(
                f"Public surface: {len(surface.urls)} URLs, {len(surface.domains)} domains — "
                "use: python scripts/re_surface.py <path> --probe"
            )
    except Exception as exc:
        report.notes.append(f"surface analysis skipped: {exc}"[:120])
    return report


def triage_path(path: str | os.PathLike[str]) -> list[dict[str, Any]]:
    """Analyze a file or walk a directory of binaries/sources."""
    p = Path(path)
    results: list[dict[str, Any]] = []
    if p.is_file():
        return [analyze_binary(p).to_dict()]
    if not p.is_dir():
        return results

    exts = {".exe", ".dll", ".sys", ".so", ".dylib", ".bin", ".elf", ".dex", ".apk", ".o", ".a",
            ".py", ".c", ".cpp", ".rs", ".go", ".java", ".js", ".ts"}
    for child in sorted(p.rglob("*")):
        if not child.is_file():
            continue
        if child.suffix.lower() not in exts and child.name.lower() not in {"makefile",}:
            # Still accept extensionless ELF/PE by magic if small enough
            try:
                head = child.read_bytes()[:4]
            except OSError:
                continue
            if head[:2] != b"MZ" and head[:4] != b"\x7fELF" and head[:4] != b"dex\n":
                continue
        if child.stat().st_size > 30_000_000:
            continue
        results.append(analyze_binary(child).to_dict())
        if len(results) >= 100:
            break
    return results


def main(argv: list[str] | None = None) -> int:
    args = list(argv if argv is not None else sys.argv[1:])
    if not args:
        print("Usage: python reverse_engineering.py <file-or-dir> [--json]")
        return 2
    target = args[0]
    as_json = "--json" in args
    reports = triage_path(target)
    if as_json:
        print(json.dumps(reports if len(reports) != 1 else reports[0], indent=2, ensure_ascii=False))
        return 0

    if not reports:
        print(f"No analyzable files under: {target}")
        return 1

    for r in reports:
        print("=" * 60)
        print(f"path     : {r.get('path')}")
        print(f"sha256   : {r.get('sha256')}")
        print(f"md5      : {r.get('md5')}")
        print(f"size     : {r.get('size')}")
        fmt = r.get("format") or {}
        print(f"format   : {fmt.get('kind')} {fmt.get('arch')} {fmt.get('bits')}bit")
        print(f"imphash  : {fmt.get('imphash') or '-'}")
        print(f"overlay  : {fmt.get('overlay_size') or 0}")
        print(f"entropy  : {r.get('entropy')}  packed={r.get('is_packed')}  packers={r.get('packers')}")
        print(f"anti-dbg : {r.get('anti_debug')}")
        print(f"anti-vm  : {r.get('anti_vm')}")
        print(f"crypto   : {r.get('crypto_constants')}")
        ident = r.get("software_identity") or {}
        if ident:
            print(f"product  : {ident.get('CompanyName') or ident.get('company_hint') or '-'} / "
                  f"{ident.get('ProductName') or ident.get('FileDescription') or '-'} "
                  f"{ident.get('FileVersion') or ''}")
        caps = r.get("capability_map") or {}
        if caps:
            print(f"caps     : {', '.join(caps.keys())}")
        apis = r.get("dangerous_apis") or []
        if apis:
            print(f"apis     : {', '.join(a['api'] for a in apis[:12])}")
        imps = (fmt.get("import_functions") or [])[:15]
        if imps:
            print(f"imports  : {', '.join(f.get('name','') for f in imps)}")
        surf = r.get("network_surface") or {}
        if surf.get("urls") or surf.get("domains"):
            print(f"surface  : urls={len(surf.get('urls') or [])} domains={len(surf.get('domains') or [])} "
                  f"cloud={surf.get('cloud_hits')}")
            for u in (surf.get("urls") or [])[:8]:
                print(f"  url    : {u}")
            for d in (surf.get("domains") or [])[:8]:
                print(f"  domain : {d}")
        if surf.get("pdb_paths"):
            for pdb in surf["pdb_paths"][:3]:
                print(f"  pdb    : {pdb}")
        rich = r.get("rich_header") or {}
        if rich.get("present"):
            print(f"rich     : present key={rich.get('xor_key')}")
        lic = r.get("license_patterns") or []
        if lic:
            print(f"license  : {len(lic)} pattern hits")
        notes = r.get("notes") or []
        for n in notes:
            print(f"note     : {n}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
