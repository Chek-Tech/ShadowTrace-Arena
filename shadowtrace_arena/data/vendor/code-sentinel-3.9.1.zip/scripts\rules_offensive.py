#!/usr/bin/env python3
"""
Offensive attack rule catalog — spider patterns, brute-force signatures,
keygen detection, game cheat patterns, network attack indicators.
Compatible with SentinelRule format for the scan engine.
"""
from __future__ import annotations
import re

def offensive_rules(SentinelRule, _rx):
    return [
        # ── Spider / Crawler detection ──
        SentinelRule("off-spider-ua", "Spider/bot User-Agent", "MEDIUM", "offensive",
            _rx(r"(?i)(?:User-Agent|user_agent|USER_AGENT).{0,40}(?:scrapy|python-requests|go-http-client|HttpClient)"),
            "Bot-like User-Agent detected — potential scraping activity."),
        SentinelRule("off-spider-rate", "Aggressive request pattern", "MEDIUM", "offensive",
            _rx(r"time\.sleep\s*\(\s*0\.[0-2]\s*\)|rate_limit|throttle.*off|delay.*0\.\d"),
            "Very low delay between requests — scraping indicator."),
        SentinelRule("off-spider-proxy", "Proxy rotation logic", "MEDIUM", "offensive",
            _rx(r"(?i)proxy.*random|rotate.*proxy|proxy.*pool|free.*proxy"),
            "Proxy rotation used for distributed scraping."),
        # ── Brute force / cracking ──
        SentinelRule("off-brute-login", "Brute-force login attempt code", "HIGH", "offensive",
            _rx(r"(?i)(?:for.*username.*in.*wordlist|for.*password.*in.*passlist|"
                r"brute.*force|brute.*login|try_credentials|attempt_login)"),
            "Automated login brute-force code detected.", cwe="CWE-307"),
        SentinelRule("off-brute-threads", "Multi-threaded brute force", "HIGH", "offensive",
            _rx(r"(?i)(?:ThreadPoolExecutor.*login|concurrent.*password|"
                r"threading.*brute|futures.*credentials)"),
            "Multi-threaded credential testing detected.", cwe="CWE-307"),
        SentinelRule("off-brute-wordlist", "Password dictionary loading", "MEDIUM", "offensive",
            _rx(r"(?i)(?:rockyou|wordlist\.txt|passwords\.txt|dict\.txt|"
                r"common.*password.*list|top.*1000.*password)"),
            "Known password dictionary file referenced."),
        # ── Keygen / license crack ──
        SentinelRule("off-keygen-serial", "Serial key generation algorithm", "HIGH", "offensive",
            _rx(r"(?i)(?:\bkeygen\b|generate[_-]?(?:serial|license|activation)|"
                r"key[_-]?generator|serial[_-]?generator|create[_-]?activation[_-]?key|"
                r"make[_-]?serial|license[_-]?keygen)"),
            "Keygen or serial generation code detected."),
        SentinelRule("off-keygen-patch", "Binary patching for license bypass", "CRITICAL", "offensive",
            _rx(r"(?i)(?:patch.*je.*jmp|nop.*license|patch.*0xEB|"
                r"WriteProcessMemory.*license|VirtualProtect.*patch|hex.*edit.*bypass)"),
            "Binary patching targeted at license verification."),
        SentinelRule("off-keygen-spoof", "Hardware-ID spoofing code", "HIGH", "offensive",
            _rx(r"(?i)(?:spoof.*hwid|fake.*volume.*serial|spoof.*mac|"
                r"GetVolumeInformation.*spoof|HWID.*spoof)"),
            "Hardware-ID spoofing for license binding bypass."),
        SentinelRule("off-keygen-activation", "Activation bypass payloads", "HIGH", "offensive",
            _rx(r"(?i)(?:activation.*bypass|bypass.*activation|fake.*activation|"
                r"activation.*payload|license.*bypass)"),
            "Activation server bypass code detected."),
        # ── Game hack ──
        SentinelRule("off-game-memory", "Game memory manipulation", "HIGH", "offensive",
            _rx(r"(?i)(?:ReadProcessMemory|WriteProcessMemory|OpenProcess.*game|"
                r"memory.*hack|trainer|cheat.*engine|memory.*scan|find.*value.*address)"),
            "Game memory manipulation code detected."),
        SentinelRule("off-game-aimbot", "Aimbot/ESP/wallhack code", "HIGH", "offensive",
            _rx(r"(?i)(?:aimbot|wallhack|esp.*hack|trigger.*bot|no.*recoil|"
                r"aim.*assist|silent.*aim|bone.*aim)"),
            "Game cheat — aimbot/ESP/wallhack code."),
        SentinelRule("off-game-inject", "DLL injection for game hacking", "CRITICAL", "offensive",
            _rx(r"(?i)(?:CreateRemoteThread.*dll|inject.*dll.*game|"
                r"LoadLibrary.*inject|manual.*map.*dll|dll.*hijack.*game)"),
            "DLL injection targeted at game process.", cwe="CWE-94"),
        SentinelRule("off-game-speed", "Speedhack/timescale manipulation", "MEDIUM", "offensive",
            _rx(r"(?i)(?:speed.*hack|time.*scale|QueryPerformanceCounter.*hook|"
                r"GetTickCount.*hook|timescale|speed.*multiplier)"),
            "Game speedhack or time manipulation code."),
        SentinelRule("off-game-dxhook", "DirectX/OpenGL hook for overlay", "HIGH", "offensive",
            _rx(r"(?i)(?:EndScene.*hook|Present.*hook|d3d9.*hook|SwapBuffers.*hook|"
                r"wglSwapBuffers|hook.*directx|hook.*opengl)"),
            "DirectX/OpenGL hook for game overlay cheat."),
        # ── Network attack ──
        SentinelRule("off-net-arp", "ARP spoofing code", "CRITICAL", "offensive",
            _rx(r"(?i)(?:arp.*spoof|arp.*poison|scapy.*ARP|sendp.*ARP|"
                r"Ether.*ARP|ARP.*op=2)"),
            "ARP spoofing/poisoning attack code."),
        SentinelRule("off-net-dns", "DNS poisoning code", "CRITICAL", "offensive",
            _rx(r"(?i)(?:dns.*spoof|dns.*poison|dns.*hijack|DNSRR.*spoof|"
                r"spoof.*dns.*response|netfilterqueue.*dns)"),
            "DNS poisoning attack code."),
        SentinelRule("off-net-session", "Session hijacking code", "CRITICAL", "offensive",
            _rx(r"(?i)(?:session.*hijack|steal.*cookie|hijack.*session|"
                r"cookie.*theft|session.*replay|sidejacking)"),
            "Session hijacking / cookie theft code.", cwe="CWE-384"),
        SentinelRule("off-net-sniff", "Packet sniffing / capture code", "HIGH", "offensive",
            _rx(r"(?i)(?:scapy.*sniff|pcap|wireshark|tshark|"
                r"packet.*capture|promiscuous|raw.*socket.*sniff)"),
            "Network packet capture/sniffing code."),
        SentinelRule("off-net-deauth", "WiFi deauthentication attack", "HIGH", "offensive",
            _rx(r"(?i)(?:deauth|deauth.*attack|wifi.*jam|Dot11Deauth|"
                r"disconnect.*client|aireplay|mdk3|mdk4)"),
            "WiFi deauthentication attack code."),
        SentinelRule("off-net-dos", "Denial of service attack code", "CRITICAL", "offensive",
            _rx(r"(?i)(?:dos.*attack|ddos|flood.*attack|syn.*flood|"
                r"slowloris|hulk.*dos|goldeneye.*dos)"),
            "Denial-of-service attack code.", cwe="CWE-400"),
        SentinelRule("off-net-portscan", "Port scanning code", "MEDIUM", "offensive",
            _rx(r"(?i)(?:\bport[_-]?scan(?:ner|ning)?\b|\bnmap\b.{0,30}\bscan\b|\bmasscan\b|"
                r"\bsyn[_-]?scan\b|\btcp[_-]?connect[_-]?scan\b|"
                r"socket\.connect.{0,40}for\s+\w+\s+in\s+.*ports)"),
            "Port scanning code."),
        # ── Membership / card-key ──
        SentinelRule("off-member-payment", "Payment bypass / fraud code", "CRITICAL", "offensive",
            _rx(r"(?i)(?:payment.*bypass|price.*0.*bypass|free.*upgrade|"
                r"payment.*fraud|bypass.*payment|subscription.*bypass)"),
            "Payment bypass or fraud code.", cwe="CWE-841"),
        SentinelRule("off-member-cardkey", "Card-key generation/brute force", "HIGH", "offensive",
            _rx(r"(?i)(?:card.*key.*generat|卡密.*生|card.*code.*brute|"
                r"activation.*code.*gen|vip.*card.*gen)"),
            "Card-key generation or brute-force code."),
        SentinelRule("off-member-escalation", "Privilege escalation payload", "HIGH", "offensive",
            _rx(r"(?i)(?:role.*admin.*payload|escalat.*privilege|"
                r"is_admin.*true.*payload|isAdmin.*payload|user.*role.*tamper)"),
            "Privilege escalation payload detected.", cwe="CWE-269"),
        # ── Web / recon offensive patterns ──
        SentinelRule("off-web-sqli-payload", "SQL injection payload crafting", "HIGH", "offensive",
            _rx(r"(?i)(?:'?\s*or\s+'?1'?\s*=\s*'?1|union\s+select\s+null|sleep\s*\(\s*\d+\s*\)|"
                r"benchmark\s*\(|information_schema\.tables|xp_cmdshell)"),
            "SQL injection payload strings detected.", cwe="CWE-89"),
        SentinelRule("off-web-xss-payload", "XSS payload crafting", "HIGH", "offensive",
            _rx(r"(?i)(?:<script>alert\(|onerror\s*=\s*alert|javascript:\s*alert|"
                r"document\.cookie\s*=|<img\s+src=x\s+onerror)"),
            "Cross-site scripting payload patterns detected.", cwe="CWE-79"),
        SentinelRule("off-recon-subdomain", "Subdomain enumeration tooling", "MEDIUM", "offensive",
            _rx(r"(?i)(?:subfinder|amass\s+enum|sublist3r|assetfinder|"
                r"dnsrecon|fierce\s+.*domain|bruteforce.*subdomain)"),
            "Subdomain enumeration / attack-surface recon tooling."),
        SentinelRule("off-ad-bloodhound", "Active Directory attack path tooling", "HIGH", "offensive",
            _rx(r"(?i)(?:bloodhound|sharpHound|certipy|rubeus\b|mimikatz|"
                r"secretsdump|ntlmrelayx|kerberoast)"),
            "Active Directory offensive tooling references."),
        SentinelRule("off-c2-framework", "C2 framework indicators", "CRITICAL", "offensive",
            _rx(r"(?i)(?:\bcobalt\s*strike\b|\bsliver\b|\bmythic\b|\bhavoc\b\s*c2|"
                r"\bmetasploit\b.*\bpayload\b|\bmsfvenom\b)"),
            "Command-and-control framework indicators."),
    ]
