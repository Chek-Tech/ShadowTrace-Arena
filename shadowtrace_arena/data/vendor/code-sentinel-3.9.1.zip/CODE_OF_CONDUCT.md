# Contributor Covenant Code of Conduct

## Our Pledge

We pledge to make participation in this project a harassment-free experience for everyone.

## Standards

- Use welcoming and inclusive language
- Be respectful of differing viewpoints
- Accept constructive criticism gracefully
- Focus on what is best for the community
- Show empathy towards other community members

## Enforcement

Project maintainers are responsible for clarifying and enforcing standards of acceptable behavior. Instances of abusive, harassing, or otherwise unacceptable behavior may be reported to the project team.

## Attribution

This Code of Conduct is adapted from the Contributor Covenant, version 2.1.
