# Code Sentinel CTF World

**虚拟攻防网络拓扑 | 5 网段 · 14 服务 · 13 Flag | 全授权·零限制**

```
                    ┌──────────────┐
                    │   ATTACKER   │  10.0.0.10
                    │    (Kali)    │
                    └──────┬───────┘
                           │
      ═════════════════════╪══════════════════  EXTERNAL (10.0.0.0/24)
                           │
              ┌────────────┼────────────┐
              ▼            ▼            ▼
        ┌──────────┐ ┌──────────┐      (firewall)
        │ corp-web │ │ corp-api │
        │ 10.0.1.10│ │ 10.0.1.11│
        │  :80     │ │  :5000   │
        └────┬─────┘ └────┬─────┘
             │            │          ═══════ DMZ (10.0.1.0/24)
      ══════╪════════════╪══════════
             │            │
      ┌──────┼────────────┼──────────────────────┐
      │      ▼            ▼            ▼         ▼         ▼
      │ ┌───────┐  ┌─────────┐  ┌────────┐ ┌───────┐ ┌───────┐
      │ │db-int │  │legacy   │  │iot-cam │ │vpn-gw │ │ (fw)  │
      │ │:3306  │  │:445 SMB │  │:8080   │ │:1723  │ │       │
      │ └───────┘  └─────────┘  └────────┘ └───┬───┘ └───────┘
      │      INTERNAL (10.0.2.0/24)             │
      └─────────────────────────────────────────┼────────────────┘
                                                │
                                  ══════════════╪═══════════════  DEV (10.0.3.0/24)
                                    ┌───────────┼───────────┐
                                    ▼           ▼           ▼
                              ┌─────────┐ ┌────────┐ ┌──────────┐
                              │ dev-ftp │ │jenkins │ │ grafana  │
                              │ :21     │ │ :8080  │ │ :3000    │
                              └─────────┘ └────────┘ └──────────┘

                    ═══════════════════════════════════════════  ISOLATED (10.0.4.0/24)
                         ┌─────────┐ ┌─────────┐ ┌──────────┐ ┌──────────┐
                         │  PWN01  │ │  PWN02  │ │ CRYPTO01 │ │REVERSE01 │
                         │ :40001  │ │ :40002  │ │ :40003   │ │ :40004   │
                         └─────────┘ └─────────┘ └──────────┘ └──────────┘
```

## 启动

```bash
cd ops-lab/ctf-world
docker-compose up -d          # 启动全部 15 容器
docker-compose exec attacker bash  # 进入攻击机
docker-compose down           # 销毁
```

## 网络拓扑

| 网段 | 子网 | 服务 |
|------|------|------|
| **external** | 10.0.0.0/24 | attacker (Kali, 10.0.0.10) |
| **dmz** | 10.0.1.0/24 | corp-web (:80), corp-api (:5000) |
| **internal** | 10.0.2.0/24 | db-internal (:3306), legacy-win (:445), iot-camera (:8080), vpn-gateway (:1723) |
| **dev** | 10.0.3.0/24 | dev-files (:21), jenkins (:8080), grafana (:3000) |
| **isolated** | 10.0.4.0/24 | pwn01 (:40001), pwn02 (:40002), crypto01 (:40003), reverse01 (:40004) |

## 攻击路径

### Path 1: External → Web → DB
```
attacker → corp-web:80 WordPress RCE → env → db-internal:3306 → SQL dump → FLAG_WEB01 + FLAG_DB01
```

### Path 2: SMB → VPN → DEV
```
attacker → legacy-win:445 null session → read creds → vpn-gateway:1723 → DEV network → FLAG_LEGACY + FLAG_VPN + FLAG_FILESRV + FLAG_CICD + FLAG_MONITOR
```

### Path 3: FTP → RCE → CI/CD
```
attacker → dev-files:21 anonymous FTP → upload .py → EXEC → docker socket → FLAG_FILESRV + FLAG_CICD
```

### Path 4: IoT → Shell → Internal
```
attacker → iot-camera:8080 default creds → /firmware/update RCE → internal scan → FLAG_IOT
```

### Path 5: Isolated Challenges
```
attacker → :40001 BOF → :40002 Heap → :40003 Crypto → :40004 Reverse → 4× isolated FLAGs
```

## 侦察

```bash
python extras/recon.py                  # 全扫描
python extras/recon.py --target dmz     # 单网段
python extras/recon.py --json           # JSON 输出
python extras/recon.py --ports common   # 常用端口
```

## 解题工具链

| 挑战 | 工具 | Code Sentinel |
|------|------|---------------|
| WEB01 | sqlmap, wpscan | `sentinel.py web http://10.0.1.10` |
| API01 | Burp, curl, jwt.io | `sentinel.py web http://10.0.1.11:5000` |
| LEGACY | smbclient, enum4linux | `sentinel.py recon 10.0.2.30 --ports 445` |
| VPN | hashcat, john | `sentinel.py reverse attack` |
| PWN01 | pwntools, gdb | `sentinel.py reverse --surface challenges/pwn01/bof` |
| PWN02 | pwntools | `sentinel.py ctf challenges/pwn02/` |
| CRYPTO | python | `sentinel.py ctf challenges/crypto01/` |
| REVERSE | ghidra, radare2 | `sentinel.py reverse --surface challenges/reverse01/crackme` |

## Flag 索引

| # | ID | 难度 | 类型 |
|---|-----|------|------|
| 1 | WEB01 | ★★☆ | WordPress RCE |
| 2 | API01 | ★☆☆ | JWT alg:none |
| 3 | DB01 | ★★☆ | SQLi + MySQL |
| 4 | LEGACY | ★☆☆ | SMB null session |
| 5 | IOT | ★★☆ | Cmd injection |
| 6 | VPN | ★★☆ | Hash cracking |
| 7 | FILESRV | ★☆☆ | Anonymous FTP |
| 8 | CICD | ★★★ | Jenkins RCE |
| 9 | MONITOR | ★★☆ | Grafana LFI |
| 10 | PWN01 | ★★★ | Stack BOF + canary |
| 11 | PWN02 | ★★★★ | Heap tcache poison |
| 12 | CRYPTO01 | ★★★ | Padding oracle |
| 13 | REVERSE01 | ★★☆ | Keygen algo |

---

*所有目标均为授权 CTF 资产。零限制·全开放。*
