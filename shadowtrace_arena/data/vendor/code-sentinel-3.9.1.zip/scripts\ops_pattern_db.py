#!/usr/bin/env python3
"""
Sentinel Pattern DB — language/RE/AD condensed heuristics (original tables).

Essences absorbed as data (not prose ports):
  * Go/Rust stripped binary triage cues
  * OLLVM / control-flow flattening markers
  * glibc heap technique vs version gates
  * AD / identity attack path state edges
  * Common packer / compiler fingerprints (short)
"""

from __future__ import annotations

import argparse
import json
import re
from typing import Any, Optional


GO_CUES: list[dict[str, str]] = [
    {"id": "go_buildinfo", "cue": "Go buildinfo / moduledata", "action": "定位 runtime 与 main.main"},
    {"id": "go_pclntab", "cue": "pclntab 符号恢复", "action": "用 go 符号恢复工具/脚本还原函数名"},
    {"id": "go_strings", "cue": "长路径/包路径字符串", "action": "按 package 聚类逆向"},
    {"id": "go_interfaces", "cue": "iface/itab 结构", "action": "类型断言与方法表恢复"},
    {"id": "go_stripped", "cue": "无符号但仍有 .gopclntab", "action": "优先 pclntab 而非盲目 strings"},
]

RUST_CUES: list[dict[str, str]] = [
    {"id": "rust_panic", "cue": "panic/str fmt 路径", "action": "从 panic 字符串反推模块"},
    {"id": "rust_mangling", "cue": "Rust 符号修饰残留", "action": "demangle 恢复类型"},
    {"id": "rust_enums", "cue": "enum 判别域 + niche", "action": "恢复代数类型布局"},
    {"id": "rust_async", "cue": "async state machine", "action": "按 poll 状态机读控制流"},
]

OLLVM_MARKERS: list[dict[str, str]] = [
    {"id": "cff", "marker": "控制流平坦化 (state var + switch dispatcher)", "respond": "识别 dispatcher，恢复基本块序"},
    {"id": "bcf", "marker": "虚假控制流 (不透明谓词)", "respond": "常量传播/符号执行消假边"},
    {"id": "sub", "marker": "指令替换 (add→位运算组合)", "respond": "模式匹配还原算术"},
    {"id": "split", "marker": "基本块拆分过细", "respond": "合并同 state 后继"},
    {"id": "strenc", "marker": "运行时解密字符串", "respond": "动态 dump 或模拟解密函数"},
]

# glibc heap: version → preferred primitives (research checklist)
GLIBC_HEAP: list[dict[str, Any]] = [
    {"ver": "2.23-", "notes": "fastbin/unsorted 经典；无 tcache", "tech": ["fastbin_dup", "unsorted_bin_attack", "house_of_spirit"]},
    {"ver": "2.26-2.31", "notes": "tcache 引入；利用面变宽", "tech": ["tcache_poison", "tcache_dup", "fastbin_dup"]},
    {"ver": "2.32+", "notes": "safe-linking 搅指针", "tech": ["safe_linking_leak", "tcache_stashing", "house_of_mango_like"]},
    {"ver": "2.34+", "notes": "malloc hook 移除", "tech": ["exit_hook_alt", "IO_FILE", "fsop", "stack_pivot_via_IO"]},
]

AD_EDGES: list[dict[str, str]] = [
    {"from": "domain_user", "to": "spn_roast", "via": "Kerberoast 可请求 SPN 哈希", "next": "crack→service account"},
    {"from": "domain_user", "to": "asrep", "via": "不需预认证账户", "next": "AS-REP roast"},
    {"from": "local_admin", "to": "credential_dump", "via": "LSASS/LSA 机密", "next": "票据或哈希重用"},
    {"from": "credential", "to": "lateral", "via": "PtH/PtT/WinRM/SMB", "next": "第二主机"},
    {"from": "generic_write", "to": "rbcd", "via": "基于资源的约束委派配置", "next": "冒充主机"},
    {"from": "enroll_rights", "to": "adcs", "via": "证书模板滥用", "next": "认证证书→提权"},
    {"from": "coercion", "to": "relay", "via": "强制认证到中继目标", "next": "SMB/HTTP relay 接受条件"},
    {"from": "da", "to": "enterprise", "via": "域管持久化/信任", "next": "演练目标达成+清理"},
]

PACKER_HINTS: list[dict[str, str]] = [
    {"id": "upx", "sig": "UPX!", "note": "常见壳，可脱"},
    {"id": "themida", "sig": "高熵+反虚拟", "note": "重保护，动态优先"},
    {"id": "vmprotect", "sig": "VM handler 表", "note": "虚拟化保护"},
    {"id": "pecompact", "sig": "PEC2", "note": "压缩壳"},
    {"id": "go_native", "sig": "无壳但体积大", "note": "可能是 Go 静态链接"},
]

DOTNET_CUES = [
    {"id": "clr", "cue": "mscoree / CLR 头", "action": "dnSpy/ILSpy 优先"},
    {"id": "obfus", "cue": "Confuser/SmartAssembly 名", "action": "去混淆再读逻辑"},
]

ELF_CUES = [
    {"id": "dynsym", "cue": "动态符号/plt", "action": "plt/got 交叉引用"},
    {"id": "full_relro", "cue": "RELRO 级别", "action": "影响 got 覆写策略"},
    {"id": "pie", "cue": "DYN PIE", "action": "需要 leak 基址"},
]

MACHO_CUES = [
    {"id": "objc", "cue": "ObjC 类/方法列表", "action": "class-dump 等价恢复"},
    {"id": "swift", "cue": "Swift 元数据", "action": "demangle + 协议见证表"},
]

CTF_PATTERN_CUES = [
    {"id": "flag_fmt", "cue": "flag{}/CTF{}", "action": "ctf_toolkit 扫描"},
    {"id": "custom_vm", "cue": "自定义字节码 VM", "action": "handler 表还原"},
    {"id": "tea_const", "cue": "0x9e3779b9", "action": "TEA/XTEA 族"},
    {"id": "rc4", "cue": "S盒交换循环", "action": "RC4/KSA 识别"},
]

HARDWARE_CUES = [
    {"id": "uart", "cue": "115200/57600 串口", "action": "固件获取 F2"},
    {"id": "jtag", "cue": "调试口", "action": "硬件 dump 路径"},
    {"id": "spi", "cue": "flashrom/CH341", "action": "整片读取"},
]


def search(query: str) -> dict[str, Any]:
    q = (query or "").lower()
    hits: list[dict[str, Any]] = []

    def add(family: str, row: dict[str, Any], score: float) -> None:
        hits.append({"family": family, "score": score, **row})

    for row in GO_CUES:
        if any(k in q for k in ("go ", "golang", "pclntab", "go.mod", "stripped")) or re.search(r"\bgo\b", q):
            add("go", row, 1.0)
    for row in RUST_CUES:
        if "rust" in q or "panic" in q:
            add("rust", row, 1.0)
    for row in OLLVM_MARKERS:
        if any(k in q for k in ("ollvm", "平坦", "混淆", "cff", "opaque", "fla")):
            add("ollvm", row, 1.2)
    for row in GLIBC_HEAP:
        if any(k in q for k in ("tcache", "glibc", "堆", "heap", "fastbin", "unsorted")):
            add("heap", row, 1.0)
    for row in AD_EDGES:
        if any(k in q for k in ("kerberoast", "adcs", "rbcd", "域", "票据", "ntlm", "relay", "委派")):
            add("ad", row, 1.0)
    for row in PACKER_HINTS:
        if any(k in q for k in ("壳", "upx", "themida", "vmprotect", "packer")):
            add("packer", row, 0.9)
    for row in DOTNET_CUES:
        if any(k in q for k in (".net", "dotnet", "clr", "dnspy")):
            add("dotnet", row, 1.0)
    for row in ELF_CUES:
        if any(k in q for k in ("elf", "plt", "got", "relro", "pie")):
            add("elf", row, 0.9)
    for row in MACHO_CUES:
        if any(k in q for k in ("mach-o", "macho", "objc", "swift", "ios")):
            add("macho", row, 0.9)
    for row in CTF_PATTERN_CUES:
        if any(k in q for k in ("flag{", "ctf", "vm 字节", "tea", "rc4", "自定义 vm")):
            add("ctf_pat", row, 1.0)
    for row in HARDWARE_CUES:
        if any(k in q for k in ("uart", "jtag", "spi", "串口", "flashrom")):
            add("hw", row, 1.0)

    hits.sort(key=lambda x: -x["score"])
    return {"protocol": "sentinel-pattern-db-v1", "query": query, "hits": hits[:40], "total_hits": len(hits)}


def heap_for_version(ver: str) -> dict[str, Any]:
    """Best-effort match e.g. 2.31, 2.35."""
    m = re.search(r"2\.(\d+)", ver)
    if not m:
        return {"error": "need version like 2.31", "table": GLIBC_HEAP}
    minor = int(m.group(1))
    if minor <= 23:
        key = "2.23-"
    elif minor < 32:
        key = "2.26-2.31"
    elif minor < 34:
        key = "2.32+"
    else:
        key = "2.34+"
    row = next(r for r in GLIBC_HEAP if r["ver"] == key)
    return {"input": ver, "bucket": key, **row}


def ad_paths(start: str = "domain_user") -> list[dict[str, str]]:
    """BFS-ish list of edges from start node."""
    start = start or "domain_user"
    out = [e for e in AD_EDGES if e["from"] == start]
    # also include downstream one hop
    seen = {start}
    frontier = [start]
    edges = []
    while frontier:
        cur = frontier.pop(0)
        for e in AD_EDGES:
            if e["from"] == cur:
                edges.append(e)
                if e["to"] not in seen:
                    seen.add(e["to"])
                    frontier.append(e["to"])
    return edges or out


def catalog() -> dict[str, Any]:
    return {
        "go": GO_CUES,
        "rust": RUST_CUES,
        "ollvm": OLLVM_MARKERS,
        "heap": GLIBC_HEAP,
        "ad": AD_EDGES,
        "packer": PACKER_HINTS,
        "dotnet": DOTNET_CUES,
        "elf": ELF_CUES,
        "macho": MACHO_CUES,
        "ctf_pat": CTF_PATTERN_CUES,
        "hw": HARDWARE_CUES,
    }


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Sentinel RE/AD/lang pattern DB")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("search", help="Search patterns by free text")
    s.add_argument("query", nargs="+")

    h = sub.add_parser("heap", help="glibc heap tech by version")
    h.add_argument("version", help="e.g. 2.31")

    a = sub.add_parser("ad", help="AD path edges from node")
    a.add_argument("--from", dest="start", default="domain_user")

    sub.add_parser("catalog", help="Full catalog JSON")
    g = sub.add_parser("family", help="One family table")
    g.add_argument(
        "name",
        choices=["go", "rust", "ollvm", "heap", "ad", "packer", "dotnet", "elf", "macho", "ctf_pat", "hw"],
    )

    args = p.parse_args(argv)
    if args.cmd == "search":
        print(json.dumps(search(" ".join(args.query)), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "heap":
        print(json.dumps(heap_for_version(args.version), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "ad":
        print(json.dumps(ad_paths(args.start), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "catalog":
        print(json.dumps(catalog(), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "family":
        print(json.dumps(catalog()[args.name], ensure_ascii=False, indent=2))
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
