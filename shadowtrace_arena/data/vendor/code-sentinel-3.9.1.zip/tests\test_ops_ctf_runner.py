"""Tests for CTF sandbox runner (workspace resume + contract)."""

from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import ops_ctf_runner


class CtfRunnerTests(unittest.TestCase):
    def test_init_and_resume(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            st = ops_ctf_runner.init_workspace(root)
            self.assertTrue(st.exists)
            for rel in ops_ctf_runner.STATE_FILES:
                self.assertTrue((root / rel).is_file(), msg=rel)
            self.assertTrue((root / "reverse_artifacts").is_dir())

            data = ops_ctf_runner.resume_workspace(root)
            self.assertEqual(data["protocol"], "sentinel-ctf-lab-v1")
            self.assertEqual(len(data["workspace"]["present"]), len(ops_ctf_runner.STATE_FILES))
            self.assertIn("progress.md", data["snippets"])

    def test_init_subproject(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            st = ops_ctf_runner.init_workspace(root, subproject="chall-01")
            self.assertTrue(Path(st.root).name.startswith("chall"))
            self.assertTrue((Path(st.root) / "findings.md").is_file())

    def test_detect_empty(self):
        with tempfile.TemporaryDirectory() as tmp:
            st = ops_ctf_runner.detect_state(Path(tmp))
            self.assertEqual(len(st.present), 0)
            self.assertTrue(st.needs_subproject or not st.present)

    def test_evidence_order_aligned(self):
        ids = [e["id"] for e in ops_ctf_runner.EVIDENCE_ORDER]
        self.assertEqual(ids[0], "runtime")
        self.assertEqual(ids[-1], "comments")
        self.assertEqual(len(ids), 8)

    def test_domain_playbooks(self):
        for name in ("web", "reverse", "pwn", "crypto", "payment", "identity", "misc"):
            pb = ops_ctf_runner.domain_playbook(name)
            self.assertEqual(pb["domain"], name if name != "js" else "reverse")
            self.assertTrue(pb["focus"])
            self.assertTrue(pb["tools"])
        self.assertEqual(ops_ctf_runner.domain_playbook("apk")["domain"], "reverse")

    def test_mask_secrets(self):
        raw = "password=SuperSecret123 token=abcdEFGHijkl"
        out = ops_ctf_runner.mask_secrets(raw)
        self.assertNotIn("SuperSecret123", out)
        self.assertIn("password=", out)

    def test_next_priority(self):
        n = ops_ctf_runner.next_priority([])
        self.assertEqual(n["id"], "P1")
        n2 = ops_ctf_runner.next_priority(["P1", "P2"])
        self.assertEqual(n2["id"], "P3")

    def test_append_finding(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            ops_ctf_runner.init_workspace(root)
            p = ops_ctf_runner.append_finding(
                root, "F1", "web", "runtime", "IDOR on /order", "reverse_artifacts/x.har"
            )
            text = p.read_text(encoding="utf-8")
            self.assertIn("F1", text)
            self.assertIn("IDOR", text)

    def test_session_brief(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            ops_ctf_runner.init_workspace(root)
            data = ops_ctf_runner.session_brief(root, domain="reverse", include_proxy=False)
            self.assertIn("contract", data)
            self.assertEqual(data["domain"]["domain"], "reverse")
            md = ops_ctf_runner.render_brief_markdown(data)
            self.assertIn("CTF Sandbox", md)

    def test_cli_contract(self):
        rc = ops_ctf_runner.main(["contract", "--json"])
        self.assertEqual(rc, 0)

    def test_cli_init_resume(self):
        with tempfile.TemporaryDirectory() as tmp:
            rc = ops_ctf_runner.main(["init", tmp, "--json"])
            self.assertEqual(rc, 0)
            rc2 = ops_ctf_runner.main(["resume", tmp, "--json"])
            self.assertEqual(rc2, 0)

    def test_proxy_probe_returns_shape(self):
        r = ops_ctf_runner.probe_proxy(host="127.0.0.1", port=1, timeout=0.3)
        self.assertIn("reachable", r)
        self.assertIn("header_spoof", r)
        self.assertIn("X-Forwarded-For", r["header_spoof"])
        # port 1 almost always closed
        self.assertFalse(r["reachable"])

    def test_contract_has_no_hardcoded_exit_ip(self):
        body = ops_ctf_runner.ctf_contract_block() + ops_ctf_runner.__doc__
        # skill essence: do not hardcode third-party exit IP as fact in contract
        self.assertNotIn("156.245.145.165", body)


if __name__ == "__main__":
    unittest.main()
