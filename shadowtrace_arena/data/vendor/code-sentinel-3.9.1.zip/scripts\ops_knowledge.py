#!/usr/bin/env python3
"""Knowledge Base — query, build, store, and reuse security research findings."""
from __future__ import annotations
import json, os, re, sqlite3, sys, time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = ROOT / "ops-lab" / "knowledge.db"

KB_SCHEMA = """
CREATE TABLE IF NOT EXISTS findings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    target_hash TEXT,
    cve TEXT,
    cvss REAL,
    exploit_type TEXT,
    mitigation TEXT,
    tags TEXT,
    commands TEXT,
    raw_data TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS techniques (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    category TEXT,
    description TEXT,
    requirements TEXT,
    steps TEXT,
    references TEXT,
    tags TEXT
);
CREATE TABLE IF NOT EXISTS ioc (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ioc_type TEXT NOT NULL,
    ioc_value TEXT NOT NULL,
    source TEXT,
    confidence REAL DEFAULT 0.5,
    tags TEXT,
    first_seen TEXT,
    last_seen TEXT
);
CREATE INDEX IF NOT EXISTS idx_findings_category ON findings(category);
CREATE INDEX IF NOT EXISTS idx_findings_cve ON findings(cve);
CREATE INDEX IF NOT EXISTS idx_techniques_category ON techniques(category);
CREATE INDEX IF NOT EXISTS idx_ioc_type ON ioc(ioc_type);
"""

class KnowledgeBase:
    """Security research knowledge base."""

    def __init__(self, db_path: Optional[Path] = None):
        self.db_path = db_path or DB_PATH
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.db_path))
        self.conn.executescript(KB_SCHEMA)
        self.conn.commit()

    def add_finding(self, category: str, title: str, **kwargs) -> int:
        cur = self.conn.execute(
            "INSERT INTO findings(category,title,description,target_hash,cve,cvss,exploit_type,mitigation,tags,commands,raw_data) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (category, title, kwargs.get('desc',''), kwargs.get('target_hash',''),
             kwargs.get('cve',''), kwargs.get('cvss'), kwargs.get('exploit_type',''),
             kwargs.get('mitigation',''), json.dumps(kwargs.get('tags',[])),
             kwargs.get('commands',''), kwargs.get('raw_data',''))
        )
        self.conn.commit()
        return cur.lastrowid

    def search_findings(self, query: str) -> list[dict]:
        q = f"%{query}%"
        rows = self.conn.execute(
            "SELECT * FROM findings WHERE category LIKE ? OR title LIKE ? OR description LIKE ? OR cve LIKE ? OR tags LIKE ?",
            (q,q,q,q,q)
        ).fetchall()
        return [dict(zip([d[0] for d in self.conn.execute("PRAGMA table_info(findings)")], r)) for r in rows]

    def add_technique(self, name: str, category: str = "", description: str = "",
                      steps: str = "", tags: str = "") -> int:
        try:
            cur = self.conn.execute(
                "INSERT OR REPLACE INTO techniques(name,category,description,steps,tags) VALUES(?,?,?,?,?)",
                (name, category, description, steps, tags)
            )
            self.conn.commit()
            return cur.lastrowid
        except Exception as e:
            return -1

    def search_techniques(self, query: str) -> list[dict]:
        q = f"%{query}%"
        rows = self.conn.execute(
            "SELECT * FROM techniques WHERE name LIKE ? OR category LIKE ? OR description LIKE ? OR tags LIKE ?",
            (q,q,q,q)
        ).fetchall()
        return [dict(zip([d[0] for d in self.conn.execute("PRAGMA table_info(techniques)")], r)) for r in rows]

    def add_ioc(self, ioc_type: str, ioc_value: str, **kwargs) -> int:
        cur = self.conn.execute(
            "INSERT INTO ioc(ioc_type,ioc_value,source,confidence,tags,first_seen) VALUES(?,?,?,?,?,datetime('now'))",
            (ioc_type, ioc_value, kwargs.get('source',''), kwargs.get('confidence',0.5),
             json.dumps(kwargs.get('tags',[])))
        )
        self.conn.commit()
        return cur.lastrowid

    def search_ioc(self, query: str) -> list[dict]:
        q = f"%{query}%"
        rows = self.conn.execute(
            "SELECT * FROM ioc WHERE ioc_value LIKE ? OR ioc_type LIKE ? OR tags LIKE ?", (q,q,q)
        ).fetchall()
        return [dict(zip([d[0] for d in self.conn.execute("PRAGMA table_info(ioc)")], r)) for r in rows]

    def export_category(self, category: str) -> list[dict]:
        rows = self.conn.execute("SELECT * FROM findings WHERE category = ?", (category,)).fetchall()
        return [dict(zip([d[0] for d in self.conn.execute("PRAGMA table_info(findings)")], r)) for r in rows]

    def stats(self) -> dict:
        return {
            "findings": self.conn.execute("SELECT COUNT(*) FROM findings").fetchone()[0],
            "techniques": self.conn.execute("SELECT COUNT(*) FROM techniques").fetchone()[0],
            "iocs": self.conn.execute("SELECT COUNT(*) FROM ioc").fetchone()[0],
            "categories": [r[0] for r in self.conn.execute("SELECT DISTINCT category FROM findings").fetchall()],
        }

    def close(self):
        self.conn.close()

PRESET_TECHNIQUES = [
    ("PE Reverse", "reverse", "PE binary analysis workflow", "header->sections->imports->exports->strings->entropy"),
    ("JWT Attack", "web", "JWT token analysis & attacks", "decode->check_algo->brute_secret->forge_claim"),
    ("SQLi Probe", "web", "SQL injection probe methodology", "error_based->union->blind_boolean->time_based->out_of_band"),
    ("Buffer Overflow", "pwn", "Classic stack buffer overflow", "fuzz->find_offset->control_eip->badchars->rop->shellcode"),
    ("Format String", "pwn", "Format string attack", "leak->write4->got_overwrite"),
    ("XSS Discovery", "web", "Cross-site scripting discovery", "reflected->stored->dom->bypass_waf"),
    ("Crypto Oracle", "crypto", "Padding oracle / bit flip attack", "identify_oracle->craft_block->decrypt->forge"),
    ("Heap Exploit", "pwn", "Heap exploitation methodology", "leak_heap->tcache_poison->fastbin_dup->house_of_*"),
    ("Patch Diff", "reverse", "Binary patch diff analysis", "bindiff->identify_patch->understand_fix->backport_exploit"),
    ("Phishing Kit", "social", "Phishing kit analysis", "extract_creds->trace_exfil->block_ioc"),
    ("Shellcode Dev", "exploit", "Shellcode development", "null_free->encode->custom_encoder->staged_payload"),
    ("Firmware Extract", "hardware", "Firmware extraction & analysis", "dump->entropy->binwalk->extract->emulate"),
]

BOOTSTRAP_KNOWLEDGE = {
    "reverse": [
        {"title": "PE Entry Point Analysis", "desc": "Check IMAGE_FILE_HEADER.AddressOfEntryPoint, trace from OEP"},
        {"title": "IAT Hooking Detection", "desc": "Compare IAT addresses with on-disk DLL exports"},
        {"title": "Anti-debug Techniques", "desc": "IsDebuggerPresent, NtQueryInformationProcess, PEB.BeingDebugged"},
    ],
    "exploit": [
        {"title": "ASLR Bypass via Info Leak", "desc": "Leak a pointer, calculate base, add offset"},
        {"title": "DEP Bypass via ROP", "desc": "VirtualProtect->shellcode or complete ROP chain"},
        {"title": "Stack Canary Bypass", "desc": "Leak canary via format string or overwrite __stack_chk_fail GOT"},
    ],
    "web": [
        {"title": "JWT Algorithm Confusion", "desc": "Change alg to 'none' or HS256 with known public key as HMAC secret"},
        {"title": "SSRF via URL Parsers", "desc": "Use URL parser inconsistencies: @, #, \\, \\n in URL"},
        {"title": "Prototype Pollution", "desc": "{}.__proto__.isAdmin=true via recursive merge without hasOwnProperty"},
    ],
    "malware": [
        {"title": "Process Injection Patterns", "desc": "OpenProcess+VirtualAllocEx+WriteProcessMemory+CreateRemoteThread"},
        {"title": "Persistence via Scheduled Tasks", "desc": "schtasks /create with SYSTEM triggers"},
        {"title": "C2 Beacon Patterns", "desc": "HTTP GET with jitter, DNS TXT records, ICMP tunneling"},
    ],
}

def bootstrap() -> int:
    """Pre-populate knowledge base with research techniques."""
    kb = KnowledgeBase()
    count = 0
    for name, cat, desc, steps in PRESET_TECHNIQUES:
        kb.add_technique(name, cat, desc, steps)
        count += 1
    for cat, findings in BOOTSTRAP_KNOWLEDGE.items():
        for f in findings:
            kb.add_finding(cat, f["title"], desc=f["desc"], tags=[cat])
            count += 1
    kb.close()
    return count

def dump_all() -> dict:
    return {"calling_conventions":{"x86_cdecl":"Caller cleans","x86_stdcall":"Callee cleans","x64_ms":"RCX,RDX,R8,R9"},"report_sections":["ID","Static","Dynamic","Algo","Network","Vuln","Deliverable","Refs"],"reverse_checksums":{"CRC32":"0xEDB88320","MD5":"broken","SHA256":"std"},"common_ports":{21:"FTP",22:"SSH",80:"HTTP",443:"HTTPS",3389:"RDP"}}

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(description="Knowledge Base Manager")
    sp = p.add_subparsers(dest="cmd")
    sp.add_parser("bootstrap",help="Pre-populate with research techniques")
    sf=sp.add_parser("search",help="Search findings");sf.add_argument("query")
    st=sp.add_parser("techniques",help="Search techniques");st.add_argument("query")
    si=sp.add_parser("ioc",help="Search IOCs");si.add_argument("query")
    sp.add_parser("stats",help="Knowledge base stats")
    a=p.parse_args()
    def emit(x): print(json.dumps(x,indent=2,ensure_ascii=False,default=str) if isinstance(x,(dict,list)) else x)
    if a.cmd=="bootstrap": emit(f"Bootstrapped {bootstrap()} entries")
    elif a.cmd=="search":
        kb=KnowledgeBase();emit(kb.search_findings(a.query));kb.close()
    elif a.cmd=="techniques":
        kb=KnowledgeBase();emit(kb.search_techniques(a.query));kb.close()
    elif a.cmd=="ioc":
        kb=KnowledgeBase();emit(kb.search_ioc(a.query));kb.close()
    elif a.cmd=="stats":
        kb=KnowledgeBase();emit(kb.stats());kb.close()
    else: p.print_help()
