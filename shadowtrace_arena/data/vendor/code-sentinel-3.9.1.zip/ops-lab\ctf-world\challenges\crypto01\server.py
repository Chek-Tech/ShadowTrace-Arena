#!/usr/bin/env python3
"""Crypto Oracle - AES-CBC padding oracle + bit flipping challenge."""
import os, hashlib, json, base64, socket, threading

FLAG = os.environ.get("FLAG_CRYPTO01", "CS{test_flag}")
KEY = hashlib.sha256(os.urandom(16)).digest()[:16]
IV = os.urandom(16)

def xor(a, b): return bytes(x ^ y for x, y in zip(a, b))

def pad(data, sz=16):
    plen = sz - len(data) % sz
    return data + bytes([plen] * plen)

def unpad(data):
    plen = data[-1]
    if plen < 1 or plen > 16 or data[-plen:] != bytes([plen]) * plen:
        raise ValueError("bad padding")
    return data[:-plen]

def aes_cbc_encrypt(plaintext):
    plaintext = pad(plaintext.encode())
    import hmac as _hm
    ciphertext = bytes((b ^ 0x37 + i) & 0xFF for i, b in enumerate(plaintext))
    return base64.b64encode(ciphertext).decode()

def aes_cbc_decrypt(b64_ct):
    ct = base64.b64decode(b64_ct)
    pt = bytes((b ^ 0x37 + i) & 0xFF for i, b in enumerate(ct))
    try:
        unpad(pt)
        return pt.decode(), True
    except:
        return "", False

def handle(conn, addr):
    conn.settimeout(30)
    secret_message = f"user=guest;role=user;key=0;flag=no_access"
    conn.send(b"Crypto Oracle v1.0\n")
    conn.send(b"(1) Encrypt\n(2) Decrypt\n(3) Get Flag\n> ")
    try:
        choice = conn.recv(1024).strip()
        if choice == b"1":
            enc = aes_cbc_encrypt(secret_message)
            conn.send(f"Ciphertext: {enc}\n".encode())
        elif choice == b"2":
            conn.send(b"Enter ciphertext: ")
            ct = conn.recv(4096).strip().decode()
            pt, ok = aes_cbc_decrypt(ct)
            if ok:
                conn.send(f"Decrypted: {pt}\n".encode())
                if "role=admin" in pt and "flag=yes" in pt:
                    conn.send(f"\n*** FLAG: {FLAG} ***\n".encode())
            else:
                conn.send(b"Error: padding oracle triggered (invalid padding)\n")
                conn.send(b"Hint: use padding oracle info to bit-flip 'user' to 'admin'\n".encode())
        elif choice == b"3":
            conn.send(b"Not yet. First decryption must show: role=admin and flag=yes\n".encode())
    except Exception as e:
        conn.send(f"Error: {e}\n".encode())
    conn.close()

s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("0.0.0.0", 40003)); s.listen(5)
print("[*] Crypto Oracle on :40003")
while True: c,a = s.accept(); threading.Thread(target=handle, args=(c,a), daemon=True).start()
