"""Tests for deep method packs / anon / report / protocol lab."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import ops_method_packs
import ops_anon
import ops_report_contract
import ops_protocol_lab


class MethodPacksTests(unittest.TestCase):
    def test_pack_count(self):
        self.assertGreaterEqual(len(ops_method_packs.PACKS), 12)

    def test_route_js(self):
        r = ops_method_packs.route_pack("前端 JS 签名参数 webpack 补环境")
        ids = [t["id"] for t in r["top"]]
        self.assertIn("js5", ids)

    def test_route_pwn(self):
        r = ops_method_packs.route_pack("ret2libc ROP one_gadget 远程")
        ids = [t["id"] for t in r["top"]]
        self.assertIn("pwn6", ids)

    def test_next_phase(self):
        n = ops_method_packs.next_phase("js5", ["J1"])
        self.assertEqual(n["next"]["id"], "J2")

    def test_get_fw9(self):
        p = ops_method_packs.get_pack("fw9")
        self.assertIsNotNone(p)
        self.assertEqual(len(p["phases"]), 9)

    def test_api10_phases(self):
        p = ops_method_packs.get_pack("api10")
        self.assertEqual(len(p["phases"]), 10)

    def test_anti(self):
        self.assertGreaterEqual(len(ops_method_packs.anti_analysis_table()), 5)


class AnonTests(unittest.TestCase):
    def test_mask_ip_token(self):
        r = ops_anon.anonymize("connect 10.20.30.40 token=SuperSecret99")
        self.assertNotIn("10.20.30.40", r["text"])
        self.assertNotIn("SuperSecret99", r["text"])
        self.assertGreater(r["replacements"], 0)


class ReportContractTests(unittest.TestCase):
    def test_template(self):
        t = ops_report_contract.template("ctf")
        blob = " ".join(t["sections"]).lower()
        self.assertTrue("复现" in blob or "flag" in blob or "证据" in blob)

    def test_validate_missing(self):
        v = ops_report_contract.validate_finding({"title": "x"})
        self.assertFalse(v["ok"])
        self.assertIn("request", v["missing"])

    def test_validate_ok(self):
        v = ops_report_contract.validate_finding({
            "title": "IDOR",
            "request": "GET /api/order/1 HTTP/1.1\nHost: lab",
            "side_effect": "order owned by other user visible",
            "diff": "id=1 vs id=2",
            "response_key": "200 owner_id",
        })
        self.assertTrue(v["ok"])


class ProtocolLabTests(unittest.TestCase):
    def test_checksum(self):
        c = ops_protocol_lab.checksum_candidates(b"\x01\x02\x03")
        algos = {x["algo"] for x in c}
        self.assertIn("crc32", algos)
        self.assertIn("xor8", algos)

    def test_mutate(self):
        base = b"\x00\x11\x22\x33"
        m = ops_protocol_lab.mutate_one_field(base, 1, 1, b"\xff")
        self.assertEqual(m[1], 0xFF)
        self.assertEqual(m[0], 0x00)

    def test_replay_plan(self):
        r = ops_protocol_lab.replay_plan("01020304", 1, 1)
        self.assertIn("mutants", r)
        self.assertGreaterEqual(len(r["mutants"]), 3)


if __name__ == "__main__":
    unittest.main()
