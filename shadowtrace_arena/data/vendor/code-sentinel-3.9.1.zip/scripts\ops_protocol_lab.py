#!/usr/bin/env python3
"""
Sentinel protocol lab helpers (original, stdlib).

Essences from protocol reverse / replay skill patterns:
  * Field map + state machine sketch
  * One-field differential mutations
  * Checksum/CRC candidates (common algos)
  * Session frame encode/decode scaffolding
  * Never claim a checksum without verifying against captured frames
"""

from __future__ import annotations

import argparse
import binascii
import json
import struct
import zlib
from dataclasses import asdict, dataclass, field
from typing import Any, Optional


def crc32(data: bytes) -> int:
    return zlib.crc32(data) & 0xFFFFFFFF


def checksum_sum8(data: bytes) -> int:
    return sum(data) & 0xFF


def checksum_xor(data: bytes) -> int:
    x = 0
    for b in data:
        x ^= b
    return x


def checksum_candidates(payload: bytes, claimed: Optional[int] = None) -> list[dict[str, Any]]:
    cands = [
        {"algo": "crc32", "value": crc32(payload), "hex": f"{crc32(payload):08x}"},
        {"algo": "sum8", "value": checksum_sum8(payload), "hex": f"{checksum_sum8(payload):02x}"},
        {"algo": "xor8", "value": checksum_xor(payload), "hex": f"{checksum_xor(payload):02x}"},
        {"algo": "len", "value": len(payload), "hex": f"{len(payload):x}"},
    ]
    if claimed is not None:
        for c in cands:
            c["matches_claimed"] = int(c["value"]) == int(claimed)
    return cands


@dataclass
class FieldSpec:
    name: str
    offset: int
    size: int
    kind: str = "bytes"  # bytes|u8|u16le|u16be|u32le|u32be|ascii
    notes: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ProtocolSketch:
    name: str
    fields: list[FieldSpec] = field(default_factory=list)
    states: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "fields": [f.to_dict() for f in self.fields],
            "states": self.states,
            "notes": self.notes,
        }


def parse_fields(data: bytes, fields: list[FieldSpec]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for f in fields:
        chunk = data[f.offset: f.offset + f.size]
        if len(chunk) < f.size:
            out[f.name] = {"error": "short", "got": len(chunk)}
            continue
        if f.kind == "u8":
            out[f.name] = chunk[0]
        elif f.kind == "u16le":
            out[f.name] = struct.unpack("<H", chunk)[0]
        elif f.kind == "u16be":
            out[f.name] = struct.unpack(">H", chunk)[0]
        elif f.kind == "u32le":
            out[f.name] = struct.unpack("<I", chunk)[0]
        elif f.kind == "u32be":
            out[f.name] = struct.unpack(">I", chunk)[0]
        elif f.kind == "ascii":
            out[f.name] = chunk.split(b"\x00")[0].decode("latin-1", errors="replace")
        else:
            out[f.name] = chunk.hex()
    return out


def mutate_one_field(base: bytes, offset: int, size: int, new_value: bytes) -> bytes:
    """Single-field differential: only [offset:offset+size] changes."""
    if len(new_value) != size:
        new_value = (new_value + b"\x00" * size)[:size]
    return base[:offset] + new_value + base[offset + size:]


def hex_diff(a: bytes, b: bytes) -> list[dict[str, Any]]:
    diffs = []
    n = max(len(a), len(b))
    for i in range(n):
        ba = a[i] if i < len(a) else None
        bb = b[i] if i < len(b) else None
        if ba != bb:
            diffs.append({"offset": i, "a": None if ba is None else f"{ba:02x}", "b": None if bb is None else f"{bb:02x}"})
    return diffs


def decode_hex(s: str) -> bytes:
    s = s.strip().replace(" ", "").replace("0x", "")
    return binascii.unhexlify(s)


def replay_plan(frame_hex: str, mut_offset: int = 0, mut_size: int = 1) -> dict[str, Any]:
    """Build a one-variable mutation plan from a captured frame."""
    try:
        frame = decode_hex(frame_hex)
    except Exception as exc:
        return {"error": str(exc)}
    mutants = []
    for b in (0x00, 0x01, 0xFF, 0x41):
        nv = bytes([b]) * mut_size
        m = mutate_one_field(frame, mut_offset, mut_size, nv)
        mutants.append({
            "value": nv.hex(),
            "frame_hex": m.hex(),
            "checksums": checksum_candidates(m),
            "diff_count": len(hex_diff(frame, m)),
        })
    return {
        "protocol": "sentinel-protocol-lab-v1",
        "base_len": len(frame),
        "base_checksums": checksum_candidates(frame),
        "mut_offset": mut_offset,
        "mut_size": mut_size,
        "mutants": mutants,
        "rules": [
            "每次只改一个字段",
            "记录服务接受/拒绝与状态推进",
            "校验和匹配需用多帧投票，单帧不可定论",
        ],
    }


def example_sketch() -> dict[str, Any]:
    sk = ProtocolSketch(
        name="lab-frame-v0",
        fields=[
            FieldSpec("magic", 0, 2, "bytes", "fixed header"),
            FieldSpec("version", 2, 1, "u8"),
            FieldSpec("msg_type", 3, 1, "u8"),
            FieldSpec("length", 4, 2, "u16le"),
            FieldSpec("payload", 6, 0, "bytes", "variable — set size from length"),
        ],
        states=["handshake", "auth", "data", "close"],
        notes=["先用被动捕获建字段表", "再单字段差分", "最后再写自动化 replay"],
    )
    return sk.to_dict()


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Protocol lab: checksums, mutate, sketch")
    sub = p.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("checksum", help="Checksum candidates for hex payload")
    c.add_argument("hex")
    c.add_argument("--claimed", type=lambda x: int(x, 0), default=None)

    r = sub.add_parser("replay-plan", help="One-field mutation plan")
    r.add_argument("hex")
    r.add_argument("--offset", type=int, default=0)
    r.add_argument("--size", type=int, default=1)

    d = sub.add_parser("diff", help="Hex diff two frames")
    d.add_argument("hex_a")
    d.add_argument("hex_b")

    sub.add_parser("sketch", help="Example protocol sketch")

    args = p.parse_args(argv)
    if args.cmd == "checksum":
        data = decode_hex(args.hex)
        print(json.dumps(checksum_candidates(data, args.claimed), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "replay-plan":
        print(json.dumps(replay_plan(args.hex, args.offset, args.size), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "diff":
        a, b = decode_hex(args.hex_a), decode_hex(args.hex_b)
        print(json.dumps(hex_diff(a, b), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "sketch":
        print(json.dumps(example_sketch(), ensure_ascii=False, indent=2))
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
