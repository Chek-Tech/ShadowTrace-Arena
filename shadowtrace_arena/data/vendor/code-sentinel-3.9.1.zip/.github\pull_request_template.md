## Description

<!-- Brief description of changes -->

## Type
- [ ] feat: new feature
- [ ] fix: bug fix
- [ ] docs: documentation
- [ ] refactor: code cleanup
- [ ] test: test addition/fix
- [ ] chore: maintenance

## Checklist
- [ ] Tests pass: `python -m unittest discover -s tests`
- [ ] Self-audit clean: `python scripts/sentinel_scan.py . --fail-on HIGH`
- [ ] New features have tests
- [ ] Documentation updated if needed
