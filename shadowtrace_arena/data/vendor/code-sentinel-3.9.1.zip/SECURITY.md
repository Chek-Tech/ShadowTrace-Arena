# Security Policy

## Supported Versions

| Version | Supported |
|---------|-----------|
| 2.x     | ✅ Active |
| < 2.0   | ❌ Deprecated |

## Reporting a Vulnerability

To report a security issue, open an issue in the repository with full details.

**Do not report security scanner false positives as vulnerabilities.** The scanner produces findings that require human triage. A finding is not a confirmed vulnerability until verified against source evidence and runtime context.

## Scope

This project is a **static analysis and review tool**. It does not:
- Execute or analyze live binaries
- Perform network scanning or exploitation
- Generate or deliver payloads
- Connect to external services

Vulnerability reports should concern the tool's own code — not findings produced by the scanner.
