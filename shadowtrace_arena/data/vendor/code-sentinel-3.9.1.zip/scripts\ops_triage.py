#!/usr/bin/env python3
"""
Sentinel deep triage — fingerprint card for files/hosts (original).

Produces a structured fingerprint used by ops_pipeline stage TRIAGE.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import struct
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional


MAGIC_TABLE: list[tuple[bytes, str]] = [
    (b"\x7fELF", "ELF"),
    (b"MZ", "PE/DOS"),
    (b"\xcf\xfa\xed\xfe", "Mach-O 64 LE"),
    (b"\xce\xfa\xed\xfe", "Mach-O 32 LE"),
    (b"\xca\xfe\xba\xbe", "Mach-O Fat"),
    (b"dex\n", "DEX"),
    (b"PK\x03\x04", "ZIP/APK/JAR/DOCX"),
    (b"\x00asm", "WASM"),
    (b"\x89PNG\r\n\x1a\n", "PNG"),
    (b"\xff\xd8\xff", "JPEG"),
    (b"%PDF", "PDF"),
    (b"\x1f\x8b", "GZIP"),
    (b"hsqs", "SquashFS"),
]


@dataclass
class Fingerprint:
    path: str
    exists: bool = False
    kind: str = "unknown"  # file|dir|host|url
    size: int = 0
    md5: str = ""
    sha256: str = ""
    magic: str = ""
    format: str = "unknown"
    arch_guess: str = ""
    entropy: float = 0.0
    packed_hint: bool = False
    packer_names: list[str] = field(default_factory=list)
    protections: dict[str, Any] = field(default_factory=dict)
    pe: dict[str, Any] = field(default_factory=dict)
    elf: dict[str, Any] = field(default_factory=dict)
    strings_sample: list[str] = field(default_factory=list)
    recommended_modules: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _entropy(data: bytes) -> float:
    if not data:
        return 0.0
    counts = [0] * 256
    for b in data:
        counts[b] += 1
    total = len(data)
    ent = 0.0
    for c in counts:
        if c:
            p = c / total
            ent -= p * math.log2(p)
    return ent


def _hashes(path: Path, max_read: int = 32_000_000) -> tuple[str, str]:
    md5 = hashlib.md5()
    sha = hashlib.sha256()
    with path.open("rb") as f:
        read = 0
        while read < max_read:
            chunk = f.read(65536)
            if not chunk:
                break
            md5.update(chunk)
            sha.update(chunk)
            read += len(chunk)
    return md5.hexdigest(), sha.hexdigest()


def _detect_magic(head: bytes) -> tuple[str, str]:
    for mag, name in MAGIC_TABLE:
        if head.startswith(mag):
            return mag.hex(), name
    return head[:8].hex(), "unknown"


def _sample_strings(data: bytes, n: int = 20) -> list[str]:
    found = re.findall(rb"[\x20-\x7e]{6,80}", data[:200_000])
    return [s.decode("ascii", errors="ignore") for s in found[:n]]


def _pe_light(data: bytes) -> dict[str, Any]:
    info: dict[str, Any] = {}
    if len(data) < 0x40 or data[:2] != b"MZ":
        return info
    e_lfanew = struct.unpack_from("<I", data, 0x3C)[0]
    if e_lfanew + 24 > len(data) or data[e_lfanew:e_lfanew + 4] != b"PE\x00\x00":
        return info
    machine = struct.unpack_from("<H", data, e_lfanew + 4)[0]
    chars = struct.unpack_from("<H", data, e_lfanew + 22)[0]
    machines = {0x14C: "x86", 0x8664: "x86_64", 0xAA64: "arm64"}
    info["machine"] = machines.get(machine, hex(machine))
    info["dll"] = bool(chars & 0x2000)
    info["relocs_stripped"] = bool(chars & 0x0001)
    # packer section names
    opt_size = struct.unpack_from("<H", data, e_lfanew + 20)[0]
    num_sec = struct.unpack_from("<H", data, e_lfanew + 6)[0]
    sec_off = e_lfanew + 24 + opt_size
    names = []
    for i in range(min(num_sec, 32)):
        off = sec_off + i * 40
        if off + 8 > len(data):
            break
        name = data[off:off + 8].split(b"\x00", 1)[0].decode("latin-1", errors="replace")
        names.append(name)
    info["sections"] = names
    packer_map = {
        "UPX": ["UPX0", "UPX1", "UPX2"],
        "ASPack": [".aspack", ".adata"],
        "VMP": [".vmp0", ".vmp1"],
        "Themida": [".themida"],
    }
    hits = []
    for pk, secs in packer_map.items():
        if any(s in names for s in secs):
            hits.append(pk)
    info["section_packers"] = hits
    return info


def _elf_light(data: bytes) -> dict[str, Any]:
    info: dict[str, Any] = {}
    if not data.startswith(b"\x7fELF") or len(data) < 20:
        return info
    ei_class = data[4]
    ei_data = data[5]
    info["bits"] = 64 if ei_class == 2 else 32
    info["endian"] = "little" if ei_data == 1 else "big"
    endian = "<" if info["endian"] == "little" else ">"
    machine = struct.unpack_from(endian + "H", data, 18)[0]
    arch = {3: "x86", 62: "x86_64", 40: "arm", 183: "arm64", 8: "mips", 243: "riscv"}.get(machine, str(machine))
    info["machine"] = arch
    return info


def triage_path(path: str | Path) -> Fingerprint:
    p = Path(path)
    fp = Fingerprint(path=str(p))
    if not p.exists():
        # host/url
        s = str(path)
        if re.match(r"https?://", s, re.I):
            fp.kind = "url"
            fp.format = "URL"
            fp.notes.append("network target — prefer M16/M17")
            fp.recommended_modules = ["M16", "M17", "M13"]
        elif re.search(r"\b\d{1,3}(?:\.\d{1,3}){3}\b", s) or ("." in s and " " not in s):
            fp.kind = "host"
            fp.format = "HOST"
            fp.recommended_modules = ["M17", "M16", "M13"]
        else:
            fp.notes.append("path not found")
        return fp

    fp.exists = True
    if p.is_dir():
        fp.kind = "dir"
        fp.format = "DIRECTORY"
        fp.size = sum(1 for _ in p.rglob("*") if _.is_file())
        fp.recommended_modules = ["M15", "M23", "M14"]
        fp.notes.append("directory — source/cloud gate preferred")
        return fp

    fp.kind = "file"
    fp.size = p.stat().st_size
    data = p.read_bytes()[: min(fp.size, 4_000_000)]
    fp.md5, fp.sha256 = _hashes(p)
    mag_hex, fmt = _detect_magic(data[:16] if data else b"")
    fp.magic = mag_hex
    fp.format = fmt
    fp.entropy = round(_entropy(data[: min(len(data), 256_000)]), 3)
    fp.strings_sample = _sample_strings(data)

    if fmt.startswith("PE"):
        fp.pe = _pe_light(data)
        fp.arch_guess = fp.pe.get("machine", "")
        fp.packer_names = list(fp.pe.get("section_packers") or [])
        fp.protections = {
            "relocs_stripped": fp.pe.get("relocs_stripped"),
            "dll": fp.pe.get("dll"),
        }
        fp.recommended_modules = ["M02", "M19", "M03"]
    elif fmt == "ELF":
        fp.elf = _elf_light(data)
        fp.arch_guess = fp.elf.get("machine", "")
        fp.recommended_modules = ["M01", "M22"]
    elif fmt == "DEX":
        fp.recommended_modules = ["M04"]
    elif fmt.startswith("Mach-O"):
        fp.recommended_modules = ["M03", "M05"]
    elif fmt.startswith("ZIP"):
        fp.recommended_modules = ["M04", "M07"]
        if p.suffix.lower() == ".apk":
            fp.notes.append("likely APK")
    elif fmt == "WASM":
        fp.recommended_modules = ["M06"]
    else:
        fp.recommended_modules = ["M25", "M21"]

    # packed heuristic
    if fp.entropy >= 7.2 or fp.packer_names:
        fp.packed_hint = True
        fp.notes.append("high entropy or packer section names")
        if "M02" in fp.recommended_modules or "M01" in fp.recommended_modules:
            pass
        fp.recommended_modules = list(dict.fromkeys(["M25"] + fp.recommended_modules + ["M21"]))

    # interesting string cues
    joined = " ".join(fp.strings_sample).lower()
    if any(x in joined for x in ("virtualalloc", "writeprocessmemory", "createremotethread")):
        fp.notes.append("injection-related strings")
        fp.recommended_modules = list(dict.fromkeys(fp.recommended_modules + ["M19"]))
    if any(x in joined for x in ("bitcoin", "encrypt", "ransom", "wallet")):
        fp.notes.append("ransomware-ish strings")
        fp.recommended_modules = list(dict.fromkeys(fp.recommended_modules + ["M03"]))

    return fp


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Sentinel deep triage")
    parser.add_argument("target")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    fp = triage_path(args.target)
    if args.json:
        print(json.dumps(fp.to_dict(), ensure_ascii=False, indent=2))
    else:
        d = fp.to_dict()
        for k in ("path", "kind", "format", "size", "sha256", "entropy", "packed_hint", "arch_guess"):
            print(f"{k:16}: {d.get(k)}")
        print(f"{'modules':16}: {d.get('recommended_modules')}")
        for n in d.get("notes") or []:
            print(f"note: {n}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
