#!/usr/bin/env python3
"""
Sentinel Ops Router — original task dispatch engine.

Design essences (re-implemented, not ported):
  * Slim core: route first, load details on demand
  * Multi-signal classification from free-text intent
  * Priority order when multiple signals fire
  * Module matrix → concrete tool invocations in this repo

This is Code Sentinel's own routing fabric. It does not load external
prompt packs or foreign knowledge-base chapters.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional


# ---------------------------------------------------------------------------
# Signal taxonomy (Sentinel-native names, not a copy of foreign labels)
# ---------------------------------------------------------------------------
# S1 源码门禁  S2 二进制静态  S3 样本画像  S4 算法/校验
# S5 网络侦察  S6 Web 面  S7 漏洞利用面  S8 专题(CTF/游戏/供应链)
SIGNAL_ORDER = ("S1", "S2", "S3", "S4", "S5", "S6", "S7", "S8")

SIGNAL_META: dict[str, dict[str, str]] = {
    "S1": {"name": "source_gate", "title": "源码安全门禁", "primary": "sentinel_scan"},
    "S2": {"name": "binary_static", "title": "二进制静态逆向", "primary": "reverse_engineering"},
    "S3": {"name": "malware_profile", "title": "恶意样本画像", "primary": "malware_analysis"},
    "S4": {"name": "algo_verify", "title": "算法/校验还原", "primary": "ctf_toolkit"},
    "S5": {"name": "net_recon", "title": "网络侦察", "primary": "pentest_recon"},
    "S6": {"name": "web_surface", "title": "Web 攻击面", "primary": "web_pentest"},
    "S7": {"name": "vuln_chain", "title": "漏洞链构造", "primary": "ctf_toolkit"},
    "S8": {"name": "special_topic", "title": "专题扩展", "primary": "attack_toolkit"},
}

# Weighted keyword cues → signal scores (Chinese + English, technical terms)
SIGNAL_CUES: dict[str, list[tuple[str, float]]] = {
    "S1": [
        (r"源码|代码审计|安全扫描|pr\b|pull request|ci\b|门禁|secret|注入|sql|xss|哨兵|sentinel_scan", 2.0),
        (r"\.py\b|\.js\b|\.ts\b|dockerfile|k8s|terraform|依赖|supply.?chain", 1.2),
        (r"扫描仓库|review pack|sarif|baseline", 1.5),
    ],
    "S2": [
        (r"逆向|反汇编|pe\b|elf\b|mach-?o|dex\b|二进制|ida|ghidra|imphash|iat\b|加壳|upx", 2.2),
        (r"\.exe\b|\.dll\b|\.so\b|\.sys\b|反调试|anti.?debug|section|entropy", 1.5),
        (r"静态分析|看汇编|字符串提取|导出表", 1.3),
        # mobile / APK surface (still binary-static primary)
        (r"apk|android|smali|jadx|apktool|il2cpp|so\s*库|native\s*so", 2.0),
        (r"frida|objection|ssl.?pin|jdwp|重打包|重签名", 1.6),
    ],
    "S3": [
        (r"木马|病毒|勒索|ransomware|rat\b|miner|恶意|malware|ioc|yara|c2\b", 2.2),
        (r"样本|sandbox|家族|持久化|注入进程|keylog", 1.4),
    ],
    "S4": [
        (r"算法|keygen|注册机|序列号|license|校验|crypto|aes|rsa|tea|xor|还原", 2.0),
        (r"crackme|keygenme|flag\{|ctf|cipher|hash", 1.6),
        (r"靶场|沙盒会话|继续项目|授权测试|ctf.?sandbox", 1.5),
    ],
    "S5": [
        (r"端口|port.?scan|banner|侦察|recon|dns|tls|主机|内网|nmap|存活", 2.0),
        (r"\b\d{1,3}(?:\.\d{1,3}){3}\b|网段|cidr|服务探测", 1.3),
        (r"ptes|渗透阶段|情报收集|pre-?engagement|engagement", 1.6),
    ],
    "S6": [
        (r"web|网站|http|https|cors|cookie|xss|sqli|lfi|目录|爆破|登录", 2.0),
        (r"owasp|waf|api\b|graphql|swagger|越权", 1.4),
        (r"web\s*预检|ptes.*web|应用面快扫", 1.4),
    ],
    "S7": [
        (r"漏洞|exploit|pwn|rop|溢出|uaf|堆|栈|shellcode|提权|rce", 2.2),
        (r"poc|利用链|内存破坏|格式化字符串", 1.5),
        (r"pwntools|ret2libc|one_gadget|ropgadget", 1.4),
    ],
    "S8": [
        (r"游戏|外挂|aimbot|unity|unreal|il2cpp|供应链|web3|固件|iot|隐写", 1.8),
        (r"spider|爬虫|卡密|会员|mitm|arp", 1.4),
        (r"移动安全|ios\b|ipa\b|越狱|root.?detect|mobile", 1.5),
        (r"全速|ctf.?speed|writeup|kali\s*工具", 1.2),
    ],
}

# Artifact extension → module bias
EXT_BIAS: dict[str, tuple[str, float]] = {
    ".py": ("S1", 1.5), ".js": ("S1", 1.5), ".ts": ("S1", 1.5), ".go": ("S1", 1.2),
    ".java": ("S1", 1.2), ".rs": ("S1", 1.2),
    ".exe": ("S2", 2.0), ".dll": ("S2", 2.0), ".sys": ("S2", 2.0),
    ".so": ("S2", 2.0), ".elf": ("S2", 2.0), ".bin": ("S2", 1.2),
    ".dex": ("S2", 1.8), ".apk": ("S2", 1.8), ".dylib": ("S2", 1.8),
    ".pcap": ("S5", 2.0), ".pcapng": ("S5", 2.0),
    ".yar": ("S3", 1.5), ".yara": ("S3", 1.5),
}

# Signal → ordered tool plan (repo-native modules)
TOOL_PLAN: dict[str, list[dict[str, str]]] = {
    "S1": [
        {"tool": "sentinel_scan", "cmd": "python scripts/sentinel_scan.py {target} --fail-on HIGH"},
        {"tool": "sentinel_pack", "cmd": "python scripts/sentinel_pack.py {target} --depth deep"},
        {"tool": "sentinel_report", "cmd": "python scripts/sentinel_report.py {target}"},
    ],
    "S2": [
        {"tool": "reverse_engineering", "cmd": "python scripts/reverse_engineering.py {target} --json"},
        {"tool": "re_surface", "cmd": "python scripts/re_surface.py {target} --json"},
        {"tool": "malware_analysis", "cmd": "python scripts/malware_analysis.py {target} --json"},
        {
            "tool": "gpt56_reverse_tools",
            "cmd": "python scripts/gpt56_reverse_pentest/reverse_tools.py pe {target}",
        },
    ],
    "S3": [
        {"tool": "malware_analysis", "cmd": "python scripts/malware_analysis.py {target} --json"},
        {"tool": "reverse_engineering", "cmd": "python scripts/reverse_engineering.py {target} --json"},
    ],
    "S4": [
        {"tool": "ops_ctf_runner", "cmd": "python scripts/ops_ctf_runner.py resume {target}"},
        {"tool": "ctf_toolkit", "cmd": "python scripts/ctf_toolkit.py {target}"},
        {"tool": "gpt56_crypto_helper", "cmd": "python scripts/gpt56_reverse_pentest/crypto_helper.py demo"},
        {"tool": "reverse_engineering", "cmd": "python scripts/reverse_engineering.py {target} --json"},
    ],
    "S5": [
        {"tool": "ops_ptes_lab", "cmd": "python scripts/ops_ptes_lab.py init {target}"},
        {"tool": "ops_phase_runner", "cmd": "python scripts/ops_phase_runner.py run {target} --advance"},
        {"tool": "ops_phase_kb", "cmd": "python scripts/ops_phase_kb.py target {target}"},
        {"tool": "ops_engagement", "cmd": "python scripts/ops_engagement.py enum-plan {target} --ports 22,80,443,445"},
        {"tool": "pentest_recon", "cmd": "python scripts/pentest_recon.py {target} --json"},
        {"tool": "attack_network", "cmd": "python scripts/pentest_suite.py attack network {target}"},
    ],
    "S6": [
        {"tool": "ops_phase_runner", "cmd": "python scripts/ops_phase_runner.py run {target} --phase L1W --advance"},
        {"tool": "ops_ptes_lab", "cmd": "python scripts/ops_ptes_lab.py plan L1W --target {target}"},
        {"tool": "ops_engagement", "cmd": "python scripts/ops_engagement.py web-pretest {target}"},
        {"tool": "ops_ctf_runner", "cmd": "python scripts/ops_ctf_runner.py domain web"},
        {"tool": "web_pentest", "cmd": "python scripts/web_pentest.py {target} --json"},
        {"tool": "pentest_recon", "cmd": "python scripts/pentest_recon.py {target} --json"},
        {"tool": "attack_spider", "cmd": "python scripts/pentest_suite.py attack spider {target}"},
    ],
    "S7": [
        {"tool": "ops_ctf_runner", "cmd": "python scripts/ops_ctf_runner.py brief {target} --domain pwn"},
        {"tool": "ctf_toolkit", "cmd": "python scripts/ctf_toolkit.py {target}"},
        {"tool": "gpt56_pwn_template", "cmd": "python scripts/gpt56_reverse_pentest/pwn_template.py --check"},
        {"tool": "reverse_engineering", "cmd": "python scripts/reverse_engineering.py {target} --json"},
        {"tool": "web_pentest", "cmd": "python scripts/web_pentest.py {target} --json"},
    ],
    "S8": [
        {"tool": "ops_phase_runner", "cmd": "python scripts/ops_phase_runner.py auto {target}"},
        {"tool": "ops_engagement", "cmd": "python scripts/ops_engagement.py bootstrap {target}"},
        {"tool": "attack_toolkit", "cmd": "python scripts/pentest_suite.py attack toolkit {target}"},
        {"tool": "ctf_toolkit", "cmd": "python scripts/ctf_toolkit.py {target}"},
        {
            "tool": "gpt56_reverse_tools",
            "cmd": "python scripts/gpt56_reverse_pentest/reverse_tools.py demo",
        },
    ],
}

# Mobile / APK enrichment steps (inserted when cues match)
_MOBILE_STEPS: list[dict[str, str]] = [
    {
        "tool": "gpt56_reverse_tools",
        "cmd": "python scripts/gpt56_reverse_pentest/reverse_tools.py strings {target}",
        "title": "APK/二进制字符串与编码辅助",
    },
    {
        "tool": "re_surface",
        "cmd": "python scripts/re_surface.py {target} --json",
        "title": "公网/包面提取",
    },
]
_MOBILE_RE = re.compile(
    r"apk|android|smali|jadx|apktool|frida|objection|ssl.?pin|ipa\b|ios\b|移动|重打包",
    re.I,
)

# Nested / special tool command templates
_TOOL_CMD_OVERRIDES: dict[str, str] = {
    "gpt56_reverse_tools": "python scripts/gpt56_reverse_pentest/reverse_tools.py pe {target}",
    "gpt56_crypto_helper": "python scripts/gpt56_reverse_pentest/crypto_helper.py demo",
    "gpt56_pwn_template": "python scripts/gpt56_reverse_pentest/pwn_template.py --check",
    "ops_ctf_runner": "python scripts/ops_ctf_runner.py resume {target}",
    "ops_chain": "python scripts/ops_chain.py plan --query \"{target}\"",
    "ops_framing": "python scripts/ops_framing.py auto --text \"{target}\"",
    "ops_surface_matrix": "python scripts/ops_surface_matrix.py route \"{target}\" --json",
}


def _tool_cmd(tool: str) -> str:
    """Build a python scripts/... invocation for a tool id (supports fusion paths)."""
    if tool in _TOOL_CMD_OVERRIDES:
        return _TOOL_CMD_OVERRIDES[tool]
    # Prefer known TOOL_PLAN entries
    for steps in TOOL_PLAN.values():
        for step in steps:
            if step.get("tool") == tool:
                return step["cmd"]
    return f"python scripts/{tool}.py {{target}}"


# Fallback chains when a tool is missing or fails (tool_bridge names)
FALLBACKS: dict[str, list[str]] = {
    "reverse_engineering": ["strings", "objdump", "readelf", "die", "ghidra", "gpt56_reverse_tools"],
    "malware_analysis": ["yara", "floss", "strings"],
    "pentest_recon": ["nmap", "httpx", "masscan"],
    "web_pentest": ["nuclei", "nikto", "ffuf", "sqlmap"],
    "sentinel_scan": ["semgrep", "bandit", "gitleaks", "trivy"],
    "ctf_toolkit": ["ropgadget", "one_gadget", "pwntools", "gpt56_crypto_helper", "gpt56_pwn_template"],
    "gpt56_reverse_tools": ["strings", "reverse_engineering"],
    "gpt56_crypto_helper": ["ctf_toolkit", "ops_algo"],
    "gpt56_pwn_template": ["ctf_toolkit", "pwntools"],
    "ops_phase_runner": ["ops_ptes_lab", "pentest_recon", "web_pentest"],
    "ops_engagement": ["ops_ptes_lab", "ops_phase_kb", "ops_phase_runner"],
    "ops_ptes_lab": ["ops_engagement", "ops_phase_runner"],
}


@dataclass
class RouteDecision:
    query: str
    signals: list[str]
    scores: dict[str, float]
    primary: str
    plan: list[dict[str, str]] = field(default_factory=list)
    fallbacks: dict[str, list[str]] = field(default_factory=dict)
    modules: list[dict[str, Any]] = field(default_factory=list)
    patterns: list[dict[str, Any]] = field(default_factory=list)
    surfaces: list[dict[str, Any]] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    defense_prompt: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _score_text(text: str) -> dict[str, float]:
    scores = {s: 0.0 for s in SIGNAL_ORDER}
    blob = text.lower()
    for sig, cues in SIGNAL_CUES.items():
        for pat, weight in cues:
            if re.search(pat, blob, re.I):
                scores[sig] += weight
    # path / extension hints
    for token in re.findall(r"[\w./\\-]+\.\w+", text):
        ext = Path(token).suffix.lower()
        if ext in EXT_BIAS:
            sig, w = EXT_BIAS[ext]
            scores[sig] += w
    # URL bias
    if re.search(r"https?://", text, re.I):
        scores["S6"] += 1.5
        scores["S5"] += 0.8
    # IP bias
    if re.search(r"\b\d{1,3}(?:\.\d{1,3}){3}\b", text):
        scores["S5"] += 1.5
    return scores


def classify(query: str, threshold: float = 1.0, reframe: bool = True) -> RouteDecision:
    """Classify free-text task into ordered signals and an execution plan.

    When reframe=True, hot colloquial terms are technically rewritten first
    (ops_framing) so routing sees precise language.
    """
    work_query = query
    frame_note = ""
    if reframe:
        try:
            import ops_framing
            fr = ops_framing.reframe_text(query, add_anchors=False)
            if fr.replacements:
                work_query = fr.rewritten
                frame_note = f"framing: {len(fr.replacements)} term(s) rewritten"
        except Exception:
            pass
    scores = _score_text(work_query)
    ranked = sorted(
        ((s, scores[s]) for s in SIGNAL_ORDER if scores[s] >= threshold),
        key=lambda x: (-x[1], SIGNAL_ORDER.index(x[0])),
    )
    if not ranked:
        # Default: source gate if looks like path to repo, else triage binary static
        if re.search(r"[/\\]|\.git\b|repo", work_query, re.I):
            ranked = [("S1", 0.5)]
        else:
            ranked = [("S2", 0.5)]
        notes = ["低置信默认路由 — 请补充更具体任务描述"]
    else:
        notes = []
    if frame_note:
        notes.append(frame_note)

    signals = [s for s, _ in ranked]
    primary = signals[0]
    # Merge tool plans, de-dupe by tool name, keep signal order
    seen: set[str] = set()
    plan: list[dict[str, str]] = []
    fb: dict[str, list[str]] = {}
    for sig in signals:
        for step in TOOL_PLAN.get(sig, []):
            name = step["tool"]
            if name in seen:
                continue
            seen.add(name)
            plan.append({
                "signal": sig,
                "tool": name,
                "cmd": step["cmd"],
                "title": SIGNAL_META[sig]["title"],
            })
            if name in FALLBACKS:
                fb[name] = FALLBACKS[name]

    defense = (
        "交付时同步输出：①如何检测同类风险 ②如何在真实产品中加固 "
        "（输入校验/完整性校验/最小权限/观测告警）。"
    )
    if not notes:
        notes.append(f"主信号 {primary}={SIGNAL_META[primary]['title']}")
        if len(signals) > 1:
            notes.append("多信号并行: " + " > ".join(signals))

    # Mobile / APK: ensure fusion helpers appear early in plan
    if _MOBILE_RE.search(work_query):
        notes.append("mobile/apk: 启用 gpt56-reverse-pentest 辅助 + re_surface")
        notes.append("refs: references/gpt56-reverse-pentest/apk-reverse.md")
        for step in reversed(_MOBILE_STEPS):
            name = step["tool"]
            if name in seen:
                # move existing to front by re-inserting if not already first
                continue
            seen.add(name)
            plan.insert(0, {
                "signal": "S2",
                "tool": name,
                "cmd": step["cmd"],
                "title": step["title"],
            })
            if name in FALLBACKS:
                fb[name] = FALLBACKS[name]

    # Fine modules + tool patterns (lazy import to keep router light)
    modules: list[dict[str, Any]] = []
    patterns: list[dict[str, Any]] = []
    try:
        import ops_modules
        modules = ops_modules.select_modules(query=work_query, target="", signals=signals, limit=6)
    except Exception as exc:
        notes.append(f"modules unavailable: {exc}")
    try:
        import ops_patterns
        patterns = ops_patterns.select_patterns(signals)
    except Exception as exc:
        notes.append(f"patterns unavailable: {exc}")

    surfaces: list[dict[str, Any]] = []
    try:
        import ops_surface_matrix
        mx = ops_surface_matrix.route_matrix(work_query, target="", top_k=4)
        surfaces = mx.get("top") or []
        if mx.get("dominant") and not mx.get("stay_generic"):
            notes.append(
                f"surface={mx['dominant'].get('surface_id')} "
                f"({mx['dominant'].get('title')})"
            )
            # prepend surface tools not already in plan
            for tool in (mx["dominant"].get("tools") or [])[:3]:
                if tool in seen:
                    continue
                seen.add(tool)
                cmd = _tool_cmd(tool)
                plan.insert(0, {
                    "signal": primary,
                    "tool": tool,
                    "cmd": cmd,
                    "title": f"surface:{mx['dominant'].get('surface_id')}",
                })
        elif mx.get("stay_generic"):
            notes.append("surface-matrix: stay generic (multi-surface / low score)")
    except Exception as exc:
        notes.append(f"surface matrix unavailable: {exc}")

    try:
        import ops_method_packs
        pk = ops_method_packs.route_pack(work_query, top_k=2)
        if pk.get("top"):
            notes.append("method_pack=" + ",".join(t["id"] for t in pk["top"]))
    except Exception as exc:
        notes.append(f"method packs unavailable: {exc}")

    return RouteDecision(
        query=query if query == work_query else f"{query} || framed: {work_query}",
        signals=signals,
        scores={k: round(v, 2) for k, v in scores.items() if v > 0},
        primary=primary,
        plan=plan,
        fallbacks=fb,
        modules=modules,
        patterns=patterns,
        surfaces=surfaces,
        notes=notes,
        defense_prompt=defense,
    )


def self_check() -> list[dict[str, Any]]:
    """Startup quality checklist (ops discipline, not persona roleplay)."""
    scripts = Path(__file__).parent
    extras = {
        "ops_modules": (scripts / "ops_modules.py").is_file(),
        "ops_patterns": (scripts / "ops_patterns.py").is_file(),
        "ops_fallback": (scripts / "ops_fallback.py").is_file(),
        "ops_triage": (scripts / "ops_triage.py").is_file(),
        "ops_algo": (scripts / "ops_algo.py").is_file(),
        "ops_knowledge": (scripts / "ops_knowledge.py").is_file(),
        "ops_framing": (scripts / "ops_framing.py").is_file(),
        "ops_sandbox": (scripts / "ops_sandbox.py").is_file(),
        "ops_payloads": (scripts / "ops_payloads.py").is_file(),
        "ops_gpt56": (scripts / "ops_gpt56.py").is_file(),
        "ops_doctor": (scripts / "ops_doctor.py").is_file(),
        "ops_surface_matrix": (scripts / "ops_surface_matrix.py").is_file(),
        "ops_tool_index": (scripts / "ops_tool_index.py").is_file(),
        "ops_journal": (scripts / "ops_journal.py").is_file(),
        "ops_chain": (scripts / "ops_chain.py").is_file(),
        "ops_ctf_runner": (scripts / "ops_ctf_runner.py").is_file(),
        "ops_method_packs": (scripts / "ops_method_packs.py").is_file(),
        "ops_anon": (scripts / "ops_anon.py").is_file(),
        "ops_report_contract": (scripts / "ops_report_contract.py").is_file(),
        "ops_protocol_lab": (scripts / "ops_protocol_lab.py").is_file(),
    }
    mod_count_ok = False
    try:
        import ops_modules
        mod_count_ok = len(ops_modules.MODULES) >= 25
    except Exception:
        pass
    checks = [
        ("signal_taxonomy", "S1-S8 信号表已加载", True),
        ("tool_plan", "每信号至少 1 个工具步骤", all(len(TOOL_PLAN[s]) >= 1 for s in SIGNAL_ORDER)),
        ("fallbacks", "核心工具具备 fallback", "reverse_engineering" in FALLBACKS),
        ("module_matrix", "25 细模块矩阵", mod_count_ok),
        ("ops_extras", "ops stack files (framing/sandbox/payloads/gpt56/doctor)", all(extras.values())),
        ("scripts_dir", "scripts 目录存在", scripts.is_dir()),
        ("references", "references 方法论目录", (Path(__file__).resolve().parents[1] / "references").is_dir()),
        ("gpt56_core", "GPT-5.6 core prompt", (Path(__file__).resolve().parents[1] / "prompts" / "gpt56-core.md").is_file()),
        ("defense_required", "攻防一体提示启用", True),
    ]
    return [{"id": i, "label": lab, "ok": ok} for i, lab, ok in checks]


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Sentinel Ops Router")
    parser.add_argument("query", nargs="*", help="任务描述（自然语言）")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--self-check", action="store_true")
    parser.add_argument("--target", default="{target}", help="替换计划中的 {target}")
    args = parser.parse_args(argv)

    if args.self_check:
        rows = self_check()
        if args.json:
            print(json.dumps(rows, ensure_ascii=False, indent=2))
        else:
            for r in rows:
                mark = "OK" if r["ok"] else "FAIL"
                print(f"[{mark}] {r['id']}: {r['label']}")
        return 0 if all(r["ok"] for r in rows) else 1

    query = " ".join(args.query).strip()
    if not query:
        print("Usage: ops_router.py <任务描述> [--target PATH] [--json]", file=sys.stderr)
        return 2

    decision = classify(query)
    # materialize target placeholder
    for step in decision.plan:
        step["cmd"] = step["cmd"].replace("{target}", args.target)

    if args.json:
        print(json.dumps(decision.to_dict(), ensure_ascii=False, indent=2))
    else:
        print(f"Query   : {decision.query}")
        print(f"Primary : {decision.primary} ({SIGNAL_META[decision.primary]['title']})")
        print(f"Signals : {' > '.join(decision.signals)}")
        print(f"Scores  : {decision.scores}")
        print("Plan:")
        for i, step in enumerate(decision.plan, 1):
            print(f"  {i}. [{step['signal']}] {step['tool']}")
            print(f"     {step['cmd']}")
        if decision.fallbacks:
            print("Fallbacks:")
            for tool, chain in decision.fallbacks.items():
                print(f"  {tool} → {' | '.join(chain)}")
        for n in decision.notes:
            print(f"note: {n}")
        print(f"defense: {decision.defense_prompt}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
