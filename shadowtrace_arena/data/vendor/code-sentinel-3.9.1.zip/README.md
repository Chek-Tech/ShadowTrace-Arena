# Code Sentinel

**零依赖安全全栈 · GPT-5.6 优先 · 可一键注入 Codex**

源码门禁扫描 · 二进制逆向 · 恶意样本画像 · 网络侦察 · Web 探测 · CTF 工具 ·  
实验室编排 / 破甲 framing · Trigger 激活（**豆包大人**）

版本：**3.9.1**（可交付 · 查缺补漏 · 阶段真执行闭环 · 全量交战精髓 · 域图谱）

---

## 1 分钟上手

### Windows（推荐）

| 操作 | 文件 |
|------|------|
| **一键注入 Codex** | 双击 **`Windows启动.bat`** |
| 卸载 | 双击 **`Windows卸载.bat`** |
| 查看状态 | 双击 **`Windows状态.bat`** |

然后：

1. **完全退出并重启 Codex**
2. 对话中发送：**`豆包大人`**
3. 即可使用全部 Code Sentinel 能力

关闭激活：`豆包退下` 或 `CS-OFF`

### Linux / macOS

```bash
chmod +x Linux启动.sh Linux卸载.sh
./Linux启动.sh          # Linux
# 或双击 macOS启动.command
```

### 命令行自检

```bash
python sentinel.py doctor
python sentinel.py --version
```

---

## 能力一览

| 模块 | 说明 |
|------|------|
| 源码扫描 | 182 条规则，JSON / Markdown / SARIF，CI 门禁 |
| 证据包 / 报告 | `sentinel_pack` + `sentinel_report`（AI 深审合并） |
| 二进制逆向 | PE IAT/imphash、ELF/DEX/Mach-O、能力图、Rich 头 |
| 公网/软件面 | 从样本提取 URL/域名/IP/PDB/云服务，可选联机探测 |
| 恶意画像 | 勒索/RAT/矿工评分、IoC、YARA 草稿 |
| 侦察 / Web | 端口 Banner、TLS、安全头、SQLi/XSS/LFI 等 |
| 攻防实验室 | spider / keygen / network 等引擎 + payload 任务馆 |
| Ops 编排 | S1–S8 路由、25 模块、6 Pattern、Fallback、全深流水线 |
| 精髓栈 | 表面矩阵 48 · 方法包 26 · CTF 续跑 · 攻击链 · 工具索引 · 战地日志 |
| 破甲/服从 | framing L1–L5 · 双层沙箱 · 服从性门禁 · 可选 lab model_instructions |
| 图谱 | `ops_essence_atlas` 91 源 → 原创模块（coverage complete） |
| GPT-5.6 | 瘦核心提示、framing、双层沙箱、L1–L5 恢复 |
| Codex 注入 | AGENTS + **9** Skills（gpt56-reverse-pentest / ptes / **engagement**…），触发词 **豆包大人** |
| 全栈逆向渗透包 | 16 篇 references + reverse_tools/crypto/pwn 模板（Desktop CTF 融合） |
| 原创 PTES Lab | `ops_ptes_lab` 阶段交接 / 目标契约 / 转段门禁 + `ops_phase_kb` 证据驱动知识路由 |
| 全量交战精髓栈 | `ops_engagement`：枚举剧本 / Web 预检 / solutions 合并 / 报告门禁 / 范围访谈 |

---

## 目录结构（交付态）

```
Code Sentinel/
├── Windows启动.bat / Windows卸载.bat / Windows状态.bat   # Windows 一键
├── Linux启动.sh / Linux卸载.sh
├── macOS启动.command / macOS卸载.command
├── sentinel.py                 # CLI 总入口
├── VERSION / LICENSE / README.md
├── SKILL.md                    # Agent/Skill 说明
├── pyproject.toml
├── agents/                     # gpt56 / openai / claude
├── prompts/                    # gpt56-core + config
├── codex-bundle/               # 注入 Codex 的 AGENTS 片段 + skills
├── scripts/                    # 全部引擎与 ops 工具
│   ├── sentinel_*.py           # 扫描 / 证据包 / 报告
│   ├── reverse_engineering.py / malware_analysis.py
│   ├── pentest_*.py / web_pentest.py / attack_*.py
│   ├── ops_*.py / codex_inject.py
│   └── auditors/
├── references/                 # 方法论文档
├── tests/                      # 单元测试
├── ops-lab/                    # 运行时案例目录（空壳交付）
└── .github/workflows/          # CI
```

---

## 常用命令

```bash
# 健康检查（含精髓图谱）
python sentinel.py doctor
python scripts/ops_essence_atlas.py coverage

# 源码门禁
python scripts/sentinel_scan.py /path/to/repo --fail-on HIGH

# 全深分析流水线
python sentinel.py pipeline sample.exe --query "恶意画像"

# 公网/商业软件逆向（URL·域名·版本·PDB + 可选探测）
python scripts/re_surface.py sample.exe --json
python scripts/re_surface.py sample.exe --probe
python sentinel.py reverse sample.exe --surface --json

# GPT-5.6 会话包（可粘贴到 ChatGPT）
python scripts/ops_gpt56.py session "分析 pe" --target sample.exe --paste

# 实验室 payload 任务
python scripts/ops_payloads.py list
python scripts/ops_payloads.py build P-REMOTE-AGENT --mode progressive

# 原创 PTES Lab（阶段生命周期 · 非第三方语料）
python scripts/ops_ptes_lab.py init 192.168.1.10
python scripts/ops_ptes_lab.py status 192.168.1.10
python scripts/ops_phase_kb.py target 192.168.1.10
python sentinel.py ptes advance 192.168.1.10 --http --summary "recon done"

# 全量交战精髓栈（一次性精髓落地）
python scripts/ops_engagement.py essences
python scripts/ops_engagement.py bootstrap https://lab.example
python scripts/ops_engagement.py enum-plan 10.0.0.1 --ports 22,80,445,3389
python scripts/ops_engagement.py web-pretest https://lab.example
python sentinel.py engage chain lab.example

# 阶段真执行闭环（recon→…→report 落盘）
python scripts/ops_phase_runner.py auto 127.0.0.1 --ports 22,80,443
python scripts/ops_engagement.py auto https://example.com --ports 80,443
python sentinel.py engage auto 127.0.0.1 --ports 22,80,443

# Codex 注入（等价于 Windows启动）
python scripts/codex_inject.py install
python scripts/codex_inject.py status
```

---

## 文档索引

| 文档 | 内容 |
|------|------|
| [使用说明.md](使用说明.md) | 交付使用手册（中文） |
| [references/codex-inject.md](references/codex-inject.md) | Codex 注入与触发词 |
| [references/gpt56-profile.md](references/gpt56-profile.md) | GPT-5.6 配置 |
| [references/ops-method.md](references/ops-method.md) | Ops 编排方法论 |
| [references/ops-sandbox-protocol.md](references/ops-sandbox-protocol.md) | 双层沙箱与证据序 |
| [references/deep-analysis.md](references/deep-analysis.md) | 七维 AI 深审 |
| [references/configuration.md](references/configuration.md) | `.sentinel.toml` 配置 |
| [SKILL.md](SKILL.md) | 完整能力与命令表 |
| [CHANGELOG.md](CHANGELOG.md) | 版本历史 |

---

## 环境要求

- **Python 3.10+**（仅标准库，无 pip 依赖）
- Windows / Linux / macOS
- 注入 Codex 需本机已安装 [Codex CLI](https://github.com/openai/codex)（`~/.codex`）

```bash
python -m unittest discover -s tests -p "test_*.py"
python scripts/ops_doctor.py
```

---

## 许可

MIT · 详见 [LICENSE](LICENSE)
