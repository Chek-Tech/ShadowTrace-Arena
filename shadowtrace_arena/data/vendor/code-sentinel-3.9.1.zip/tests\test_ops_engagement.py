"""Tests for original engagement suite (full essence stack)."""

from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import ops_engagement
import ops_ptes_lab


class EngagementTests(unittest.TestCase):
    def test_essence_count(self):
        m = ops_engagement.essence_map()
        self.assertGreaterEqual(m["count"], 15)

    def test_enum_plan(self):
        p = ops_engagement.plan_service_enum("10.0.0.1", [22, 80, 445, 3389])
        ids = {x["id"] for x in p["playbooks"]}
        self.assertIn("SP-HTTP", ids)
        self.assertIn("SP-SMB", ids)
        self.assertIn("SP-SSH", ids)

    def test_web_pretest(self):
        b = ops_engagement.web_pretest_blueprint("https://x.test")
        self.assertEqual(len(b["phases"]), 3)

    def test_bootstrap_and_report(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            # init via ptes then engagement
            ops_ptes_lab.init_target("https://eng.test", base=base, force=True)
            mat = ops_engagement.materialize_phase_dirs("https://eng.test", "L1", base)
            self.assertTrue(mat["created"] or True)
            val = ops_engagement.validate_engagement("https://eng.test", base)
            self.assertIn("phases", val)
            ch = ops_engagement.chain_plan("https://eng.test", base)
            self.assertTrue(ch.get("sequence"))
            rep = ops_engagement.build_report("https://eng.test", base)
            self.assertTrue(Path(rep["report"]).is_file())
            # solutions merge
            ops_ptes_lab.append_solution("https://eng.test", "L1", "demo note", base=base)
            merged = ops_engagement.merge_solutions(base)
            self.assertTrue(merged["ok"])
            self.assertGreaterEqual(merged["entries"], 1)

    def test_scope_interview(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "scope.json"
            q1 = ops_engagement.scope_interview_ask(path)
            self.assertFalse(q1["done"])
            slot = q1["slot"]
            r = ops_engagement.scope_interview_answer(slot, "10.0.0.1", path)
            self.assertTrue(r.get("done") or r.get("question"))


if __name__ == "__main__":
    unittest.main()
