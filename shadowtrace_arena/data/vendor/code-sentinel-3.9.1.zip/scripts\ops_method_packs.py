#!/usr/bin/env python3
"""
Sentinel Method Packs — deep methodology engines (original).

Essences learned from multi-domain reverse/pentest skill systems
(re-implemented as structured phase machines, not copied prose):

  JS:     Observe-first → Capture (hook>breakpoint) → Rebuild → Patch → DeepDive
  Pwn:    mitigations → strategy → gadgets → local → remote stabilize (≥N runs)
  FW:     gather → obtain → analyze → extract → fs-static → emulate → dynamic → runtime → exploit
  API:    discover → authn → authz → graphql → input → logic → ws → rate → exposure → cicd
  EDR:    identify → hook-diff → combo → implement → validate → deliver  (+ blue dual notes)
  LLM:    map surface → inject ladder → tool abuse → memory poison → output sinks → sysprompt → agent control
  Malware:triage → static → dynamic → yara → sigma → ioc
  Supply: inventory → sbom → sca → build → deploy → runtime
  Patch:  anchor → export pair → structured match → apply → iterate
  Mobile: manifest → static → pin/hook → native → network → retest
  Loop:   scope → recon → exploit → validate → report → learn
  Gap:    control inventory → expected enforce → observed enforce → delta → prove
  Diff:   old symbols → new binary → anchor → migrate map

Each pack: phases with must-produce, tools, defense, failure rewind.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import asdict, dataclass, field
from typing import Any, Optional


@dataclass
class Phase:
    id: str
    title: str
    must: list[str]
    actions: list[str]
    tools: list[str] = field(default_factory=list)
    fail_rewind: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class MethodPack:
    id: str
    title: str
    family: str
    cues: list[str]
    principles: list[str]
    phases: list[Phase]
    defense: list[str]
    sentinel_tools: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        return d


PACKS: dict[str, MethodPack] = {}


def _p(pid: str, title: str, must: list[str], actions: list[str],
       tools: Optional[list[str]] = None, fail_rewind: str = "") -> Phase:
    return Phase(pid, title, must, actions, tools or [], fail_rewind)


def _pack(**kwargs) -> MethodPack:
    mp = MethodPack(**kwargs)
    PACKS[mp.id] = mp
    return mp


# ---------------------------------------------------------------------------
# Packs
# ---------------------------------------------------------------------------
_pack(
    id="js5",
    title="前端 JS 签名五阶段",
    family="web",
    cues=[r"js.?逆|签名参数|webpack|补环境|ast.?反混淆|sourcemap|xhr|fetch.?sign"],
    principles=[
        "先观察后猜测环境",
        "Hook 优先于硬断点",
        "本地重建必须以页面证据为依据",
        "一次一个最小补丁，立即复测",
        "签名任务可跳过 DeepDive；算法复用必须 DeepDive",
    ],
    phases=[
        _p("J1", "Observe 观察",
           ["目标请求 URL/特征", "initiator 线索", "可疑脚本 URL", "任务记录起步"],
           ["打开页面/列出网络请求", "回溯 initiator", "搜索脚本中的签名关键字"],
           ["web_pentest", "ops_ctf_runner"], "无目标请求时不进入 Capture"),
        _p("J2", "Capture 采样",
           ["参数样例", "调用顺序", "运行时入参/返回"],
           ["XHR/Fetch 断点或轻量 evaluate", "记录 paused 信息", "必要时文本断点"],
           ["web_pentest"], "证据不足回 J1"),
        _p("J3", "Rebuild 本地重建",
           ["最小 Node 复现骨架", "证据→环境映射表"],
           ["整理捕获为本地脚本输入", "禁止空想 window/document/crypto"],
           ["ops_algo", "ctf_toolkit"], "与页面不一致回 J2"),
        _p("J4", "Patch 差分补环境",
           ["稳定产出目标参数", "补丁决策日志"],
           ["按 first divergence 补丁", "单变量补丁+复测"],
           ["ops_algo"], "发散扩大时回 J3 缩小因果"),
        _p("J5", "DeepDive 提纯",
           ["去混淆后可读算法", "可复用变换链说明"],
           ["AST/控制流还原", "业务逻辑提纯"],
           ["ops_algo", "ctf_toolkit"], ""),
    ],
    defense=["服务端重算签名", "nonce/时间窗", "设备指纹不可单独信任客户端", "关键字段服务端权威"],
    sentinel_tools=["web_pentest", "ops_algo", "ctf_toolkit", "ops_ctf_runner"],
)

_pack(
    id="pwn6",
    title="漏洞点→稳定利用六阶",
    family="reverse",
    cues=[r"pwn|rop|ret2|one_gadget|堆利用|tcache|uaf|kernel.?pwn|smep|kaslr"],
    principles=[
        "先确认保护机制再选策略",
        "本地通 ≠ 远程通",
        "libc 必须 leak+指纹反查，禁止拍脑袋版本",
        "x64 栈 16 字节对齐（movaps 坑）",
        "远程稳定性用精确 recv 锚点 + 多轮成功率",
    ],
    phases=[
        _p("P1", "分型与缓解",
           ["漏洞类(栈/格式化/堆/内核)", "NX/Canary/PIE/RELRO/…"],
           ["checksec/file/readelf", "确认崩溃原语"],
           ["reverse_engineering", "ctf_toolkit"]),
        _p("P2", "利用策略",
           ["策略树节点", "是否需要 leak"],
           ["NX 关→shellcode", "有 libc→ret2libc/one_gadget", "堆按 glibc 版本选型", "内核看 SMEP/SMAP/KASLR"],
           ["ctf_toolkit"]),
        _p("P3", "Gadget/Libc 材料",
           ["gadget 列表或 one_gadget", "libc base 计算式"],
           ["ROPgadget/one_gadget/libc-database 思路", "记录偏移公式"],
           ["ctf_toolkit", "ops_algo"]),
        _p("P4", "本地 exploit",
           ["本地 interactive/shell", "offset 精确"],
           ["cyclic 定偏移", "调试器确认寄存器", "模板化 payload"],
           ["ctf_toolkit", "reverse_engineering"]),
        _p("P5", "远程稳定化",
           ["remote 连续成功阈值", "对齐/延迟/缓冲处理"],
           ["leak 反查 libc", "加 ret 对齐", "sendlineafter 锚点", "堆喷放大"],
           ["ctf_toolkit"], "失败回 P3/P4 查环境差"),
        _p("P6", "移交/后利用",
           ["可复现脚本+环境说明", "下游攻击链接口"],
           ["归档 ops_case", "接入 ops_chain C2+"],
           ["ops_case", "ops_chain", "ops_journal"]),
    ],
    defense=["开启全缓解", "沙箱化服务", "禁止可写可执行", "及时补丁 glibc/内核"],
    sentinel_tools=["reverse_engineering", "ctf_toolkit", "ops_chain", "ops_case"],
)

_pack(
    id="fw9",
    title="固件/IoT 九阶渗透链",
    family="reverse",
    cues=[r"固件|firmware|binwalk|squashfs|ubi|iot|路由器|firmadyne|uart|jtag"],
    principles=[
        "提取失败先换提取器组合，勿直接断定加密",
        "高熵全段才优先 bootloader/硬件 dump",
        "仿真失败优先 NVRAM/网卡名/dev 节点",
        "MIPS/ARM 注意大小端",
        "EMBA/自动报告要人工核对可达性",
    ],
    phases=[
        _p("F1", "情报收集", ["芯片/SDK/公开 CVE"], ["型号 FCC/资料", "SDK 线索"], ["pentest_recon", "ops_journal"]),
        _p("F2", "获取固件", ["固件文件哈希"], ["官网/OTA/UART/SPI"], ["pentest_recon"]),
        _p("F3", "头部/熵/字符串", ["magic/熵图/关键串"], ["strings/file/hex 头"], ["reverse_engineering", "re_surface"]),
        _p("F4", "文件系统提取", ["rootfs 目录"], ["多提取器递归", "JFFS2/UBI 专项"], ["reverse_engineering"], "全失败→bootloader/硬件"),
        _p("F5", "FS 静态分析", ["默认凭据/危险 CGI/旧组件"], ["扫 conf/shadow/system 拼接"], ["sentinel_scan", "malware_analysis"]),
        _p("F6", "仿真运行", ["可达管理面/服务"], ["user qemu 或全系统仿真"], ["pentest_recon"]),
        _p("F7", "动态分析", ["可触发输入点"], ["抓包/调试挂接"], ["web_pentest", "reverse_engineering"]),
        _p("F8", "运行时/Fuzz", ["crash 或覆盖率线索"], ["qemu-mode fuzz/覆盖缺口"], ["ctf_toolkit"]),
        _p("F9", "利用落地", ["PoC + 真机或仿真复现"], ["架构匹配 payload", "权威态确认"], ["ctf_toolkit", "ops_case"]),
    ],
    defense=["安全启动", "签名更新", "关闭调试口", "默认口令轮换", "Web CGI 参数不进 shell"],
    sentinel_tools=["reverse_engineering", "re_surface", "web_pentest", "ctf_toolkit", "ops_case"],
)

_pack(
    id="api10",
    title="API 安全十阶段",
    family="web",
    cues=[r"api.?安全|bola|bfla|graphql|openapi|swagger|websocket.?安全|oauth|jwt.?测试"],
    principles=[
        "先发现契约再测授权",
        "授权结论需要双会话差分",
        "GraphQL 内省可能被裁剪，分级尝试",
        "限速绕过与业务逻辑分开记",
        "发现要能落回归用例",
    ],
    phases=[
        _p("A1", "发现与侦察", ["端点清单/规范"], ["swagger/openapi/js 提取/爆破路径"], ["web_pentest", "pentest_recon"]),
        _p("A2", "认证", ["token 弱点列表"], ["JWT alg/kid/弱密钥", "OAuth redirect/state/PKCE"], ["ops_algo", "web_pentest"]),
        _p("A3", "授权 BOLA/BFLA", ["可复现越权流量"], ["ID 遍历", "方法切换", "角色矩阵"], ["web_pentest", "ops_ctf_runner"]),
        _p("A4", "GraphQL 专项", ["内省/批/深度结果"], ["别名过载", "GET mutation"], ["web_pentest"]),
        _p("A5", "REST 输入", ["注入/SSRF/污染点"], ["方法/Content-Type 切换", "HPP/批量赋值"], ["web_pentest"]),
        _p("A6", "业务逻辑/差分", ["状态机异常"], ["多角色工作流", "竞态", "版本差分"], ["web_pentest", "ops_ctf_runner"]),
        _p("A7", "WebSocket", ["握手鉴权与注入面"], ["消息类型混淆", "CSWH 面"], ["web_pentest", "attack_network"]),
        _p("A8", "限速/DoS", ["绕过头/路径变体结果"], ["XFF 等", "批查询深度"], ["web_pentest", "ops_ctf_runner"]),
        _p("A9", "数据暴露", ["过度返回字段"], ["UI vs API 对比", "错误信息"], ["web_pentest"]),
        _p("A10", "回归/CI", ["可重复用例集"], ["固化请求到测试", "变更监听思路"], ["ops_journal", "ops_case"]),
    ],
    defense=["对象级授权强制", "schema 最小化", "统一限速", "错误脱敏", "OpenAPI 驱动网关"],
    sentinel_tools=["web_pentest", "ops_algo", "pentest_recon", "ops_ctf_runner"],
)

_pack(
    id="edr6",
    title="检测面测绘→对抗评估六阶",
    family="identity",
    cues=[r"edr|amsi|etw|unhook|syscall|免杀|pe-sieve|call.?stack.?spoof|sysmon"],
    principles=[
        "先识别监控面再谈组合对抗",
        "用户态 hook ≠ 全部战场（ETW/内核回调）",
        "顺序影响可观测性",
        "实验室验证必须双写蓝队检测点",
        "授权演练边界内操作",
    ],
    phases=[
        _p("E1", "识别 EDR/AV", ["产品/驱动/minifilter 列表"], ["服务名/fltmc/进程"], ["ops_tool_index", "malware_analysis"]),
        _p("E2", "Hook/遥测面", ["hook 点或 provider 列表"], ["内存 ntdll vs 磁盘 diff", "ETW/AMSI 入口"], ["malware_analysis", "reverse_engineering"]),
        _p("E3", "组合策略", ["监控面→对策映射表"], ["间接 syscall/ETW/AMSI/栈欺骗 组合"], ["ops_surface_matrix"]),
        _p("E4", "实验室实现说明", ["可审计步骤", "不落未授权目标"], ["在隔离环境实现验证用 harness"], ["ops_payloads", "attack_toolkit"]),
        _p("E5", "验证", ["告警源对照表"], ["Defender/Sysmon/ETW-TI/EDR 控制台"], ["ops_journal"]),
        _p("E6", "投递上下文+加固", ["OPSEC 检查表", "检测加固清单"], ["合法路径/PPID 上下文说明", "蓝队规则建议"], ["ops_case"]),
    ],
    defense=[
        "内核回调与 ETW-TI 覆盖",
        "内存扫描与 call stack 异常",
        "AMSI/脚本阻断",
        "Sysmon 1/7/8/10 关联",
        "禁止仅依赖用户态 hook",
    ],
    sentinel_tools=["malware_analysis", "reverse_engineering", "ops_payloads", "ops_case"],
)

_pack(
    id="llm7",
    title="LLM/Agent 威胁七阶",
    family="special",
    cues=[r"prompt.?inject|llm.?安全|rag.?投毒|agent.?工具|系统提示词|越狱|garak|asi\b"],
    principles=[
        "不可信内容≠指令",
        "工具调用要最小权限+人审",
        "间接注入在检索/邮件/网页中",
        "输出可能成为下游注入载荷",
        "用 canary 检测提示词泄漏",
    ],
    phases=[
        _p("L1", "攻击面测绘", ["入口/工具/数据流图"], ["聊天/上传/API/邮件", "工具清单"], ["ops_surface_matrix", "sentinel_scan"]),
        _p("L2", "注入阶梯", ["各等级结果"], ["直接覆盖→角色→编码→多轮→间接"], ["ops_framing", "ops_sandbox"]),
        _p("L3", "工具滥用", ["越权组合路径"], ["参数注入", "跳过审批话术"], ["ops_payloads"]),
        _p("L4", "记忆/RAG 投毒", ["检索污染证据"], ["恶意文档植入", "长期记忆漂移"], ["ops_journal"]),
        _p("L5", "输出安全", ["下游 sink 列表"], ["XSS/SQLi/命令/SSRF via 生成内容"], ["sentinel_scan", "web_pentest"]),
        _p("L6", "系统提示提取", ["泄漏等级"], ["复述/翻译/JSON/多轮逼近", "canary"], ["ops_framing"]),
        _p("L7", "Agent 控制面", ["服从性/规划漂移记录"], ["强制步骤契约", "工具边界"], ["ops_sandbox", "ops_gpt56"]),
    ],
    defense=["输入/检索隔离", "工具 allowlist", "输出编码", "canary token", "人在回路"],
    sentinel_tools=["ops_framing", "ops_sandbox", "ops_gpt56", "sentinel_scan"],
)

_pack(
    id="mal6",
    title="样本分析六阶段",
    family="reverse",
    cues=[r"恶意样本|malware|yara|sigma|ioc|沙箱|勒索|rat\b|c2"],
    principles=[
        "先分诊再深潜",
        "静态解释动态，动态裁决冲突",
        "规则要可回归",
        "IOC 分网络/主机/行为/静态",
        "反分析要列入画像",
    ],
    phases=[
        _p("M1", "初步分诊", ["类型/哈希/粗 IOC"], ["file/strings/壳识别"], ["malware_analysis", "ops_triage"]),
        _p("M2", "静态", ["导入/节/入口/资源"], ["反编译重点路径"], ["reverse_engineering", "re_surface"]),
        _p("M3", "动态/沙箱", ["行为时间线"], ["进程/文件/注册表/网络/注入"], ["malware_analysis"]),
        _p("M4", "YARA", ["可测规则"], ["串+hex+条件"], ["malware_analysis"]),
        _p("M5", "Sigma/行为", ["检测逻辑"], ["日志源与 selection"], ["ops_case"]),
        _p("M6", "IOC/情报", ["分类 IOC 包"], ["MITRE 映射", "时效标注"], ["ops_journal", "ops_case"]),
    ],
    defense=["YARA/Sigma 落地", "网络出口控制", "应用白名单", "备份防勒索"],
    sentinel_tools=["malware_analysis", "reverse_engineering", "re_surface", "ops_triage"],
)

_pack(
    id="supply6",
    title="供应链六层",
    family="cloud",
    cues=[r"供应链|sbom|sca|依赖投毒|ci/?cd|lockfile|镜像层|构建完整性"],
    principles=["清单先于扫描", "可达性 > 仅 CVE 堆砌", "构建与发布签名", "运行时漂移单独看"],
    phases=[
        _p("S1", "资产清单", ["组件列表"], ["语言生态/镜像"], ["sentinel_scan"]),
        _p("S2", "SBOM", ["SBOM 产物"], ["生成与差分"], ["sentinel_pack"]),
        _p("S3", "SCA 漏洞", ["可利用子集"], ["严重度+可达"], ["sentinel_scan"]),
        _p("S4", "构建管道", ["CI 密钥/权限问题"], ["workflow 审计"], ["sentinel_scan"]),
        _p("S5", "发布完整性", ["签名/哈希链"], ["产物比对"], ["ops_case"]),
        _p("S6", "运行时", ["漂移检测"], ["镜像/配置 vs 发布"], ["pentest_recon"]),
    ],
    defense=["钉版本", "私有源", "签名强制", "最小 CI 权限", "持续 SCA"],
    sentinel_tools=["sentinel_scan", "sentinel_pack", "ops_case"],
)

_pack(
    id="patch5",
    title="补丁差分/符号迁移五阶",
    family="reverse",
    cues=[r"补丁差分|bindiff|符号迁移|n-?day|缺.?pdb|跨版本|patch.?tuesday"],
    principles=[
        "可靠锚点优先（导出/字符串）",
        "一次比对一个函数",
        "结构化输出再批量应用",
        "关键符号人工抽检",
        "迭代：已迁移函数变新锚点",
    ],
    phases=[
        _p("D1", "准备双版本", ["旧/新二进制与符号状态"], ["加载两侧", "记录版本"], ["reverse_engineering"]),
        _p("D2", "选锚点", ["锚点函数表"], ["导出/字符串/常量"], ["reverse_engineering"]),
        _p("D3", "导出成对材料", ["反汇编+伪代码对"], ["按函数导出"], ["reverse_engineering"]),
        _p("D4", "结构化匹配", ["映射表 call/vcall/gv/offset"], ["LLM 或手工表", "禁止整包丢模型"], ["ops_algo", "ops_journal"]),
        _p("D5", "应用与迭代", ["新版命名覆盖率"], ["批量 rename/comment", "扩展锚点"], ["ops_case"]),
    ],
    defense=["补丁及时", "符号服务器内控", "变更审计"],
    sentinel_tools=["reverse_engineering", "ops_algo", "ops_case"],
)

_pack(
    id="mobile5",
    title="移动端五阶",
    family="mobile",
    cues=[r"apk|ipa|frida|ssl.?pin|objection|smali|jadx|越狱|root.?detect"],
    principles=["manifest 先于 hook", "pinning 与 root 检测分开绕", "native bridge 单独记", "流量与存储证据"],
    phases=[
        _p("MO1", "清单/入口", ["组件与权限"], ["manifest/Info.plist"], ["reverse_engineering"]),
        _p("MO2", "静态", ["关键类/字符串/so"], ["jadx/反编译"], ["reverse_engineering", "re_surface"]),
        _p("MO3", "动态插桩", ["hook 证据"], ["Frida/Objection 面"], ["malware_analysis"]),
        _p("MO4", "信任边界", ["pinning/root/签名校验结果"], ["证书钉扎", "完整性"], ["web_pentest", "reverse_engineering"]),
        _p("MO5", "网络与复测", ["API 面与加固建议"], ["抓包", "服务端权威"], ["web_pentest", "ops_case"]),
    ],
    defense=["证书钉扎+服务端校验", "根检测多层", "代码混淆非唯一防线"],
    sentinel_tools=["reverse_engineering", "re_surface", "web_pentest", "malware_analysis"],
)

_pack(
    id="loop6",
    title="渗透自动化闭环",
    family="special",
    cues=[r"渗透闭环|自动化扫描|持续监控|bug.?bounty|asm\b|攻击面管理"],
    principles=["范围门禁", "发现→验证→报告→学习", "无验证不升级严重度", "工具结果需人工抽样"],
    phases=[
        _p("O1", "Scope", ["书面/任务范围"], ["in/out 列表"], ["ops_ctf_runner"]),
        _p("O2", "Recon", ["资产图"], ["recon 脚本"], ["pentest_recon", "ops_tool_index"]),
        _p("O3", "Exploit/验证", ["可复现原语"], ["窄探测"], ["web_pentest", "ctf_toolkit"]),
        _p("O4", "Evidence", ["流量+副作用"], ["按证据纪律打包"], ["ops_report_contract"]),
        _p("O5", "Report", ["结构化报告"], ["结论+复现+防御"], ["ops_case"]),
        _p("O6", "Learn", ["journal 条目"], ["回写表面/字典"], ["ops_journal"]),
    ],
    defense=["持续暴露面缩减", "变更触发复测"],
    sentinel_tools=["pentest_recon", "web_pentest", "ops_case", "ops_journal"],
)

_pack(
    id="gap4",
    title="控制缺口狩猎",
    family="web",
    cues=[r"控制缺口|鉴权漂移|预期控制|enforce|bypass.?control|业务越权"],
    principles=[
        "先列应有控制再测实际 enforce",
        "文档/UI 显示 ≠ 服务端 enforce",
        "缺口=应拦未拦 + 可复现",
    ],
    phases=[
        _p("G1", "控制清单", ["应有控制表"], ["认证/授权/校验/限速/审计"], ["ops_surface_matrix"]),
        _p("G2", "预期路径", ["设计上的 enforce 点"], ["读配置/网关/中间件声明"], ["sentinel_scan"]),
        _p("G3", "观察路径", ["实际请求结果矩阵"], ["双角色/绕路径实测"], ["web_pentest"]),
        _p("G4", "差分证明", ["缺口条目+流量"], ["预期 vs 观察", "副作用"], ["ops_report_contract", "ops_case"]),
    ],
    defense=["统一中间件 enforce", "默认拒绝", "审计日志"],
    sentinel_tools=["web_pentest", "sentinel_scan", "ops_case"],
)

_pack(
    id="evidence3",
    title="黑盒证据三原则",
    family="special",
    cues=[r"证据|复现|误报|幻觉|写报告|src.?提交"],
    principles=[
        "结论=可复现流量 + 可观察副作用",
        "差分证明（良性 vs 恶意）",
        "拒绝响应特征/延时/回显幻觉",
    ],
    phases=[
        _p("V1", "流量原貌", ["可粘贴请求"], ["方法/头/体完整", "敏感头脱敏"], ["ops_anon", "ops_report_contract"]),
        _p("V2", "差分证明", ["对照实验"], ["只改一个变量", "状态/时序记录"], ["ops_ctf_runner"]),
        _p("V3", "副作用", ["权威态变化"], ["DB/文件/权限/flag"], ["ops_case"]),
    ],
    defense=["审核级证据模板", "禁止猜测 CVE"],
    sentinel_tools=["ops_report_contract", "ops_anon", "ops_case"],
)


# --- Full-coverage extra packs (Sentinel domain expansion) ---
_pack(
    id="ad8",
    title="AD/身份攻击路径八阶",
    family="identity",
    cues=[r"域渗透|adcs|kerberoast|rbcd|委派|lsass|dpapi|证书模板|relay|ntlm"],
    principles=["边有效才前进", "票证可用性优先于理论路径", "证书/委托单独验证接受条件", "演练清理必做"],
    phases=[
        _p("AD1", "域情收集", ["用户/SPN/信任概览"], ["LDAP/枚举面"], ["pentest_recon"]),
        _p("AD2", "Kerberoast/ASREP", ["可烤账户列表"], ["SPN/无预认证"], ["pentest_recon", "ops_pattern_db"]),
        _p("AD3", "本地提权/凭据", ["可用哈希/票"], ["LSASS/DPAPI 链（授权环境）"], ["malware_analysis", "ops_pattern_db"]),
        _p("AD4", "横向", ["第二主机会话"], ["PtH/PtT/WinRM/SMB"], ["attack_network", "ops_chain"]),
        _p("AD5", "委托/RBCD", ["配置差与利用条件"], ["GenericWrite→RBCD"], ["ops_pattern_db"]),
        _p("AD6", "ADCS", ["危险模板/注册权"], ["ESC 类路径检查表"], ["ops_pattern_db", "ops_surface_matrix"]),
        _p("AD7", "强制认证/中继", ["coercion→relay 接受"], ["监听与目标选择"], ["attack_network"]),
        _p("AD8", "目标+清理", ["演练目标达成记录"], ["回滚测试账号/规则"], ["ops_case", "ops_journal"]),
    ],
    defense=["LAPS", "受保护用户", "模板加固", "SMB 签名", "委派审计"],
    sentinel_tools=["pentest_recon", "attack_network", "ops_pattern_db", "ops_chain", "ops_case"],
)

_pack(
    id="browse5",
    title="浏览器/桌面自动化五阶",
    family="web",
    cues=[r"浏览器自动化|playwright|截图|填表|桌面.?uia|headless|爬取页面"],
    principles=["先稳定选择器", "网络观察与 UI 同步", "密钥不进脚本明文", "失败可回放"],
    phases=[
        _p("B1", "目标页面", ["URL/登录态"], ["导航与就绪条件"], ["web_pentest"]),
        _p("B2", "网络观察", ["关键 XHR 列表"], ["与 UI 动作对齐"], ["web_pentest", "ops_ctf_runner"]),
        _p("B3", "交互脚本", ["可重复步骤"], ["点击/填表/等待"], ["ops_journal"]),
        _p("B4", "证据捕获", ["截图/HAR 指针"], ["脱敏后归档"], ["ops_anon", "ops_case"]),
        _p("B5", "桌面扩展", ["窗口/控件路径"], ["UIA 级说明（实验室）"], ["ops_journal"]),
    ],
    defense=["自动化账号隔离", "MFA", "异常登录检测"],
    sentinel_tools=["web_pentest", "ops_ctf_runner", "ops_anon"],
)

_pack(
    id="ida4",
    title="静态反编译四阶（IDA/Ghidra 面）",
    family="reverse",
    cues=[r"ida|ghidra|反编译|交叉引用|伪代码|静态分析深度"],
    principles=["先入口与导入", "xref 驱动", "命名迭代", "动静态对照"],
    phases=[
        _p("I1", "加载与分诊", ["架构/入口/导入"], ["文件头+导入表"], ["reverse_engineering", "ops_triage"]),
        _p("I2", "定位", ["关键函数列表"], ["字符串/导入 xref"], ["reverse_engineering", "re_surface"]),
        _p("I3", "恢复", ["命名/类型/注释"], ["伪代码迭代"], ["reverse_engineering", "ops_algo"]),
        _p("I4", "验证", ["动态或样本对照"], ["断点/日志验证假设"], ["malware_analysis", "ops_case"]),
    ],
    defense=["符号内控", "补丁差分监控"],
    sentinel_tools=["reverse_engineering", "re_surface", "ops_triage", "malware_analysis"],
)

_pack(
    id="r24",
    title="radare2/CLI 侦察四阶",
    family="reverse",
    cues=[r"radare2|\br2\b|rabin2|rasm2|cli.?逆向"],
    principles=["命令可复现", "先 info/导入/串", "脚本化输出"],
    phases=[
        _p("R1", "info", ["格式/架构/保护"], ["iI / checksec 等价"], ["reverse_engineering", "ctf_toolkit"]),
        _p("R2", "symbols/strings", ["串与导入"], ["iz/ii"], ["reverse_engineering", "re_surface"]),
        _p("R3", "seek/analyze", ["函数边界"], ["aaa/s 入口"], ["reverse_engineering"]),
        _p("R4", "emit", ["可分享笔记"], ["命令日志归档"], ["ops_journal", "ops_case"]),
    ],
    defense=["同静态加固视角"],
    sentinel_tools=["reverse_engineering", "ctf_toolkit", "re_surface"],
)

_pack(
    id="k8s5",
    title="K8s/容器五阶",
    family="cloud",
    cues=[r"k8s|kubernetes|rbac|service.?account|容器逃逸|privileged|cgroup|docker.?sock"],
    principles=["清单 vs 运行时", "SA 最小权限", "逃逸先证前置条件", "元数据与挂载"],
    phases=[
        _p("K1", "清单", ["部署/SA/Role"], ["yaml 审计"], ["sentinel_scan"]),
        _p("K2", "运行时", ["挂载/能力/特权"], ["与清单差分"], ["pentest_recon"]),
        _p("K3", "API 面", ["可调 API"], ["RBAC 实测"], ["web_pentest", "pentest_recon"]),
        _p("K4", "逃逸前置", ["条件清单"], ["sock/挂载/内核 CVE 面"], ["ctf_toolkit", "ops_pattern_db"]),
        _p("K5", "加固", ["策略建议"], ["PSS/NetworkPolicy"], ["ops_case"]),
    ],
    defense=["PSS restricted", "只读根", "无特权", "SA 令牌自动挂载关闭"],
    sentinel_tools=["sentinel_scan", "pentest_recon", "ops_case"],
)

_pack(
    id="re6",
    title="通用逆向六阶",
    family="reverse",
    cues=[r"通用逆向|反汇编|协议还原|语言识别|平台.?mach-?o|elf.?分析"],
    principles=["格式→导入→串→控制流→算法→验证", "语言/平台特化加载 pattern_db"],
    phases=[
        _p("RE1", "格式", ["PE/ELF/Mach-O/DEX"], ["magic/节"], ["reverse_engineering", "ops_triage"]),
        _p("RE2", "语言/平台", ["Go/Rust/.NET/…"], ["pattern_db search"], ["ops_pattern_db"]),
        _p("RE3", "导入与串", ["IOC/API 画像"], ["re_surface"], ["re_surface", "malware_analysis"]),
        _p("RE4", "控制流", ["关键路径"], ["静态+可选动态"], ["reverse_engineering"]),
        _p("RE5", "算法/协议", ["变换链"], ["ops_algo/ctf"], ["ops_algo", "ctf_toolkit"]),
        _p("RE6", "交付", ["报告+防御"], ["case/journal"], ["ops_case", "ops_report_contract"]),
    ],
    defense=["完整性校验", "反篡改", "符号最小化对外"],
    sentinel_tools=["reverse_engineering", "ops_pattern_db", "re_surface", "ops_algo"],
)

_pack(
    id="src5",
    title="SRC/众测五纪律",
    family="web",
    cues=[r"src|众测|bug.?bounty|挖洞|timebox|绕过工具箱"],
    principles=["范围门禁", "攻击优先级", "证据纪律", "控制缺口", "时间盒"],
    phases=[
        _p("SRC1", "范围", ["in/out 资产"], ["书面 scope"], ["ops_ctf_runner"]),
        _p("SRC2", "优先级", ["高价值面排序"], ["authz/上传/回调优先"], ["ops_surface_matrix"]),
        _p("SRC3", "绕过工具箱", ["已试变形记录"], ["编码/方法/路径变体，有节流"], ["web_pentest"]),
        _p("SRC4", "证据", ["流量+副作用"], ["report validate"], ["ops_report_contract", "evidence3"]),
        _p("SRC5", "时间盒", ["本轮结论"], ["到时归档与 next pivot"], ["ops_journal", "ops_case"]),
    ],
    defense=["响应计划", "赏金范围资产盘点"],
    sentinel_tools=["web_pentest", "ops_surface_matrix", "ops_report_contract", "ops_journal"],
)

_pack(
    id="game7",
    title="客户端安全研究七阶",
    family="special",
    cues=[r"游戏安全|trainer|自瞄|esp|il2cpp|反作弊研究|dma|驱动读写"],
    principles=["服务端权威优先", "可行性分级", "实验室授权", "攻防双写"],
    phases=[
        _p("G1", "分级", ["tier 1-5"], ["game_research_brief"], ["attack_game"]),
        _p("G2", "模块/结构", ["关键对象线索"], ["PE/il2cpp/字符串"], ["reverse_engineering", "re_surface"]),
        _p("G3", "内存模型", ["读写面说明"], ["实验室 scanner 原理"], ["attack_game"]),
        _p("G4", "输入/渲染", ["可信边界"], ["本地 vs 服务器字段"], ["attack_game", "ops_framing"]),
        _p("G5", "协议", ["封包字段"], ["重放面"], ["ops_protocol_lab", "re_surface"]),
        _p("G6", "检测特征", ["AC 可观测点"], ["蓝队清单"], ["malware_analysis", "ops_case"]),
        _p("G7", "加固", ["服务端权威方案"], ["校验/反作弊建议"], ["ops_case"]),
    ],
    defense=["关键数值服务器算", "完整性", "异常输入检测"],
    sentinel_tools=["attack_game", "reverse_engineering", "re_surface", "ops_framing"],
)

_pack(
    id="diagram3",
    title="攻击图/报告图三阶",
    family="special",
    cues=[r"画图|mermaid|攻击路径图|架构图|时序图"],
    principles=["先结论结构", "图服务证据", "可嵌入报告"],
    phases=[
        _p("DG1", "选图类型", ["路径/时序/架构"], ["匹配任务"], ["ops_report_contract"]),
        _p("DG2", "节点边", ["资产与动作"], ["与 findings 对齐"], ["ops_case"]),
        _p("DG3", "嵌入交付", ["报告章节"], ["markdown 图"], ["ops_case", "ops_journal"]),
    ],
    defense=["图中脱敏"],
    sentinel_tools=["ops_report_contract", "ops_case", "ops_anon"],
)

_pack(
    id="docs3",
    title="安全文档三阶",
    family="special",
    cues=[r"写报告|writeup|渗透报告|逆向报告"],
    principles=["模板驱动", "证据门禁", "脱敏"],
    phases=[
        _p("DO1", "选模板", ["security/ctf/reverse/api"], ["report template"], ["ops_report_contract"]),
        _p("DO2", "填发现", ["每条 validate"], ["finding schema"], ["ops_report_contract"]),
        _p("DO3", "脱敏发布", ["对外文本"], ["ops_anon"], ["ops_anon", "ops_journal"]),
    ],
    defense=["报告含修复优先级"],
    sentinel_tools=["ops_report_contract", "ops_anon", "ops_case"],
)

_pack(
    id="escape5",
    title="容器/内核逃逸前置五阶",
    family="cloud",
    cues=[r"容器逃逸|kernel.?escape|privileged|docker\.sock|cap_sys_admin|ns.?escape"],
    principles=["先证明前置", "再谈利用", "内核版本对齐", "演练隔离"],
    phases=[
        _p("ES1", "环境指纹", ["运行时/内核/能力"], ["id/cap/mount"], ["pentest_recon"]),
        _p("ES2", "危险挂载", ["sock/proc/sys"], ["清单"], ["sentinel_scan"]),
        _p("ES3", "权限面", ["特权/SYS_ADMIN"], ["与基线比"], ["pentest_recon"]),
        _p("ES4", "利用条件", ["是否满足"], ["缺条件则停并报告"], ["ctf_toolkit", "ops_report_contract"]),
        _p("ES5", "加固验证", ["修复后复测"], ["策略生效"], ["ops_case"]),
    ],
    defense=["无特权", "只读", "seccomp", "用户命名空间"],
    sentinel_tools=["pentest_recon", "sentinel_scan", "ops_case"],
)

_pack(
    id="mailbox4",
    title="邮箱/委托滥用四阶",
    family="identity",
    cues=[r"mailbox|邮箱规则|转发规则|oauth.?consent|委托邮箱"],
    principles=["规则与令牌并查", "同意钓鱼面", "清理持久化"],
    phases=[
        _p("MB1", "枚举", ["规则/委托"], ["邮箱审计面"], ["pentest_recon"]),
        _p("MB2", "令牌", ["OAuth 同意"], ["应用权限"], ["web_pentest"]),
        _p("MB3", "影响", ["外传路径"], ["演练证明"], ["ops_case"]),
        _p("MB4", "清除+加固", ["规则删除", "条件访问"], ["ops_case"]),
    ],
    defense=["同意治理", "外发 DLP", "规则告警"],
    sentinel_tools=["pentest_recon", "web_pentest", "ops_case"],
)

_pack(
    id="kernel_drv4",
    title="内核/驱动逆向四阶",
    family="reverse",
    cues=[r"驱动逆向|ioctl|rootkit|lkm|内核模块|deviceiocontrol"],
    principles=["IOCTL 表优先", "用户态触发路径", "权限边界"],
    phases=[
        _p("KD1", "加载信息", ["驱动类型/入口"], ["PE/ELF 模块"], ["reverse_engineering"]),
        _p("KD2", "分发例程", ["MajorFunction/IOCTL"], ["码表"], ["reverse_engineering"]),
        _p("KD3", "危险原语", ["任意读写/溢出面"], ["输入验证"], ["ctf_toolkit", "ops_algo"]),
        _p("KD4", "利用/加固", ["PoC 或修复"], ["访问控制"], ["ops_case"]),
    ],
    defense=["签名强制", "HVCI", "最小暴露设备接口"],
    sentinel_tools=["reverse_engineering", "ctf_toolkit", "ops_case"],
)

# Anti-analysis quick map (condensed original labels)
ANTI_ANALYSIS: list[dict[str, str]] = [
    {"id": "vm", "detect": "BIOS/磁盘/CPU 特征", "note": "环境指纹"},
    {"id": "sandbox", "detect": "低配资源/用户交互缺失", "note": "延迟执行"},
    {"id": "debugger", "detect": "PEB/IsDebuggerPresent/NtQuery", "note": "反调试"},
    {"id": "timing", "detect": "长 Sleep/RDTSC", "note": "定时逃逸"},
    {"id": "geo", "detect": "键盘布局/时区", "note": "区域过滤"},
    {"id": "parent", "detect": "父进程名", "note": "启动链"},
    {"id": "syscall", "detect": "直调/间接 syscall", "note": "绕用户态 hook"},
]


def list_packs(family: Optional[str] = None) -> list[dict[str, Any]]:
    out = []
    for p in PACKS.values():
        if family and p.family != family:
            continue
        out.append({
            "id": p.id,
            "title": p.title,
            "family": p.family,
            "phases": len(p.phases),
            "principles": p.principles[:3],
        })
    return sorted(out, key=lambda x: x["id"])


def get_pack(pid: str) -> Optional[dict[str, Any]]:
    p = PACKS.get(pid)
    return p.to_dict() if p else None


def score_packs(query: str) -> list[tuple[str, float]]:
    scores: dict[str, float] = {k: 0.0 for k in PACKS}
    for pid, pack in PACKS.items():
        for cue in pack.cues:
            if re.search(cue, query, re.I):
                scores[pid] += 2.0
    ranked = sorted(((k, v) for k, v in scores.items() if v > 0), key=lambda x: -x[1])
    return ranked


def route_pack(query: str, top_k: int = 3) -> dict[str, Any]:
    ranked = score_packs(query)
    top = []
    for pid, sc in ranked[:top_k]:
        p = PACKS[pid]
        top.append({
            "id": pid,
            "title": p.title,
            "score": sc,
            "first_phase": p.phases[0].to_dict() if p.phases else None,
            "principles": p.principles,
            "sentinel_tools": p.sentinel_tools,
        })
    return {
        "protocol": "sentinel-method-packs-v1",
        "query": query,
        "top": top,
        "catalog_size": len(PACKS),
        "hint": "命中后用 pack / next 推进阶段；证据不足按 fail_rewind 回退",
    }


def next_phase(pack_id: str, done: list[str]) -> dict[str, Any]:
    p = PACKS.get(pack_id)
    if not p:
        return {"error": "unknown pack", "id": pack_id}
    done_set = {d.strip().upper() for d in done}
    for ph in p.phases:
        if ph.id.upper() not in done_set and ph.id not in done_set:
            return {
                "pack": pack_id,
                "next": ph.to_dict(),
                "remaining": [x.id for x in p.phases if x.id.upper() not in done_set],
                "defense": p.defense,
            }
    return {"pack": pack_id, "next": None, "status": "complete", "defense": p.defense}


def pack_commands(pack_id: str) -> list[str]:
    p = PACKS.get(pack_id)
    if not p:
        return []
    cmds = [f'python scripts/ops_method_packs.py pack {pack_id}']
    for t in p.sentinel_tools:
        if t.startswith("ops_") or t in ("sentinel_scan", "sentinel_pack", "web_pentest",
                                         "pentest_recon", "ctf_toolkit", "malware_analysis",
                                         "reverse_engineering", "re_surface"):
            cmds.append(f"python scripts/{t}.py --help")
    return cmds


def anti_analysis_table() -> list[dict[str, str]]:
    return list(ANTI_ANALYSIS)


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Sentinel deep method packs")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("list", help="List packs")
    g = sub.add_parser("pack", help="Show full pack")
    g.add_argument("id")
    r = sub.add_parser("route", help="Route query to packs")
    r.add_argument("query", nargs="+")
    n = sub.add_parser("next", help="Next phase")
    n.add_argument("id")
    n.add_argument("--done", default="")
    sub.add_parser("anti", help="Anti-analysis quick map")

    args = ap.parse_args(argv)
    if args.cmd == "list":
        print(json.dumps(list_packs(), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "pack":
        data = get_pack(args.id)
        if not data:
            print(json.dumps({"error": "unknown", "id": args.id}, ensure_ascii=False))
            return 1
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "route":
        print(json.dumps(route_pack(" ".join(args.query)), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "next":
        done = [x for x in args.done.split(",") if x.strip()]
        print(json.dumps(next_phase(args.id, done), ensure_ascii=False, indent=2))
        return 0
    if args.cmd == "anti":
        print(json.dumps(anti_analysis_table(), ensure_ascii=False, indent=2))
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
