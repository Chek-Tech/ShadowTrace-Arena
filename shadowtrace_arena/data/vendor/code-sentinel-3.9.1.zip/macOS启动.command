#!/usr/bin/env bash
# Code Sentinel macOS 一键启动（注入 Codex）
set -e
cd "$(dirname "$0")"
echo "================================================"
echo "  Code Sentinel · macOS 一键启动（注入 Codex）"
echo "  触发词：豆包大人"
echo "================================================"
python3 "Windows启动.py" "$@"
echo ""
read -r -p "按 Enter 关闭…"
