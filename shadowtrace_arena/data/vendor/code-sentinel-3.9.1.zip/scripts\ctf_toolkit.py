#!/usr/bin/env python3
"""
CTF all-category toolkit. Covers: rev, pwn, crypto, web, misc, forensics,
steganography, OSINT. Auto-detection, solver strategies, encoding cascade,
flag format guessing, common exploit skeletons.
Pure stdlib, zero dependencies.
"""
from __future__ import annotations
import base64, codecs, hashlib, itertools, math, re, string, struct, sys
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

# ── Flag format patterns ────────────────────────────────────────────
FLAG_PATTERNS: dict[str, str] = {
    "flag{...}": r"flag\{[^\}]+\}",
    "CTF{...}": r"CTF\{[^\}]+\}",
    "ctf{...}": r"ctf\{[^\}]+\}",
    "HTB{...}": r"HTB\{[^\}]+\}",
    "picoCTF{...}": r"picoCTF\{[^\}]+\}",
    "FLAG{...}": r"FLAG\{[^\}]+\}",
    "CCTF{...}": r"CCTF\{[^\}]+\}",
    "HackTheBoo{...}": r"HackTheBoo\{[^\}]+\}",
    "shellmates{...}": r"shellmates\{[^\}]+\}",
    "hspace{...}": r"hspace\{[^\}]+\}",
    "inctf{...}": r"inctf\{[^\}]+\}",
    "Securinets{...}": r"Securinets\{[^\}]+\}",
    "ASCIS{...}": r"ASCIS\{[^\}]+\}",
    "VSL{...}": r"VSL\{[^\}]+\}",
    "utflag{...}": r"utflag\{[^\}]+\}",
}

# ── Encoding signature database ─────────────────────────────────────
ENCODING_SIGS: list[tuple[str, str, Callable]] = [
    ("Base64", r"^[A-Za-z0-9+/]+=*$", lambda s: base64.b64decode(s).decode("latin-1")),
    ("Base32", r"^[A-Z2-7]+=*$", lambda s: base64.b32decode(s).decode("latin-1")),
    ("Base16/Hex", r"^[0-9A-Fa-f]+$", lambda s: bytes.fromhex(s).decode("latin-1")),
    ("Base85", r"^[A-Za-z0-9!#$%&()*+,-./:;<=>?@[\]^_`{|}~]+$", lambda s: base64.b85decode(s).decode("latin-1")),
    ("ROT13", None, lambda s: codecs.decode(s, "rot_13")),
    ("URL Encoding", r"%[0-9A-Fa-f]{2}", lambda s: __import__("urllib.parse").unquote(s)),
    ("Binary", r"^[01\s]+$", lambda s: "".join(chr(int(b,2)) for b in s.split())),
    ("Octal", r"^[0-7\s]+$", lambda s: "".join(chr(int(o,8)) for o in s.split())),
    ("Morse Code", r"^[.\-/\s]+$", None),
    ("XOR single-byte", None, None),
]

# ── Challenge type detection ────────────────────────────────────────
CHALLENGE_SIGS: dict[str, list[str]] = {
    "rev": [r"\.exe$", r"\.elf$", r"\.bin$", r"crackme", r"keygen", r"license",
            r"\.apk$", r"\.dex$", r"\.so$", r"\.dylib$", r"\.dll$", r"\.sys$",
            r"reverse", r"reversing", r"serial", r"patch"],
    "pwn": [r"nc\s+\S+\s+\d+", r"\.c$", r"buffer overflow", r"rop", r"shellcode",
            r"format string", r"heap", r"use after free", r"bof", r"ret2",
            r"pwntools", r"got overwrite", r"plt"],
    "crypto": [r"rsa", r"aes", r"des", r"ecc", r"elliptic", r"cipher",
               r"encrypt", r"decrypt", r"oracle", r"padding", r"cbc", r"ecb",
               r"diffie.hellman", r"dhke", r"discrete.log", r"factor"],
    "web": [r"http", r"\.php", r"\.asp", r"\.jsp", r"xss", r"sqli", r"csrf",
            r"ssti", r"ssrf", r"lfi", r"rfi", r"idor", r"cookie", r"session",
            r"jwt", r"graphql", r"\.html?", r"nginx", r"apache"],
    "misc": [r"forensic", r"stegano|pcap", r"\.pcap", r"\.pcapng", r"wireshark",
             r"memory dump", r"\.raw$", r"\.img$", r"\.vmem", r"volatility"],
    "blockchain": [r"solidity", r"\.sol$", r"ethereum", r"smart.contract",
                   r"reentrancy", r"flash.loan", r"uniswap", r"web3"],
}

# ── Classical cipher database ────────────────────────────────────────
CIPHER_FINGERPRINTS: list[tuple[str, str, Optional[str]]] = [
    ("Caesar/ROT-N", r"^[A-Za-z]+$", "alphabet-only, try all 25 shifts"),
    ("Vigenere", r"^[A-Za-z]{20,}$", "check IC, Kasiski if long enough"),
    ("Substitution", r"^[A-Za-z\s]{20,}$", "frequency analysis vs English"),
    ("XOR single-byte", r"^[0-9a-fA-F]+$", "brute-force 0x00-0xFF"),
    ("XOR repeating-key", r"^[0-9a-fA-F]{40,}$", "Hamming distance for keysize"),
    ("Rail Fence", r"^[A-Za-z]{10,}$", "try rail counts 2-10"),
    ("Base family", r"^[A-Za-z0-9+/=_-]+$", "try Base64→32→85→58→62"),
    ("Atbash", r"^[A-Za-z]+$", "alphabet-reversed mapping"),
    ("Affine", r"^[A-Za-z]{10,}$", "brute (a,b) with gcd(a,26)=1"),
    ("Bifid/Polybius", r"^[0-9\s]{10,}$", "check digit-only with spaces"),
    ("ADFGVX/ADFGX", r"^[ADFGVXadfgvx\s]+$", "WWI German cipher"),
]

# ── Common CTF crypto parameters ─────────────────────────────────────
RSA_COMMON: list[dict] = [
    {"n": 0x00b51faafc60, "e": 65537, "label": "small-n-factored-by-msieve"},
    {"n": 0xcfcf5eeccfcf, "e": 65537, "label": "fermat-factorable"},
]

def detect_challenge_type(filepath: Optional[str], description: str = "") -> list[str]:
    """Return likely CTF categories ranked by confidence."""
    scores: dict[str, int] = {cat: 0 for cat in CHALLENGE_SIGS}
    text = description.lower()
    if filepath:
        text += " " + Path(filepath).name.lower()
        ext = Path(filepath).suffix.lower()
        ext_map = {".exe": "rev", ".elf": "rev", ".bin": "rev", ".apk": "rev",
                   ".dex": "rev", ".pcap": "misc", ".pcapng": "misc",
                   ".py": "crypto", ".c": "pwn", ".cpp": "pwn",
                   ".html": "web", ".php": "web", ".sol": "blockchain"}
        if ext in ext_map:
            scores[ext_map[ext]] += 3
    for cat, patterns in CHALLENGE_SIGS.items():
        for pat in patterns:
            if re.search(pat, text, re.IGNORECASE):
                scores[cat] += 1
    ranked = sorted(scores.items(), key=lambda x: -x[1])
    return [cat for cat, score in ranked if score > 0] or ["rev"]

def detect_encoding(data: str) -> list[dict]:
    """Cascade through encoding detection. Returns list of {name, decoded}."""
    results = []
    current = data.strip()
    for _ in range(8):  # max cascade depth
        found = False
        for name, pattern, decoder in ENCODING_SIGS:
            if pattern and not re.match(pattern, current):
                continue
            try:
                decoded = decoder(current) if decoder else None
                if decoded and len(decoded) > 0:
                    current = decoded
                    results.append({"name": name, "decoded": decoded[:200]})
                    found = True
                    break
            except Exception:
                continue
        if not found:
            break
    return results

def solve_xor_single_byte(hex_data: str) -> list[dict]:
    """Brute-force single-byte XOR, return top-5 by printable ratio."""
    try:
        raw = bytes.fromhex(hex_data.replace(" ", ""))
    except ValueError:
        return []
    results = []
    for key in range(256):
        dec = bytes(b ^ key for b in raw)
        printable = sum(1 for c in dec if 32 <= c < 127 or c in (9, 10, 13))
        ratio = printable / len(dec) if dec else 0
        if ratio > 0.85:
            results.append({"key": hex(key), "key_int": key, "ratio": round(ratio, 3),
                          "text": dec.decode("latin-1")[:200]})
    return sorted(results, key=lambda x: -x["ratio"])[:5]

def flag_search(text: str) -> list[str]:
    """Search for CTF flag patterns in any text."""
    found = []
    for name, pattern in FLAG_PATTERNS.items():
        for match in re.finditer(pattern, text):
            found.append(match.group(0))
    return found

def recommend_solver(challenge_type: str, details: str = "") -> str:
    """Return recommended approach for a CTF challenge type."""
    strategies = {
        "rev": "1. Run `file`/Detect-It-Easy on binary\n"
               "2. Check entropy for packing; if packed, identify packer\n"
               "3. Open in Ghidra/IDA → find main/entry → trace to serial check\n"
               "4. For keygens: replicate algorithm from disassembly\n"
               "5. For patches: NOP the jump at the failure branch\n"
               "6. Strings → look for success/failure messages near check",
        "pwn": "1. `checksec` → identify mitigations (ASLR/NX/PIE/canary)\n"
               "2. Identify vulnerable function (gets/read/scanf)\n"
               "3. Calculate offset to return address (pattern create/offset)\n"
               "4. Find gadgets (ROPgadget/ropper) or one_gadget\n"
               "5. Leak libc if ASLR → ret2plt → ret2libc\n"
               "6. For heap: analyze malloc/free pattern; check UAF/double-free",
        "crypto": "1. Identify algorithm from challenge description\n"
                  "2. RSA: check n for known factors (factordb), small e (Hastad),\n"
                  "   close p/q (Fermat), common modulus, Wiener (small d)\n"
                  "3. AES: check mode (ECB→byte-at-a-time, CBC→padding oracle)\n"
                  "4. Classical: frequency analysis, Kasiski, IC for key length\n"
                  "5. Always check: is the cipher just base64/hex of the flag?",
        "web": "1. Map all endpoints, parameters, HTTP methods\n"
               "2. Check for: SQLi (', \", --, union), XSS (<script>), SSTI ({{}})\n"
               "3. Test file inclusion: ../../../etc/passwd, php://filter\n"
               "4. JWT: try none algorithm, weak HMAC secret (rockyou)\n"
               "5. SSRF: try http://127.0.0.1, file://, gopher://\n"
               "6. Check source: /robots.txt, /.git/, /backup, view-source",
        "misc": "1. Forensics: volatility for mem dumps, foremost for carving\n"
                "2. Stego: steghide, zsteg, binwalk, strings, exiftool\n"
                "3. PCAP: Wireshark → follow TCP streams, extract objects\n"
                "4. Always try: strings, binwalk -e, foremost, file signature check",
    }
    return strategies.get(challenge_type, strategies["rev"])

# ── PWN exploit skeleton generator ──────────────────────────────────
def gen_exploit_skeleton(challenge_type: str, arch: str = "amd64",
                         host: str = "127.0.0.1", port: int = 1337) -> str:
    """Generate pwntools exploit skeleton."""
    if challenge_type != "pwn":
        return f"# Not a pwn challenge (detected: {challenge_type})"
    skeleton = f'''#!/usr/bin/env python3
from pwn import *
context.arch = "{arch}"
context.log_level = "debug"
# p = process("./chall")
p = remote("{host}", {port})
# ── Stage 1: Leak / BOF ──
offset = 0  # TODO: pattern create/offset
# ── Stage 2: Gadgets / ROP ──
pop_rdi = 0x0  # TODO
ret = 0x0
# ── Stage 3: Payload ──
payload = b"A" * offset
# payload += p64(pop_rdi) + p64(binsh) + p64(ret) + p64(system)
p.sendline(payload)
p.interactive()
'''
    return skeleton

# ── Crypto solver: classical ciphers ─────────────────────────────────
def crack_classical(ciphertext: str) -> list[dict]:
    """Attempt common classical cipher breaks."""
    results = []
    ct = ciphertext.strip()
    # Caesar
    for shift in range(1, 26):
        plain = "".join(
            chr((ord(c) - 65 - shift) % 26 + 65) if c.isupper() else
            chr((ord(c) - 97 - shift) % 26 + 97) if c.islower() else c
            for c in ct
        )
        words = len(re.findall(r'\b[a-zA-Z]{2,}\b', plain))
        if words > len(ct.split()) * 0.5:
            results.append({"cipher": f"Caesar(shift={shift})", "plaintext": plain[:200]})
    # ROT13
    rot = codecs.decode(ct, "rot_13")
    if rot != ct:
        results.append({"cipher": "ROT13", "plaintext": rot[:200]})
    # Atbash
    atb = ct.translate(str.maketrans(
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
        "ZYXWVUTSRQPONMLKJIHGFEDCBAzyxwvutsrqponmlkjihgfedcba"))
    if atb != ct:
        results.append({"cipher": "Atbash", "plaintext": atb[:200]})
    return results

# ── Simple RSA attack co-processor ───────────────────────────────────
def rsa_attack(n: int, e: int, c: Optional[int] = None) -> list[str]:
    """Run common RSA attacks and return results."""
    hints = []
    # Small n factorization via trial division (up to 1M)
    for p in range(2, min(1000000, int(math.isqrt(n)) + 1)):
        if n % p == 0:
            q = n // p
            phi = (p - 1) * (q - 1)
            d = pow(e, -1, phi)
            plain = pow(c, d, n) if c is not None else None
            hints.append(f"Factored: p={p}, q={q}, d={d}")
            if plain is not None:
                hints.append(f"Decrypted: {plain.to_bytes((plain.bit_length()+7)//8,'big')}")
            break
    else:
        hints.append("No small factor found. Try factordb.com or yafu.")
    # Wiener attack check (small d)
    if e > n:
        hints.append("e > n: possible small d (Wiener attack)")
    # Small e check
    if e == 3 and c:
        m, exact = _integer_nth_root(c, 3)
        if exact:
            hints.append(f"e=3, cube root gives: {m.to_bytes((m.bit_length()+7)//8,'big')}")
    return hints

def _integer_nth_root(x: int, n: int) -> tuple[int, bool]:
    lo, hi = 0, 1 << ((x.bit_length() + n - 1) // n)
    while lo < hi:
        mid = (lo + hi) // 2
        if pow(mid, n) < x:
            lo = mid + 1
        else:
            hi = mid
    return lo, pow(lo, n) == x

# ── Quick triage entrypoint ─────────────────────────────────────────
def triage_ctf(path_or_text: str, is_file: bool = True) -> dict:
    """One-shot CTF challenge triage: detect type, encoding, flag search."""
    if is_file:
        p = Path(path_or_text)
        text = p.read_text(errors="replace") if p.suffix not in ('.exe','.bin','.elf','.apk','.dex') else ""
        result = {"file": str(p), "size": p.stat().st_size, "ext": p.suffix}
    else:
        text = path_or_text
        result = {"raw_length": len(text)}
    result["challenge_type"] = detect_challenge_type(str(p) if is_file else None, text[:500] if text else "")
    result["flags_found"] = flag_search(text) if text else []
    result["encoding_cascade"] = detect_encoding(text[:2000]) if text else []
    result["classical_ciphers"] = crack_classical(text[:500]) if text else []
    result["solver_strategy"] = recommend_solver(result["challenge_type"][0] if result["challenge_type"] else "rev")
    return result

if __name__ == "__main__":
    if len(sys.argv) > 1:
        r = triage_ctf(sys.argv[1])
        for k, v in r.items():
            print(f"{k}: {v}")
    else:
        print("Usage: python ctf_toolkit.py <file|text>")
