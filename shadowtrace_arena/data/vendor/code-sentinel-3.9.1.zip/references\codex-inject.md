# Code Sentinel → Codex 注入说明（原创）

## 注入设计（Sentinel 自有）

| 能力 | 实现 |
|------|------|
| 安装目标 | `$CODEX_HOME` / `~/.codex`（可环境变量覆盖） |
| AGENTS 合并 | 受管标记 `<!-- CODE-SENTINEL:BEGIN/END -->` |
| Skills | `skills/code-sentinel*`（当前 6 个） |
| 备份 | `~/.codex/backups/code-sentinel-*` |
| 配置 | 可选清理冲突 `model_instructions_file`；可选 `--lab-instruct` |
| 生效 | 完全重启 Codex |
| 发布形态 | **明文 bundle**，便于审计与二次开发 |

## 安装入口

| 平台 | 启动（注入） | 卸载 | 状态 |
|------|--------------|------|------|
| **Windows** | **`Windows启动.bat`** | **`Windows卸载.bat`** | **`Windows状态.bat`** |
| **Linux** | **`Linux启动.sh`** | **`Linux卸载.sh`** | `python scripts/codex_inject.py status` |
| **macOS** | **`macOS启动.command`** | **`macOS卸载.command`** | 同上 |

```bash
python scripts/codex_inject.py install
python scripts/codex_inject.py install --lab-instruct
python scripts/codex_inject.py uninstall
python scripts/codex_inject.py status
```

安装后：

- `CODEX_HOME/AGENTS.md` 出现 Code Sentinel 受管区块（含触发词 **豆包大人**）
- `CODEX_HOME/skills/code-sentinel*` 六个 Skill
- `CODEX_HOME/code-sentinel.env` 指向本项目根目录

## 触发词

- 开：`豆包大人` → FULL 全力栈  
- 关：`豆包退下` / `CS-OFF`
