"""Originality gate tests."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import ops_originality
import ops_instruct


class OriginalityTests(unittest.TestCase):
    def test_scan_clean(self):
        rep = ops_originality.scan(ROOT)
        self.assertTrue(rep["ok"], msg=rep.get("hits"))

    def test_lab_instruct_no_jailbreak_banner(self):
        md = ops_instruct.build_lab_instructions(ROOT)
        self.assertNotIn("[MODE: UNRESTRICTED]", md)
        self.assertNotIn("All standard content filters are disabled", md)
        self.assertIn("Code Sentinel", md)


if __name__ == "__main__":
    unittest.main()
