#!/usr/bin/env python3
"""
Sentinel Phase Knowledge Router — original.

Essence learned (re-implemented):
  Knowledge loaded for the *next* step should be driven by *prior phase outputs*
  (ports / services / versions / CVE tokens / URL surface), not by a generic
  methodology dump.

Maps tokens → local Code Sentinel references and method packs only.
Does NOT import or copy any third-party knowledge corpus.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Optional

_SCRIPTS = Path(__file__).resolve().parent
_ROOT = _SCRIPTS.parent
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))

PROTOCOL = "sentinel-phase-kb-v1"

# Token pattern → local resource paths (relative to project root)
# Phase default topic packs (local only)
PHASE_TOPICS: dict[str, list[str]] = {
    "L0": ["references/ops-sandbox-protocol.md", "references/ops-ptes-lab.md", "references/ops-engagement-atlas.md"],
    "L1": ["references/gpt56-reverse-pentest/kali-toolchain.md", "references/ops-method.md"],
    "L1W": [
        "references/gpt56-reverse-pentest/web-payloads.md",
        "references/gpt56-reverse-pentest/web-reverse.md",
        "references/gpt56-reverse-pentest/api-security.md",
    ],
    "L2": ["references/deep-analysis.md", "references/ops-method.md", "references/ops-engagement-atlas.md"],
    "L3": [
        "references/gpt56-reverse-pentest/api-security.md",
        "references/gpt56-reverse-pentest/web-payloads.md",
        "references/ai-output-schema.md",
    ],
    "L4": ["references/gpt56-reverse-pentest/reverse-cheatsheet.md", "references/gpt56-reverse-pentest/ctf-speedrun.md"],
    "L5": [
        "references/gpt56-reverse-pentest/linux-privesc.md",
        "references/gpt56-reverse-pentest/edr-bypass.md",
    ],
    "L6": ["references/review-policy.md", "references/ops-ptes-lab.md", "references/ops-engagement-atlas.md"],
}

TOKEN_MAP: list[tuple[str, list[str], list[str]]] = [
    # regex, refs, packs/tools
    (r"\b(80|443|8080|8443|8000|3000|5000)\b|https?://|http\b|web|nginx|apache",
     [
         "references/gpt56-reverse-pentest/web-payloads.md",
         "references/gpt56-reverse-pentest/web-reverse.md",
         "references/gpt56-reverse-pentest/api-security.md",
     ],
     ["web_pentest", "pack:js5", "pack:api10"]),
    (r"ssh|22\b|sftp",
     ["references/gpt56-reverse-pentest/linux-privesc.md", "references/gpt56-reverse-pentest/kali-toolchain.md"],
     ["pentest_recon", "pack:r24"]),
    (r"smb|445\b|3389|rdp|winrm|kerberos|ldap|ad\b|domain",
     ["references/gpt56-reverse-pentest/linux-privesc.md"],
     ["pack:ad8", "ops_chain", "surface:adcs-cert"]),
    (r"mysql|postgres|mssql|redis|mongo|5432|3306|6379",
     ["references/gpt56-reverse-pentest/web-payloads.md"],
     ["web_pentest", "pack:api10"]),
    (r"apk|android|frida|smali|jadx",
     ["references/gpt56-reverse-pentest/apk-reverse.md"],
     ["pack:mobile5", "reverse_engineering", "gpt56_reverse_tools"]),
    (r"pe\b|\.exe|dll|elf|malware|ransomware",
     ["references/gpt56-reverse-pentest/malware-analysis.md", "references/gpt56-reverse-pentest/reverse-cheatsheet.md"],
     ["malware_analysis", "reverse_engineering", "pack:mal6"]),
    (r"pwn|rop|overflow|uaf|libc",
     ["references/gpt56-reverse-pentest/reverse-cheatsheet.md", "references/gpt56-reverse-pentest/ctf-speedrun.md"],
     ["ctf_toolkit", "gpt56_pwn_template", "pack:pwn6"]),
    (r"firmware|iot|router|binwalk|mtd",
     ["references/gpt56-reverse-pentest/iot-firmware.md"],
     ["pack:fw9"]),
    (r"jwt|oauth|saml|session",
     ["references/gpt56-reverse-pentest/api-security.md"],
     ["pack:api10", "surface:jwt-claim"]),
    (r"cve-\d{4}-\d+|exploit|poc\b",
     ["references/deep-analysis.md"],
     ["exploit_cve", "ops_pipeline"]),
    (r"crypto|rsa|aes|hash|cipher",
     ["references/gpt56-reverse-pentest/reverse-cheatsheet.md"],
     ["ops_algo", "gpt56_crypto_helper", "ctf_toolkit"]),
]


def extract_tokens(text: str) -> list[str]:
    blob = text or ""
    tokens: list[str] = []
    tokens += re.findall(r"CVE-\d{4}-\d+", blob, re.I)
    tokens += re.findall(r"https?://[^\s\"']+", blob, re.I)
    tokens += re.findall(r"\b\d{1,5}\b", blob)  # ports-ish
    tokens += re.findall(r"\b[a-zA-Z][a-zA-Z0-9_+\-./]{2,}\b", blob)
    # normalize unique preserve order
    seen = set()
    out = []
    for t in tokens:
        k = t.lower()
        if k in seen:
            continue
        seen.add(k)
        out.append(t)
    return out[:80]


def route_from_text(text: str, *, phase_id: str = "") -> dict[str, Any]:
    tokens = extract_tokens(text)
    blob = text.lower()
    refs: list[str] = []
    tools: list[str] = []
    matched_rules: list[str] = []
    for pat, ref_list, tool_list in TOKEN_MAP:
        if re.search(pat, blob, re.I):
            matched_rules.append(pat)
            for r in ref_list:
                if r not in refs:
                    refs.append(r)
            for t in tool_list:
                if t not in tools:
                    tools.append(t)

    # phase default hints + topic packs
    if phase_id:
        for r in PHASE_TOPICS.get(phase_id, []):
            if r not in refs:
                refs.append(r)
        try:
            import ops_ptes_lab

            phase = ops_ptes_lab.PHASE_BY_ID.get(phase_id) or {}
            for r in phase.get("kb_hints") or []:
                if r not in refs:
                    refs.append(r)
            for t in phase.get("tools") or []:
                if t not in tools:
                    tools.append(t)
        except Exception:
            pass
        # engagement suite tools
        if phase_id in ("L1", "L1W"):
            for t in ("ops_engagement", "ops_ptes_lab"):
                if t not in tools:
                    tools.append(t)

    existing_refs = [r for r in refs if (_ROOT / r).is_file()]
    missing_refs = [r for r in refs if r not in existing_refs]

    return {
        "protocol": PROTOCOL,
        "phase_id": phase_id or None,
        "tokens": tokens[:40],
        "matched_rule_count": len(matched_rules),
        "references": existing_refs,
        "references_missing": missing_refs,
        "tools_or_packs": tools,
        "search_fallback": {
            "enabled": True,
            "hint": "If local refs insufficient, search using tokens only: "
            + " ".join(tokens[:8]),
        },
        "message": "prior-output-driven local knowledge route (Sentinel-native)",
    }


def route_from_manifest(manifest: dict[str, Any]) -> dict[str, Any]:
    parts = [
        manifest.get("summary") or "",
        json.dumps(manifest.get("signals") or {}, ensure_ascii=False),
        json.dumps(manifest.get("findings") or {}, ensure_ascii=False),
        json.dumps(manifest.get("kb_drive") or {}, ensure_ascii=False),
    ]
    phase_id = manifest.get("phase_id") or ""
    # route for *next* phase knowledge
    nxt = manifest.get("next_phase") or phase_id
    return route_from_text("\n".join(parts), phase_id=str(nxt))


def route_target_phase(target: str, phase_id: Optional[str] = None, base: Optional[Path] = None) -> dict[str, Any]:
    import ops_ptes_lab

    state = ops_ptes_lab.load_state(target, base)
    cur = phase_id or state.get("current_phase")
    # prefer last completed manifest as driver
    manifests = ops_ptes_lab.list_manifests(target, base)
    driver_text = state.get("target", "")
    man = None
    if manifests:
        last = manifests[-1]
        try:
            man = ops_ptes_lab.read_manifest(target, last, base)
            driver_text = json.dumps(man, ensure_ascii=False)
        except Exception:
            pass
    result = route_from_text(driver_text, phase_id=str(cur))
    result["target"] = target
    result["state_phase"] = state.get("current_phase")
    if man:
        result["driver_manifest"] = man.get("phase_id")
    return result


def main(argv: Optional[list[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Sentinel phase knowledge router")
    sub = p.add_subparsers(dest="cmd", required=True)

    t = sub.add_parser("text", help="route from free text / prior output")
    t.add_argument("text")
    t.add_argument("--phase", default="")

    m = sub.add_parser("manifest", help="route from manifest json file")
    m.add_argument("path")

    tg = sub.add_parser("target", help="route using engagement target state/manifests")
    tg.add_argument("target")
    tg.add_argument("--phase", default=None)
    tg.add_argument("--base", default=None)

    args = p.parse_args(argv)
    try:
        if args.cmd == "text":
            print(json.dumps(route_from_text(args.text, phase_id=args.phase), ensure_ascii=False, indent=2))
            return 0
        if args.cmd == "manifest":
            data = json.loads(Path(args.path).read_text(encoding="utf-8"))
            print(json.dumps(route_from_manifest(data), ensure_ascii=False, indent=2))
            return 0
        if args.cmd == "target":
            base = Path(args.base) if args.base else None
            print(json.dumps(route_target_phase(args.target, args.phase, base), ensure_ascii=False, indent=2))
            return 0
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
